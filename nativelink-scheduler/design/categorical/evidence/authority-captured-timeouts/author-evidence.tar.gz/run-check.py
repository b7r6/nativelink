import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys
root=pathlib.Path('/tmp/nativelink-authority-captured-timeouts')
out=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-captured-timeouts')
label=sys.argv[1];command=sys.argv[2:]
env=dict(os.environ,CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target',CARGO_INCREMENTAL='0')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(label+'.log')).open('w') as log:
 result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'returncode':result.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print('\n'.join((out/(label+'.log')).read_text().splitlines()[-35:]))
raise SystemExit(result.returncode)
