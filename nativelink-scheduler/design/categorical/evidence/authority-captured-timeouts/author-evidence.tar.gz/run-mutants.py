import hashlib,json,os,pathlib,shutil,subprocess,sys,time
root=pathlib.Path('/tmp/nativelink-authority-captured-timeouts');out=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-captured-timeouts');target=pathlib.Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target/smol/deps')
request='nativelink-scheduler/src/authority/request.rs';server='nativelink-service/src/authority_server.rs'
mutants=[
 ('zero-as-omitted',request,'    Ok(\n        (u64::try_from(duration.seconds)','    if duration.seconds == 0 && duration.nanos == 0 { return Ok(u64::MAX); }\n    Ok(\n        (u64::try_from(duration.seconds)','scheduler'),
 ('omitted-as-zero',request,'return Ok(u64::MAX);','return Ok(1);','scheduler'),
 ('maximum-fraction-lost',request,'u64::from(duration.nanos != 0)','u64::from(duration.nanos != 0 && duration.seconds < MAX_PROTO_SECONDS)','scheduler'),
 ('unchecked-timeout-projection',request,'            || self.execution_timeout != expected.execution_timeout\n','','scheduler'),
 ('inclusive-driver-expiry',server,'attempt.running_deadline.is_some_and(|at| at < now)','attempt.running_deadline.is_some_and(|at| at <= now)','service'),
]
env=dict(os.environ,CARGO_TARGET_DIR=str(target.parent.parent),CARGO_INCREMENTAL='0')
receipts=[]
for name,path,before,after,kind in mutants:
 source=root/path;original=source.read_bytes();text=original.decode();assert text.count(before)==1,(name,text.count(before))
 source.write_text(text.replace(before,after,1));saved=out/'mutants'/name;saved.mkdir(parents=True,exist_ok=False);(saved/'source.rs').write_bytes(source.read_bytes())
 if kind=='scheduler': args=['-p','nativelink-scheduler','--test','authority_request_test','captured_timeout_boundaries_survive_restore_and_reject_changed_projection'];prefix='authority_request_test-'
 else: args=['-p','nativelink-service','--lib','captured_durations_keep_driver_boundary_and_request_bytes_on_reopen'];prefix='nativelink_service-'
 command=['cargo','test','--locked','--offline','--profile','smol','-j4',*args,'--','--nocapture','--test-threads=1']
 try:
  with (saved/'run.log').open('w') as log: r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(saved/'run.log').read_text();assert r.returncode!=0,(name,'mutant survived');assert 'panicked at' in output and 'test result: FAILED' in output,(name,'not a test assertion failure')
  binary=max((p for p in target.glob(prefix+'*') if p.is_file() and os.access(p,os.X_OK) and p.suffix==''),key=lambda p:p.stat().st_mtime_ns)
  shutil.copy2(binary,saved/'test-binary')
  receipts.append({'name':name,'command':command,'returncode':r.returncode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((saved/'test-binary').read_bytes()).hexdigest(),'oracle':'compiled selected test panicked; test result FAILED'})
  print(name,'DETECTED',flush=True)
 finally:
  source.write_bytes(original);assert source.read_bytes()==original
 (out/'mutants.json').write_text(json.dumps(receipts,indent=2)+'\n')
