from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
root=Path.cwd();out=Path('/tmp/nativelink-temporal-terminal-root-integration/fixture-corrected-strict');out.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
names=[n for n in subprocess.check_output(['git','ls-files','-z'],text=True).split('\0') if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]
def freeze():return {n:hashlib.sha256(os.readlink(root/n).encode()).hexdigest() if (root/n).is_symlink() else sha(root/n) for n in names}
before=freeze();write('sources-before.json',before);(out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True));shutil.copy2(__file__,out/'run.py')
for n in names:
 if n.endswith('.rs'):os.utime(root/n,None)
command=['/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo','clippy','-p','nativelink-service','--all-targets','--locked','--offline','--profile','smol','-j4','--message-format=json','--','-D','warnings'];write('command.json',command)
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/'target');env['CARGO_INCREMENTAL']='0';start=time.monotonic()
with (out/'compile.log').open('w') as log:code=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
after=freeze();write('sources-after.json',after);assert before==after
result={'exit_code':code,'elapsed_seconds':time.monotonic()-start,'unchanged_inputs':len(before),'log_sha256':sha(out/'compile.log')};write('result.json',result);print(json.dumps(result),flush=True);raise SystemExit(code)
