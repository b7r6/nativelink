from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('stage')
parser.add_argument('--filter', default='bytestream_identity::completion::')
parser.add_argument('--uncached', action='store_true')
args = parser.parse_args()
root = Path.cwd()
out = Path('/tmp/nativelink-temporal-terminal-root-integration') / args.stage
out.mkdir(exist_ok=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


names = [name for name in subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0')
         if name and not name.startswith('nativelink-scheduler/design/categorical/evidence/')]


def snapshot():
    return {name: hashlib.sha256(os.readlink(root / name).encode()).hexdigest()
            if (root / name).is_symlink() else sha(root / name) for name in names}


before = snapshot()
write('sources-before.json', before)
(out / 'head.txt').write_text(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True))
(out / 'status.txt').write_text(subprocess.check_output(['git', 'status', '--porcelain'], text=True))
label = '//nativelink-service:integration_tests/authority_listener_test_test'
path = label[2:].replace(':', '/')
command = ['bazel', 'test', '--jobs=4', '--local_test_jobs=1', '--test_env=RUST_TEST_THREADS=1',
           '--test_arg=' + args.filter, '--test_output=errors', '--keep_going',
           '--build_event_json_file=' + str(out / 'events.jsonl'), label]
if args.uncached:
    command.insert(2, '--nocache_test_results')
write('command.json', command)
start = time.monotonic()
with (out / 'build-and-test.log').open('w') as log:
    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
elapsed = time.monotonic() - start
after = snapshot()
write('sources-after.json', after)
assert before == after
summaries = []
counts = []
for line in (out / 'events.jsonl').read_text().splitlines():
    row = json.loads(line)
    if 'testSummary' not in row:
        continue
    assert row['id']['testSummary']['label'] == label
    summary = row['testSummary']
    summaries.append({'label': label, 'status': summary['overallStatus'], 'runs': summary['totalRunCount'],
                      'cached': summary.get('totalNumCached', 0), 'duration': summary['totalRunDuration']})
    shutil.copy2(root / 'bazel-testlogs' / path / 'test.log', out / 'test.log')
    shutil.copy2(root / 'bazel-bin' / path, out / 'test-binary')
    counts = [list(map(int, match)) for match in re.findall(
        r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;.*? (\d+) filtered out;',
        (out / 'test.log').read_text())]
write('summaries.json', summaries)
result = {'exit_code': code, 'elapsed_seconds': elapsed, 'targets': len(summaries),
          'rust_counts_from_logs': counts, 'source_inputs_unchanged': len(before),
          'binary_sha256': sha(out / 'test-binary') if (out / 'test-binary').exists() else None}
write('result.json', result)
print(json.dumps(result), flush=True)
raise SystemExit(code)
