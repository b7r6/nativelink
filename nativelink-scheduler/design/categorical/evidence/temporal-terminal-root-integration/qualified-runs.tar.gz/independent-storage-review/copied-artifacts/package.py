from pathlib import Path
import hashlib,json,shutil,tarfile
src=Path('/tmp/nativelink-temporal-terminal-root-integration')
dst=Path('nativelink-scheduler/design/categorical/evidence/temporal-terminal-root-integration');dst.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
assert load(src/'result.json')['rust_counts_from_logs']==[421,0,2]
assert load(src/'result.json')['executed']==12
assert load(src/'fixture-corrected-listener/result.json')['rust_counts_from_logs']==[[45,0,1,0]]
assert load(src/'fixture-corrected-strict/result.json')['exit_code']==0
for directory in [src,src/'fixture-corrected-listener',src/'fixture-corrected-strict']:assert load(directory/'sources-before.json')==load(directory/'sources-after.json')
before=load(src/'sources-before.json');after=load(src/'fixture-corrected-listener/sources-before.json');changed={n:{'original':h,'corrected':after[n]} for n,h in before.items() if after[n]!=h}
fixture='nativelink-service/tests/authority_listener/bytestream_identity/completion.rs';assert set(changed)=={fixture}
q=src/'corrected-source'/fixture;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(fixture,q)
for source,name in [('/tmp/nativelink-temporal-root-hooks.log','temporal-root-hooks.log'),('/tmp/nativelink-terminal-fixture-strict-hooks.log','fixture-initial-hooks.log'),('/tmp/nativelink-terminal-fixture-strict-hooks-formatted.log','fixture-formatted-hooks.log'),('/tmp/run-terminal-corrected-root.py','run-corrected-listener.py'),(__file__,'package.py')]:shutil.copy2(source,src/name)
binaries=[p for p in (src/'binaries').rglob('*') if p.is_file()]+[src/'fixture-corrected-listener/test-binary']
archives=[]
for p in sorted(binaries):
 rel=str(p.relative_to(src));name='executable-'+rel.replace('/','-')+'.tar.gz';archive=dst/name
 with tarfile.open(archive,'w:gz',compresslevel=6) as f:f.add(p,arcname=rel,recursive=False)
 assert archive.stat().st_size<45*1024*1024
 with tarfile.open(archive,'r:gz') as f:
  members=f.getmembers();assert len(members)==1 and members[0].isfile();assert hashlib.file_digest(f.extractfile(members[0]),'sha256').hexdigest()==sha(p)
 archives.append({'path':name,'bytes':archive.stat().st_size,'sha256':sha(archive),'member':{'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}})
 print('Verified',rel,flush=True)
(src/'executable-archives.json').write_text(json.dumps(archives,indent=2)+'\n')
(src/'fixture-source-delta.json').write_text(json.dumps(changed,indent=2)+'\n')
print('Binaries complete; metadata packaging awaits independent root review.',flush=True)
