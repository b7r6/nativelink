from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--author-manifest', required=True)
args = parser.parse_args()
root = Path.cwd()
out = Path('/tmp/nativelink-temporal-terminal-root-integration')
out.mkdir(exist_ok=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
assert not status.strip(), status
assert os.environ.get('NL_FIXED_DIGEST_CASE') is None
names = [name for name in subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0')
         if name and not name.startswith('nativelink-scheduler/design/categorical/evidence/')]


def snapshot():
    return {name: hashlib.sha256(os.readlink(root / name).encode()).hexdigest()
            if (root / name).is_symlink() else sha(root / name) for name in names}


before = snapshot()
write('sources-before.json', before)
(out / 'head.txt').write_text(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True))
(out / 'status.txt').write_text(status)
selected = set()
for group, manifest, allowed in [
    ('temporal', Path(args.author_manifest), {'nativelink-scheduler/BUILD.bazel'}),
    ('terminal', Path('/tmp/nativelink-bytestream-terminal-update-evidence/runtime-candidate.json'), set()),
]:
    shutil.copy2(manifest, out / (group + '-source.json'))
    author = json.loads(manifest.read_text())['files']
    same = {name: value for name, value in author.items() if before[name] == value}
    different = {name: {'author': value, 'root': before[name]}
                 for name, value in author.items() if before[name] != value}
    assert set(different) <= allowed, different
    write(group + '-source-comparison.json', {'manifest_sha256': sha(manifest), 'exact': same, 'different': different})
    selected.update(author)
for name in selected:
    dest = out / 'root-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, dest)
# Check all frozen tracked inputs against actual committed blobs, including symlink targets.
head = (out / 'head.txt').read_text().strip()
proc = subprocess.Popen(['git', 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for name, value in before.items():
    proc.stdin.write((head + ':' + name + '\n').encode()); proc.stdin.flush()
    header = proc.stdout.readline().split()
    assert len(header) == 3 and header[1] == b'blob', header
    data = proc.stdout.read(int(header[2])); assert proc.stdout.read(1) == b'\n'
    assert hashlib.sha256(data).hexdigest() == value, name
proc.stdin.close(); assert proc.wait() == 0
write('git-source-verification.json', {'commit': head, 'inputs': len(before), 'all_match': True})
shutil.copy2(Path(__file__), out / 'run.py')
targets = [
    '//nativelink-scheduler:unit_test',
    '//nativelink-scheduler:canonical_owner_api_test',
    '//tools/canonical-filesystem:ownership_test',
    '//tools/canonical-filesystem:journal_test',
    '//tools/canonical-filesystem:journal_bridge_test',
    '//nativelink-service:unit_test',
    '//nativelink-service:integration_tests/authority_listener_test_test',
    '//nativelink-service:integration_tests/bytestream_server_test_test',
    '//nativelink-service:integration_tests/grpc_wire_compression_test_test',
    '//nativelink-service:integration_tests/wire_compression_test_test',
    '//tools/canonical-store:canonical_store_test',
    '//tools/canonical-store:fixed_digest_default_test',
]
command = ['bazel', 'test', '--jobs=4', '--local_test_jobs=1', '--test_env=RUST_TEST_THREADS=1',
           '--test_output=errors', '--nocache_test_results', '--keep_going', '--build_event_json_file=' + str(out / 'events.jsonl'),
           *targets, '//:nativelink']
write('command.json', command)
start = time.monotonic()
with (out / 'build-and-test.log').open('w') as log:
    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
after = snapshot()
write('sources-after.json', after)
assert before == after
summaries = []
counts = [0, 0, 0]
for line in (out / 'events.jsonl').read_text().splitlines():
    row = json.loads(line)
    if 'testSummary' not in row:
        continue
    label = row['id']['testSummary']['label']
    summary = row['testSummary']
    summaries.append({'label': label, 'status': summary['overallStatus'],
                      'runs': summary['totalRunCount'], 'cached': summary.get('totalNumCached', 0),
                      'duration': summary['totalRunDuration']})
    path = label[2:].replace(':', '/')
    dest = out / 'testlogs' / path / 'test.log'
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / 'bazel-testlogs' / path / 'test.log', dest)
    for result in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', dest.read_text()):
        counts = [a + int(b) for a, b in zip(counts, result)]
    binary = out / 'binaries' / path
    binary.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / 'bazel-bin' / path, binary)
write('summaries.json', summaries)
result = {'exit_code': code, 'elapsed_seconds': time.monotonic() - start,
          'targets': len(summaries), 'passed': sum(item['status'] == 'PASSED' for item in summaries),
          'executed': sum(item['cached'] == 0 for item in summaries),
          'rust_counts_from_logs': counts, 'source_inputs_unchanged': len(before)}
write('result.json', result)
print(json.dumps(result), flush=True)
raise SystemExit(code)
