import pathlib,hashlib,json,datetime
E=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-evidence'); P='nativelink-scheduler/src/authority/canonical_recovery.rs'; S=(E/'qualified-source'/P).read_text(); D=E/'planned-fault-sources';D.mkdir();rows=[]
def add(name,old,new,test,oracle):
 assert S.count(old)==1,(name,S.count(old))
 b=S.replace(old,new).encode();d=D/name/P;d.parent.mkdir(parents=True);d.write_bytes(b)
 rows.append({'name':name,'source':str(d.relative_to(E)),'sha256':hashlib.sha256(b).hexdigest(),'test':test,'expected_oracle':oracle,'removed':old,'inserted':new})
add('abort-supervisor-with-consumer','''        drop(self.stop.take());
    }
}

impl Control''','''        self.supervisor.abort();
        drop(self.stop.take());
    }
}

impl Control''','lifecycle_cancel_at_each_reached_startup_stage_retains_supervisor','After an actually reached startup gate and caller cancellation, all four namespace locks must remain held and the supervisor must still own the reached gate receiver; it must resume into cleanup after release. Classify exact observed failure, including a lost receiver, rather than calling an unreached prerequisite a semantic assertion.')
add('queued-offer-counts-as-accepted','''    tokio::select! {
        result = &mut accepted => result.map_err(|_| RecoveryError::Handoff)?,
        _ = &mut *stop => return Ok(()),
    }
''','''    drop(accepted);
''','lifecycle_abandoned_queued_offer_is_not_acceptance','After actual Offered marker while consumer remains paused before receiving, Accepted must still be absent; direct assertion, not leader timeout.')
add('return-error-before-cleanup','''        // Even a startup failure cannot be returned before real cleanup.
        control.stop_and_join().await?;
        return Err(RecoveryError::Handoff);''','''        // Fault: return without joining supervised cleanup.
        return Err(RecoveryError::Handoff);''','lifecycle_startup_errors_and_panics_wait_for_real_final_drop','Actual final blocking-Drop gate must be reached and held; constructor completion in either Result state fails the direct pending assertion.')
old='''    canonical_cleanup::drain_database(
        resources.database,
        #[cfg(test)]
        canonical_cleanup::Hooks {
            before_drop: hooks.take_drop_gate(),
        },
    )
    .await
    .map_err(|_| RecoveryError::Task)?;'''
new='''    let detached = background_spawn!(
        "fault_detach_canonical_drop",
        canonical_cleanup::drain_database(
            resources.database,
            #[cfg(test)]
            canonical_cleanup::Hooks {
                before_drop: hooks.take_drop_gate(),
            },
        )
    );
    drop(detached);'''
add('ack-stop-before-drop',old,new,'lifecycle_cancelled_shutdown_waiter_does_not_abort_supervisor','Actual final blocking-Drop gate is reached and held; explicit shutdown must still be pending. Detached drain remains actually running so this tests acknowledgement timing.')
old='''                if metrics.state == ServerState::Shutdown
                    && matches!(metrics.running_state, Err(Fatal::Stopped))
                {
                    Ok(())
                } else {
                    Err(RecoveryError::Runtime)
                }'''
new='''                let _ignored_normal_core = metrics.state == ServerState::Shutdown
                    && matches!(metrics.running_state, Err(Fatal::Stopped));
                Ok(())'''
add('ignore-abnormal-core',old,new,'lifecycle_actual_core_panic_cannot_be_reported_as_normal_shutdown','After actual accepted core Fatal::Panicked is observed and private Raft clone dropped, shutdown must return Runtime after physical drain; isolated from startup errors.')
add('ignore-created-provenance','''    if diagnostic.phase != OwnerPhase::Sealed || journal.created {''','''    if diagnostic.phase != OwnerPhase::Sealed {''','lifecycle_created_flag_refuses_even_a_private_sealed_fixture','A genuinely reopened private Sealed journal whose original-created flag is privately set must refuse Phase before Raft; otherwise unwrap_err fails with an actual LifecycleOwner.')
R={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified_source_manifest_sha256':hashlib.sha256((E/'qualified-source.json').read_bytes()).hexdigest(),'qualified_runtime_sha256':hashlib.sha256(S.encode()).hexdigest(),'faults':rows,'status':'Six separately frozen planned source mutations. No fault source compiled/executed yet. Tests and other runtime sources remain exact qualified input. Compiler/prerequisite failures are not counted as semantic detection.'}
P=E/'planned-faults.json';P.write_text(json.dumps(R,indent=2)+'\n');print(hashlib.sha256(P.read_bytes()).hexdigest())
