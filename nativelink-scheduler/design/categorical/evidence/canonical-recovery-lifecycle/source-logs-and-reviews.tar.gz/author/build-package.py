import pathlib,json,hashlib,tarfile,gzip,io,shutil,datetime
E=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-evidence');W=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle');D=W/'nativelink-scheduler/design/categorical/evidence/canonical-recovery-lifecycle'
D.mkdir(parents=True,exist_ok=False)
roots={'author':E,'root-review':pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-independent-root-review'),'storage-review':pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-independent-storage-review'),'prior-design-review':pathlib.Path('/tmp/nativelink-canonical-recovery-independent-authority-review')}
def sha(b):return hashlib.sha256(b).hexdigest()
files=[];binary_groups={};aliases=[]
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  name=prefix+'/'+str(p.relative_to(root));b=p.read_bytes();entry={'path':name,'bytes':len(b),'sha256':sha(b)}
  if b[:4]==b'\x7fELF':
   binary_groups.setdefault(entry['sha256'],(p,len(b)));aliases.append(entry)
  else:files.append((p,entry))
archives=[]
def archive(name,kind,items):
 path=D/name;members=[]
 with path.open('wb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed:
   with tarfile.open(fileobj=compressed,mode='w') as output:
    for p,entry in items:
     b=p.read_bytes();assert sha(b)==entry['sha256'];assert len(b)==entry['bytes'];info=tarfile.TarInfo(entry['path']);info.size=len(b);info.mode=0o755 if kind=='executables' else 0o644;info.mtime=0;output.addfile(info,io.BytesIO(b));members.append(entry)
 assert path.stat().st_size<25_000_000,path
 archives.append({'path':name,'kind':kind,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':members})
archive('source-logs-and-reviews.tar.gz','source-logs-and-reviews',files)
unique=[(p,{'path':'binaries/'+digest,'bytes':size,'sha256':digest}) for digest,(p,size) in sorted(binary_groups.items())]
for number,start in enumerate(range(0,len(unique),3)):archive(f'executables-{number:03}.tar.gz','executables',unique[start:start+3])
shutil.copyfile(E/'verify-bundle.py',D/'verify-bundle.py')
labels=[('focused-first','original-runtime'),('focused-corrected','fixture-corrected'),('broad-premutation','fixture-corrected'),('strict-premutation','fixture-corrected'),('strict-corrected','qualified'),('qualified-broad','qualified'),('fault-abort-supervisor','abort-supervisor-with-consumer'),('fault-queued-offer','queued-offer-counts-as-accepted'),('fault-return-error','return-error-before-cleanup'),('fault-early-stop-ack','ack-stop-before-drop'),('fault-ignore-core','ignore-abnormal-core'),('fault-ignore-created','ignore-created-provenance'),('restored-broad','qualified'),('restored-strict','qualified')]
attempts=[{'receipt':'author/'+label+'.json','sha256':sha((E/(label+'.json')).read_bytes()),'log':'author/'+label+'.log','source_boundary':boundary} for label,boundary in labels]
M={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':'327d41eb37285192e0b249ac78fe5f6cacad9fdf','scope':'Private canonical recovery resource lifecycle only. No public recover method, recovered clock, read barrier, serving authority, cold initialization or seal writer.','verifier_sha256':sha((D/'verify-bundle.py').read_bytes()),'qualified_source_manifest_sha256':sha((E/'qualified-source.json').read_bytes()),'source_restoration_receipt_sha256':sha((E/'source-restoration.json').read_bytes()),'fault_results_sha256':sha((E/'fault-results.json').read_bytes()),'archives':archives,'distinct_executable_count':len(unique),'executable_alias_count':len(aliases),'executable_aliases':sorted(aliases,key=lambda r:r['path']),'attempts':attempts,'positive_results':'21 focused new lifecycle tests. Qualified and restored combined library184passed+1existingignore, external ownerAPI1passed. Corrected/restored strictalltargets exit0.','original_attempts':'Tests-first source frozen before implementation. First implementation compile E0382 fixture prerequisite only, zero tests/ELF. Corrected positives precede strict7diagnostics/4distinctlints. All original source/log boundaries retained; no claim original missing private API produced21semantic failures.','compiled_controls':'Six separately frozen source mutations, six distinct tested ELFs, six direct semantic detections; zero control compile/prerequisite failures. Each detection retains its exact first-failure boundary and does not claim unreached loop cases.','limits':['Early Raft::new storage failure proves final backend quiescence, not explicit tick join.','Normal core metrics qualify core outcome; pinned shutdown does not expose tick health.','Process/runtime destruction, unavailableexecutor and doublepanic do not acknowledge asynchronous cleanup.','Blocked I/O or independently held backend references can keep cleanup pending.','Successful release concerns canonical backend custody; external Ownership aliases can retain namespace locks.','Database Drop completion is not a new durability acknowledgement.']}
(D/'manifest.json').write_text(json.dumps(M,indent=2)+'\n')
(D/'README.md').write_text('''# Private canonical recovery lifecycle evidence

Source commit `327d41eb37285192e0b249ac78fe5f6cacad9fdf` adds a private supervised lifecycle. It exposes no public recovery method, recovered clock, read barrier, serving authority, cold initialization or seal writer.

The focused suite passes all 21 new tests. The qualified and restored combined runs pass 184 library tests and one external owner API test, with one existing ignored test. Strict checks pass on the corrected and restored source. All six compiled control mutations fail at their declared, reached assertions. The records identify the first failing case and preserve the limits of each observation.

The first implementation compile failed on a fixture ownership error and executed no tests. Its correction retains the intended external ownership alias. The initial strict attempt reported seven diagnostics from four distinct lints; the corrections preserve the resource and acknowledgement rules. These attempts, the original tests, every source boundary, raw logs, independent reviews and every retained test executable are included.

Run `python3 verify-bundle.py` from this directory to check the relative archive contents, all executable aliases, and all 14 Cargo attempt bindings. Add `--extract /path/to/output` to reconstruct the source, logs, reviews and executable paths. The verifier reads only this bundle and the selected extraction destination.

Actual final database destruction precedes completion. Early startup storage failure has no returned Raft handle and does not prove an explicit tick join. Blocked storage work can keep cleanup pending. External ownership aliases may retain namespace locks, and database destruction is not a new durability acknowledgement. Process or runtime destruction cannot acknowledge asynchronous cleanup.
''')
print(json.dumps({'directory':str(D),'manifest_sha256':sha((D/'manifest.json').read_bytes()),'archives':[{k:v for k,v in a.items() if k!='members'} for a in archives],'distinct_executables':len(unique),'retained_executable_aliases':len(aliases),'source_log_review_files':len(files)},indent=2))
