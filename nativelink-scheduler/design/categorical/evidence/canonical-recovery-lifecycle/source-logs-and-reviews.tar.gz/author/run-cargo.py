#!/usr/bin/env python3
import hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
root=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-evidence')
work=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle')
label=sys.argv[1]
argv=['/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo',*sys.argv[2:]]
env=os.environ.copy()
env['CARGO_TARGET_DIR']='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
env['CARGO_INCREMENTAL']='0'
paths=[row['path'] for row in json.loads((root/'runtime-source.json').read_text())['source_inputs']]
def inputs():
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
before=inputs()
directory=root/(label+'-source');directory.mkdir()
for p in paths:
 destination=directory/p;destination.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(work/p,destination)
log=root/(label+'.log')
assert not log.exists(), label
start=time.monotonic()
with log.open('w') as stream:
 run=subprocess.run(argv,cwd=work,env=env,text=True,stdout=stream,stderr=subprocess.STDOUT)
seconds=time.monotonic()-start
output=log.read_text();artifacts=[]
for line in output.splitlines():
 try:record=json.loads(line)
 except json.JSONDecodeError:continue
 if record.get('reason')=='compiler-artifact' and record.get('profile',{}).get('test') and record.get('executable'):
  artifacts.append(record)
after=inputs()
receipt={'source_before':before,'source_after':after,'source_unchanged':before==after,'source_directory':directory.name,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'worktree_status':subprocess.check_output(['git','status','--short'],cwd=work,text=True),'command':argv,'exit_code':run.returncode,'seconds':seconds,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'test_results':[line for line in output.splitlines() if line.startswith('test result:')],'compiler_errors':sum('"level":"error"' in line and 'compiler-message' in line for line in output.splitlines()),'artifacts':[]}
for entry in artifacts:
 binary=root/(label+'-'+entry['target']['name']+'-test-binary')
 shutil.copyfile(entry['executable'],binary);binary.chmod(0o755)
 receipt['artifacts'].append({'target':entry['target']['name'],'origin':entry['executable'],'copy':binary.name,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'bytes':binary.stat().st_size,'compiler_fresh':entry['fresh']})
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ['command','exit_code','seconds','source_unchanged','test_results','compiler_errors','artifacts']},indent=2),flush=True)
