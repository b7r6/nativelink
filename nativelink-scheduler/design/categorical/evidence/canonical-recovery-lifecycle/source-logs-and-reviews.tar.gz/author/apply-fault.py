import pathlib,json,hashlib,sys
E=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle-evidence');W=pathlib.Path('/tmp/nativelink-canonical-recovery-lifecycle');P='nativelink-scheduler/src/authority/canonical_recovery.rs'
for row in json.loads((E/'qualified-source.json').read_text())['source_inputs']:
 if row['path']!=P:assert hashlib.sha256((W/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
name=sys.argv[1];row=next(r for r in json.loads((E/'planned-faults.json').read_text())['faults'] if r['name']==name);b=(E/row['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];(W/P).write_bytes(b)
print(json.dumps({'fault':name,'sha256':row['sha256'],'test':row['test']}))
