use nativelink_canonical_config::parse_canonical;
use nativelink_canonical_filesystem::Ownership;
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let manifest = parse_canonical(&std::fs::read(&args[2]).unwrap()).unwrap();
    let result = match args[1].as_str() {
        "claim" => Ownership::claim_cold(&manifest),
        "reopen" => Ownership::reopen(&manifest),
        _ => panic!("unknown mode"),
    };
    match result {
        Ok(guard) => { println!("accepted"); drop(guard); }
        Err(error) => { println!("refused:{}", error.code); std::process::exit(2); }
    }
}
