# Independent canonical filesystem review

Reviewed author commit `a967496c59` without editing author files. The frozen source and exact SHA-256 map are under `source/` and `source-sha256.json`. The external harness links the frozen package, using the author-approved independent Cargo target `/tmp/nativelink-authority-namespace-target`; no shared root Cargo target was used.

## Findings

1. **Device/inode equality does not prove historical physical-directory continuity.** After a successful claim and guard drop, the experiment saved the CAS record, deleted the record and CAS directory, then recreated the directory. This filesystem allocated the same device/inode immediately. Restoring the saved record made `Ownership::reopen` accept. The README sentence claiming copying records onto replacement directories fails is unconditional and false under inode reuse. Limit the guarantee to current device/inode equality, explicitly exclude directory deletion/recreation, metadata restoration/cloning and inode reuse as provenance proofs, or add independently qualified persistent generation evidence before stronger runtime claims. This is not a live advisory-lock bypass or a new concurrent mutation guarantee: the original owner was stopped.

2. **Readable records do not prove a successful historical sync sequence.** Injecting EIO on fsync call 7 (last record) or 8 (last directory) made claim return `sync_record` / `sync_directory`, but all four exact records remained readable and reopen accepted. The README sentence saying a completed group proves the protocol completed therefore overstates the evidence. Reopen establishes current matching records only. A durable-startup guarantee would need an explicit recovery/sync protocol and qualification, but this current library grants no execution authority and promises no data/journal recovery, so documentation narrowing is sufficient for the present namespace-only scope.

## Meaningful fault cases

The external `run.py` executes 14 deterministic cases: one inode-reuse witness, all eight file/directory fsync sites with injected EIO, all four record writes with injected ENOSPC, and a FIFO record. Earlier sync failures and all write failures preserve evidence, refuse reopen, and refuse cold retry. Final sync failures produce the documented witness above. Every reopen left record bytes unchanged. FIFO rejection returns promptly rather than hanging. Exact outputs and syscall traces are retained.

These experiments do not simulate power loss, kernel crashes, bind-mount topology, hostile concurrent mutation, network filesystems, or restored journal/store data. They do not qualify runtime construction, worker admission, fencing, credential exclusion, or complete cutover. Within the declared static cooperative namespace scope, no further concrete implementation defect was found by this review.
