#!/usr/bin/env python3
import json,pathlib,tempfile,subprocess,os,shutil,time,hashlib
OUT=pathlib.Path(__file__).resolve().parent
BIN=pathlib.Path('/tmp/nativelink-authority-namespace-target/smol/canonical-filesystem-review')
REC='.nativelink-namespace-v1.json'
BASE=json.loads((OUT/'source/tools/canonical-config/fixtures/canonical.json').read_text())
results=[]
def fixture(name):
 p=pathlib.Path(tempfile.mkdtemp(prefix='nl-fs-review-'+name+'-'))
 m=json.loads(json.dumps(BASE))
 for role in ['journal','cas','sink','worker']:(p/role).mkdir()
 m['authority']['journal_root']=str(p/'journal');m['cas']['root']=str(p/'cas')
 m['temporary_action_cache']['root']=str(p/'sink');m['worker']['root']=str(p/'worker')
 (p/'manifest.json').write_text(json.dumps(m))
 return p,m
def run(p,mode,inject=None,label=None):
 cmd=[str(BIN),mode,str(p/'manifest.json')]
 if inject:
  cmd=['strace','-qq','-f','-o',str(OUT/(label+'.strace')),'-e','trace=fsync,write,openat,flock','-e','inject='+inject]+cmd
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
 return {'exit':r.returncode,'stdout':r.stdout.strip(),'stderr':r.stderr.strip(),'seconds':time.monotonic()-start}
def records(p):
 return {name: {'length':(p/name/REC).stat().st_size,'sha256':hashlib.sha256((p/name/REC).read_bytes()).hexdigest()} for name in ['journal','cas','sink','worker'] if (p/name/REC).is_file()}
# Recycled inode plus copied exact record accepts: distinct directory lifecycle.
p,m=fixture('inode')
claim=run(p,'claim');assert claim['stdout']=='accepted',claim
cas=p/'cas';old=cas.stat();saved=(cas/REC).read_bytes()
(cas/REC).unlink();cas.rmdir();reused=None
for attempt in range(1,10001):
 cas.mkdir();now=cas.stat()
 if (now.st_dev,now.st_ino)==(old.st_dev,old.st_ino):reused=attempt;break
 cas.rmdir()
if reused:
 (cas/REC).write_bytes(saved);reopen=run(p,'reopen');assert reopen['stdout']=='accepted',reopen
else:reopen=None
results.append({'case':'copied-record-after-inode-reuse','old_dev_inode':[old.st_dev,old.st_ino],'new_dev_inode':[now.st_dev,now.st_ino],'allocations':reused,'claim':claim,'reopen':reopen})
shutil.rmtree(p)
# Actual errors: no fake crash/power-loss claim.
for syscall,count,error in [('fsync',8,'EIO'),('write',4,'ENOSPC')]:
 for nth in range(1,count+1):
  label=f'{syscall}-error-{nth}';p,m=fixture(label)
  failed=run(p,'claim',f'{syscall}:error={error}:when={nth}',label)
  assert failed['exit']==2,failed
  before=records(p);reopen=run(p,'reopen');after=records(p);assert before==after
  cold=run(p,'claim');assert cold['stdout']=='refused:cold_root_not_empty'
  expected=('accepted' if syscall=='fsync' and nth>=7 else ('refused:invalid_record' if syscall=='write' else 'refused:open_record'))
  assert reopen['stdout']==expected,(label,reopen,expected)
  results.append({'case':label,'claim':failed,'visible_records':before,'reopen':reopen,'retry_cold':cold,'records_unchanged_after_reopen':before==after})
  shutil.rmtree(p)
# FIFO open must not block; bounded operation rejects a nonregular record.
p,m=fixture('fifo');assert run(p,'claim')['stdout']=='accepted'
(p/'cas'/REC).unlink();os.mkfifo(p/'cas'/REC)
r=run(p,'reopen');assert r['stdout']=='refused:invalid_record',r
results.append({'case':'fifo-record-refused-without-blocking','reopen':r});shutil.rmtree(p)
summary={'source_commit':'a967496c59','binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'results':results,'limits':['No power-loss or kernel-crash experiment','Local /tmp filesystem only','No runtime store/journal constructor consumes Ownership','Inode-reuse experiment deletes and recreates a stopped namespace directory, then explicitly copies its saved record; it is not a concurrent advisory-lock bypass.']}
(OUT/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'cases':len(results),'inode_reuse':results[0],'last_sync_failures':[r for r in results if r['case'] in ['fsync-error-7','fsync-error-8']]},indent=2))
