import pathlib,hashlib,json,re,subprocess,difflib,datetime
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
OLD=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-first')
D=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-addendum')
BASE='255fa9c0fb3d2abeb170aee9f7deff8f100b17ec'
TEST='tools/canonical-filesystem/src/worker_tests.rs'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,v):
 p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n');return sha(p.read_bytes())
def copy(p,n):
 b=p.read_bytes();q=D/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return sha(b)
old=(OLD/'candidate-source'/TEST).read_bytes();new=(W/TEST).read_bytes()
assert sha(old)=='df773e3ddd01b11c49c409700061b60b2602e991c0629b0444998d73a56212eb'
assert new.startswith(old),'All30 original tests must remain byte-identical'
assert sha((OLD/'proposal.json').read_bytes())=='0ca1fd50f8af0a5daf063cff6e36e5104b16c1ee4d07a06db5967d75ef6c67cb'
review=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-independent-root-review/review.json')
assert sha(review.read_bytes())=='011a15c532adc27702d71164ce6ce80db25ec91b1932e463a0699caf1758396f'
copy(review,'root-review.json')
for name in ['proposal.json','seal.json','verification.json','inputs.json','receipts.json']:
 copy(OLD/name,'original/'+name)
copy(OLD/'candidate-source'/TEST,'original/'+TEST)
copy(W/TEST,'candidate-source/'+TEST)
for path in ['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/src/tests.rs']:
 assert (W/path).read_bytes()==(OLD/'candidate-source'/path).read_bytes()
 copy(W/path,'candidate-source/'+path)
(D/'test-addendum.patch').write_text(''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='original/'+TEST,tofile='candidate-source/'+TEST)))
s=new.decode();tests=[{'name':m.group(1),'line':s[:m.start()].count('\n')+1} for m in re.finditer(r'^fn (worker_[a-z0-9_]+)\(',s,re.M)]
assert len(tests)==33
proposal=json.loads((OLD/'proposal.json').read_text())
proposal['phase']='Source-only revised proposal,33 drafted tests;30 original tests byte-identical plus3addendum tests. Review required before normal-private-library implementation. No Cargo/Bazel/Rust compilation or tests run.'
proposal['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
proposal['supersedes_proposal_sha256']=sha((OLD/'proposal.json').read_bytes())
proposal['root_review_sha256']=sha(review.read_bytes())
proposal['tests']=tests
for record in proposal['changed_files']:
 b=(W/record['path']).read_bytes();record['sha256']=sha(b);record['bytes']=len(b)
proposal['construction']['boundary']='Future implementation is private tools/canonical-filesystem/src/worker.rs, introduced only after addendum review. Declare ordinary mod worker in lib.rs (NO cfg(test) on module), with only a narrow dead_code allowance and reason that these staged private capabilities have no canonical factory consumer yet. Compile the module in normal library builds. Only fault enums/helpers and readonly write probe use cfg(test). No public exports, constructor integration, new runtime selector, dependencies or factories. Add source to both existing library src lists for normal and redb builds. This checkpoint still has no worker module or lib.rs edit.'
proposal['finite_qualification_bound']['scope']='33 finite tests on temporary Linux roots. Cross-family fixtures use eight physically separate roots, two real Ownership claims, identical logical IDs and separate capabilities. No network, gateway, worker factory, subprocess execution, symlink action materialization, cleanup or recovery.'
proposal['future_execution']['positive']='After addendum review and implementation, compile normal private library (including non-test worker module) and run explicit manual //tools/canonical-filesystem:ownership_test. Discover/list actual tests and require all33 new names plus existing ownership/capability/namespace tests. Run journal_test where needed to check redb coexistence. Full server/worker regressions deferred until actual worker integration.'
for c in proposal['future_execution']['negative_controls']:
 if c['id']=='C08':
  c['expected']='Require actual reached EBADF write syscall. Swallowing write failure may still be refused by an independent final-size guard, so report the actual survivor/refusal path honestly. Do not weaken the positive oracle or add extra defects to manufacture a caught result. Unexpected ready or wrong expected error may fail the selected assertion, but distinguish success-corruption from changed refusal code.'
proposal['future_execution']['negative_controls'] += [
 {'id':'C14','change':'Omit same-family guard specifically in WorkerInput::link_into, leaving real link operation intact.','test':tests[-3],'expected':'Initial same-family positive succeeds; first cross-family operation with equal IDs unexpectedly succeeds and assert_error fails. Both source inodes and independently owned capabilities remain real. No missing setup/API failure counts.'},
 {'id':'C15','change':'Omit same-family guard specifically in WorkerInput::copy_into, leaving real private copy intact.','test':tests[-2],'expected':'Initial same-family positive succeeds; first cross-family copy unexpectedly succeeds and assert_error fails. Claim only reached branch, not both-direction mutation counts.'},
 {'id':'C16','change':'Treat Interrupted as terminal in real copy or mandatoryEOF read path. Freeze separate exact code mutations if these paths differ.','test':tests[-1],'expected':'Finite scripted source reaches actual interrupted read then copy returns Err instead of successful one, or exact7reads/4interruptions/3bytes/1EOF witness fails. If standard Read helper already retries, classify ineffective variant as survivor; not an infinite-reader liveness claim.'}
]
proposal['future_execution']['controls_not_claimed'][0] = 'All16 control entries are currently design proposals; no runtime exists to produce exact mutations yet. Freeze exact source edits after runtime review before applying.'
proposal['addendum']={
 'original_preservation':'Original proposal/seal/verification/input receipts/test file are copied unchanged; old evidence directory untouched. New test source starts with every original byte. BUILD/test module wiring unchanged from original freeze.',
 'cross_family_contract':'Both link and copy must reject different Arc worker-directory families before destination I/O with different_worker_capability. Two separate real Ownership claims over eight separate physical roots use equal InputId1/ActionId1 and unchanged logical worker/namespace IDs. Each family successfully materializes its own distinct bytes first. Cross-direction operations reject without creating foreign leaf, changing existing local/sentinel entries, or changing source bytes/inode/link-count/mode/mtime. One shared Fixture lock avoids deadlocking the existing test fixture mutex.',
 'interrupted_contract':'The finite source produces Interrupted, byte o, Interrupted, bytes ne, Interrupted, Interrupted, EOF in exactly7read calls. Mid-copy and finalEOF interruptions retry; one completed input has exact bytes one and mode0444, no staging leaf. Script panics on extra reads; no arbitrary/infinite read source liveness guarantee.',
 'normal_library_boundary':'The runtime source is compiled as an ordinary private library module; only test seams cfg(test). Narrow module-level dead_code allowance is justified by absent factory consumer, not a crate-level lint suppression.',
 'C08_limit':'Independent final-size guard may preserve refusal after swallowed write failure. Record that actual result without recasting an uncompiled, prerequisite-failed or equivalent mutation as detection.',
 'remaining':'No runtime code yet. Parent quick addendum review must precede implementation; shared Cargo/Bazel lane authorization remains separately required.'
}
proposal_sha=write('proposal.json',proposal)
fmt=['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',TEST]
r=subprocess.run(fmt,cwd=W,capture_output=True,text=True);assert r.returncode==0
(D/'rustfmt.stdout').write_text(r.stdout);(D/'rustfmt.stderr').write_text(r.stderr)
r2=subprocess.run(['git','diff','--check'],cwd=W,capture_output=True,text=True);assert r2.returncode==0
assert not(W/'tools/canonical-filesystem/src/worker.rs').exists()
assert (W/'tools/canonical-filesystem/src/lib.rs').read_bytes()==(OLD/'base-source/tools/canonical-filesystem/src/lib.rs').read_bytes()
for item in json.loads((OLD/'inputs.json').read_text())['inputs']:
 assert sha((OLD/item['copy']).read_bytes())==item['sha256']
verification_sha=write('verification.json',{'base_commit':BASE,'source_tests':33,'original_tests':30,'original_source_is_exact_byte_prefix':True,'original_proposal_and_test_hashes_verified':True,'original_copied_base_inputs_verified':33,'new_tests':tests[-3:],'no_runtime_or_lib_changes':True,'normal_library_compilation_is_proposed_not_run':True,'Cargo_Bazel_Rust_compilation_tests_run':False,'nightly_rustfmt_command':fmt,'nightly_rustfmt_exit':r.returncode,'git_diff_check_exit':r2.returncode,'proposal_sha256':proposal_sha,'new_test_source_sha256':sha(new),'negative_controls_proposed_not_run':16})
receipts=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and not (p.parent == D and p.name in ['receipts.json','seal.json']):
  b=p.read_bytes();receipts.append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b)})
receipts_sha=write('receipts.json',receipts)
seal={'base_commit':BASE,'prior_proposal_sha256':sha((OLD/'proposal.json').read_bytes()),'prior_test_source_sha256':sha(old),'review_sha256':sha(review.read_bytes()),'proposal_sha256':proposal_sha,'test_source_sha256':sha(new),'verification_sha256':verification_sha,'receipts_sha256':receipts_sha}
seal_sha=write('seal.json',seal)
print(json.dumps({'seal_sha256':seal_sha,**seal,'source_tests':33,'added_bytes':len(new)-len(old)},indent=2))
