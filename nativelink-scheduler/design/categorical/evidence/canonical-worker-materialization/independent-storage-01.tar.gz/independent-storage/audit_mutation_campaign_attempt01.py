from pathlib import Path
import hashlib,json,os,re,shutil,difflib
E=Path('/tmp/nativelink-canonical-worker-materialization-mutation-evidence')
R=Path('/tmp/nativelink-canonical-worker-materialization-independent-storage-review')
W=Path('/tmp/nativelink-canonical-worker-materialization')
D=R/'mutation-campaign'
D.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(p): return sha(p.read_bytes())
def js(p): return json.loads(p.read_bytes())
def record(p): return {'sha256':digest(p),'bytes':p.stat().st_size}
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
for p in E.rglob('*'):
 if p.is_file():
  dst=D/p.relative_to(E);dst.parent.mkdir(parents=True,exist_ok=True)
  if p.name in ['ownership_test','journal_test'] or p.suffix=='.rlib': os.link(p,dst)
  else:shutil.copyfile(p,dst)
seal=js(D/'seal.json');receipts=js(D/'receipts.json')
assert digest(D/'seal.json')=='1cf6d686051b0eb23bcef1331b453e0df3e2061313da73e4d3c7bf6d4dc1a30b'
assert digest(D/'receipts.json')==seal['receipts_sha256']
assert len(receipts)==seal['files']==434
assert sum(x['bytes'] for x in receipts)==seal['bytes']==249935888
assert {x['path'] for x in receipts}=={str(p.relative_to(D)) for p in D.rglob('*') if p.is_file()}-{'receipts.json','seal.json'}
for x in receipts:assert record(D/x['path'])=={k:x[k] for k in ['sha256','bytes']},x['path']
for k in ['qualification','stage_classifications']:
 assert digest(D/(k.replace('_','-')+'.json'))==seal[k+'_sha256']
manifest=js(D/'approved-control-manifest.json')
assert digest(D/'approved-control-manifest.json')==digest(R/'controls-source/manifest.json')=='03f69690431255903f75f987f64afcca9e708ce70f3c0ac167842c373e5107d0'
base=js(D/'baseline-before.json');assert base==js(D/'baseline-after.json')
assert len(base)==1363 and len({x['path'] for x in base})==1363
assert digest(D/'baseline-before.json')==digest(R/'positive-evidence-v2/attempt-02/source-before.json')=='298b4b8941cee672135b2bdb2c0ba84ceae8a08fb396d389d695a4a9e97d691b'
baseidx={x['path']:x for x in base}

def bep(p):
 ev=[json.loads(x) for x in p.read_text().splitlines()]
 finished=[x['finished'] for x in ev if 'finished'in x]
 assert len(finished)==1 and finished[0]['exitCode'].get('code',0)==0
 sets={x['id']['namedSet']['id']:x['namedSetOfFiles'] for x in ev if 'namedSetOfFiles'in x}
 def flatten(i):
  s=sets[i]; out=list(s.get('files',[]))
  for child in s.get('fileSets',[]):out+=flatten(child['id'])
  return out
 plain={x['id']['targetCompleted']['label']:x for x in ev if 'completed'in x and not x['id']['targetCompleted'].get('aspect')}
 def output(label):
  x=plain[label];assert x['completed'].get('success')
  groups=[g for g in x['completed'].get('outputGroup',[]) if g['name']=='default'];assert len(groups)==1
  fs=[f for s in groups[0]['fileSets'] for f in flatten(s['id'])];assert len(fs)==1
  return fs[0]
 return ev,plain,output

def bind(p,a,output,magic):
 b=(p/a['copy']).read_bytes();f=output(a['label'])
 assert b.startswith(magic) and sha(b)==a['sha256']==a['bep_sha256']==f['digest']
 assert len(b)==a['bytes']==int(f['length']) and a['source_uri']==f['uri']
 return {'label':a['label'],'copy':str((p/a['copy']).relative_to(D)),**record(p/a['copy'])}

markers={
'C01':[':76:18:','accepted operation that must refuse with worker_root_not_empty'],
'C02':[':76:18:','accepted operation that must refuse with create_worker_action'],
'C03':[':84:9:','left: Ok(())','WouldBlock','/journal'],
'C04':[':541:56:','called `Result::unwrap()`','"open_worker_action"'],
'C05':[':411:9:','metadata copy reused shared inode','left: (2050, 8808972)','right: (2050, 8808972)'],
'C06':[':76:18:','accepted operation that must refuse with worker_input_size_mismatch'],
'C07':[':76:18:','accepted operation that must refuse with worker_input_too_large'],
'C08':[':77:23:','left: "worker_input_size_mismatch"','right: "write_worker_input"'],
'C09':[':76:18:','accepted operation that must refuse with mode_worker_input'],
'C10':[':985:33:'],
'C11':[':76:18:','accepted operation that must refuse with worker_input_replaced'],
'C12':[':76:18:','accepted operation that must refuse with mtime_worker_file'],
'C13':[':77:23:','left: "worker_input_size_mismatch"','right: "worker_destination_exists"'],
'C14_C15':[':76:18:','accepted operation that must refuse with different_worker_capability'],
'C16_copy':[':1199:10:','"read_worker_input"'],
'C16_eof':[':1199:10:','"read_worker_input"']}
stages={x['variant']:x for x in js(D/'stage-classifications.json')}
campaign={x['variant']:x for x in js(D/'campaign-results.json')}
controls=[]
for v in manifest['variants']:
 n=v['id'];p=D/n;c=campaign[n];stage=stages[n]
 assert js(p/'variant.json')==v
 for f in ['worker.rs','runtime.patch']:
  assert (p/f).read_bytes()==(R/'controls-source'/n/f).read_bytes()
 assert digest(p/'worker.rs')==v['runtime_sha256']==stage['runtime_sha256']
 expected=[dict(x) for x in base]
 for x in expected:
  if x['path']==manifest['runtime_path']:x.update(record(p/'worker.rs'))
 for name in ['source-before-build.json','source-after-build.json']:assert js(p/name)==expected
 assert js(p/'source-restored.json')==base
 build=js(p/'build-result.json');cmd=js(p/'build-command.json')
 assert build==c['build'] and build['exit_code']==0
 assert build['source_before_sha256']==build['source_after_sha256']==digest(p/'source-before-build.json')
 assert cmd['argv']==['bazel','--output_base=/tmp/bazel-canonical-worker-materialization','build','--jobs=4','--build_event_json_file='+str(E/n/'build-bep.json'),'//tools/canonical-filesystem:ownership_test']
 assert cmd['cwd']==str(W)
 ev,plain,output=bep(p/'build-bep.json');assert len(plain)==1
 artifact=bind(p,js(p/'artifact.json'),output,b'\x7fELF')
 assert artifact['sha256']==c['elf_sha256']
 tests=[]
 assert len(c['tests'])==len(v['oracles'])
 for i,oracle in enumerate(v['oracles'],1):
  t=p/f'test-{i:02}';r=js(t/'result.json');cmd=js(t/'command.json')
  assert r==c['tests'][i-1]
  assert r['exit_code']==101 and not r['timed_out']
  assert r['name']==oracle['name']
  assert cmd['argv']==[str(E/n/'ownership_test'),'--exact',oracle['name'],'--nocapture']
  assert cmd['elf_sha256']==artifact['sha256'] and cmd['cwd']==str(W) and cmd['env_overrides']=={'RUST_TEST_THREADS':'1'} and cmd['timeout_seconds']==60
  for side in ['before','after']:
   assert js(t/f'source-{side}.json')==expected
   assert r[f'source_{side}_sha256']==digest(t/f'source-{side}.json')
  for stream in ['stdout','stderr']:assert r[stream+'_sha256']==digest(t/(stream+'.log'))
  stdout=(t/'stdout.log').read_text();stderr=(t/'stderr.log').read_text()
  assert re.findall(r'^test (.+) \.\.\. (\w+)$',stdout,re.M)==[(oracle['name'],'FAILED')]
  assert re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)==[('FAILED','0','1','0')]
  assert 'running 1 test\n' in stdout and stderr.count('panicked at')==1
  for marker in markers[n]:assert marker in stderr,(n,marker,stderr)
  sr=stage['tests'][i-1]
  assert sr['observed_stderr']==stderr and sr['elf_sha256']==artifact['sha256'] and sr['name']==oracle['name']
  tests.append({'name':oracle['name'],'exit_code':101,'stderr_sha256':digest(t/'stderr.log'),'assertion_site':re.search(r'panicked at (.+):\n',stderr).group(1)})
 controls.append({'variant':n,'runtime_sha256':v['runtime_sha256'],'artifact':artifact,'tests':tests,'classification':stage['classification'],'reached_stage_and_limits':stage['stage_and_limits']})
assert len(controls)==16 and len({x['artifact']['sha256'] for x in controls})==16
assert sum(len(x['tests']) for x in controls)==17

restored={}
approved=set(re.findall(r'^fn (worker_\w+)\(', (D/'final-source'/manifest['test_path']).read_text(),re.M));assert len(approved)==33
for name in ['restored-tests','restored-libraries']:
 p=D/name;s=js(p/'summary.json');cmd=js(p/'command.json')
 assert s['exit_code']==0 and s['sources_unchanged']
 for side in ['before','after']:
  assert js(p/f'source-{side}.json')==base and digest(p/f'source-{side}.json')==s[f'source_{side}_sha256']
 for stream in ['stdout','stderr']:assert s[stream+'_sha256']==digest(p/(stream+'.log'))
 ev,plain,output=bep(p/'bep.json');assert len(plain)==2
 aspects=[x for x in ev if 'completed'in x and x['id']['targetCompleted'].get('aspect')]
 assert len(aspects)==6 and all(x['completed'].get('success') for x in aspects)
 aa=[]
 for a in js(p/'artifacts.json'):
  assert record(p/a['copy'])=={k:a[k] for k in ['sha256','bytes']}
  if a.get('kind','test_elf')=='test_elf':aa.append(bind(p,a,output,b'\x7fELF' if name=='restored-tests' else b'!<arch>\n'))
 old=js(R/'positive-and-library-review.json')['attempt-02' if name=='restored-tests' else 'library-build-01']['artifacts']
 assert {x['sha256'] for x in aa}=={x['sha256'] for x in old}
 results=[x for x in ev if 'testResult'in x];counts={}
 if name=='restored-tests':
  assert len(results)==2 and '--cache_test_results=no' in cmd['argv']
  sets=[]
  for x in results:
   target=x['id']['testResult']['label'].split(':')[-1];result=x['testResult']
   assert result['status']=='PASSED' and not result.get('cachedLocally',False) and result['executionInfo']['strategy']=='linux-sandbox'
   for a in result['testActionOutput']:
    log=p/'testlogs'/target/a['name']
    stored=[y for y in js(p/'artifacts.json') if y['copy']==str(log.relative_to(p))];assert len(stored)==1 and stored[0]['source_uri']==a['uri']
   log=(p/'testlogs'/target/'test.log').read_text()
   names=re.findall(r'^test ([^ ]+) \.\.\. ok$',log,re.M);count=68 if target=='ownership_test' else 80
   assert len(names)==len(set(names))==count
   assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)==[(str(count),'0','0')]
   assert {n.split('::')[-1] for n in names if n.split('::')[-1].startswith('worker_')}==approved
   sets.append(set(names));counts[target]=count
  assert len(set.union(*sets))==80
 else:assert not results
 restored[name]={'exit_code':0,'artifacts':aa,'counts':counts,'successful_format_clippy_aspects':6,'bytes_equal_original_qualified_artifacts':True}

hooks={}
for name in ['hooks-01','hooks-02']:
 p=D/name;s=js(p/'results.json');before=js(p/'source-before.json');after=js(p/'source-after.json')
 assert before==after and len(before)==1363 and s['sources_unchanged']
 assert digest(p/'source-before.json')==digest(p/'source-after.json')==s['source_before_sha256']==s['source_after_sha256']
 idx={x['path']:x for x in before};changed=[key for key in baseidx if baseidx[key]!=idx[key]]
 assert changed==['tools/canonical-filesystem/README.md']
 for c in s['commands']:
  assert digest(p/(c['name']+'.log'))==c['log_sha256']
  assert c['exit_code']==(1 if name=='hooks-01' and c['name']=='precommit' else 0)
 log=(p/'precommit.log').read_text()
 assert ('vale.....................................................................Failed' in log)==(name=='hooks-01')
 assert js(p/'precommit-command.json')['env_overrides']=={'SKIP':'machete,rustfmt'}
 hooks[name]={'commands':s['commands'],'source_manifest_sha256':s['source_before_sha256'],'only_changed_from_restored_manifest':changed}
final=js(D/'hooks-02/source-after.json');finalidx={x['path']:x for x in final}
for x in final:
 assert record(W/x['path'])=={k:x[k] for k in ['sha256','bytes']},x['path']
for p in (D/'final-source').rglob('*'):
 if p.is_file():assert record(p)=={k:finalidx[str(p.relative_to(D/'final-source'))][k] for k in ['sha256','bytes']}
assert finalidx[manifest['runtime_path']]['sha256']==manifest['base_runtime_sha256']
assert finalidx[manifest['test_path']]['sha256']==manifest['test_source_sha256']
old=(R/'positive-evidence-v2/source/tools/canonical-filesystem/README.md').read_text()
new=(D/'final-source/tools/canonical-filesystem/README.md').read_text()
(R/'final-readme-delta.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='qualified-positive/README.md',tofile='final/README.md')))
out={'campaign_seal_sha256':digest(D/'seal.json'),'receipts_verified':434,'retained_bytes':seal['bytes'],'review_scope':'Independent source/evidence/artifact audit only; no compiler, Bazel, Cargo, runtime-test invocation, or worktree edit by reviewer.','manifest_sha256':digest(D/'approved-control-manifest.json'),'baseline_source_records':1363,'controls':controls,'restored':restored,'hooks':hooks,'final_all_live_source_records_exact':1363,'final_source_manifest_sha256':digest(D/'hooks-02/source-after.json'),'runtime_sha256':manifest['base_runtime_sha256'],'test_source_sha256':manifest['test_source_sha256'],'counts':{'compiled_distinct_variants':16,'distinct_actual_test_elfs':16,'exact_invocations':17,'named_assertion_failures':17,'compiler_failures':0,'timeouts':0,'zero_tests':0,'behavioral_variants':14,'behavioral_invocations':15,'refusal_preserved_error_contract_variants':2,'restored_test_executions':148,'restored_unique_tests':80,'worker_unique_tests':33}}
save(R/'mutation-campaign-raw-review.json',out)
print(json.dumps({'receipt':str(R/'mutation-campaign-raw-review.json'),'sha256':digest(R/'mutation-campaign-raw-review.json'),'counts':out['counts']},indent=2))
