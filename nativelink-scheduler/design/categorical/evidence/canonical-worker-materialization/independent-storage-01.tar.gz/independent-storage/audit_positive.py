from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
from urllib.parse import urlparse, unquote

E = Path('/tmp/nativelink-canonical-worker-materialization-evidence')
W = Path('/tmp/nativelink-canonical-worker-materialization')
R = Path('/tmp/nativelink-canonical-worker-materialization-independent-storage-review')
D = R / 'positive-evidence-v2'
D.mkdir(exist_ok=False)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)

def uri_path(uri):
    parsed = urlparse(uri)
    assert parsed.scheme == 'file'
    return Path(unquote(parsed.path))

def js(p):
    return json.loads(p.read_bytes())

old = js(R / 'evidence/sources.json')
oldidx = {x['path']: x for x in old['files']}
runtime = js(R / 'lint-correction-01-review.json')['after_sha256']
tests = (W / 'tools/canonical-filesystem/src/worker_tests.rs').read_text()
approved = set(re.findall(r'^fn (worker_\w+)\(', tests, re.M))
assert len(approved) == 33
out = {}
for name in ['attempt-01', 'attempt-02', 'library-build-01']:
    A = E / name
    C = D / name
    C.mkdir()
    for p in A.rglob('*'):
        if not p.is_file():
            continue
        dst = C / p.relative_to(A)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if p.parent.name == 'elf':
            os.link(p, dst)  # Author-retained immutable executable only.
        else:
            shutil.copyfile(p, dst)
    summary = js(C / 'summary.json')
    command = js(C / 'command.json')
    before = js(C / 'source-before.json')
    after = js(C / 'source-after.json')
    assert before == after and len(before) == 1363
    assert sha((C / 'source-before.json').read_bytes()) == summary['source_before_sha256'] == summary['source_after_sha256'] == command['source_before_sha256']
    for stream in ['stdout', 'stderr']:
        assert sha((C / (stream + '.log')).read_bytes()) == summary[stream + '_sha256']
    idx = {x['path']: x for x in before}
    assert len(idx) == len(before)
    for p, x in idx.items():
        b = (W / p).read_bytes()
        if name == 'attempt-01' and p == 'tools/canonical-filesystem/src/worker.rs':
            b = (R / 'lint-correction-01/worker-before.rs').read_bytes()
        assert len(b) == x['bytes'] and sha(b) == x['sha256'], (name, p)
    for p, x in oldidx.items():
        want = runtime if p == 'tools/canonical-filesystem/src/worker.rs' and name != 'attempt-01' else x['sha256']
        assert idx[p]['sha256'] == want, (name, p)
    for config in ['lre.bazelrc', 'nixos.bazelrc', 'nativelink.bazelrc']:
        assert sha((C / config).read_bytes()) == idx[config]['sha256']
    events = [json.loads(line) for line in (C / 'bep.json').read_text().splitlines()]
    finished = [x['finished'] for x in events if 'finished' in x]
    assert len(finished) == 1
    assert finished[0]['exitCode'].get('code', 0) == summary['exit_code']
    results = [x for x in events if 'testResult' in x]
    named = {x['id']['namedSet']['id']: x['namedSetOfFiles'] for x in events if 'namedSetOfFiles' in x}
    completed = [x for x in events if 'completed' in x]
    if name == 'attempt-01':
        assert summary['exit_code'] == 1 and not results
        stderr = (C / 'stderr.log').read_text()
        assert stderr.count('error: this argument is passed by value') == 3
        assert stderr.count('error: item in documentation is missing backticks') == 1
        out[name] = {'exit_code': 1, 'test_results': 0, 'classification': 'Lint prerequisite failure;3 needless_pass_by_value +1 doc_markdown. No semantic detection or failed runtime test.'}
        continue
    assert summary['exit_code'] == 0
    plain = [x for x in completed if not x['id']['targetCompleted'].get('aspect')]
    assert len(plain) == 2 and all(x['completed'].get('success') for x in plain)
    aspects = [x for x in completed if x['id']['targetCompleted'].get('aspect')]
    assert len(aspects) == 6 and all(x['completed'].get('success') for x in aspects)
    artifacts = []
    for x in plain:
        label = x['id']['targetCompleted']['label']
        groups = [g for g in x['completed']['outputGroup'] if g['name'] == 'default']
        assert len(groups) == 1 and len(groups[0]['fileSets']) == 1
        files = named[groups[0]['fileSets'][0]['id']]['files']
        assert len(files) == 1
        f = files[0]
        if name == 'attempt-02':
            p = C / 'elf' / label.rsplit(':', 1)[1]
            b = p.read_bytes()
            assert b[:4] == b'\x7fELF'
        else:
            b = uri_path(f['uri']).read_bytes()
            assert b[:8] == b'!<arch>\n'
            p = C / 'rlib' / Path(f['name']).name
            save(p, b)  # Copy mutable Bazel output; never hardlink.
        assert sha(b) == f['digest'] and len(b) == int(f['length'])
        artifacts.append({'label': label, 'sha256': sha(b), 'bytes': len(b), 'copy': str(p.relative_to(D)), 'bep_uri': f['uri']})
    if name == 'attempt-02':
        assert len(results) == 2 and '--cache_test_results=no' in command['argv']
        actual_tests = {}
        for x in results:
            label = x['id']['testResult']['label']
            target = label.rsplit(':', 1)[1]
            result = x['testResult']
            assert result['status'] == 'PASSED' and not result.get('cachedLocally', False)
            assert result['executionInfo']['strategy'] == 'linux-sandbox'
            for f in result['testActionOutput']:
                stored = C / 'testlogs' / target / f['name']
                assert stored.read_bytes() == uri_path(f['uri']).read_bytes()
            log = (C / 'testlogs' / target / 'test.log').read_text()
            names = re.findall(r'^test ([^ ]+) \.\.\. ok$', log, re.M)
            expected_count = 68 if target == 'ownership_test' else 80
            assert len(names) == expected_count and len(set(names)) == expected_count
            assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log) == [(str(expected_count), '0', '0')]
            worker_names = {n.rsplit('::', 1)[-1] for n in names if n.rsplit('::', 1)[-1].startswith('worker_')}
            assert worker_names == approved
            actual_tests[target] = names
        assert set(actual_tests['ownership_test']).issubset(actual_tests['journal_test'])
        for artifact in js(C / 'artifacts.json'):
            b = (C / artifact['copy']).read_bytes()
            assert sha(b) == artifact['sha256'] and len(b) == artifact['bytes']
        out[name] = {'exit_code': 0, 'source_manifest_sha256': summary['source_before_sha256'], 'all_live_sources_exact': 1363, 'uncached_sandbox_targets': 2, 'test_invocations': 148, 'unique_test_names': 80, 'approved_worker_names': 33, 'each_variant_worker_passed': 33, 'ignored': 0, 'artifacts': artifacts, 'successful_clippy_and_rustfmt_aspects': 6}
    else:
        assert not results
        out[name] = {'exit_code': 0, 'source_manifest_sha256': summary['source_before_sha256'], 'all_live_sources_exact': 1363, 'normal_and_redb_targets_completed': True, 'successful_clippy_and_rustfmt_aspects': 6, 'artifacts': artifacts, 'test_results': 0}

# Establish exactly one source change between the failed and successful attempts.
one = {x['path']: x for x in js(D / 'attempt-01/source-before.json')}
two = {x['path']: x for x in js(D / 'attempt-02/source-before.json')}
assert one.keys() == two.keys()
assert [p for p in one if one[p] != two[p]] == ['tools/canonical-filesystem/src/worker.rs']
assert js(D / 'attempt-02/source-before.json') == js(D / 'library-build-01/source-before.json')

# Copy all selected source inputs at the qualified boundary; other tracked files
# are validated against Git in one batch, without running a compiler.
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=W).decode().split('\0')
tracked = [p for p in paths if p and not p.startswith('nativelink-scheduler/design/categorical/evidence/')]
git_changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=W).decode().splitlines()
assert set(git_changed) == {'tools/canonical-filesystem/BUILD.bazel', 'tools/canonical-filesystem/README.md', 'tools/canonical-filesystem/src/lib.rs', 'tools/canonical-filesystem/src/tests.rs'}
for p in oldidx:
    save(D / 'source' / p, (W / p).read_bytes())
out['scope'] = 'Independent retained evidence and actual artifact audit only. No builds, compiler/test invocations or worktree edits by reviewer.'
out['reviewer_prerequisite'] = 'Initial source audit matched every /worker.rs suffix when substituting the original attempt01 source, including an unrelated scheduler file. Narrowed to the exact canonical-filesystem path; original partial evidence copies retained. No production source or runtime failure inferred.'
out['qualified_runtime_sha256'] = runtime
out['original33tests_sha256'] = sha((W / 'tools/canonical-filesystem/src/worker_tests.rs').read_bytes())
out['limits'] = ['148 executions across variants represent80unique tests; the33worker cases run in each variant.', 'Standalone libraries are successful builds, not additional tests. These are actual retained rlib archive bytes, not executable test binaries.', 'Build cache use for dependencies/aspects is allowed; both test results are fresh actual sandbox executions.', 'No mutant/control result, production worker integration, durability or hostile namespace race guarantee is established.']
payload = (json.dumps(out, indent=2) + '\n').encode()
save(R / 'positive-and-library-review.json', payload)
print(json.dumps({'receipt': str(R / 'positive-and-library-review.json'), 'sha256': sha(payload), 'results': out}, indent=2))
