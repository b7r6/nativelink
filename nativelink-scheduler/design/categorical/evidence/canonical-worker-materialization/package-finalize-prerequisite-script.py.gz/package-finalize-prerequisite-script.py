import gzip,hashlib,json,os,pathlib,shutil,subprocess,time
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=W/'nativelink-scheduler/design/categorical/evidence/canonical-worker-materialization'
E=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-integration-records')
E.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
indices=[json.loads(p.read_text()) for p in sorted(D.glob('*-index.json'))]
assert len(indices)==9
members=[r for i in indices for r in i['members']]
archives=[r for i in indices for r in i['archives']]
q=json.loads(pathlib.Path('/tmp/nativelink-canonical-worker-materialization-mutation-evidence/qualification.json').read_text())
package={'version':1,'kind':'private-worker-materialization-prerequisite','base_commit':'255fa9c0fb3d2abeb170aee9f7deff8f100b17ec','runtime_sha256':q['qualified_runtime_sha256'],'test_sha256':q['frozen_test_source_sha256'],'mutation_seal_sha256':'1cf6d686051b0eb23bcef1331b453e0df3e2061313da73e4d3c7bf6d4dc1a30b','counts':q['counts'],'archives':archives,'members':members}
write(D/'package.json',package)
shutil.copyfile('/tmp/nativelink-worker-materialization-package.py',D/'build-package.py')
config=E/'precommit-config.yaml';config.write_bytes(pathlib.Path('/tmp/nativelink-current-precommit-config.json').read_bytes())
files=['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/README.md','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/tests.rs','tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/worker_tests.rs']
files += [str(p.relative_to(W)) for p in sorted(D.rglob('*')) if p.is_file()]
argv=['pre-commit','run','--config',str(config),'--files',*files]
write(E/'hooks-command.json',{'argv':argv,'cwd':str(W),'env_overrides':{'SKIP':'machete,rustfmt'},'reason':'Cargo lane reserved; direct pinned nightly rustfmt plus default Bazel formatting/Clippy already passed; no dependency changes.'})
start=time.monotonic()
with (E/'hooks.log').open('wb') as out:
 result=subprocess.run(argv,cwd=W,env={**os.environ,'SKIP':'machete,rustfmt'},stdout=out,stderr=subprocess.STDOUT)
write(E/'hooks-result.json',{'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log_sha256':sha((E/'hooks.log').read_bytes())})
print((E/'hooks.log').read_text(),flush=True)
assert result.returncode==0,'Preserve failures before fixing packet docs; do not repeat this whole script.'
for name in ['hooks-command.json','hooks-result.json','hooks.log','precommit-config.yaml']:
 with (D/('package-'+name+'.gz')).open('wb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as gz:gz.write((E/name).read_bytes())
command=['python3',str(D/'verify.py')]
verified=subprocess.run(command,capture_output=True,cwd=W)
(E/'verification.stdout').write_bytes(verified.stdout);(E/'verification.stderr').write_bytes(verified.stderr)
assert verified.returncode==0,verified.stderr
(D/'package-verification.json').write_bytes(verified.stdout)
write(D/'package-verification-command.json',{'argv':command,'cwd':str(W),'exit_code':verified.returncode,'stderr_sha256':sha(verified.stderr)})
subprocess.run(['git','diff','--check'],cwd=W,check=True)
receipt=[]
for p in sorted(D.rglob('*')):
 if p.is_file():
  b=p.read_bytes();receipt.append({'path':str(p.relative_to(D)),'sha256':sha(b),'bytes':len(b)})
seal={'files':receipt,'package_sha256':sha((D/'package.json').read_bytes()),'verification_sha256':sha((D/'package-verification.json').read_bytes()),'archive_bytes':sum(a['bytes'] for a in archives),'source_member_bytes':sum(m['bytes'] for m in members),'mutations_immutable_seal_sha256':package['mutation_seal_sha256']}
write(D/'package-seal.json',seal)
print(json.dumps({'package_sha256':seal['package_sha256'],'seal_sha256':sha((D/'package-seal.json').read_bytes()),'archives':len(archives),'members':len(members),'archive_bytes':seal['archive_bytes'],'verification':json.loads(verified.stdout)},indent=2),flush=True)
