from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
out=Path(__file__).parent
commit='255fa9c0fb3d2abeb170aee9f7deff8f100b17ec'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[
 'Cargo.toml','Cargo.lock','src/bin/nativelink.rs',
 'tools/canonical-config/src/lib.rs','tools/canonical-config/src/schema.rs',
 'tools/canonical-filesystem/Cargo.toml','tools/canonical-filesystem/Cargo.lock','tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/README.md','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/capability.rs','tools/canonical-filesystem/src/capability_tests.rs','tools/canonical-filesystem/src/namespace.rs','tools/canonical-filesystem/src/namespace_tests.rs','tools/canonical-filesystem/src/tests.rs',
 'tools/canonical-store/Cargo.toml','tools/canonical-store/README.md','tools/canonical-store/src/lib.rs',
 'nativelink-config/src/cas_server.rs','nativelink-worker/Cargo.toml','nativelink-worker/BUILD.bazel','nativelink-worker/src/local_worker.rs','nativelink-worker/src/running_actions_manager.rs','nativelink-worker/src/authority_worker.rs','nativelink-worker/src/directory_cache.rs','nativelink-worker/tests/running_actions_manager_test.rs','nativelink-worker/tests/directory_cache_test.rs','nativelink-worker/tests/authority_rpc_test.rs','nativelink-util/src/fs.rs','nativelink-util/src/task.rs','nativelink-store/src/filesystem_store.rs','nativelink-store/src/fast_slow_store.rs','nativelink-scheduler/design/categorical/source-plan.md','nativelink-scheduler/design/categorical/source-map.md'
]
inputs=[]
for rel in paths:
 data=subprocess.check_output(['git','show',commit+':'+rel],cwd=root)
 dest=out/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':rel,'copy':str(dest.relative_to(out)),'bytes':len(data),'sha256':sha(dest),'source_commit':commit,'current_worktree_byte_match':(root/rel).read_bytes()==data})
external=Path('/home/b7r6/nativelink-categorical-elimination-plan.md');dest=out/'requested-plan.md';shutil.copy2(external,dest)
inputs.append({'path':str(external),'copy':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'source_commit':None})
reg=Path('/home/b7r6/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustix-1.1.2')
for rel in ['src/fs/at.rs','src/fs/fd.rs']:
 dest=out/'pinned-rustix-1.1.2'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(reg/rel,dest)
 inputs.append({'path':str(reg/rel),'copy':str(dest.relative_to(out)),'bytes':dest.stat().st_size,'sha256':sha(dest),'source_commit':None})
(out/'inputs.json').write_text(json.dumps({'base_commit':commit,'scope':'34 selected repository inputs, requested external plan, and two pinned rustix API source files; not a complete build-input freeze.','files':inputs},indent=2)+'\n')
print(json.dumps({'copied_inputs':len(inputs),'repository_inputs':len(paths),'total_bytes':sum(i['bytes'] for i in inputs),'inputs_sha256':sha(out/'inputs.json'),'all_selected_current_repository_files_match':all(i.get('current_worktree_byte_match',True) for i in inputs)},indent=2))
