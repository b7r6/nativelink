import pathlib,json,hashlib,subprocess,datetime,time,sys
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-evidence')/sys.argv[1]
D.mkdir(parents=True,exist_ok=False)
ROOT=pathlib.Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
for name in ['lre.bazelrc','nixos.bazelrc','nativelink.bazelrc']:
 p=W/name
 if not p.exists():p.symlink_to((ROOT/name).resolve())
assert (W/'tools/canonical-filesystem/src/worker_tests.rs').read_bytes()==pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-addendum/candidate-source/tools/canonical-filesystem/src/worker_tests.rs').read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
 p=D/name;p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')
paths=sorted(set(p for p in tracked if p and not p.startswith('nativelink-scheduler/design/categorical/evidence/'))|{'tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/worker_tests.rs','lre.bazelrc','nixos.bazelrc','nativelink.bazelrc'})
def snapshot(name):
 entries=[]
 for p in paths:
  f=W/p
  if f.is_file():
   b=f.read_bytes();entries.append({'path':p,'bytes':len(b),'sha256':sha(b)})
  else:entries.append({'path':p,'missing':True})
 return entries,write(name,entries)
before,before_sha=snapshot('source-before.json')
command=['bazel','--output_base=/tmp/bazel-canonical-worker-materialization','build','--jobs=4','--build_event_json_file='+str(D/'bep.json'),'//tools/canonical-filesystem:nativelink-canonical-filesystem','//tools/canonical-filesystem:nativelink-canonical-filesystem-redb']
write('command.json',{'argv':command,'cwd':str(W),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before_sha256':before_sha,'tracked_evidence_exclusion':'nativelink-scheduler/design/categorical/evidence/; immutable prior evidence is not a compiler input','generated_configs':'Three existing immutable Nix-generated root configs symlinked into isolated worktree; all copied/hash recorded.'})
for name in ['lre.bazelrc','nixos.bazelrc','nativelink.bazelrc']:(D/name).write_bytes((W/name).read_bytes())
start=time.monotonic()
with (D/'stdout.log').open('wb') as out,(D/'stderr.log').open('wb') as err:
 result=subprocess.run(command,cwd=W,stdout=out,stderr=err)
after,after_sha=snapshot('source-after.json')
summary={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':len(before),'source_before_sha256':before_sha,'source_after_sha256':after_sha,'sources_unchanged':before==after,'stdout_sha256':sha((D/'stdout.log').read_bytes()),'stderr_sha256':sha((D/'stderr.log').read_bytes())}
write('summary.json',summary)
print(json.dumps(summary,indent=2),flush=True)
print((D/'stderr.log').read_text(errors='replace')[-14000:],flush=True)
