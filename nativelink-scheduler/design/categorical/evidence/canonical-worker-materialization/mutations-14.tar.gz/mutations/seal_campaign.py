import hashlib, json, pathlib, shutil, datetime
D=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-controls')
P=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-evidence')
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
manifest=json.loads((C/'manifest.json').read_text())
results=json.loads((D/'campaign-results.json').read_text())
assert len(results)==16 and sum(len(r['tests']) for r in results)==17
observations={
 'C01':('behavioral_assertion_failure','Unexpected success instead of worker_root_not_empty; first unknown regular-file case. Later partial/special branches not observed.'),
 'C02':('behavioral_assertion_failure','Unexpected success instead of create_worker_action; duplicate existing action adopted. Pending collision branch not observed.'),
 'C03':('custody_assertion_failure','Independent journal-root flock returned Ok instead of WouldBlock after dropping original Ownership; first OwnedWorkerFs-only case. Other descendants and role probes not reached.'),
 'C04':('descriptor_availability_assertion_failure','create_action returned open_worker_action when actions child was renamed and replaced by symlink. Earlier input/staging rename branches completed. NOFOLLOW retained: no outside mutation claim.'),
 'C05':('inode_isolation_assertion_failure','Private copy inode equals shared input inode at first assert_ne. Later metadata assertions not reached.'),
 'C06':('exact_input_assertion_failure','Unexpected completed input instead of worker_input_size_mismatch for declared3/data4; short case first still refuses. Later zero case not reached.'),
 'C07':('input_bound_assertion_failure','Unexpected PendingWorkerInput instead of worker_input_too_large for cap+1. u64MAX branch not reached.'),
 'C08':('refusal_preserved_error_contract_failure','Reached assertion passed after real same-inode RDONLY substitution. Actual error worker_input_size_mismatch differs from expected write_worker_input. Final physical-size guard still refuses; no unsafe-ready/publication catch. Later prefix/absence assertions not reached.'),
 'C09':('mode_error_assertion_failure','Reached assertion passed for actual O_PATH fchmod. Unexpected WorkerInput instead of mode_worker_input. Later prefix/absence assertions not reached.'),
 'C10':('writable_descriptor_assertion_failure','Actual write through completed handle succeeded with one byte; expect_err failed. chmod0444 did not revoke retained RDWR descriptor.'),
 'C11':('named_inode_assertion_failure','Unexpected success instead of worker_input_replaced after same-size named replacement; real linkat addresses replacement name. No atomic hostile-writer defense claim.'),
 'C12':('metadata_error_assertion_failure','Unexpected successful copy instead of mtime_worker_file after invalid-nanoseconds futimens. No manufactured errno.'),
 'C13':('refusal_preserved_with_source_inferred_prefix_write','Actual error worker_input_size_mismatch differs from expected worker_destination_exists. Final-size guard still refuses. Frozen source path opens existing8byte file without EXCL/TRUNC and writes3byte prefix before size check; overwrite is SOURCE INFERENCE because later byte assertions never run. No unsafe-ready or direct byte-observation claim.'),
 'C14_C15':('cross_family_assertion_failure','Both independent exact tests report unexpected success instead of different_worker_capability after own-family positive operations. One shared guard omission, two invocations; reverse cross-direction not reached in either.'),
 'C16_copy':('interrupted_read_assertion_failure','copy_from unwrap returns read_worker_input. Frozen patch removes retry in read_retry: first scripted body-read Interrupted is returned; no later stage claim.'),
 'C16_eof':('interrupted_eof_assertion_failure','copy_from unwrap returns read_worker_input. Frozen patch changes only EOF probe, so source stage implies body completed3bytes/two interruptions before EOF Interrupted. Counters after unwrap are not observed; no infinite-interruption liveness claim.')
}
classified=[]
for r,v in zip(results,manifest['variants']):
 assert r['variant']==v['id'] and r['build']['exit_code']==0
 assert r['build']['source_before_sha256']==r['build']['source_after_sha256']
 a=json.loads((D/r['variant']/'artifact.json').read_text())
 assert a['sha256']==a['bep_sha256']==sha((D/r['variant']/a['copy']).read_bytes())
 ts=[]
 for i,t in enumerate(r['tests']):
  assert t['raw_outcome']=='one_exact_assertion_failure_requires_stage_review' and not t['timed_out']
  assert t['exit_code']==101 and t['rust_summaries']==[['FAILED','0','1','0']]
  assert t['named_results']==[[v['oracles'][i]['name'],'FAILED']]
  assert t['source_before_sha256']==t['source_after_sha256']==r['build']['source_before_sha256']
  ts.append({'name':t['name'],'result':str(pathlib.Path(r['variant'])/f'test-{i+1:02}'/'result.json'),'observed_stderr':(D/r['variant']/f'test-{i+1:02}'/'stderr.log').read_text(),'elf_sha256':a['sha256']})
 classified.append({'variant':r['variant'],'classification':observations[r['variant']][0],'stage_and_limits':observations[r['variant']][1],'approved_required_stage':v['required_stage'],'runtime_sha256':v['runtime_sha256'],'tests':ts})
for source,dest in [('restored-attempt-01','restored-tests'),('restored-library-build-01','restored-libraries')]:
 shutil.copytree(P/source,D/dest)
 summary=json.loads((D/dest/'summary.json').read_text())
 assert summary['exit_code']==0 and summary['sources_unchanged'] and summary['source_before_sha256']==summary['source_after_sha256']=='298b4b8941cee672135b2bdb2c0ba84ceae8a08fb396d389d695a4a9e97d691b'
tests=json.loads((D/'restored-tests/test-summary.json').read_text())
assert sorted(int(t['final_rust_summary'][1]) for t in tests)==[68,80]
assert all(len(t['worker_tests_passed'])==33 and not t['cachedLocally'] and t['bep_status']=='PASSED' for t in tests)
hooks=json.loads((D/'hooks-02/results.json').read_text())
assert hooks['sources_unchanged'] and all(x['exit_code']==0 for x in hooks['commands'])
files=['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/README.md','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/tests.rs','tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/worker_tests.rs']
for f in files:
 p=D/'final-source'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/f).read_bytes())
assert sha((W/manifest['runtime_path']).read_bytes())==manifest['base_runtime_sha256']
assert sha((W/manifest['test_path']).read_bytes())==manifest['test_source_sha256']
shutil.copyfile(C/'manifest.json',D/'approved-control-manifest.json')
write(D/'stage-classifications.json',classified)
qualification={
 'base_commit':manifest['base_commit'],'scope':'Private canonical-filesystem worker prerequisite; no public exports, factory, production execution, cleanup, durability, digest identity, aggregate budgeting, or rollout qualification.',
 'frozen_test_source_sha256':manifest['test_source_sha256'],'qualified_runtime_sha256':manifest['base_runtime_sha256'],
 'control_manifest_sha256':sha((C/'manifest.json').read_bytes()),'control_source_review_sha256':'8b072f0da5d75c617bde0e5fd2a22a6841acbb6469cf4eb20bef9fd66efedcd9',
 'counts':{'compiled_distinct_variants':16,'exact_test_invocations':17,'named_assertion_failures':17,'compile_failures':0,'timeouts':0,'zero_tests':0,'behavioral_variants':14,'behavioral_invocations':15,'refusal_preserved_error_contract_variants':2,'restored_test_executions':148,'restored_unique_tests':80,'new_worker_unique_tests':33},
 'count_limits':'14 behavioral variants include availability, custody, identity and finite retry semantics; this is not a claim of14 independent unsafe-success failures. C14_C15 is one variant/two invocations. C08/C13 preserve refusal; C13 prefix mutation is source-inferred.',
 'restore':'All1363 source records exact after every variant and before/after restored68+80 tests and normal/redb builds. Worker runtime149815... and testsCAF... unchanged.',
 'final_docs_delta':'Only README differs from restored1363 manifest: qualification status and two spelling corrections. hooks-02 source-before/after match across1363; no compiler/test input differs.',
 'hooks':'Default Bazel formatting/Clippy passed on restored tests. Direct pinned nightly rustfmt passed. All relevant pre-commit hooks passed on6source/docs files; cargo-machete and cargo-fmt wrappers intentionally skipped because no Cargo lane authorization. No dependency edits.',
 'preserved_failures':'Initial positive attempt01 Clippy4errors and exact lint-only correction are in positive evidence. Initial hooks-01 Vale2spelling errors preserved; README corrections in hooks-02. No test oracle edits.',
 'positive_original_seal_sha256':'adcbfc1e8ed803b3f2ca48b31dd996b22141fe0528dbfa8a32bccdf0f5906ea9',
 'restored_libraries':'Normal/redb build exit0; cache hits permitted; copied rlib bytes match BEP and earlier real compilation artifacts.',
 'final_source_manifest_sha256':hooks['source_after_sha256'],
 'prerequisites_remaining':['Factory adoption and stable host namespace/permission boundary','Production aggregate resource budgets and eviction/cleanup','Digest-verified tree materialization and actual worker execution','Durability/recovery/physical generations and rollout qualification'],
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
}
write(D/'qualification.json',qualification)
receipts=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name not in ('receipts.json','seal.json'):
  b=p.read_bytes();receipts.append({'path':str(p.relative_to(D)),'sha256':sha(b),'bytes':len(b)})
rh=write(D/'receipts.json',receipts)
seal={'receipts_sha256':rh,'files':len(receipts),'bytes':sum(r['bytes'] for r in receipts),'qualification_sha256':sha((D/'qualification.json').read_bytes()),'stage_classifications_sha256':sha((D/'stage-classifications.json').read_bytes()),'immutability':'No more writes beneath this directory; subsequent independent reviews live outside.'}
write(D/'seal.json',seal)
print(json.dumps({'seal':seal,'seal_sha256':sha((D/'seal.json').read_bytes())},indent=2))
