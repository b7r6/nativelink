import datetime, hashlib, json, os, pathlib, re, shutil, subprocess, time, urllib.parse

W = pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
C = pathlib.Path('/tmp/nativelink-canonical-worker-materialization-controls')
D = pathlib.Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p, obj):
    p.write_text(json.dumps(obj, indent=2) + '\n')
    return sha(p.read_bytes())
assert sha((C/'manifest.json').read_bytes()) == '03f69690431255903f75f987f64afcca9e708ce70f3c0ac167842c373e5107d0'
assert sha((C/'apply.py').read_bytes()) == '836a045ab17a98933a7842bf1a1d1df9613975acaf603a2fc296f4f46129f315'
manifest = json.loads((C/'manifest.json').read_text())
records = json.loads((C/'positive/source-before.json').read_text())
def snapshot(p):
    result = []
    for r in records:
        f = W/r['path']
        if f.is_file():
            b = f.read_bytes()
            result.append({'path':r['path'], 'bytes':len(b), 'sha256':sha(b)})
        else: result.append({'path':r['path'], 'missing':True})
    return write(p, result)
def helper(p, *args):
    result = subprocess.run(['python3', str(C/'apply.py'), *args], capture_output=True, cwd=W)
    p.write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
def collect_elf(vdir):
    events = [json.loads(x) for x in (vdir/'build-bep.json').read_text().splitlines()]
    sets = {e['id']['namedSet']['id']: e['namedSetOfFiles'] for e in events if 'namedSetOfFiles' in e}
    def resolve(i):
        s = sets[i]; result = list(s.get('files', []))
        for child in s.get('fileSets', []): result.extend(resolve(child['id']))
        return result
    candidates = []
    for e in events:
        t = e.get('id', {}).get('targetCompleted', {})
        if t.get('label') != '//tools/canonical-filesystem:ownership_test' or t.get('aspect') or not e.get('completed', {}).get('success'): continue
        for group in e['completed'].get('outputGroup', []):
            if group['name'] != 'default': continue
            for fset in group.get('fileSets', []):
                for output in resolve(fset['id']):
                    uri = output.get('uri', '')
                    if not uri.startswith('file://'): continue
                    b = pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(uri).path)).read_bytes()
                    if b[:4] != b'\x7fELF': continue
                    assert output['digest'] == sha(b)
                    assert int(output['length']) == len(b)
                    dest = vdir/'ownership_test'; dest.write_bytes(b); dest.chmod(0o755)
                    candidates.append({'label':t['label'], 'copy':'ownership_test', 'source_uri':uri, 'bep_sha256':output['digest'], 'sha256':sha(b), 'bytes':len(b)})
    assert len(candidates) == 1, candidates
    write(vdir/'artifact.json', candidates[0])
    return candidates[0]

helper(D/'initial-verify.log', 'verify')
assert snapshot(D/'baseline-before.json') == '298b4b8941cee672135b2bdb2c0ba84ceae8a08fb396d389d695a4a9e97d691b'
write(D/'authorization.json', {'parent_approval':'Proceed exact16variants17invocations after controls source review8b072f0da5d75c617bde0e5fd2a22a6841acbb6469cf4eb20bef9fd66efedcd9; preserve classifications, restore1363 then rerun68+80+normal/redb+hooks', 'control_manifest_sha256':sha((C/'manifest.json').read_bytes()), 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
results = []
for variant in manifest['variants']:
    vdir = D/variant['id']; vdir.mkdir(exist_ok=False)
    write(vdir/'variant.json', variant)
    shutil.copyfile(C/variant['runtime_file'], vdir/'worker.rs')
    shutil.copyfile(C/variant['patch'], vdir/'runtime.patch')
    result = {'variant':variant['id'], 'build':None, 'tests':[]}
    try:
        helper(vdir/'apply.log', 'apply', variant['id'])
        before = snapshot(vdir/'source-before-build.json')
        command = ['bazel', '--output_base=/tmp/bazel-canonical-worker-materialization', 'build', '--jobs=4', '--build_event_json_file='+str(vdir/'build-bep.json'), '//tools/canonical-filesystem:ownership_test']
        write(vdir/'build-command.json', {'argv':command, 'cwd':str(W), 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        start = time.monotonic()
        with (vdir/'build-stdout.log').open('wb') as out, (vdir/'build-stderr.log').open('wb') as err:
            built = subprocess.run(command, cwd=W, stdout=out, stderr=err)
        after = snapshot(vdir/'source-after-build.json')
        assert before == after
        result['build'] = {'exit_code':built.returncode, 'elapsed_seconds':time.monotonic()-start, 'source_before_sha256':before, 'source_after_sha256':after}
        write(vdir/'build-result.json', result['build'])
        if built.returncode:
            result['classification'] = 'invalid_control_compile_or_build_failure'
        else:
            artifact = collect_elf(vdir)
            result['elf_sha256'] = artifact['sha256']
            for i, oracle in enumerate(variant['oracles']):
                tdir = vdir/f'test-{i+1:02}'; tdir.mkdir()
                before_test = snapshot(tdir/'source-before.json')
                command = [str(vdir/'ownership_test'), '--exact', oracle['name'], '--nocapture']
                write(tdir/'command.json', {'argv':command, 'cwd':str(W), 'env_overrides':{'RUST_TEST_THREADS':'1'}, 'timeout_seconds':60, 'elf_sha256':artifact['sha256'], 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
                assert sha((vdir/'ownership_test').read_bytes()) == artifact['sha256']
                start = time.monotonic(); timeout = False
                with (tdir/'stdout.log').open('wb') as out, (tdir/'stderr.log').open('wb') as err:
                    try:
                        tested = subprocess.run(command, cwd=W, env={**os.environ, 'RUST_TEST_THREADS':'1'}, stdout=out, stderr=err, timeout=60)
                        code = tested.returncode
                    except subprocess.TimeoutExpired:
                        timeout = True; code = None
                after_test = snapshot(tdir/'source-after.json')
                assert before_test == after_test == before
                stdout = (tdir/'stdout.log').read_text(errors='replace'); stderr = (tdir/'stderr.log').read_text(errors='replace')
                counts = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
                named = re.findall(r'^test (\S+) \.\.\. (\S+)$', stdout, re.M)
                test_result = {'name':oracle['name'], 'exit_code':code, 'timed_out':timeout, 'elapsed_seconds':time.monotonic()-start, 'rust_summaries':counts, 'named_results':named, 'source_before_sha256':before_test, 'source_after_sha256':after_test, 'stdout_sha256':sha((tdir/'stdout.log').read_bytes()), 'stderr_sha256':sha((tdir/'stderr.log').read_bytes()), 'raw_outcome':'unclassified_requires_stage_review'}
                if timeout: test_result['raw_outcome'] = 'timeout_invalid_until_stage_review'
                elif counts == [('FAILED','0','1','0')] and named == [(oracle['name'],'FAILED')] and code == 101: test_result['raw_outcome'] = 'one_exact_assertion_failure_requires_stage_review'
                elif counts == [('ok','1','0','0')] and named == [(oracle['name'],'ok')] and code == 0: test_result['raw_outcome'] = 'survived_selected_test'
                else: test_result['raw_outcome'] = 'invalid_or_unexpected_test_result'
                write(tdir/'result.json', test_result); result['tests'].append(test_result)
                print(json.dumps({'variant':variant['id'], 'test':oracle['name'], 'exit_code':code, 'raw_outcome':test_result['raw_outcome'], 'stderr':stderr[-1800:]}), flush=True)
    finally:
        helper(vdir/'restore.log', 'restore')
        assert snapshot(vdir/'source-restored.json') == '298b4b8941cee672135b2bdb2c0ba84ceae8a08fb396d389d695a4a9e97d691b'
    write(vdir/'result.json', result); results.append(result)
    write(D/'campaign-results.json', results)
    print(json.dumps({'variant':variant['id'], 'build_exit':result['build']['exit_code'], 'restored':True}), flush=True)
helper(D/'final-verify.log', 'verify')
assert snapshot(D/'baseline-after.json') == '298b4b8941cee672135b2bdb2c0ba84ceae8a08fb396d389d695a4a9e97d691b'
print('CAMPAIGN COMPLETE: all16variants restored; inspect exact stage outcomes before classification.', flush=True)
