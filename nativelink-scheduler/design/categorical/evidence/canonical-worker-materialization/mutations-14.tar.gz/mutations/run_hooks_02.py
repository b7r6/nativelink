import pathlib, subprocess, os, hashlib, json, time
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=pathlib.Path(__file__).resolve().parent/'hooks-02';D.mkdir(exist_ok=False)
C=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-controls')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
records=json.loads((C/'positive/source-before.json').read_text())
def snap(name):
 out=[]
 for r in records:
  p=W/r['path']
  if p.is_file():
   b=p.read_bytes();out.append({'path':r['path'],'bytes':len(b),'sha256':sha(b)})
  else:out.append({'path':r['path'],'missing':True})
 write(D/name,out);return out
before=snap('source-before.json')
changes=[(a,b) for a,b in zip(records,before) if a!=b]
assert len(changes)==1 and changes[0][0]['path']=='tools/canonical-filesystem/README.md'
(D/'README-before.md').write_bytes((C/'base-source/tools/canonical-filesystem/README.md').read_bytes())
(D/'README-after.md').write_bytes((W/'tools/canonical-filesystem/README.md').read_bytes())
write(D/'docs-only-delta.json',{'changes':changes,'reason':'Replace historical uncompiled source-checkpoint statement with completed qualification results; runtime and all frozen tests unchanged.'})
config=D/'precommit-config.yaml';config.write_bytes(pathlib.Path('/tmp/nativelink-current-precommit-config.json').read_bytes())
files=['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/README.md','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/tests.rs','tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/worker_tests.rs']
commands=[('rustfmt',['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--check','--edition','2024',*files[2:]],{}),('precommit',['pre-commit','run','--config',str(config),'--files',*files],{'SKIP':'machete,rustfmt'}),('diff-check',['git','diff','--check'],{})]
results=[]
for name,argv,overrides in commands:
 write(D/(name+'-command.json'),{'argv':argv,'cwd':str(W),'env_overrides':overrides,'skip_reason':'Cargo lane reserved by authority_core; direct pinned nightly rustfmt plus default Bazel fmt/Clippy already run; no dependency changes, cargo-machete omitted.' if name=='precommit' else None})
 start=time.monotonic()
 with (D/(name+'.log')).open('wb') as out:
  p=subprocess.run(argv,cwd=W,env={**os.environ,**overrides},stdout=out,stderr=subprocess.STDOUT)
 result={'name':name,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'log_sha256':sha((D/(name+'.log')).read_bytes())};results.append(result);print(json.dumps(result),flush=True);print((D/(name+'.log')).read_text()[-5000:],flush=True)
after=snap('source-after.json')
write(D/'results.json',{'commands':results,'sources_unchanged':before==after,'source_files':len(before),'source_before_sha256':sha((D/'source-before.json').read_bytes()),'source_after_sha256':sha((D/'source-after.json').read_bytes())})
assert before==after,'Hook modified frozen source; inspect and explicitly refreeze before continuing'
