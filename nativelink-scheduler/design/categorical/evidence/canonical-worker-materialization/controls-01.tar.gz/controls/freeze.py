import pathlib,json,hashlib,difflib,re,subprocess
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-controls')
E=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-evidence')
R=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-runtime-review')
P='tools/canonical-filesystem/src/worker.rs';T='tools/canonical-filesystem/src/worker_tests.rs'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,obj):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
def cp(p,n):
 q=D/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
base=(W/P).read_text();tests=(W/T).read_text()
assert sha(base.encode())=='149815cc62b9467d47dcc059105cb29319d335f5482afdf4343423bb0f96bbee'
assert sha(tests.encode())=='cafb721735aeb7f8bc2d6faafa9e40f1feaadd8bec9ca49d4f46d77377bd424d'
for f in ['summary.json','command.json','test-summary.json','artifacts.json','source-before.json']:
 cp(E/'attempt-02'/f,'positive/'+f)
cp(E/'library-build-01/summary.json','positive/library-summary.json')
cp(E/'library-build-01/artifacts.json','positive/library-artifacts.json')
source=[]
for r in json.loads((R/'sources.json').read_text())['files']:
 p=r['path'];b=(W/p).read_bytes();cp(W/p,'base-source/'+p);source.append({'path':p,'copy':'base-source/'+p,'sha256':sha(b),'bytes':len(b)})
source_sha=dump('base-sources.json',source)
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
def cut(s,start,end,replacement):
 a=s.index(start);b=s.index(end,a);return s[:a]+replacement+s[b:]
def test(name):
 full='worker_'+name;m=re.search(r'^fn '+full+r'\(',tests,re.M);assert m,full
 return {'name':'tests::worker::'+full,'line':tests[:m.start()].count('\n')+1,'test_source_sha256':sha(tests.encode())}
variants=[]
def add(id,s,oracles,classification,stage,expected):
 assert s!=base
 folder=D/id;folder.mkdir(exist_ok=True);p=folder/'worker.rs';p.write_text(s)
 fmt=['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config-path',str(W/'.rustfmt.toml'),str(p)]
 r=subprocess.run(fmt,capture_output=True,text=True);assert r.returncode==0,(id,r.stderr)
 s=p.read_text();(folder/'runtime.patch').write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='base/'+P,tofile=id+'/'+P)))
 row={'id':id,'runtime_file':str(p.relative_to(D)),'runtime_sha256':sha(s.encode()),'patch':str((folder/'runtime.patch').relative_to(D)),'oracles':[test(x) for x in oracles],'expected_classification':classification,'required_stage':stage,'expected_result':expected,'current_status':'Frozen source only, not applied or compiled'}
 variants.append(row)
# C01: cold root guard only, with imports made consistent.
s=cut(base,'        let mut entries = Dir::read_from(root)','        let mut opened = Vec::with_capacity(CHILDREN.len());','')
s=replace(s,'AtFlags, Dir, FileType','AtFlags, FileType');s=replace(s,'DIRECTORY_FLAGS, OWNERSHIP_RECORD, Ownership','DIRECTORY_FLAGS, Ownership')
add('C01',s,['cold_layout_refuses_unknown_partial_and_special_state_without_mutation'],'expected_semantic_failure','kind0: real claimed Worker root contains unknown regular file, then actual layout creation runs','assert_error observes unexpected Ok on worker_root_not_empty; later partial-layout cases are not reached/countable')
s=replace(base,'        mkdirat(&self.0.actions, name.as_str(), Mode::RWXU)\n            .map_err(|_| failure("create_worker_action"))?;','''        match mkdirat(&self.0.actions, name.as_str(), Mode::RWXU) {
            Ok(()) | Err(Errno::EXIST) => {}
            Err(_) => return Err(failure("create_worker_action")),
        }''')
add('C02',s,['action_and_pending_id_collisions_never_adopt_or_overwrite'],'expected_semantic_failure','real initial action and sentinel exist; duplicate mkdir EEXIST is adopted and actual open succeeds','assert_error observes Ok instead of create_worker_action; pending-name branch not reached')
s=replace(base,'    _ownership: Arc<Ownership>,','    _ownership: (),');s=replace(s,'            _ownership: Arc::clone(ownership),','            _ownership: (),')
add('C03',s,['each_descendant_alone_retains_all_four_role_locks'],'expected_semantic_failure','kind0 OwnedWorkerFs survives after original Ownership drop; independent root flock probe runs','held assertion sees Ok instead of WOULDBLOCK, first role only; descendant/closure tests share same custody defect and are not separate mutation classes')
a=base.index('    pub(super) fn create_action(');b=base.index('    pub(super) fn begin_input(',a);block=base[a:b]
block=replace(block,'        let name = format!("action-{:032x}", id.0);','''        let name = format!("action-{:032x}", id.0);
        let configured = &self.0._ownership.roots.iter()
            .find(|root| root.role == Role::Worker).unwrap().path;
        let actions = rustix::fs::open(
            std::path::Path::new(configured).join("actions"),
            DIRECTORY_FLAGS, Mode::empty(),
        ).map_err(|_| failure("open_worker_action"))?;''')
block=replace(block,'&self.0.actions','&actions',2);s=base[:a]+block+base[b:]
add('C04',s,['each_fixed_child_rename_keeps_pinned_directory_operations'],'expected_semantic_failure','input/staging rename branches still pass; actions rename branch calls actual ambient open of replaced actions symlink','create_action unwrap gets open_worker_action instead of succeeding on pinned original. This is lost descriptor-relative availability, not an outside sentinel-write claim; NOFOLLOW remains enabled')
a=base.index('    pub(super) fn copy_into(');start=base.index('        self.check_for(action)?;',a);end=base.index('\n    }\n\n    #[cfg(test)]',start)
s=base[:start]+'''        self.link_into(action, name)?;
        apply_metadata(&self.file, metadata)'''+base[end:]
add('C05',s,['private_metadata_copy_does_not_change_other_action_or_input'],'expected_semantic_failure','first executable/private metadata case performs real link and fchmod/futimens on shared input','private inode assert_ne fails; later shared-metadata assertions do not execute, do not count them as separate catches')
probe='''    if read_retry(source, &mut buffer[..1]).map_err(|_| failure("read_worker_input"))? != 0 {
        return Err(failure("worker_input_size_mismatch"));
    }
'''
s=replace(base,probe,'')
add('C06',s,['short_and_overlong_streams_never_publish_input_capability'],'expected_semantic_failure','short first case still refuses; second declared3/data4 actual copy omits mandatory EOF','assert_error sees unexpected completed input rather than worker_input_size_mismatch; zero-size later branch not reached')
s=replace(base,'''        if declared_size > QUALIFICATION_MAX_INPUT_BYTES {
            return Err(failure("worker_input_too_large"));
        }
''','')
add('C07',s,['declared_size_above_qualification_limit_refuses_before_creation'],'expected_semantic_failure','first cap+1 declaration reaches actual staging exclusive create','assert_error sees unexpected PendingWorkerInput; u64MAX case not reached; no allocation or production-budget claim')
s=replace(base,'''            self.file
                .write_all(bytes)
                .map_err(|_| failure("write_worker_input"))?;''','''            self.file.write_all(bytes).unwrap_or_default();''')
add('C08',s,['actual_write_syscall_failure_cannot_be_reported_as_ready'],'expected_refusal_preserved_error_contract_failure','reached=true after sameinode RDONLY substitution; actual second write fails EBADF but is swallowed; final fstat guard still runs','expected worker_input_size_mismatch refusal instead of write_worker_input. Selected test fails on error-code distinction; this is NOT unsafe ready/publication or a caught readiness safety failure. Record actual result/survivor honestly')
s=replace(base,'.map_err(|_| failure("mode_worker_input"))','.or(Ok(()))',2)
add('C09',s,['actual_fchmod_failure_cannot_be_reported_as_ready'],'expected_semantic_failure','reached=true and real O_PATH fchmod fails; both real finalization callsites ignore mode errors','assert_error sees unexpected WorkerInput; do not count pre-stage type/open refusal as detection')
s=replace(base,'        drop(file);','        drop(reader);');s=replace(s,'            file: File::from(reader),','            file,')
add('C10',s,['completed_input_retains_a_read_only_descriptor'],'expected_semantic_failure','actual readonly reopened descriptor is dropped; original RDWR descriptor survives chmod and publication; test_write_attempt invokes real write','expect_err fails because retained RDWR handle successfully writes; mode0444 alone does not revoke it')
s=replace(base,'''        let stat = named_file(
            &self.directories.inputs,
            &self.name,
            &self.file,
            false,
            "worker_input_replaced",
        )?;''','''        let stat = fstat(&self.file).map_err(|_| failure("stat_worker_file"))?;
        regular(&stat, false)?;''')
add('C11',s,['replaced_input_name_cannot_redirect_hardlink_to_another_inode'],'expected_semantic_failure','samefamily retained source remains real; original name replaced by same-size other regular file; real linkat uses replacement name','assert_error sees Ok rather than worker_input_replaced; source pending checks remain intact')
s=replace(base,'.map_err(|_| failure("mtime_worker_file"))?;','.unwrap_or_default();')
add('C12',s,['private_metadata_failure_preserves_partial_file_and_shared_input'],'expected_semantic_failure','real futimens receives invalid nanoseconds and fails; return is swallowed','assert_error sees successful private copy rather than mtime_worker_file')
a=base.index('    fn create_file(');b=base.index('    pub(super) fn create_empty(',a);block=base[a:b]
block=replace(block,'        absent(&self.directory, &name.0, "worker_destination_exists")?;\n','');block=replace(block,'            CREATE_FLAGS,','            CREATE_FLAGS & !OFlags::EXCL,');s=base[:a]+block+base[b:]
add('C13',s,['existing_regular_symlink_directory_fifo_destinations_are_preserved'],'expected_refusal_after_unauthorized_write','all link cases unchanged; copy operation1/kind0 opens existing8byte file, writes3bytes; final size guard rejects8!=3','expected worker_input_size_mismatch instead of worker_destination_exists. Test stops on error-code assertion before later byte assertions. Do not claim directly observed preserved/sentinel bytes or unsafe ready; overwritten prefix is source-stage inference. Do not add TRUNC to manufacture acceptance')
s=replace(base,'''        if !Arc::ptr_eq(&self.directories, &action.directories) {
            return Err(failure("different_worker_capability"));
        }
''','');s=replace(s,'fn check_for(&self, action: &ActionWorkspace)','fn check_for(&self, _action: &ActionWorkspace)')
add('C14_C15',s,['cross_namespace_link_refuses_equal_ids_without_mutation','cross_namespace_copy_refuses_equal_ids_without_mutation'],'expected_semantic_failure','each separate oracle establishes own-family success over real eight-root/two-Ownership fixture then performs first cross-family operation','assert_error sees unexpected Ok rather than different_worker_capability; same frozen mutation exercised by two tests, not two independent mutation variants; reverse direction not reached after first assertion')
s=replace(base,'''    loop {
        match source.read(bytes) {
            Err(error) if error.kind() == io::ErrorKind::Interrupted => {}
            result => return result,
        }
    }
''','''    source.read(bytes)
''')
add('C16_copy',s,['finite_interrupted_reads_retry_mid_copy_and_mandatory_eof'],'expected_semantic_failure','first scripted Interrupted occurs at actual first copy read; no retry','copy_from unwrap receives read_worker_input; no claim later mid-copy/EOF branches were reached in this variant')
s=replace(base,'if read_retry(source, &mut buffer[..1]).map_err(|_| failure("read_worker_input"))? != 0','if source.read(&mut buffer[..1]).map_err(|_| failure("read_worker_input"))? != 0')
add('C16_eof',s,['finite_interrupted_reads_retry_mid_copy_and_mandatory_eof'],'expected_semantic_failure','copy-loop retry unchanged: first2interruptions and3bytes succeed, then first mandatoryEOF Interrupted is returned','copy_from unwrap receives read_worker_input after physical prefix; frozen exact callsite isolates EOF retry. No infinite-interruption liveness claim')
assert len(variants)==16 and len({v['runtime_sha256'] for v in variants})==16
manifest={
 'base_commit':'255fa9c0fb3d2abeb170aee9f7deff8f100b17ec','runtime_path':P,'base_runtime_sha256':sha(base.encode()),'test_path':T,'test_source_sha256':sha(tests.encode()),'base_sources_sha256':source_sha,
 'status':'Exact16distinct source variants frozen for review; none applied, built or executed. Original13 plus shared cross-family control and two Interrupted paths.17planned exact test invocations because cross-family variant has two oracles.',
 'positive':'Uncached ownership68PASS/journal80PASS, all33worker tests in each; normal/redb libraries buildPASS. Evidence paths copied in positive/.',
 'scope':'Only worker.rs may change in any variant. Tests and all other1362 source/config records must remain exact. Cargo never invoked. No public/factory change.',
 'variants':variants,
 'execution_plan':{
  'approval':'Parent must review manifest/patches before any application. This freeze does not authorize mutation execution.',
  'apply':'Guarded apply.py verify/apply/restore checks all1363positive source hashes, overriding only worker.rs to a known variant. Reject unknown source changes; restore immediately after every variant.',
  'build':['bazel','--output_base=/tmp/bazel-canonical-worker-materialization','build','--jobs=4','--build_event_json_file=<variant-build-bep>','//tools/canonical-filesystem:ownership_test'],
  'build_note':'Bazel build compiles actual test ELF; default rustfmt/clippy test outputgroups are not requested for intentionally defective variants. Preserve compile failures as invalid controls, never caught.',
  'run':'Copied actual ELF, RUST_TEST_THREADS=1, --exact <oracle.name> --nocapture; subprocess timeout60s. Record ELF hash from BEP, command, raw logs, exit, sourcebefore/after, exact failure/test count. Zero tests/timeouts before stage/setup/dependency failures are invalid, not semantic catches.',
  'restore':'Restore exact149815... runtime after each; final baseline ownership+journal tests uncached with default test formatting/clippy. Check current sources equal positive manifest before restored run.',
  'classification':'C08 and C13 explicitly predict refusal still preserved by independent final-size guard, despite selected error-contract assertion failing. Report exact guard/first assertion; do not inflate unsafe-success detection. One first-failing loop branch is one observation. Uncompilable/no-stage mutations remain invalid. No variant yet executed.'
 }
}
manifest_sha=dump('manifest.json',manifest)
verification=dump('verification.json',{'variants':16,'distinct_runtime_hashes':16,'planned_exact_test_invocations':17,'original13_plus_addendum':True,'base_runtime_sha256':sha(base.encode()),'approved_test_bytes_unchanged':True,'all_variants_only_worker_rs':True,'rustfmt_syntax_format_passed':True,'no_variants_applied_or_compiled':True,'worktree_runtime_unchanged':(W/P).read_text()==base,'manifest_sha256':manifest_sha})
print(json.dumps({'manifest_sha256':manifest_sha,'verification_sha256':verification,'variants':16,'test_invocations':17},indent=2))
