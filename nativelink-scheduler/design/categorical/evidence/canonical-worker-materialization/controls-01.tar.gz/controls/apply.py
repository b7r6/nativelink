import pathlib,json,hashlib,sys
D=pathlib.Path(__file__).resolve().parent
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
manifest=json.loads((D/'manifest.json').read_text())
records=json.loads((D/'positive/source-before.json').read_text())
runtime=manifest['runtime_path']
variants={x['id']:x for x in manifest['variants']}
def sha(b):return hashlib.sha256(b).hexdigest()
def check(runtime_sha):
 for r in records:
  p=W/r['path']
  if r.get('missing'):
   assert not p.exists(),f"Expected absent source {p}"
  else:
   expected=runtime_sha if r['path']==runtime else r['sha256']
   assert sha(p.read_bytes())==expected,f"Source guard mismatch: {p}"
for v in variants.values():assert sha((D/v['runtime_file']).read_bytes())==v['runtime_sha256']
assert sha((D/'base-source'/runtime).read_bytes())==manifest['base_runtime_sha256']
action=sys.argv[1]
current=sha((W/runtime).read_bytes())
if action=='verify':
 assert current in {manifest['base_runtime_sha256']}|{v['runtime_sha256'] for v in variants.values()}
 check(current)
 print(json.dumps({'action':'verify','source_files':len(records),'runtime_sha256':current,'worktree_edited':False}))
elif action=='apply':
 variant=variants[sys.argv[2]]
 check(manifest['base_runtime_sha256'])
 (W/runtime).write_bytes((D/variant['runtime_file']).read_bytes())
 check(variant['runtime_sha256'])
 print(json.dumps({'action':'apply','variant':variant['id'],'runtime_sha256':variant['runtime_sha256']}))
elif action=='restore':
 assert current in {manifest['base_runtime_sha256']}|{v['runtime_sha256'] for v in variants.values()},'Unknown runtime bytes; refusing overwrite'
 check(current)
 (W/runtime).write_bytes((D/'base-source'/runtime).read_bytes())
 check(manifest['base_runtime_sha256'])
 print(json.dumps({'action':'restore','runtime_sha256':manifest['base_runtime_sha256']}))
else:raise ValueError('Expected verify, apply <variant>, or restore')
