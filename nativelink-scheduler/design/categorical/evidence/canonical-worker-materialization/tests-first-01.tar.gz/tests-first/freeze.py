import hashlib,json,pathlib,re,subprocess,datetime
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-first')
BASE='255fa9c0fb3d2abeb170aee9f7deff8f100b17ec'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
assert git('rev-parse','HEAD').decode().strip()==BASE
changed=['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/src/tests.rs','tools/canonical-filesystem/src/worker_tests.rs']
assert sorted(git('diff','--name-only').decode().splitlines())==changed[:2]
assert git('ls-files','--others','--exclude-standard').decode().splitlines()==[changed[2]]
paths=git('ls-tree','-r','--name-only',BASE,'--','tools/canonical-filesystem','tools/canonical-config').decode().splitlines()
paths += ['.rustfmt.toml','.claude/skills/nativelink-rust-change/SKILL.md','nativelink-scheduler/design/categorical/source-plan.md','nativelink-worker/src/running_actions_manager.rs']
inputs=[]
for path in paths:
 b=git('show',BASE+':'+path)
 if path not in changed:assert (W/path).read_bytes()==b,path
 p=D/'base-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 inputs.append({'path':path,'copy':'base-source/'+path,'bytes':len(b),'sha256':sha(b)})
current=[]
for path in changed:
 b=(W/path).read_bytes();p=D/'candidate-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 current.append({'path':path,'copy':'candidate-source/'+path,'bytes':len(b),'sha256':sha(b)})
original=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-review/proposal.json').read_bytes()
assert sha(original)=='8263506056cf45070592d7dedc4a1ec3da41e8ab7c57fcea8dba125f3db307b4'
(D/'prior-approved-proposal.json').write_bytes(original)
(D/'tracked-tests-only.patch').write_bytes(git('diff','--binary'))
text=(W/changed[2]).read_text();lines=text.splitlines()
tests=[{'name':m.group(1),'line':text[:m.start()].count('\n')+1} for m in re.finditer(r'^fn (worker_[a-z0-9_]+)\(',text,re.M)]
assert len(tests)==30
names={x['name']:x for x in tests}
def test(s):
 name='worker_'+s
 assert name in names,name
 return names[name]
construction={
 'boundary':'Future implementation is private tools/canonical-filesystem/src/worker.rs, introduced only after review. Propose #[cfg(test)] mod worker in lib.rs: no non-test library construction, no public export. Add source to existing two library src lists so manual ownership_test and redb journal_test can compile it. Existing fixture remains the sole constructor caller. This checkpoint contains no worker module or lib.rs edit.',
 'types':[
  {'type':'OwnedWorkerFs','constructor':'create(&Arc<Ownership>) -> Result<Self, Error>','custody':'Own Arc<WorkerDirectories>; WorkerDirectories stores inputs/staging/actions OwnedFd and Arc<Ownership> last. Select existing Role::Worker root descriptor; no root string, caller FD, or path accepted.'},
  {'type':'ActionId(u128), InputId(u128)','meaning':'Caller-chosen exclusive leaf identity only. Encodings action-{id:032x}, input-{id:032x}, staging pending-{id:032x}. Not durable generation, action authorization, or incarnation authority.'},
  {'type':'EntryName','constructor':'new(&str) rejects empty/dot/dot-dot/slash/NUL before mutation; retains only one UTF-8 leaf. No root path accessor.'},
  {'type':'ActionWorkspace','constructor':'OwnedWorkerFs::create_action(ActionId)','custody':'Exclusive mkdirat then openat DIRECTORY|NOFOLLOW|CLOEXEC; private action OwnedFd before Arc<WorkerDirectories> so child closes before last locks. Preexisting name fails; never adopts.'},
  {'type':'PendingWorkerInput','constructor':'OwnedWorkerFs::begin_input(InputId, declared_size:u64)','custody':'Reject size above fixed qualification cap before creation. Open staging file RDWR|CREATE|EXCL|NOFOLLOW|NONBLOCK|CLOEXEC mode0600, require regular nlink1. Holds private writer, typed leaf/size and Arc directories. Drop only closes; no unlink or recursive cleanup.'},
  {'type':'WorkerInput','constructor':'PendingWorkerInput::copy_from(&mut impl Read) consumes pending on either success/error','custody':'Actual separate Worker inode. Retains RDONLY File, typed original input name, declared size, Arc directories. No Write/Seek/rawFD/File/path conversion, no Clone escape. Only filesystem staging/custody, never hash verification.'},
  {'type':'WorkerFileMetadata','shape':'executable:bool, unix_mode:Option<u32>, mtime:Option<rustix::fs::Timespec>; Default false/None/None','meaning':'Per-action private inode settings. Preserve existing requested-mode semantics for covered ordinary permissions: custom mode unchanged or OR0111 if executable; default executable0555; no requested mode on plain private file leaves exclusive creation mode0600.'}
 ],
 'cold_creation':['Enumerate pinned Worker root. Permit only dot entries and OWNERSHIP_RECORD; any other entry rejects worker_root_not_empty before creating children. Do not remove or rewrite records.','mkdirat inputs/staging/actions with0700 then open with existing DIRECTORY_FLAGS. No rollback or automatic adoption after partial I/O. Retained directory FDs remain the operation targets even after parent/child rename.','No Worker reopen, resync, restart purge, directory traversal or recursive child workspace creation in this slice. Existing namespace reopen is only a lock-release test, not worker reconstruction.'],
 'staging_order':['Check pending opened/named inode identity and regular nlink1 before using a named publication; a replaced source name cannot be adopted. Repeat relevant checks before rename.','Read/write through one fixed8192-byte buffer until exactly declared size, requesting at most remaining bytes; retry Interrupted in real I/O as appropriate. Read one additional byte to require EOF. Zero declared size still reads once. Short, extra, or error => no WorkerInput. Overlong may consume only declared+1 and must write at most declared.','All writes go to fresh Worker staging inode. ReadHandle is consumed only as Read input; do not reach through its private File or reinterpret its digest leaf as proof.','fchmod staging inode0444 must succeed. Open original staging inode RDONLY|NOFOLLOW|NONBLOCK|CLOEXEC and verify it matches; close all writable access before returning input. Runtime review must inspect this ordering; a test-only write attempt through the retained descriptor must fail with real EBADF.','Rename staging to inputs with RENAME_NOREPLACE relative to pinned directories after observed destination absence and identity checks. Any existing regular/symbolic/directory/FIFO destination returns worker_input_exists without replacement. On success no staging name remains; on failure preserve partial artifacts. No fsync/durability acknowledgment claimed.'],
 'materialization':['WorkerInput::link_into(&ActionWorkspace,&EntryName) checks same directory capability family, verifies original named source still equals retained File, and requires ordinary regular inode; managed Worker hardlinks are allowed here, unlike canonical CAS regular(). linkat between pinned input/action directories with no overwrite; do not use /proc/self/fd or configured paths. Retain both capabilities through syscall completion.','WorkerInput::copy_into(&ActionWorkspace,&EntryName,WorkerFileMetadata) uses exclusive new action inode, fixed-buffer read of retained readonly input (e.g. FileExt::read_at to avoid shared cursor changes), exact length/EOF accounting, descriptor fchmod/futimens. Mode/mtime operations never touch shared input inode. Per-action copy returns unit only after success; errors preserve partial action file.','ActionWorkspace::create_empty(&EntryName,WorkerFileMetadata) creates a new exclusive private inode directly, applies metadata, and needs no CAS/local input slot. All existing destinations refuse worker_destination_exists without opening/writing them.','No mutation serialization/fencing against hostile writers is claimed. The same cooperative participants that honor Ownership must serialize input namespace changes; check-then-link is not an atomic identity compare under hostile mutation. Readonly mode does not prevent its owner from chmod.'],
 'test_seams':[
  {'api':'PendingWorkerInput::copy_from_with_fault(reader, TestIoFault, &AtomicBool)','scope':'cfg(test) only; shares the actual copy/finalization implementation. No production generic fault policy. Atomic reached is set only once descriptor substitution is complete and immediately before the physical operation.','write':'ReadOnlyWriterAfterFirstChunk: first8192 bytes really written. Reopen the same staging inode RDONLY with identity check and replace the private writer, so the next actual File::write_all fails EBADF. No synthetic returned write error.','mode':'PathOnlyModeDescriptor: after complete copy, open same staging inode O_PATH|NOFOLLOW|CLOEXEC with identity check; call the real fchmod on that descriptor so it fails EBADF. Do not skip the actual syscall or fabricate its return.'},
  {'api':'WorkerInput::test_write_attempt(&mut self)->io::Result<usize>','scope':'cfg(test) only; direct File::write of one byte through the retained input descriptor. No raw descriptor exposure, reopen, or unconditional fabricated failure.'}
 ],
 'failure_semantics':'Error code strings fixed in tests. Unknown/duplicate/special state preserves bytes and object identity. No success handle may escape after copy, EOF, write, mode, metadata, identity or publication refusal. Some action-private failures leave a visible partial file; this private substrate provides no admission/execution path that can mistake it for completion.'
}
controls=[
 {'id':'C01','change':'Omit Worker cold-directory enumeration while retaining real mkdir/open operations.','test':test('cold_layout_refuses_unknown_partial_and_special_state_without_mutation'),'expected':'kind0 unknown regular entry is unexpectedly accepted, assert_error panics; later EEXIST is not counted as detection.'},
 {'id':'C02','change':'Adopt preexisting action directory after EEXIST; leave mkdir/open otherwise real.','test':test('action_and_pending_id_collisions_never_adopt_or_overwrite'),'expected':'duplicate action returns Ok and assert_error panics while sentinel remains.'},
 {'id':'C03','change':'Remove effective Arc<Ownership> retention from Worker directories/descendant chain, retaining real data descriptors.','test':test('each_descendant_alone_retains_all_four_role_locks'),'expected':'held independent lock probe succeeds while descendant lives. Need compile and reach probe; no absent API evidence.'},
 {'id':'C04','change':'Reopen configured path instead of using pinned directory for actual stage/link operations.','test':test('each_fixed_child_rename_keeps_pinned_directory_operations'),'expected':'positive operation fails or writes decoy at known rename branch. Require successful baseline + reached mutation operation; unrelated dependency/setup failures invalid. Root/ancestor/action-specific tests should also run.'},
 {'id':'C05','change':'Private metadata materialization uses worker input hardlink then applies actual fchmod/futimens.','test':test('private_metadata_copy_does_not_change_other_action_or_input'),'expected':'private-inode or independent shared-input/other-action metadata assertion fails. Actual successful link and metadata stage required.'},
 {'id':'C06','change':'Ignore the mandatory EOF read after declared bytes.','test':test('short_and_overlong_streams_never_publish_input_capability'),'expected':'declared3/data4 branch returns Ok and assert_error fails; short branch may pass refusal. Secondary read_error_at_expected_eof must also unexpectedly accept.'},
 {'id':'C07','change':'Disable precreation qualification size guard.','test':test('declared_size_above_qualification_limit_refuses_before_creation'),'expected':'first cap+1 begin_input unexpectedly succeeds or creates artifact. Later unrelated allocation failure is not detection.'},
 {'id':'C08','change':'Swallow actual File write failure and permit final publication.','test':test('actual_write_syscall_failure_cannot_be_reported_as_ready'),'expected':'reached is true and result unexpectedly ready or wrong code; require actual EBADF syscall path, not pre-stage failure.'},
 {'id':'C09','change':'Ignore fchmod error on completed staging input.','test':test('actual_fchmod_failure_cannot_be_reported_as_ready'),'expected':'reached true, actual O_PATH fchmod occurred, input improperly returned or expected mode error absent.'},
 {'id':'C10','change':'Keep original RDWR File in WorkerInput after mode0444 instead of replacing/closing writable access.','test':test('completed_input_retains_a_read_only_descriptor'),'expected':'real test_write_attempt unexpectedly writes successfully; expect_err fails. No fake failed write accepted.'},
 {'id':'C11','change':'Remove named input/opened input identity guard before linkat.','test':test('replaced_input_name_cannot_redirect_hardlink_to_another_inode'),'expected':'real replacement inode linked and operation incorrectly succeeds.'},
 {'id':'C12','change':'Ignore actual futimens error when applying requested action metadata.','test':test('private_metadata_failure_preserves_partial_file_and_shared_input'),'expected':'invalid tv_nsec real syscall ran; method incorrectly succeeds instead of mtime_worker_file.'},
 {'id':'C13','change':'Remove O_EXCL or destination existence protection in private action copy while preserving real create/write.','test':test('existing_regular_symlink_directory_fifo_destinations_are_preserved'),'expected':'operation1/kind0 existing regular file is adopted/written instead of worker_destination_exists. NOFOLLOW alone still refuses symlink; those survivors are not hidden.'}
]
proposal={
 'title':'Tests-first private Worker filesystem construction and qualification proposal',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_commit':BASE,'worktree':str(W),'branch':'codex/canonical-worker-materialization',
 'prior_approved_proposal_sha256':sha(original),
 'phase':'Source-only,30 drafted tests; review required before private runtime implementation. No Cargo/Bazel/Rust compilation or tests run. Direct repository nightly rustfmt only.',
 'changed_files':current,
 'construction':construction,
 'finite_qualification_bound':{'max_declared_input_bytes':65536,'copy_buffer_bytes':8192,'extra_eof_probe_bytes':1,'thread_handshake_seconds':5,'meaning':'Experimental per-file qualification limit only. Not a production disk, aggregate tree, input pin, action count, queue or transfer budget; no default production values selected.','scope':'30 finite tests on temporary Linux roots. No network, gateway, worker factory, subprocess execution, symlink action materialization, cleanup or recovery.'},
 'tests':tests,
 'future_execution':{
  'lane':'Wait for parent explicit shared Cargo/Bazel lane authorization. No builds initiated for this proposal.',
  'positive':'After reviewed implementation, explicit manual //tools/canonical-filesystem:ownership_test. Discover/list actual tests and require all30 new names plus existing ownership/capability/namespace tests. Run journal_test where needed to check redb coexistence. Full server/worker regressions deferred until actual worker integration.',
  'limits':'Use target timeout and a60second external limit for selected test ELF calls. Five-second thread handshakes bound setup; timeout before named stage is prerequisite failure, never semantic mutant evidence.',
  'records':'Copy exact candidate/runtime/test/dependency source, command, toolchain/ELF hashes, stdout/stderr/exit status and selected test stage. Positive first, then compiling source mutations one at a time, then exact byte restore and restored positives. Record any test/format edits with replacement frozen hash.',
  'negative_controls':controls,
  'controls_not_claimed':['All13 control entries are currently design proposals; no runtime exists to produce exact mutations yet. Freeze exact source edits after runtime review before applying.','Direct authoritative CAS hardlink requires violating the opaque ReadHandle interface. The positive inode witness is real; an uncompilable source shortcut is not a caught mutation. Source/API boundary review remains required.','Current closure tests detach std::thread JoinHandle; they prove custody of actual blocking closures after waiting handle drop. They do not prove tokio cancellation, worker cleanup, fencing, crash or process death behavior.','Removing closure-specific custody may be structurally coupled to descendant ownership. Do not claim independent mutation diversity from one Arc omission.','Readonly-descriptor probe proves retained input FD cannot write. Closing every other writable handle and never exposing raw File/FD/path still requires runtime/API source review.','No public capability proposed: external compile-fail tests for an intentionally public capability remain deferred. Missing worker module/imports at this checkpoint are expected and not execution evidence.']
 },
 'ownership_and_cas_nonregression':'Existing canonical capability.rs regular() (including st_nlink==1), ReadHandle opacity, Ownership, namespace, journal and all existing tests are byte unchanged. Inputs are copied into different Worker inode before local hardlinks. No canonical store/cas/sink permission, digest or publication semantics change.',
 'remaining_gates':['Whole-tree directory traversal and all memory/pin/disk/transfer admission bounds.','Digest/algorithm/exact size validation at the later fixed gateway/materializer boundary. Raw ReadHandle and arbitrary test digest do not prove content identity.','Owned action execution cwd/namespaces/TMPDIR/output traversal/cleanup/process lifecycle.','Fixed canonical factory/gateway listener/authority worker integration without FastSlow or FilesystemStore downcast.','Production filesystem/host cooperation, actual placement, credentials/routes, supported features, measured budgets, old incarnation fencing and restart disposition. Existing facts saved for morning; no user questions issued.'],
 'review_request':'Review test scope, proposed private contracts, real syscall fault seams and controls. Do not authorize production construction implicitly. Implementation waits for parent review.'
}
inputs_sha=write('inputs.json',{'base_commit':BASE,'inputs':inputs,'prior_proposal_sha256':sha(original)})
proposal_sha=write('proposal.json',proposal)
format_cmd=['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',changed[2],changed[1]]
f=subprocess.run(format_cmd,cwd=W,capture_output=True,text=True)
(D/'rustfmt.stdout').write_text(f.stdout);(D/'rustfmt.stderr').write_text(f.stderr)
assert f.returncode==0
check=subprocess.run(['git','diff','--check'],cwd=W,capture_output=True,text=True);assert check.returncode==0
for record in inputs:
 assert sha((D/record['copy']).read_bytes())==record['sha256']
for record in current:
 assert sha((D/record['copy']).read_bytes())==record['sha256']
 assert (D/record['copy']).read_bytes()==(W/record['path']).read_bytes()
verification_sha=write('verification.json',{'base_commit':BASE,'input_files':len(inputs),'input_bytes':sum(x['bytes'] for x in inputs),'test_count_source_only':30,'runtime_source_exists':(W/'tools/canonical-filesystem/src/worker.rs').exists(),'runtime_lib_unchanged':(W/'tools/canonical-filesystem/src/lib.rs').read_bytes()==git('show',BASE+':tools/canonical-filesystem/src/lib.rs'),'all_copied_hashes_verified':True,'only_three_test_wiring_files_changed':True,'Cargo_Bazel_Rust_compilation_tests_run':False,'formatter_command':format_cmd,'formatter_exit_code':f.returncode,'git_diff_check_exit_code':check.returncode,'tests_expected_not_to_compile_before_runtime':'crate::worker intentionally absent, not tested or counted as a semantic failure','controls_proposed_not_executed':13,'proposal_sha256':proposal_sha,'inputs_sha256':inputs_sha})
receipts=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name not in ['receipts.json','seal.json']:
  b=p.read_bytes();receipts.append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b)})
receipts_sha=write('receipts.json',receipts)
seal={'base_commit':BASE,'proposal_sha256':proposal_sha,'inputs_sha256':inputs_sha,'verification_sha256':verification_sha,'receipts_sha256':receipts_sha,'test_source_sha256':current[2]['sha256']}
seal_sha=write('seal.json',seal)
print(json.dumps({'seal_sha256':seal_sha,**seal,'copied_inputs':len(inputs),'bytes':sum(x['bytes'] for x in inputs),'candidate_bytes':sum(x['bytes'] for x in current),'test_count':len(tests)},indent=2))
