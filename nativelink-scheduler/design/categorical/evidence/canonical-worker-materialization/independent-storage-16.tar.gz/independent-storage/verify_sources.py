import hashlib
import json
from pathlib import Path
import re
import subprocess

E = Path('/tmp/nativelink-canonical-worker-materialization-runtime-review')
W = Path('/tmp/nativelink-canonical-worker-materialization')
R = Path(__file__).parent

def sha(b):
    return hashlib.sha256(b).hexdigest()

def preserve(relative):
    p = E / relative
    b = p.read_bytes()
    target = R / 'evidence' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == b
    else:
        target.write_bytes(b)
    return sha(b)

review_sha = preserve('runtime-review.json')
review = json.loads((E / 'runtime-review.json').read_text())
source_sha = preserve('sources.json')
sources = json.loads((E / 'sources.json').read_text())
assert source_sha == review['sources_sha256']
assert preserve('approved-proposal.json') == review['approved_proposal_sha256']
assert preserve('root-addendum-review.json') == review['approved_root_review_sha256']
for name in ['approved-proposal-seal.json', 'root-initial-review.json', 'tracked-runtime-and-tests.patch', 'receipts.json', 'seal.json', 'verification.json', 'rustfmt.stdout', 'rustfmt.stderr']:
    preserve(name)

head = subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD'], text=True).strip()
assert head == sources['base_commit'] == review['base_commit']
changed = []
for row in sources['files']:
    b = (E / row['copy']).read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
    assert (W / row['path']).read_bytes() == b
    assert preserve(row['copy']) == row['sha256']
    if row['base_sha256'] is not None:
        base = subprocess.check_output(['git', '-C', str(W), 'show', head + ':' + row['path']])
        assert sha(base) == row['base_sha256']
        assert (E / 'base-source' / row['path']).read_bytes() == base
        assert preserve('base-source/' + row['path']) == row['base_sha256']
    if row['base_sha256'] != row['sha256']:
        changed.append(row['path'])
assert sorted(changed) == sorted(sources['changed_files'])

worker_path = 'tools/canonical-filesystem/src/worker.rs'
test_path = 'tools/canonical-filesystem/src/worker_tests.rs'
worker = (W / worker_path).read_text()
tests = (W / test_path).read_text()
proposal = json.loads((E / 'approved-proposal.json').read_text())
assert sha(worker.encode()) == review['runtime_sha256'] == '526d28f3be96d4d79c29fb7e9cf7dadaca184fea0620b382b6bd64f82ea6f681'
assert sha(tests.encode()) == review['test_source_sha256'] == 'cafb721735aeb7f8bc2d6faafa9e40f1feaadd8bec9ca49d4f46d77377bd424d'
assert next(r for r in proposal['changed_files'] if r['path'] == test_path)['sha256'] == review['test_source_sha256']
names = re.findall(r'^fn (worker_\w+)\(', tests, re.M)
assert names == [r['name'] for r in proposal['tests']] and len(names) == 33
library = (W / 'tools/canonical-filesystem/src/lib.rs').read_text()
base_library = (E / 'base-source/tools/canonical-filesystem/src/lib.rs').read_text()
module = '''#[allow(
    dead_code,
    reason = "Private worker capabilities are staged for qualification before canonical factory integration."
)]
mod worker;
'''
assert library == base_library.replace('mod namespace;\n', 'mod namespace;\n' + module, 1)
assert (W / 'tools/canonical-filesystem/BUILD.bazel').read_text().count('"src/worker.rs"') == 2
assert not re.search(r'pub(?:\([^)]*\))?\s+(?:fn|struct|type|enum).*\b(?:AsRawFd|IntoRawFd|AsFd|Deref|AsRef)\b', worker)
assert not re.search(r'^impl\s+(?:Clone|Read|Write|AsRawFd|IntoRawFd|AsFd|Deref|AsRef)(?:<[^\n]*>)?\s+for\s+WorkerInput\b', worker, re.M)

report = {
    'scope': 'Independent ordinary-private worker filesystem runtime source review against approved33tests. No Rust/Cargo/Bazel/compiler execution, source edits, factory integration or runtime qualification.',
    'author_runtime_review_sha256': review_sha,
    'runtime_sha256': review['runtime_sha256'],
    'test_source_sha256': review['test_source_sha256'],
    'source_manifest_sha256': source_sha,
    'base_commit': head,
    'all_selected_live_copied_and_recorded_inputs_exact': len(sources['files']),
    'all_existing_base_copies_match_git_blobs': True,
    'changed_paths': changed,
    'approved33test_source_bytes_and_names_unchanged': True,
    'normal_library_and_redb_build_wiring': 'Ordinary private mod worker, reasoned dead_code allowance only; both Bazel library source lists include worker.rs. Public reexports are byte-unchanged. Fault/write probes alone are cfg(test).',
    'fd_and_custody_review': [
        'WorkerDirectories declares inputs/staging/actions OwnedFd before final Arc<Ownership>; all three child descriptors close before the last role-lock custody is released.',
        'ActionWorkspace directory precedes directories Arc; PendingWorkerInput and WorkerInput File precedes directories Arc. Last descendant therefore owns the complete four-role lock family.',
        'Cold creation borrows Arc<Ownership> through enumeration/create/open operations and error unwinding; created local FDs close before the borrow ends. It does not adopt or delete partial directories.',
        'Pending copy errors retain self with File-first/Arc-last field order. On successful copy, complete same-inode RDONLY reopening and named checks occur while writer and Arc are still held.',
        'Pending destructuring is followed immediately by explicit drop(original writable File), then construction of a private local WorkerInput containing readonly File and Arc-last. No fallible operation occurs in that ownership-transfer gap.',
        'Destination absence/RENAME_NOREPLACE failures drop that local WorkerInput, closing its readonly FD before releasing Arc; no success handle escapes until rename succeeds.',
        'Materialization borrows both input/action handles throughout actual syscall and private-file metadata operations. PositionedReader only borrows retained readonly File and maintains a separate checked offset.',
        'Detached stdthread fixtures move actual descendants into the closure and drop handles before completion signal; they qualify blocking-closure custody, not Tokio task cancellation or process destruction.'
    ],
    'read_copy_and_mutation_review': [
        'begin_input rejects declared size>65536 before creating staging. Each copy read requests min(remaining,8192), rejects zero/past-buffer counts before slicing, writes exactly returned bytes, and decrements bounded remaining.',
        'One-byte EOF read is mandatory even for declared0; extra bytes and read errors refuse. Interrupted retries apply to both body and EOF reads; finite scripted fixture expects7calls/4interruptions/3bytes/1EOF. Infinite Interrupted/blocking-reader liveness is not qualified.',
        'Final fstat length guard independently checks actual written file size; skipping write-error propagation need not produce unsafe success because this guard can still refuse.',
        'Staging uses exclusive RDWR/NOFOLLOW/NONBLOCK creation, verifies regular nlink1 and named/opened dev+ino, then fchmod0444, same-inode RDONLY reopen, another named check, writer close, exclusive pinned-directory rename.',
        'Completed WorkerInput exposes no writable/raw FD/File/path/Clone/read trait or extraction interface; test_write_attempt invokes real File::write on the retained readonly descriptor.',
        'Write-fault seam first completes a real chunk, reopens the same inode RDONLY and replaces/drops the old writer, records reached, then executes real write_all. Mode-fault seam opens same inode O_PATH, records reached, then calls real fchmod. Neither manufactures an error return.',
        'check_for rejects unequal Arc families before source validation or target I/O. Named/opened identity and regular live-link state plus exactsize precede link/copy. Logical IDs are not used as family identity.',
        'linkat uses pinned directories and preserves managed Worker hardlinks; copy_into and create_empty create separate exclusive action inodes. Custom/executable mode and futimens operate only on those private FDs. Plain private-file mode0600 is explicitly approved semantics.',
        'Canonical capability.rs and its regular nlink1 invariant, opaque ReadHandle, namespace/journal sources/tests, manifests/locks and production running_actions_manager remain byte-identical to base.'
    ],
    'source_blockers': [],
    'reviewer_prerequisite': 'An initial unanchored text check mistook a function impl Read argument returning WorkerInput for a trait implementation. Corrected to match actual line-anchored trait impl syntax; source was unchanged and no runtime or compiler failure was inferred.',
    'execution_prerequisites': [
        'Actual normal-library and test compilation remains required; source review does not establish compiler/lint success.',
        'Run the explicitly selected manual ownership test and inspect all33names plus existing coverage; redb/journal coexistence qualification must use the exact source boundary.',
        'Positive tests before separately frozen/compiled mutations; record actual source, executable bytes, target and reached assertion. Missingstage, compile/setup errors and timeout are not semantic detections.',
        'C08 swallowed real write error may be caught by exact_size as a changed refusal code. Preserve that observation rather than claiming corrupt ready-handle acceptance.',
        'Negative loops establish only their first reached failing case. Removing common Arc custody can affect multipletests without representing multiple independent defects.'
    ],
    'limits': [
        'Named dev/ino check then link/rename is not an atomic identity compare against hostile concurrent mutation; cooperative participants must serialize namespace changes.',
        'Readonly mode does not prevent an external owner from chmod or opening a new writable alias. This component closes only its own writer and exposes no writable API.',
        'No digest validation, durable/fsync acknowledgement, aggregate admission, worker incarnation fencing, cleanup, restart adoption, process execution, full input-tree or production factory claim.',
        'Qualification cap/buffer are finite experimental values, not selected production budgets.',
        'Historical tests-first module-absence header remains in frozen test bytes; actual normal private module now exists and is reviewed here.'
    ],
    'verdict': 'No source-level implementation blocker found within the approved private Worker filesystem boundary. Proceed to explicitly authorized compilation and positive qualification; no execution result is claimed by this review.'
}
out = R / 'review.json'
assert not out.exists()
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'review_sha256': sha(out.read_bytes()), 'review_path': str(out), 'selected_sources': len(sources['files']), 'runtime_sha256': review['runtime_sha256'], 'test_count': len(names)}))
