import pathlib,hashlib,json,subprocess,re,difflib
W=pathlib.Path('/tmp/nativelink-canonical-worker-materialization')
D=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-runtime-review')
OLD=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-first')
ADD=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-tests-addendum')
ROOT_REVIEW=pathlib.Path('/tmp/nativelink-canonical-worker-materialization-independent-root-review')
BASE='255fa9c0fb3d2abeb170aee9f7deff8f100b17ec'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n');return sha(p.read_bytes())
def copy(p,name):
 b=p.read_bytes();q=D/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return sha(b)
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
assert git('rev-parse','HEAD').decode().strip()==BASE
assert sha((ADD/'proposal.json').read_bytes())=='6ba903a617663f9402f122d67985c7a1500eec09faad63af976c21739a91f5f7'
assert sha((ROOT_REVIEW/'addendum-review.json').read_bytes())=='c32d0e035aee4e969e293756ef0fc41e2e68ef3a23ac5b8ed4e46b72865de290'
newfiles=['tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/worker_tests.rs']
changed=['tools/canonical-filesystem/BUILD.bazel','tools/canonical-filesystem/README.md','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/tests.rs']
assert sorted(git('diff','--name-only').decode().splitlines())==changed
assert sorted(git('ls-files','--others','--exclude-standard').decode().splitlines())==newfiles
base_inputs=json.loads((OLD/'inputs.json').read_text())['inputs']
inputs=[]
for record in base_inputs:
 p=record['path'];b=(OLD/record['copy']).read_bytes();assert sha(b)==record['sha256']
 if p not in changed:assert(W/p).read_bytes()==b,p
 copy(OLD/record['copy'],'base-source/'+p)
 for prefix,source in [('source',W/p)]:
  data=source.read_bytes();copy(source,prefix+'/'+p);inputs.append({'path':p,'copy':prefix+'/'+p,'bytes':len(data),'sha256':sha(data),'base_sha256':sha(b)})
for p in newfiles:
 data=(W/p).read_bytes();copy(W/p,'source/'+p);inputs.append({'path':p,'copy':'source/'+p,'bytes':len(data),'sha256':sha(data),'base_sha256':None})
for p,n in [(ADD/'proposal.json','approved-proposal.json'),(ADD/'seal.json','approved-proposal-seal.json'),(ROOT_REVIEW/'review.json','root-initial-review.json'),(ROOT_REVIEW/'addendum-review.json','root-addendum-review.json')]:copy(p,n)
source=(W/newfiles[0]).read_text();tests=(W/newfiles[1]).read_bytes()
assert sha(tests)=='cafb721735aeb7f8bc2d6faafa9e40f1feaadd8bec9ca49d4f46d77377bd424d'
assert (W/'tools/canonical-filesystem/src/tests.rs').read_bytes()==(ADD/'candidate-source/tools/canonical-filesystem/src/tests.rs').read_bytes()
(D/'tracked-runtime-and-tests.patch').write_bytes(git('diff','--binary'))
anchors=[]
for m in re.finditer(r'^(?:pub\(super\) )?(?:struct|enum|const) (\w+)|^\s*(?:pub\(super\) )?fn (\w+)\(',source,re.M):
 anchors.append({'name':m.group(1) or m.group(2),'line':source[:m.start()].count('\n')+1})
lib=(W/'tools/canonical-filesystem/src/lib.rs').read_text();base_lib=(OLD/'base-source/tools/canonical-filesystem/src/lib.rs').read_text()
assert re.findall(r'pub use [\s\S]*?;',lib)==re.findall(r'pub use [\s\S]*?;',base_lib)
assert 'mod worker;' in lib and '#[cfg(test)]\nmod worker;' not in lib
assert 'unsafe {' not in source and '/proc/self/fd' not in source and 'AsRawFd' not in source and 'PathBuf' not in source
manifest_sha=write('sources.json',{'base_commit':BASE,'files':inputs,'changed_files':changed+newfiles})
review={
 'title':'Private Worker filesystem runtime source review checkpoint',
 'base_commit':BASE,'worktree':str(W),'branch':'codex/canonical-worker-materialization',
 'approved_proposal_sha256':sha((ADD/'proposal.json').read_bytes()),
 'approved_root_review_sha256':sha((ROOT_REVIEW/'addendum-review.json').read_bytes()),
 'runtime_sha256':sha(source.encode()),'test_source_sha256':sha(tests),'sources_sha256':manifest_sha,
 'status':'Source implementation complete for review. No Cargo/Bazel/Rust compilation, tests, mutation execution or runtime admission. Await parent source review and independent execution-lane authorization.',
 'implementation':[
  {'area':'Normal private library module','detail':'lib.rs has ordinary mod worker and narrow dead_code allowance with staged-no-factory reason. Both existing Bazel library src lists include worker.rs. Types are pub(super) within private module; root pub use exports unchanged. Only deterministic fault and physical-write-probe seams are cfg(test).'},
  {'area':'Cold layout and custody','detail':'WorkerDirectories holds pinned inputs/staging/actions descriptors and Arc<Ownership> last. OwnedWorkerFs creates only from retained RoleWorker descriptor after record-only preflight. ActionWorkspace/PendingWorkerInput/WorkerInput hold descriptors first and directories Arc last. Exclusive typed IDs and one-component names; no ambient path opener, raw FD/File escape, deletion, adoption, reopen or recursive walk.'},
  {'area':'Separate worker input','detail':'begin_input checks65536 before creation. copy_exact uses8192 buffer, remaining-length accounting, Interrupted retries, one-byte EOF probe, explicit read/write errors. Final fstat verifies actual staged file length independently. Copy source only implements Read; real ReadHandle fixture uses intentionally arbitrary digest leaf so no digest proof is implied.'},
  {'area':'Close writable access and publish','detail':'Apply mode0444 via observable fchmod. Reopen same pinned staging inode RDONLY with type/inode verification, check named identity, explicitly drop the original writable File. Construct readonly WorkerInput only as a private local holding FD+Arc, then check destination and RENAME_NOREPLACE. Return it only after success. The local value also closes its FD before releasing Arc when publication fails; no partial artifact removal.'},
  {'area':'Action materialization','detail':'check_for rejects differing directory Arc families before target I/O and validates source named/opened inode and size. Local hardlinks use linkat between pinned descriptors; worker regular permits managed links but canonical CAS regular remains unchanged. Private copies read_at through retained readonly source with independent offset; create new exclusive inode then fchmod/futimens. Empty files are independent exclusive inodes. Errors preserve partial action files.'},
  {'area':'Real syscall fault seams','detail':'Test-only write fault after first completed chunk reopens same inode RDONLY, replaces original writer, sets reached, calls real write_all for next chunk. Test-only mode fault opens same inode O_PATH, sets reached then calls real fchmod. Readonly descriptor probe calls actual File::write. No manufactured error return replaces these operations.'},
  {'area':'Documentation','detail':'README private staging section identifies no factory/public interface, finite qualification cap/buffer, no digest/durability/aggregate admission/whole-tree/runtime claims, cooperative mutation limits, and33 unexecuted source tests.'}
 ],
 'anchors':anchors,
 'preserved_boundaries':[
  'All33 approved test source bytes unchanged; tests.rs wiring unchanged from approved addendum. Tests-first header describes the original preimplementation checkpoint and was retained with the frozen test bytes.',
  'capability.rs/capability_tests.rs, namespace.rs/namespace_tests.rs, journal.rs/journal_tests.rs unchanged; canonical CAS single-link and opaque ReadHandle contracts unchanged.',
  'No Cargo.toml/Cargo.lock/dependency, root worker factory, nativelink-worker runtime, server, config, listener or public re-export change.',
  'No fsync or durable acknowledgment, no digest check, no resource/transfer admission, cleanup, process execution, production budget, incarnation fencing or production construction.'
 ],
 'negative_control_expectations':[
  'No proposed negative mutation has been applied or compiled. Exact mutation source and target stages must be frozen after runtime review and before execution.',
  'C08 swallowing a write failure can reach independent exact_size final fstat and remain refused. The selected expected write-error assertion might then fail on error-code difference, but that is not unsafe success. Report actual refusal/survivor honestly.',
  'Custody is structurally in WorkerDirectories Arc chain. Removing one Arc can affect several tests; do not count those as independent defect classes.',
  'Read retry loop intentionally only qualifies the finite scripted Interrupted fixture. Arbitrary infinite Interrupted or blocking I/O liveness remains unqualified.',
  'Configured path reopening mutant may require explicit mutant-only source fields; zero tests/uncompilable shortcut/failed setup is not detection.'
 ],
 'review_request':'Review source and its match to approved33 tests before any execution. No additional public API or production construction is requested.'
}
review_sha=write('runtime-review.json',review)
fmt=['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check','tools/canonical-filesystem/src/worker.rs','tools/canonical-filesystem/src/lib.rs','tools/canonical-filesystem/src/worker_tests.rs','tools/canonical-filesystem/src/tests.rs']
r=subprocess.run(fmt,cwd=W,capture_output=True,text=True);assert r.returncode==0
(D/'rustfmt.stdout').write_text(r.stdout);(D/'rustfmt.stderr').write_text(r.stderr)
r2=subprocess.run(['git','diff','--check'],cwd=W,capture_output=True,text=True);assert r2.returncode==0
for x in inputs:assert sha((D/x['copy']).read_bytes())==x['sha256']==sha((W/x['path']).read_bytes())
verify_sha=write('verification.json',{'base_commit':BASE,'source_inputs':len(inputs),'source_bytes':sum(x['bytes'] for x in inputs),'source_tests':33,'all_current_and_copied_source_hashes_verified':True,'approved_test_bytes_unchanged':True,'canonical_cas_namespace_journal_source_and_tests_unchanged':True,'public_reexports_unchanged':True,'worker_module_not_cfg_test':True,'only_six_scope_files_changed':True,'no_compilation_or_execution':True,'nightly_rustfmt_command':fmt,'nightly_rustfmt_exit':r.returncode,'git_diff_check_exit':r2.returncode,'runtime_review_sha256':review_sha,'sources_sha256':manifest_sha})
receipts=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and not(p.parent==D and p.name in ['receipts.json','seal.json']):
  b=p.read_bytes();receipts.append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b)})
receipts_sha=write('receipts.json',receipts)
seal={'base_commit':BASE,'runtime_review_sha256':review_sha,'runtime_sha256':sha(source.encode()),'test_source_sha256':sha(tests),'sources_sha256':manifest_sha,'verification_sha256':verify_sha,'receipts_sha256':receipts_sha}
seal_sha=write('seal.json',seal)
print(json.dumps({'seal_sha256':seal_sha,**seal,'copied_inputs':len(inputs),'source_bytes':sum(x['bytes'] for x in inputs)},indent=2))
