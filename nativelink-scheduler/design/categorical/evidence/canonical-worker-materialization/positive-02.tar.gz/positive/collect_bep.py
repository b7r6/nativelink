import pathlib,json,hashlib,urllib.parse,re,sys
D=pathlib.Path(sys.argv[1]);events=[json.loads(x) for x in (D/'bep.json').read_text().splitlines()]
sets={e['id']['namedSet']['id']:e['namedSetOfFiles'] for e in events if 'namedSetOfFiles' in e}
def resolve(id):
 s=sets[id];out=s.get('files',[]).copy()
 for child in s.get('fileSets',[]):out.extend(resolve(child['id']))
 return out
def sha(b):return hashlib.sha256(b).hexdigest()
artifacts=[];test_summaries=[]
for e in events:
 t=e.get('id',{}).get('targetCompleted',{})
 if t and not t.get('aspect') and e.get('completed',{}).get('success'):
  label=t['label'];name=label.rsplit(':',1)[1]
  for group in e['completed'].get('outputGroup',[]):
   if group['name']!='default':continue
   for id in group.get('fileSets',[]):
    for output in resolve(id['id']):
     uri=output.get('uri','')
     if not uri.startswith('file://'):continue
     p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(uri).path));b=p.read_bytes()
     if b[:4]!=b'\x7fELF':continue
     assert output.get('digest',sha(b))==sha(b)
     dest=D/'elf'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);dest.chmod(0o755)
     artifacts.append({'label':label,'kind':'test_elf','source_uri':uri,'bep_sha256':output.get('digest'),'sha256':sha(b),'bytes':len(b),'copy':str(dest.relative_to(D))})
 if 'testResult' in e:
  label=e['id']['testResult']['label'];name=label.rsplit(':',1)[1]
  for o in e['testResult'].get('testActionOutput',[]):
   uri=o.get('uri','')
   if not uri.startswith('file://'):continue
   p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(uri).path));b=p.read_bytes();dest=D/'testlogs'/name/o['name'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
   artifacts.append({'label':label,'kind':o['name'],'source_uri':uri,'sha256':sha(b),'bytes':len(b),'copy':str(dest.relative_to(D))})
   if o['name']=='test.log':
    text=b.decode();counts=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    worker_passes=re.findall(r'^test tests::worker::(worker_\w+) \.\.\. ok$',text,re.M)
    assert len(worker_passes)==33 and len(set(worker_passes))==33
    test_summaries.append({'label':label,'bep_status':e['testResult']['status'],'all_rust_summaries':counts,'final_rust_summary':counts[-1],'worker_tests_passed':worker_passes,'cachedLocally':e['testResult'].get('cachedLocally',False)})
(D/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n');(D/'test-summary.json').write_text(json.dumps(test_summaries,indent=2)+'\n')
print(json.dumps({'test_summaries':[{k:v for k,v in s.items() if k!='worker_tests_passed'} for s in test_summaries],'elfs':[a for a in artifacts if a['kind']=='test_elf']},indent=2))
