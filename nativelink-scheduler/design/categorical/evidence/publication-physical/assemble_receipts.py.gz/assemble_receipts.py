from pathlib import Path
import difflib,gzip,hashlib,json,subprocess
root=Path('/tmp/nativelink-publication-physical')
e=Path('/tmp/nativelink-categorical-evidence/publication-physical')
sha=lambda data:hashlib.sha256(data).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert base=='27d010a3ef19b1a24d76b760625323b5bce3a51c'
inputs={'/tmp/nativelink-publication-candidate-frozen.patch':'a3cc5586f6253c717f480fb01e1e45b822a842fac31f93f32948a88088b1efed','/tmp/nativelink-publication-candidate-postfreeze.patch':'3b5a41393cd7f46e1211679f1de8ae619470c25f17774b7547357ab740a6cd5a'}
for f,h in inputs.items():assert sha(Path(f).read_bytes())==h
frozen=json.loads((e/'candidate-source-sha256.json').read_text())
assert all(sha((root/f).read_bytes())==h for f,h in frozen.items())
checks=['run03','strict-clippy-final','rustfmt-check','buildifier-check','vale-check','typos-check','git-diff-check']
runs={name:json.loads((e/(name+'.json')).read_text()) for name in checks}
assert all(r['exit_code']==0 for r in runs.values())
for receipt in runs.values():
 for f,h in receipt.get('source_sha256',{}).items():assert sha((root/f).read_bytes())==h
log=(e/'run03.log').read_text();assert '9 passed; 0 failed; 0 ignored' in log and 'SKIP' not in log
markers=[line for line in log.splitlines() if 'PUBLICATION_PHYSICAL:' in line]
assert len(markers)==8
assert sum('PUBLICATION_PHYSICAL: SHA256;' in line for line in markers)==4
assert sum('PUBLICATION_PHYSICAL: BLAKE3;' in line for line in markers)==4
owned=['nativelink-scheduler/tests/publication_physical_test.rs','nativelink-scheduler/tests/publication_physical/fixture.rs','nativelink-scheduler/tests/publication_physical/cases.rs','nativelink-scheduler/design/categorical/publication-physical.md']
# Export only this composition, excluding the supplied candidate patches.
parts=[]
for f in owned:
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',f],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert r.returncode==1,r.stderr
 parts.append(r.stdout)
f='nativelink-scheduler/BUILD.bazel';final=(root/f).read_text();marker='\nrust_test(\n    name = "publication_physical_test",'
assert final.count(marker)==1
a=final.index(marker);b=final.index('\n)\n',a)+3
baseline=final[:a]+final[b:]
parts.append(('diff --git a/'+f+' b/'+f+'\n'+''.join(difflib.unified_diff(baseline.splitlines(keepends=True),final.splitlines(keepends=True),fromfile='a/'+f,tofile='b/'+f))).encode())
patch=b''.join(parts);(e/'publication-physical.patch').write_bytes(patch)
owned.append(f)
for f in owned+list(frozen)+['nativelink-store/src/physical_filesystem.rs','nativelink-store/src/physical_closure.rs']:
 p=e/'final-source'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/f).read_bytes())
qualification={
 'base_commit':base,'required_input_patches':inputs,'patch_sha256':sha(patch),'owned_source_sha256':{f:sha((root/f).read_bytes()) for f in owned},'unchanged_candidate_and_coarse_sha256':frozen,
 'scope':'Bounded local singleton composition of actual PhysicalFilesystem and typed Preparation with the supplied frozen PublicationAuthority candidate embedding real State and Coarse. No publication reference implementation was read. No candidate implementation changes were made.',
 'coverage':{'new_physical_cases':8,'existing_imported_coarse_snapshot_case':1,'algorithms':['SHA256 physical objects','BLAKE3 physical objects'],'scenario_physical_members':6,'scenario_typed_edges':8,'all_installations_ready_false':True,'staging_committed_before_begin_write':True,'observations_require_exact_write_receipt_and_whole_verified_read':True,'prepared_evidence_from_real_reads_and_independent_expected_edges':True,'full_namespace_and_incarnation_last_byte_distinctions':True,'atomic_worker_terminal_head_and_roots':True,'old_operation_and_serving_reads_after_replacement':True,'stale_selection_and_barrier_refused':True,'index_loss_does_not_choose_result':True,'late_abandoned_writes_do_not_choose_head':True,'checkpoint_cuts':['completed local writes before all observations','prepared outer candidate','accepted outer candidate'],'preparation_refusals':['incomplete walker','missing physical binding','omitted closure member','substituted full namespace','stale catalogue revision while walker is in progress','stale prepared revision at Publish','stale retirement fence'],'strict_checks':checks[1:]},
 'failures_retained':[{'run':'run01','reason':'Two replacement cases submitted operation2 after joined operation3; real State correctly returned Scheduler(Stale). Fixture now submits cache-hit operation4. Other seven tests passed.'},{'run':'strict-clippy','reason':'Four success-marker lines used Debug formatting; replaced with explicit SHA256/BLAKE3 labels.'},{'run':'initial-doc-lint','reason':'Vale rejected resultless; wording changed to errors without an ActionResult. Initial diagnostic was observed in tool output; final Vale receipt retained.'}],
 'limits':['Frozen candidate admission uses its SHA256 placeholder ActionKey and opaque qualified-action string; BLAKE3 coverage is physical storage/preparation/publication, not REAPI digest normalization.','Local singleton outer commit counter is the fixture serving barrier; no Raft or provider read-barrier claim.','Checkpoint recovery cuts occur after all local physical write functions returned. Missing observations are reconciled from exact reads and snapshot stable write identities; no remote writer quiescence claim.','Known finite graphs independently provide conservative prewrite staging sets. Arbitrary untrusted RPC closure completeness is unqualified.','No provider deletion, production activation, load/sizing or accepted-history feature composition claim.','Focused Cargo/Clippy verification here; parent owns warm-root Bazel integration.'],
 'bazel_target':'//nativelink-scheduler:publication_physical_test','runs':runs,
}
(e/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
bundle=e/'receipt-bundle';bundle.mkdir(exist_ok=False)
files={}
for p in sorted(e.rglob('*')):
 if not p.is_file() or bundle in p.parents:continue
 rel=p.relative_to(e);raw=p.read_bytes()
 if p.suffix=='.log' or '-source' in str(rel):dest=bundle/(str(rel)+'.gz');data=gzip.compress(raw,mtime=0)
 else:dest=bundle/rel;data=raw
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 files[str(dest.relative_to(bundle))]={'sha256':sha(data),'bytes':len(data),'raw_sha256':sha(raw),'raw_bytes':len(raw)}
manifest={'base_commit':base,'patch_sha256':sha(patch),'qualification_sha256':sha((e/'qualification.json').read_bytes()),'artifacts':files}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for f,meta in files.items():assert sha((bundle/f).read_bytes())==meta['sha256']
print(json.dumps({'patch_sha256':sha(patch),'qualification_sha256':manifest['qualification_sha256'],'manifest_sha256':sha((bundle/'manifest.json').read_bytes()),'artifact_count':len(files),'bundle_bytes':sum(p.stat().st_size for p in bundle.rglob('*') if p.is_file())},indent=2))
