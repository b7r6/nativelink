from pathlib import Path
import hashlib, json, shutil, tarfile

root = Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
src = Path('/tmp/nativelink-categorical-evidence/canonical-recovered-worker-root-integration')
dst = Path('/tmp/nativelink-canonical-recovered-worker-root-package')
review = Path('/tmp/nativelink-canonical-recovered-worker-root-independent-review')
assert (review / 'review.json').is_file()
dst.mkdir(exist_ok=False)
(src / 'independent-review').mkdir()
for path in review.iterdir():
    if path.is_file():
        shutil.copy2(path, src / 'independent-review' / path.name)
shutil.copytree('/tmp/nativelink-canonical-worker-root-packet-verification', src / 'integration-history', ignore=shutil.ignore_patterns('packet'))
shutil.copy2('/tmp/nativelink-canonical-recovered-worker-root-cherry.log', src / 'integration-history' / 'cherry-pick.log')
shutil.copy2(__file__, src / 'package.py')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def record(path):
    return {'path': str(path.relative_to(src)), 'bytes': path.stat().st_size, 'sha256': sha(path)}

archives = []
def archive(name, files):
    path = dst / name
    members = [record(p) for p in files]
    with tarfile.open(path, 'w:gz', compresslevel=6) as stream:
        for member in members:
            stream.add(src / member['path'], arcname=member['path'], recursive=False)
    entry = {'name': name, 'bytes': path.stat().st_size, 'sha256': sha(path), 'members': members, 'parts': []}
    maximum = 45 * 1024 * 1024
    if path.stat().st_size > maximum:
        with path.open('rb') as stream:
            index = 0
            while chunk := stream.read(maximum):
                part = dst / (name + f'.part-{index:03}')
                part.write_bytes(chunk)
                entry['parts'].append({'path': part.name, 'bytes': len(chunk), 'sha256': sha(part)})
                index += 1
        digest = hashlib.sha256()
        for part in entry['parts']:
            digest.update((dst / part['path']).read_bytes())
        assert digest.hexdigest() == entry['sha256']
        path.unlink()
    else:
        entry['parts'].append({'path': name, 'bytes': path.stat().st_size, 'sha256': entry['sha256']})
    archives.append(entry)
    print('Packed', name, len(members), 'members', entry['bytes'], 'compressed bytes', flush=True)

for path in sorted((src / 'binaries').rglob('*')):
    if path.is_file():
        archive('executable-' + str(path.relative_to(src / 'binaries')).replace('/', '-') + '.tar.gz', [path])
archive('sources-and-runs.tar.gz', [path for path in sorted(src.rglob('*')) if path.is_file() and not str(path.relative_to(src)).startswith('binaries/')])
result = json.loads((src / 'result.json').read_text())
totals = [sum(count[i] for groups in result['rust_counts'].values() for count in groups) for i in range(3)]
assert result['exit_code'] == 0 and result['sources_unchanged'] and totals == [378, 0, 1]
manifest = {'scope': 'Root integration of the closed recovered owner with private worker materialization. Production constructors and execution remain legacy.', 'head': result['head'], 'execution': json.loads((src / 'execution.json').read_text()), 'source_inputs': result['source_inputs'], 'test_totals': totals, 'targets_executed': 6, 'cached_test_results': 0, 'retained_elf_count': len(result['binaries']), 'independent_review_sha256': sha(review / 'review.json'), 'archives': archives, 'limits': ['Focused integration, not a full workspace run or production construction.', 'Every tracked non-evidence input copied and unchanged; generated configuration contents retained separately. No hermetic dependency closure or reproducible-build claim.', 'All six test executables and the server executable match exact BEP digests. Component author faults remain separate evidence.', 'No cold initialization or seal writer, exposed clock, periodic driver, serving readiness or production workload claim.']}
(dst / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
shutil.copy2('/tmp/verify-canonical-recovery-components-packet.py', dst / 'verify.py')
seal = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(dst.iterdir())}
(dst / 'seal.json').write_text(json.dumps(seal, indent=2) + '\n')
print('Manifest', sha(dst / 'manifest.json'), 'seal', sha(dst / 'seal.json'), flush=True)
