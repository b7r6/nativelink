# Activation-only independent reference evidence

The implementation and scenario expectations were written independently in
`/tmp/nativelink-publication-activation-reference`, based at
`ec22f03826b67ebd6a39a3d8001a315241b39288`. No activation candidate exists in this
qualification. No production activation, accepted-history reducer, receipt
algorithm, provider implementation, or old reference implementation was read or
copied for the activation model. The standalone Bazel target imports only
blake3, serde, serde_json, and sha2. Cargo compiles the workspace as a dependency
but the test source imports no production NativeLink code.

Normative inputs were `source-plan.md` (M4-to-M6 activation and publication
sections), `typed-output-closure.md`, `typed-retention-bridge.md`,
`physical-filesystem.md`, and `publication-ordering.md` under the categorical
design directory. Copies and hashes are archived. Public contract clarifications
from the root agent were incorporated before freezing:

1. Successful activation needs complete retained-root coverage; quarantine is a
   migration blocker, never a successful release.
2. The current M4 outbox does not enumerate every provider send. Initial draft
   request rows were made optional evidence, with separate opaque effect
   exposure and explicit complete-effect quiescence. Preexisting observations
   and quiescence records survive as original facts.
3. Already consumed effects may have forgotten duplicate requests. A separate
   opaque legacy-domain obligation survives an empty retained outbox. It does
   not reconstruct deleted effects or invent send IDs.

The initial 13-test source and log are preserved. The subsequent 14-test
effect-exposure run and 15-test domain-exposure run are also preserved. These
were corrections to this new reference's contract before any candidate
comparison, not expected-output adjustments to make a candidate pass. The final
15 tests add exact unresolved-effect/domain assertions. Rust lint fixes changed
visibility, const helpers, statement punctuation, and a local variable used to
avoid Clippy's suspicious-operation-groupings false positive. Initial failed
lint output is preserved, with successful final logs separately named.

Cargo and Clippy used the already warm target directory
`/tmp/nativelink-history-differential-target`, profile `smol`, and eight jobs.
Bazel used the already warm `/tmp/nativelink-accepted-history-reference`
workspace, at older base `c32897774415d514ad30427f0f331ed36fd84808`, with the same
standalone target and byte-identical Rust sources. This avoids a large new
dependency cache. No frozen accepted-history files were changed; before/after
hashes are in `warm-bazel-provenance.json`. That record's README hash precedes
the final qualification prose only. `final-source-manifest.json` records the
final README and all final Rust files.

The 12 mutants were applied one at a time to the new reference only. Each was
compiled with `cargo test --no-run` before executing the resulting test binary.
All 12 compiled and failed semantic expectations in unchanged tests. No compiler
rejection is counted as a kill. Both baseline and restored sources passed all
15 tests, with identical source and binary hashes. Exact mutant source, delta,
compile output, assertion output, and classification are archived. Two guards
that enforce one invariant during transition and restore were changed together
where needed; the mutation driver records exact replacement counts. The
preexisting-observation and late-head-change mutants are killed partly by
internal invariant checks causing a valid scenario to reject; these are
positive-behavior regression kills, not claims that those guards are absent.

This is an activation-only finite reference. It does not implement or qualify a
production activation path, consensus, provider fencing, closure traversal,
retirement concurrency, proof authenticity, future head publication, direct
Action Cache updates, or an externally accessible service. The exact original
legacy inventory and external physical/protection facts are scenario-owned.
Successful snapshot restore establishes structural invariants and original
inventory preservation, not authenticity of arbitrary replacements for trusted
external evidence. Unidentified late requests remain covered by opaque exposure;
the model refuses to fabricate an identity for an observation.
