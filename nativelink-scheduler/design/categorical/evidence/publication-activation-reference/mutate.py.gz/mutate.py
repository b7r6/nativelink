#!/usr/bin/env python3
"""Compile each one-contract mutant before counting assertion-level kills."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-publication-activation-reference')
evidence = Path('/tmp/nativelink-publication-activation-evidence')
source = root / 'nativelink-scheduler/tests/publication_activation/reference.rs'
original = source.read_text()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-differential-target')
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p',
           'nativelink-scheduler', '--test', 'publication_activation_reference_test', '--no-run']
binary = Path(env['CARGO_TARGET_DIR']) / 'smol/deps/publication_activation_reference_test-2bac1c6366daf75d'

# All expectations and fixtures remain unchanged. Some invariants are checked
# both during reduction and restore; those coupled guards form one mutation.
mutants = [
    ('omit-retained-effect-dispositions', [
        ('activation.dispositions.keys().ne(legacy.effects.keys())', 'false', 1)]),
    ('alias-old-and-new-physical-domains', [
        ('old.physical_domain == new.physical_domain', 'false', 2)]),
    ('ignore-exact-typed-closure', [
        ('if proof.typed != root.required {', 'if false {', 1)]),
    ('ignore-current-retirement-fence', [
        ('if !proof.fences.is_subset(&facts.fences) {', 'if false {', 1)]),
    ('retired-generation-is-ready', [
        ('if row.state != Readiness::Ready {', 'if row.state == Readiness::Writing {', 1)]),
    ('settle-without-complete-effect-quiescence', [
        ('if !self.quiesced_effects.contains(&effect)\n                            && !facts.quiescent_effects.contains(&effect)',
         'if false', 1)]),
    ('empty-request-map-clears-opaque-effect', [
        ('.filter(|effect| !self.quiesced_effects.contains(effect))',
         '.filter(|effect| !self.quiesced_effects.contains(effect) && requests(&self.legacy).keys().any(|request| effect_of(*request) == *effect))', 1)]),
    ('empty-outbox-clears-opaque-domain', [
        ('!self.domain_quiesced\n    }', '!self.domain_quiesced && !self.legacy.effects.is_empty()\n    }', 1),
        ('pub(crate) const fn unresolved_legacy_domain', 'pub(crate) fn unresolved_legacy_domain', 1)]),
    ('revalidate-original-worker-at-import', [
        ('if !facts.migration_publishers.contains(&import.publisher) {',
         'let origin = self.legacy.terminals[&import.terminal].origin;\n                    if !facts.current_workers.contains(&(origin.worker, origin.incarnation)) || !facts.migration_publishers.contains(&import.publisher) {', 1)]),
    ('discard-preexisting-late-outcomes', [
        ('observations: legacy.late_outcomes.clone(),', 'observations: BTreeSet::new(),', 1)]),
    ('late-old-sink-outcome-selects-head', [
        ('if !self.observations.insert(Observation {',
         'if request.kind == EffectKind::Sink && *outcome == Delivery::Stored {\n                    let terminal = self.legacy.effects[&request.effect].terminal;\n                    for head in &mut self.heads { head.terminal = terminal; }\n                }\n                if !self.observations.insert(Observation {', 1)]),
    ('ignore-physical-incarnation', [
        ('.find(|row| row.key == *key)', '.find(|row| row.key.namespace == key.namespace && row.key.number == key.number)', 1),
        ('row.key == generation && row.object == member.object',
         'row.key.namespace == generation.namespace && row.key.number == generation.number && row.object == member.object', 1)]),
]

def run(name, changed):
    folder = evidence / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    source.write_text(changed)
    (folder / 'reference.rs').write_text(changed)
    with (folder / 'compile.log').open('wb') as log:
        compile_result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'source_sha256': hashlib.sha256(changed.encode()).hexdigest(),
              'compile_command': command, 'compile_status': compile_result.returncode}
    if compile_result.returncode:
        result['classification'] = 'COMPILE_REJECTED_NOT_A_KILL'
    else:
        result['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        with (folder / 'test.log').open('wb') as log:
            test_result = subprocess.run([str(binary)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        result['test_status'] = test_result.returncode
        result['classification'] = 'PASS' if not test_result.returncode else 'COMPILED_ASSERTION_KILL'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

results = []
try:
    baseline = run('baseline', original)
    assert baseline['classification'] == 'PASS', baseline
    for name, replacements in mutants:
        changed = original
        for old, new, count in replacements:
            assert changed.count(old) == count, (name, old, changed.count(old), count)
            changed = changed.replace(old, new)
        results.append(run(name, changed))
finally:
    source.write_text(original)
    restored = run('restored', original)
    (evidence / 'mutation-results.json').write_text(json.dumps({
        'baseline': baseline, 'mutants': results, 'restored': restored,
        'source_restored_exactly': source.read_text() == original,
    }, indent=2) + '\n')

assert restored['classification'] == 'PASS', restored
assert all(result['classification'] == 'COMPILED_ASSERTION_KILL' for result in results), results
