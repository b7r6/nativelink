// Copyright 2026 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};

pub const MAX_TERMINALS: usize = 8;
pub const MAX_EFFECTS: usize = 16;
pub const MAX_ROOTS: usize = 16;
pub const MAX_MEMBERS: usize = 32;
pub const MAX_REQUESTS: usize = 32;
pub const MAX_PAYLOAD_BYTES: usize = 4096;
pub const MAX_SNAPSHOT_BYTES: usize = 512 * 1024;

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub struct Namespace(pub [u8; 16]);

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub enum Algorithm {
    Sha256,
    Blake3,
}

#[derive(Clone, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Object {
    pub algorithm: Algorithm,
    pub hash: [u8; 32],
    pub bytes: u64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Generation {
    pub namespace: Namespace,
    pub incarnation: [u8; 16],
    pub number: u64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub enum Role {
    Result,
    History,
    Blob,
    Directory,
    Tree,
}

#[derive(Clone, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Member {
    pub object: Object,
    pub generation: Generation,
    pub role: Role,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Origin {
    pub epoch: u64,
    pub accepted_commit: u64,
    pub execution: u64,
    pub attempt: u64,
    pub worker: u64,
    pub incarnation: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Terminal {
    pub id: u64,
    pub action: String,
    pub origin: Origin,
    pub operations: BTreeSet<u64>,
    pub response: Vec<u8>,
    pub result: Object,
    pub result_bytes: Vec<u8>,
    pub ac_eligible: bool,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub enum Delivery {
    Issued,
    Unknown,
    Stored,
    Failed,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SinkEffect {
    pub id: u64,
    pub terminal: u64,
    pub destination: Namespace,
    pub payload: Vec<u8>,
    pub requests: BTreeMap<u64, Delivery>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HistoryEffect {
    pub id: u64,
    pub terminal: u64,
    pub origin: Origin,
    pub destination: Namespace,
    pub object: Object,
    pub payload: Vec<u8>,
    pub requests: BTreeMap<u64, Delivery>,
    pub materialized: bool,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub enum Subject {
    Result(u64),
    History(u64),
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Root {
    pub id: u64,
    pub subject: Subject,
    pub object: Object,
    /// Complete typed closure supplied independently by the scenario.
    pub required: BTreeSet<Member>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Legacy {
    pub old_sink: Namespace,
    pub terminals: BTreeMap<u64, Terminal>,
    pub effects: BTreeMap<u64, SinkEffect>,
    pub histories: BTreeMap<u64, HistoryEffect>,
    pub roots: BTreeMap<u64, Root>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub enum EffectKind {
    Sink,
    History,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RequestRef {
    pub kind: EffectKind,
    pub effect: u64,
    pub request: u64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Observation {
    pub request: RequestRef,
    pub outcome: Delivery,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum Readiness {
    Ready,
    Writing,
    Retired,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CatalogueRow {
    pub key: Generation,
    pub object: Object,
    pub state: Readiness,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Fence {
    pub namespace: Namespace,
    pub revision: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Protection {
    pub id: u64,
    pub root: u64,
    pub catalogue_revision: u64,
    pub complete: bool,
    pub verified: bool,
    pub typed: BTreeSet<Member>,
    pub protected: BTreeSet<Generation>,
    pub fences: BTreeSet<Fence>,
    pub until: u64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Binding {
    pub namespace: Namespace,
    /// Independently qualified destination identity; aliases share this value.
    pub physical_domain: [u8; 32],
    pub old_requests_confined: bool,
}

#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Facts {
    pub now: u64,
    pub catalogue_revision: u64,
    pub catalogue: Vec<CatalogueRow>,
    pub fences: BTreeSet<Fence>,
    pub protections: BTreeMap<u64, Protection>,
    pub bindings: Vec<Binding>,
    pub cold: BTreeSet<Namespace>,
    pub migration_publishers: BTreeSet<u64>,
    pub quiescent: BTreeSet<RequestRef>,
    /// Deliberately irrelevant to authority already recorded at acceptance.
    pub current_workers: BTreeSet<(u64, u64)>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum Disposition {
    Settled,
    Converted { publication: u64 },
    Retired,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Import {
    pub publication: u64,
    pub terminal: u64,
    pub publisher: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Activation {
    pub commit: u64,
    pub new_namespace: Namespace,
    pub dispositions: BTreeMap<u64, Disposition>,
    pub imports: Vec<Import>,
    pub protections: BTreeMap<u64, u64>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Head {
    pub action: String,
    pub publication: u64,
    pub terminal: u64,
    pub publisher: u64,
    pub origin: Origin,
    pub commit: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub enum Event {
    Activate(Activation),
    Observe {
        request: RequestRef,
        destination: Namespace,
        object: Object,
        outcome: Delivery,
    },
    Quiesce(RequestRef),
    Protect {
        root: u64,
        evidence: u64,
    },
    EnableCollection {
        namespace: Namespace,
        through: u64,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Outcome {
    Applied,
    Ignored,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Reject {
    Invalid,
    Bounds,
    Incomplete,
    Namespace,
    Unprotected,
    Stale,
    Unauthorized,
    WrongPhase,
    Uncertain,
    Conflict,
}
