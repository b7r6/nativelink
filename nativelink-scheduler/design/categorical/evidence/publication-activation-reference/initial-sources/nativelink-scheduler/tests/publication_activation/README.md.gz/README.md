# M4-to-M6 activation-only reference

This independent finite reference covers the committed transition and retained
obligations. It has no publication engine, Raft implementation, provider driver,
production activation switch, or claim that M6 is complete. Its inputs are
scenario-owned facts; no candidate implementation supplied these expectations.
The normative sources are the M4-to-M6 activation section and immutable
publication/retention rules in `../../design/categorical/source-plan.md`, plus
`typed-output-closure.md` and `physical-filesystem.md` in that directory.

## Contract

The legacy inventory contains accepted terminal bytes and original acceptance
provenance, every persisted mutable-sink effect, every separately issued request
(including unknown outcomes), retained history effects and exact immutable bytes,
and a complete finite set of retained result/history roots. Activation requires
an explicit disposition for exactly every old sink effect: settled, converted to
an explicit selected import, or retired. All original records survive unchanged.
A successful retry does not settle another unknown request. Retirement does not
prove a request stopped. Late observations and independently proven quiescence
remain representable after the legacy driver disappears.

The new view starts cold unless the committed activation explicitly names
imports. Imports require an authorized migration publisher, original accepted
provenance, eligibility for AC, and complete verified protection. Revocation of
the former worker never invalidates accepted authority. This bounded reference
allows at most one selected import per action at the activation boundary; future
publication ordering and direct updates belong to the later publication model.
Late old outcomes cannot select a head or modify any terminal response.

Both old and new logical namespaces require externally qualified physical
bindings. Equal namespaces or aliased physical destinations are rejected. The
new namespace must be independently established cold; issued old requests must
remain confined to the old destination. There is no guessed destination or
implicit import. This model never grants collection ownership over the old sink.
That conservative scope does not settle any unresolved request.

Every retained result and history root requires complete coverage before
activation succeeds. Missing evidence is a migration blocker: the transition is
refused and all original obligations remain. A quarantine label cannot waive an
obligation or turn refusal into a release claim. Pending history retains its
original effect identity, bytes, destination, request uncertainty, and accepted
origin. A pending acknowledgment can coexist with verified physical bytes; a
pending object that cannot yet be verified blocks this oracle's activation.

Typed completeness and physical verification are independently supplied facts,
not inferred from digest-shaped bytes or physical presence. The oracle compares
against the scenario's exact typed member set, checks the full physical
incarnation/generation and current catalogue/fences, requires ready generations,
and checks protection covering every required generation. Once acquired,
coverage remains an authority obligation; this model does not implement expiry
or retirement. Collection permission is bounded by all retained-root deadlines.
A later fence change does not retroactively revoke a valid acquisition.

## Deliberate limits and ambiguities

The plan leaves the production migration command schema, import ordering within
one commit, proof transport, and protection of history bytes not yet physically
materialized to later design. This oracle chooses explicit imports with unique
action keys, externally verified evidence, and refusal until every retained root
has protection. These are finite qualification choices, not operator selectors.
The old-effect inventory must be obtained at the same committed boundary as
activation by the eventual implementation; a caller-supplied partial inventory
cannot establish completeness in production. Here the scenario owns the entire
universe and the command must account for every member.

The root inventory states exact required typed edges. Protobuf traversal,
provider durability, acquisition/retirement concurrency, consensus, operational
namespace qualification, collector execution, future head changes, and proof
cryptography are outside this transition reference. No provenance reference
implicitly retains an action's input graph. Bounds are fixture limits, not a
production capacity or performance claim.
