# Independent terminal adapter review

Reviewer: `scheduler_review`. Result: no blocking issue found within the documented finite common alphabet after the review corrections below. The review made no repository or engine changes and ran no duplicate builds.

This is a separate-author review of `storage_review`'s differential harness. The reviewer previously authored candidate terminal tests and qualification. Both frozen engines were read for this review only after root explicitly authorized post-freeze comparison. This is not a claim of another independently implemented oracle or a newly blinded candidate author.

The final freeze is `final-freeze/manifest.json`, SHA-256 `2a6ea9fe5f06bb4451cfcee79c4ad8dafee520f60f03076061d71a9aa927d176`. The pre-mutation freeze remains `harness-freeze/manifest.json`, SHA-256 `6419ce07af43f611bdb9e73eac737f4820d80dc4ef82fc1714e6b43170516ceb`. The final patch SHA-256 is `e4fd2f2377fe40a41663609296d1e468087e15dd8456e7eacd94321bf41dab27`.

All six final artifacts were independently checked against the final frozen copies and worktree. Rust and BUILD bytes match the pre-mutation freeze. The document differs by exactly four Vale-only replacements: accessor to method, enablement to initialization, snapshotted to saved as snapshots, and nonquiescent evidence to missing quiescence. The detailed JSON receipt remains unchanged at `independent-review.json`, SHA-256 `e095d512c8c5fb55b92a3f37386f569097c4de61f533f479faeeed0a25912866`.

| Final reviewed path | SHA-256 |
| --- | --- |
| nativelink-scheduler/BUILD.bazel | `1291d843df4d44880dbcc6409b2df918c3d49ea07f618f32baf8ce4a75c5a722` |
| nativelink-scheduler/tests/terminal_outcome_differential_test.rs | `65d2a157542231f4393db4405b4223955bb8ac9b70379423dc5a0f7536aa0e5f` |
| nativelink-scheduler/tests/terminal_outcome_differential/adapter.rs | `5af07a0494810d9701c54a517404eef1927b2d528aa792d9743baf4b034b3178` |
| nativelink-scheduler/tests/terminal_outcome_differential/cases.rs | `8189e8fc58584ea476ddb06c452650f7d52e83294d249f70c7985b486d7d230e` |
| nativelink-scheduler/tests/terminal_outcome_differential/fixtures.rs | `83a61404657bc565fbe7b85b50019c9f16bbcde3be6a098628400297ca38fa84` |
| nativelink-scheduler/design/categorical/terminal-outcome-differential.md | `59895e7017844556013f510a9a04a9b8da9e55eb5ef9890599a7efd22eb38cdb` |

The initial review found three weaknesses, all resolved before the harness freeze:

- Physical closure sets and internal retention views did not explicitly compare the external catalogue-to-retention-key relation. The adapter now compares every physical identity, namespace/incarnation handle, generation, and logical object; it also asserts the exact initial empty-cohort representation difference.
- Checking only the Abandoned boolean could equate another non-Abandoned variant with Open. The adapter now requires exact Open or Abandoned state and compares the complete worker publisher identity against the independent scheduler attempt.
- Normalization and coverage limits needed precise documentation. Native commit cardinality, coarse refusal categories, differing bounds, aligned physical IDs, full-member credit use and the adapter-owned composite Stage are now explicit.

Each report's native position must equal its own engine's current commit before conversion to a common command ordinal. The map distinguishes all observed commit boundaries, so an earlier observed report position cannot be renamed to the current report's ordinal. Exact logical time, accepted bytes and epoch/execution/attempt/worker/incarnation provenance remain compared. Native commit counts are intentionally different.

Every original operation Request is read from the independent reference's retained relation and compared with the scenario ledger and actual scheduler `operation_request` result after restore. Full scheduler equality additionally covers operation-specific terminals, versions and deadlines, original charged vectors, releases, attempts, worker state, holds, effects and retry targets. Logical future credits are compared separately from physical refunds.

Retention comparisons preserve every ordered root, write, generation, protection, deletion and clock field. Stage roots, original stable write IDs and external physical identities are checked. The reference delegates decisions to its unchanged independent M1 and retention reducers; reexporting a single neutral protocol module does not import production State or Coarse decisions into that oracle.

Both engines are replaced by their restored instances after each command, so subsequent commands run on recovered state. Each canonical snapshot round-trips unchanged; rejected, ignored and duplicate commands preserve complete per-engine snapshots. The candidate's disposable index is lost and rebuilt without changing authoritative bytes.

The additional positive-peak growth from a zero original memory grant and active last-cancellation branches preserve the same comparisons. The retained worker-replacement fixture correction follows the existing independent contract: a replacement remains quarantined until old cleanup, and duplicate old cleanup after successor dispatch cannot refund the successor.

The inspected baseline log reports 13 passing tests: five new paired tests, each exercising both digest algorithms, and eight inherited component tests. The strict Clippy log passes with `-D warnings`. The reviewer independently verified all 25 restored engine/support hashes in `engines-before-mutations.json`. Mutation execution and its logs are separate author evidence; this receipt does not replace that evidence.

The qualification remains finite. Exact refusal reasons, general configured-bound parity, arbitrary namespace mappings, partial-member credits, graph/content correctness, graph publication or direct update after setup, active cache-hit admission, seeded Serving/Operation protections, collection/deletion transitions and malformed-snapshot equivalence are excluded. The composite Stage is an adapter clone boundary, not a production multi-command transaction. Worker classification, quiescence and typed closure evidence remain trusted inputs. Only a Publication seed is compared; no AC-head semantics are fabricated in the reference. Future byte/physical reserves, snapshot authenticity, durable feature 3 and production cutover remain unproved, including the known standalone pure-byte-guard survivor.
