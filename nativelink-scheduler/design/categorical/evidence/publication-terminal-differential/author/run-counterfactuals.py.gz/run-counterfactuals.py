import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

WORK = Path('/tmp/nativelink-terminal-differential')
OUT = Path('/tmp/nativelink-categorical-evidence/publication-terminal-differential')
SOURCES = Path('/tmp/nativelink-categorical-evidence/publication-terminal-tests/mutants')
NAMES = ['01-memory-to-complete', '02-drop-memory-peak', '07-duplicate-observe-mutates']
COMMAND = ['cargo', 'test', '--offline', '--locked', '--profile=smol', '-p',
           'nativelink-scheduler', '--test', 'terminal_outcome_differential_test',
           '--', '--nocapture']
ENV = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-candidate-target', CARGO_BUILD_JOBS='8')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_harness():
    manifest = json.loads((OUT / 'harness-freeze/manifest.json').read_text())
    for entry in manifest['files']:
        assert sha(WORK / entry['path']) == entry['sha256'], entry['path']

results = []
for name in NAMES:
    check_harness()
    prior = json.loads((SOURCES / name / 'run.json').read_text())
    path = WORK / prior['mutated_path']
    source = SOURCES / name / prior['mutated_path']
    assert sha(path) == prior['original_sha256']
    assert sha(source) == prior['mutant_sha256']
    original = path.read_bytes()
    directory = OUT / 'counterfactuals' / name
    directory.mkdir(parents=True, exist_ok=True)
    stored = directory / prior['mutated_path']
    stored.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, stored)
    started = time.monotonic()
    try:
        path.write_bytes(source.read_bytes())
        with (directory / 'test.log').open('wb') as stream:
            result = subprocess.run(COMMAND, cwd=WORK, env=ENV, stdout=stream, stderr=subprocess.STDOUT, check=False)
    finally:
        path.write_bytes(original)
    log = (directory / 'test.log').read_text()
    receipt = {
        'name': name, 'description': prior['description'], 'command': COMMAND,
        'source': prior['mutated_path'], 'original_sha256': prior['original_sha256'],
        'mutant_sha256': prior['mutant_sha256'], 'returncode': result.returncode,
        'elapsed_seconds': round(time.monotonic() - started, 2),
        'compiled': 'Finished `smol`' in log and 'Running tests/terminal_outcome_differential_test.rs' in log,
        'detected': result.returncode != 0 and 'test result: FAILED.' in log,
        'failure_lines': [line for line in log.splitlines() if line.startswith('test ') and ('FAILED' in line or 'result:' in line)],
        'source_restored': sha(path) == prior['original_sha256'],
        'log_sha256': sha(directory / 'test.log'),
    }
    check_harness()
    (directory / 'run.json').write_text(json.dumps(receipt, indent=2) + '\n')
    results.append(receipt)
    print(json.dumps(receipt), flush=True)
(OUT / 'counterfactuals/results.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(row['compiled'] and row['detected'] and row['source_restored'] for row in results)
