#!/usr/bin/env python3
"""Compile each one-contract mutant before counting assertion-level kills."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-activation-inventory')
evidence = Path('/tmp/nativelink-activation-bounded-evidence')
source = root / 'nativelink-scheduler/tests/publication_activation_bounded.rs'
original = source.read_text()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-differential-target')
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p',
           'nativelink-scheduler', '--test', 'publication_activation_bounded_test', '--no-run']
binary = Path(env['CARGO_TARGET_DIR']) / 'smol/deps/publication_activation_bounded_test-a6aee63a15527f65'

# All expectations and fixtures remain unchanged. Some invariants are checked
# both during reduction and restore; those coupled guards form one mutation.
mutants = [('unbounded-construction', [('        inner.snapshot()?;\n        Ok(Self { inner })', '        Ok(Self { inner })', 2)]), ('unbounded-transition', [('        next.snapshot()?;', '        // byte check omitted', 1)]), ('install-before-byte-admission', [('        next.snapshot()?;\n        self.inner = next;', '        self.inner = next;\n        self.inner.snapshot()?;', 1)]), ('byte-check-only-activation', [('        next.snapshot()?;', '        if matches!(event, Event::Activate(_)) { next.snapshot()?; }', 1)])]

def run(name, changed):
    folder = evidence / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    source.write_text(changed)
    (folder / 'reference.rs').write_text(changed)
    with (folder / 'compile.log').open('wb') as log:
        compile_result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'source_sha256': hashlib.sha256(changed.encode()).hexdigest(),
              'compile_command': command, 'compile_status': compile_result.returncode}
    if compile_result.returncode:
        result['classification'] = 'COMPILE_REJECTED_NOT_A_KILL'
    else:
        result['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        with (folder / 'test.log').open('wb') as log:
            test_result = subprocess.run([str(binary)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        result['test_status'] = test_result.returncode
        result['classification'] = 'PASS' if not test_result.returncode else 'COMPILED_ASSERTION_KILL'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

results = []
try:
    baseline = run('baseline', original)
    assert baseline['classification'] == 'PASS', baseline
    for name, replacements in mutants:
        changed = original
        for old, new, count in replacements:
            assert changed.count(old) == count, (name, old, changed.count(old), count)
            changed = changed.replace(old, new)
        results.append(run(name, changed))
finally:
    source.write_text(original)
    restored = run('restored', original)
    (evidence / 'mutation-results.json').write_text(json.dumps({
        'baseline': baseline, 'mutants': results, 'restored': restored,
        'source_restored_exactly': source.read_text() == original,
    }, indent=2) + '\n')

assert restored['classification'] == 'PASS', restored
assert all(result['classification'] == 'COMPILED_ASSERTION_KILL' for result in results), results
