# Bounded-admission successor provenance

Parent review requested a post-freeze maximum-owner snapshot experiment. The
original frozen activation-v2 model was not changed. A scratch probe copied the
original fixtures and added the 32-root/32-member case. Its compiled successful
counterexample and exact source are retained here. The probe has twenty-seven
filtered original tests; that run claims only its single explicit counterexample.

The additive wrapper changes admission only: checked construction and candidate
serialization before installation on every event. Four focused cases and four
compiled semantic mutants qualify this change. Baseline and restored source pass;
compiler failures do not count as kills. The first test-run failure was eager
fixture-search arithmetic; it was corrected and preserved in first-test-run.log.
All builds used at most eight jobs and Cargo/Bazel ran sequentially. The standalone
Bazel target ran against byte-identical new sources in the older warm workspace;
it depends only on the frozen v2 oracle and serialization/hash libraries.

The patch applies after the separately frozen activation-v2 patch. The isolated
worktree is /tmp/nativelink-activation-inventory at base
27d010a3ef19b1a24d76b760625323b5bce3a51c with that v2 patch staged as baseline. The
bounded patch includes only its new files and target, not the staged v2 addition.
No production constructor or persistent format was changed. A future real-State
inventory adapter must use this additive guard for bounded activation checks.
