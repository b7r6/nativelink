from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path.cwd()
source = Path('/tmp/nativelink-bytestream-identity-root-integration')
dest = root / 'nativelink-scheduler/design/categorical/evidence/authority-bytestream-identity'
dest.mkdir(exist_ok=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


before = load(source / 'sources-before.json')
assert before == load(source / 'sources-after.json')
head = (source / 'head.txt').read_text().strip()
process = subprocess.Popen(['git', 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for name, expected in before.items():
    process.stdin.write((head + ':' + name + '\n').encode())
    process.stdin.flush()
    header = process.stdout.readline().split()
    assert len(header) == 3, name
    body = process.stdout.read(int(header[2]))
    assert process.stdout.read(1) == b'\n'
    assert hashlib.sha256(body).hexdigest() == expected, name
process.stdin.close()
assert process.wait() == 0
result = load(source / 'result.json')
assert result['exit_code'] == 0 and result['targets'] == result['passed'] == result['executed'] == 7
assert result['rust_counts_from_logs'] == [169, 0, 1]
shutil.copy2('/tmp/run-bytestream-identity-root-integration.py', source / 'run.py')
shutil.copy2('/tmp/package-bytestream-identity-root.py', source / 'package.py')
for suffix in ('.json', '.log'):
    shutil.copy2('/tmp/nativelink-bytestream-identity-root-hooks' + suffix, source / ('hooks' + suffix))
shutil.copytree('/tmp/nativelink-authority-bytestream-identity-independent-root-review', source / 'independent-root-review')
executable_archives = []
for path in sorted((source / 'binaries').rglob('*')):
    if not path.is_file():
        continue
    name = str(path.relative_to(source))
    archive = dest / ('root-executable-' + path.name + '.tar.gz')
    with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
        stream.add(path, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        assert len(members) == 1 and members[0].isfile()
        assert hashlib.file_digest(stream.extractfile(members[0]), 'sha256').hexdigest() == sha(path)
    assert archive.stat().st_size < 45 * 1024 * 1024
    executable_archives.append({'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                                'member': {'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)}})
    print('Retained and verified', path.name, flush=True)
files = {}
external = {}
for path in sorted(source.rglob('*')):
    if not path.is_file():
        continue
    name = str(path.relative_to(source))
    if name.startswith('binaries/'):
        continue
    if path.name == 'events.jsonl':
        external[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
        continue
    files[name] = sha(path)
archive = dest / 'root-integration.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
    for name in files:
        stream.add(source / name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as stream:
    assert {member.name: hashlib.file_digest(stream.extractfile(member), 'sha256').hexdigest()
            for member in stream.getmembers() if member.isfile()} == files
manifest = {
    'scope': 'Independent root integration of fixed ByteStream exact upload identity. No production construction, aggregate admission or deployment qualification.',
    'root_source_commit': head,
    'author_source_commit': '7b1feba8deb858bd8aafd80ec7d2fa7c2e0e9272',
    'run': result,
    'git_source_verified': True,
    'author_comparison': load(source / 'author-source-comparison.json'),
    'source_difference_explanation': '13 of 17 author inputs are exact. Root retains earlier canonical owner Cargo dependency edges in two lockfiles and the workspace manifest, plus the already-qualified stdout-to-stderr fixed-digest test marker. Runtime and all identity fixtures are exact.',
    'hooks': load(source / 'hooks.json'),
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'files': files},
    'executable_archives': executable_archives,
    'external_build_events': external,
    'limits': [
        'All seven targets actually executed; the build also includes the server. Counts overlap author suites and earlier root checks.',
        'One local TLS fixture remains normally ignored; no fresh explicit TLS execution is claimed.',
        'Author original failures, corrected fixture baseline, strict Cargo checks, compiled mutations and restoration have separate source and evidence boundaries.',
        'Source review is distinct from reviewer execution; the archived independent reviews state their scope.',
        'No bound on global upload registry cardinality, aggregate heap or lifetime, arbitrary backend completion, or physical durability.',
        'All M0-M9 qualification gates and production cutover remain open.'
    ]
}
path = dest / 'root-integration.json'
path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest_sha256': sha(path), 'archive_files': len(files), 'executables': len(executable_archives),
                  'archive_bytes': archive.stat().st_size}), flush=True)
