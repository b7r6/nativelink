from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--author-manifest', required=True)
args = parser.parse_args()
root = Path.cwd()
out = Path('/tmp/nativelink-bytestream-identity-root-integration')
out.mkdir(exist_ok=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
assert not status.strip(), status
assert os.environ.get('NL_FIXED_DIGEST_CASE') is None
names = [name for name in subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0')
         if name and not name.startswith('nativelink-scheduler/design/categorical/evidence/')]


def snapshot():
    return {name: hashlib.sha256(os.readlink(root / name).encode()).hexdigest()
            if (root / name).is_symlink() else sha(root / name) for name in names}


before = snapshot()
write('sources-before.json', before)
(out / 'head.txt').write_text(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True))
(out / 'status.txt').write_text(status)
manifest = Path(args.author_manifest)
shutil.copy2(manifest, out / 'author-source.json')
author = json.loads(manifest.read_text())['files']
assert all(name in before for name in author)
same = {name: value for name, value in author.items() if before[name] == value}
different = {name: {'author': value, 'root': before[name]}
             for name, value in author.items() if before[name] != value}
assert before['nativelink-service/src/bytestream_server.rs'] == author['nativelink-service/src/bytestream_server.rs']
assert all(name in {'Cargo.toml', 'Cargo.lock', 'nativelink-service/BUILD.bazel',
                    'tools/canonical-store/Cargo.lock',
                    'tools/canonical-store/tests/fixed_digest_default.rs'} for name in different), different
write('author-source-comparison.json', {'manifest_sha256': sha(manifest), 'exact': same, 'different': different})
(out / 'author-to-root.patch').write_text(subprocess.check_output(
    ['git', 'diff', json.loads(manifest.read_text())['commit'], '--', *different], text=True))
for name in different:
    dest = out / 'root-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, dest)
targets = [
    '//nativelink-service:unit_test',
    '//nativelink-service:integration_tests/authority_listener_test_test',
    '//nativelink-service:integration_tests/bytestream_server_test_test',
    '//nativelink-service:integration_tests/grpc_wire_compression_test_test',
    '//nativelink-service:integration_tests/wire_compression_test_test',
    '//tools/canonical-store:canonical_store_test',
    '//tools/canonical-store:fixed_digest_default_test',
]
command = ['bazel', 'test', '--jobs=4', '--local_test_jobs=1', '--test_env=RUST_TEST_THREADS=1',
           '--test_output=errors', '--keep_going', '--build_event_json_file=' + str(out / 'events.jsonl'),
           *targets, '//:nativelink']
write('command.json', command)
start = time.monotonic()
with (out / 'build-and-test.log').open('w') as log:
    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
after = snapshot()
write('sources-after.json', after)
assert before == after
summaries = []
counts = [0, 0, 0]
for line in (out / 'events.jsonl').read_text().splitlines():
    row = json.loads(line)
    if 'testSummary' not in row:
        continue
    label = row['id']['testSummary']['label']
    summary = row['testSummary']
    summaries.append({'label': label, 'status': summary['overallStatus'],
                      'runs': summary['totalRunCount'], 'cached': summary.get('totalNumCached', 0),
                      'duration': summary['totalRunDuration']})
    path = label[2:].replace(':', '/')
    dest = out / 'testlogs' / path / 'test.log'
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / 'bazel-testlogs' / path / 'test.log', dest)
    for result in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', dest.read_text()):
        counts = [a + int(b) for a, b in zip(counts, result)]
    binary = out / 'binaries' / path
    binary.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / 'bazel-bin' / path, binary)
write('summaries.json', summaries)
result = {'exit_code': code, 'elapsed_seconds': time.monotonic() - start,
          'targets': len(summaries), 'passed': sum(item['status'] == 'PASSED' for item in summaries),
          'executed': sum(item['cached'] == 0 for item in summaries),
          'rust_counts_from_logs': counts, 'source_inputs_unchanged': len(before)}
write('result.json', result)
print(json.dumps(result), flush=True)
raise SystemExit(code)
