from pathlib import Path
import subprocess,hashlib,json,shutil
root=Path.cwd();out=Path(__file__).parent;path=root/'nativelink-scheduler/src/authority/journal.rs';original=path.read_text();(out/'fixed-journal.rs').write_text(original)
for short,label in [('unit','nativelink-scheduler/unit_test'),('bridge','tools/canonical-filesystem/journal_bridge_test')]:shutil.copyfile(root/'bazel-testlogs'/label/'test.log',out/('fixed-'+short+'.log'))
a='''                    if applied.state(epoch, reader)?.limits != limits {
                        return Err(failure(
                            ErrorVerb::Read,
                            "persisted authority limits differ from requested limits",
                        ));
                    }'''
b='''                                if saved.validate(epoch, reader)? != limits {
                                    return Err(failure(
                                        ErrorVerb::Read,
                                        "persisted snapshot limits differ from requested limits",
                                    ));
                                }'''
mutants=[('omit-applied-limits',a,'                    applied.state(epoch, reader)?;','ambient_reopen_refuses_every_changed_persisted_limit'),('omit-snapshot-limits',b,'                                saved.validate(epoch, reader)?;','reopen_refuses_limits_hidden_only_in_saved_snapshot')];results=[]
try:
 for name,old,new,case in mutants:
  assert original.count(old)==1;path.write_text(original.replace(old,new));(out/(name+'.rs')).write_bytes(path.read_bytes())
  cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','--test_arg='+case,'//nativelink-scheduler:unit_test']
  with (out/(name+'.log')).open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=90).returncode
  log=root/'bazel-testlogs/nativelink-scheduler/unit_test/test.log';shutil.copyfile(log,out/(name+'-test.log'))
  compiled='Build completed,' in (out/(name+'.log')).read_text() and 'test result: FAILED.' in log.read_text();detected=compiled and code!=0
  results.append({'name':name,'command':cmd,'compiled':compiled,'detected':detected,'exit_code':code,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});(out/'mutants.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,compiled,flush=True)
  if not detected:raise RuntimeError(name)
  path.write_text(original)
finally:
 path.write_text(original);assert path.read_text()==original
