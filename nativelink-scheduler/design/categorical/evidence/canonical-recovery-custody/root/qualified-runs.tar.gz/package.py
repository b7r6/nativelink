from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd();src=Path('/tmp/nativelink-categorical-evidence/canonical-custody-root-integration');dst=root/'nativelink-scheduler/design/categorical/evidence/canonical-recovery-custody';dst.mkdir(exist_ok=False)
author=Path('/tmp/nativelink-canonical-recovery-custody-package');shutil.copytree(author,dst/'author')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for p in author.iterdir():assert sha(p)==sha(dst/'author'/p.name)
shutil.copytree('/tmp/nativelink-canonical-custody-root-independent-storage-review',src/'independent-storage-review',ignore=shutil.ignore_patterns('binaries'))
shutil.copy2('/tmp/nativelink-root-completed-bazel-cache-cleanup.json',src/'disposable-cache-cleanup.json')
shutil.copy2('/tmp/nativelink-precommit-config-regeneration.json',src/'hook-config-regeneration.json')
shutil.copy2(__file__,src/'package.py')
archives=[];target=dst/'root';target.mkdir()
for p in sorted((src/'binaries').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(src));a=target/('executable-'+rel.replace('/','-')+'.tar.gz')
 with tarfile.open(a,'w:gz',compresslevel=6) as t:t.add(p,arcname=rel,recursive=False)
 with tarfile.open(a,'r:gz') as t:
  members=t.getmembers();assert len(members)==1;assert hashlib.file_digest(t.extractfile(members[0]),'sha256').hexdigest()==sha(p)
 assert a.stat().st_size<45*1024*1024
 archives.append(dict(path=a.name,bytes=a.stat().st_size,sha256=sha(a),member=dict(path=rel,bytes=p.stat().st_size,sha256=sha(p))))
 print('verified',rel,flush=True)
files={str(p.relative_to(src)):sha(p) for p in sorted(src.rglob('*')) if p.is_file() and not str(p.relative_to(src)).startswith('binaries/')}
a=target/'qualified-runs.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=6) as t:
 for p in files:t.add(src/p,arcname=p,recursive=False)
with tarfile.open(a,'r:gz') as t:assert {m.name:hashlib.file_digest(t.extractfile(m),'sha256').hexdigest() for m in t.getmembers()}==files
assert a.stat().st_size<45*1024*1024
result=json.loads((src/'result.json').read_text());assert result['total']==[258,0,1]
j=dict(scope='Root composition of private final database custody drain with previously qualified inert temporal owner. No supervised lifecycle or recovered clock in this source boundary.',result=result,root_commits=['80c4065314','05ab0b5836','0ae388d723'],author_source='f2ae7427ee304bd8ce870c46064c0c22fd86771d',author_package_sha256=sha(dst/'author/package.json'),author_seal_sha256=sha(dst/'author/package-seal.json'),independent_review_sha256=sha(src/'independent-storage-review/review.json'),source_comparison='16of19 author-selected files exact; owner, test wiring and BUILD add the previously qualified temporal audit. Helper and12custody fixtures exact.',archive=dict(path=a.name,bytes=a.stat().st_size,sha256=sha(a),files=files),executables=archives,limits=['All5targets executed uncached; 258 passes and1 existing ignore. Server built; its ELF is not archived.','Every1357 tracked non-evidence input unchanged and matches Git0ae388d723. Selected source copies, rawlogs/BEP and5testELFs retained. Not a hermetic dependency closure or reproducible-build proof.','Private drain requires a permanent uncancelled supervisor. It does not provide cancellation supervision itself or change PreparedCanonicalOwner::release.','Final database destruction is not an observable flush-success or durability acknowledgement. External ownership aliases may retain namespace locks; blocked holders leave cleanup pending.'])
(target/'manifest.json').write_text(json.dumps(j,indent=2)+'\n');print('manifest',sha(target/'manifest.json'),'files',len(files),flush=True)
