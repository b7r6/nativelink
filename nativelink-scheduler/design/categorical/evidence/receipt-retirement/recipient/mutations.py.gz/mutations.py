import json,os,pathlib,subprocess,time,hashlib
root=pathlib.Path('/tmp/nativelink-categorical-runtime')
out=pathlib.Path('/tmp/nativelink-categorical-evidence/receipt-retirement')
source=root/'nativelink-worker/src/authority_worker.rs'
original=source.read_text()
unknown='retirement_fences_unknown_first_dispatch_and_forgotten_aliases'
empty='empty_receipt_certificate_still_fences_the_allocated_effect_domain'
mutations=[
 ('retired-attempt-floor','if target.attempt_id <= certificate.attempts_through && retained.is_none() {','if false && target.attempt_id <= certificate.attempts_through && retained.is_none() {',unknown),
 ('retired-command-effect-floor','if command.effect_id <= certificate.effects_through\n','if false && command.effect_id <= certificate.effects_through\n',empty),
 ('certificate-effect-floor','if certificate.effect_id <= previous.effects_through {','if false && certificate.effect_id <= previous.effects_through {',empty),
 ('same-certificate-changed-body','Err(invalid("Retirement identity changed contents"))','Ok(false)',unknown),
 ('postcut-cancel-identity','&& (binding.cancel_effect_id != 0\n                            || report.cancel_effect_id <= certificate.effects_through)','&& report.cancel_effect_id <= certificate.effects_through','cancellation_after_certificate_cut_requires_an_absent_binding'),
 ('single-use-spent-latch','ledger.retirement = Some(certificate);','ledger.retirement = Some(certificate);\n        ledger.spent = false;','receipt_compaction_never_restores_single_use_admission'),
]
records=[]
try:
 for label,before,after,test in mutations:
  assert original.count(before)==1,(label,original.count(before))
  source.write_text(original.replace(before,after,1))
  command=['cargo','test','--locked','--profile','smol','-p','nativelink-worker','--test','authority_worker_test',test,'--','--exact','--nocapture']
  start=time.monotonic()
  logpath=out/('mutation-'+label+'.log')
  with logpath.open('w') as log:
   p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-categorical-runtime-target'))
  logtext=logpath.read_text()
  record=dict(label=label,command=command,exit=p.returncode,seconds=time.monotonic()-start,baseline_sha256=hashlib.sha256(original.encode()).hexdigest(),replacement=dict(before=before,after=after),compiled='Running tests/authority_worker_test.rs' in logtext,killed=p.returncode!=0 and 'test result: FAILED.' in logtext and 'panicked at' in logtext)
  records.append(record)
  source.write_text(original)
  print(json.dumps({key:value for key,value in record.items() if key not in ('replacement','command')}),flush=True)
  (out/'mutations.json').write_text(json.dumps(records,indent=2)+'\n')
finally:
 source.write_text(original)
assert all(r['compiled'] and r['killed'] for r in records),records
command=['cargo','test','--locked','--profile','smol','-p','nativelink-worker','--test','authority_worker_test','--','--nocapture','--test-threads=1']
start=time.monotonic()
with (out/'recipient-restored.log').open('w') as log:
 p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-categorical-runtime-target'))
record=dict(command=command,exit=p.returncode,seconds=time.monotonic()-start)
(out/'recipient-restored.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print('\n'.join(line for line in (out/'recipient-restored.log').read_text().splitlines() if line.startswith('test result:') or line.startswith('error:') or 'panicked at' in line),flush=True)
