import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/nativelink-categorical-runtime')
out=pathlib.Path('/tmp/nativelink-categorical-evidence/coordinator-ingress')
source=root/'nativelink-service/src/authority_server.rs'
original=source.read_text()
env=dict(os.environ,CARGO_BUILD_JOBS='8',CARGO_TARGET_DIR='/tmp/nativelink-categorical-runtime-target')
records=[]
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(label+'.log')).read_text()
 record=dict(label=label,command=args,exit=result.returncode,seconds=time.monotonic()-start)
 records.append(record)
 (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 print('\n'.join(x for x in text.splitlines() if x.startswith('test result:') or x.startswith('error') or x.startswith('AUTHORITY_') or 'panicked at' in x),flush=True)
 return record,text
unit=['cargo','test','--locked','--profile','smol','-p','nativelink-service','--lib','authority_server::tests','--','--show-output']
r,t=run('unit-baseline',unit);assert r['exit']==0
rpc=['cargo','test','--locked','--profile','smol','-p','nativelink-worker','--test','authority_rpc_test','--test','authority_worker_test','--test','authority_scheduler_test','--','--show-output','--test-threads=1']
r,t=run('physical-and-compatibility',rpc);assert r['exit']==0
mutations=[
 ('duplicate-notifications','''    if pending.queued {
        return None;
    }''','''    if pending.queued {
        return Some(Input::WorkerSnapshots(session, snapshots.clone()));
    }'''),
 ('report-barrier-overtaken','''            *snapshots = Arc::new(Mutex::new(WorkerSnapshots::default()));''','''            // Mutation: later observations overwrite the notification before Report.'''),
]
mutant_records=[]
try:
 for name,before,after in mutations:
  assert original.count(before)==1,(name,original.count(before))
  source.write_text(original.replace(before,after,1))
  r,t=run('mutation-'+name,unit)
  r.update(source_sha256=hashlib.sha256(original.encode()).hexdigest(),replacement=dict(before=before,after=after),compiled='Running unittests src/lib.rs' in t,killed=r['exit']!=0 and 'test result: FAILED.' in t and 'panicked at' in t)
  mutant_records.append(r)
  (out/'mutations.json').write_text(json.dumps(mutant_records,indent=2)+'\n')
  source.write_text(original)
finally:source.write_text(original)
assert len(mutant_records)==2 and all(x['compiled'] and x['killed'] for x in mutant_records)
r,t=run('unit-restored',unit);assert r['exit']==0
r,t=run('strict-clippy',['cargo','clippy','--locked','--profile','smol','-p','nativelink-service','--lib','--tests','--','-D','warnings']);assert r['exit']==0
