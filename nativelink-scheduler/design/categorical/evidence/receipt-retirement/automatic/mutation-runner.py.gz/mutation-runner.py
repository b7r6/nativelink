import json,os,pathlib,subprocess,time,hashlib,shutil
root=pathlib.Path('/tmp/nativelink-categorical-runtime')
out=pathlib.Path('/tmp/nativelink-categorical-evidence/automatic-receipts')
source=root/'nativelink-service/src/authority_server.rs'
original=source.read_text()
name='activated_receipt_outbox_survives_rpc_restart_cutpoints_and_old_active_hole'
command=['cargo','test','--locked','--profile','smol','-p','nativelink-worker','--test','authority_rpc_test',name,'--','--exact','--show-output']
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-categorical-runtime-target',CARGO_BUILD_JOBS='8')
records=[]
def execute(label,command):
 start=time.monotonic();logpath=out/(label+'.log')
 with logpath.open('w') as log:
  p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=env)
 text=logpath.read_text()
 record=dict(label=label,command=command,exit=p.returncode,seconds=time.monotonic()-start,environment=dict(CARGO_BUILD_JOBS='8',CARGO_TARGET_DIR=env['CARGO_TARGET_DIR']))
 print(json.dumps(record),flush=True)
 print('\n'.join(line for line in text.splitlines() if line.startswith('error') or line.startswith('test result:') or 'panicked at' in line or line.startswith('Receipt wait failed') or line.startswith('AUTHORITY_AUTOMATIC')),flush=True)
 return record,text
baseline,text=execute('adapter-baseline',command)
(out/'adapter-baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
assert baseline['exit']==0,'Baseline failed; refusing mutation claims'
before='''        let (Some(identity), Some(certificate)) = (session.worker, certificate) else {
            return Ok(());
        };'''
after='''        let Some(identity) = session.worker else { return Ok(()); };
        let certificate = certificate.or_else(|| {
            self.receipts.as_ref().as_ref()
                .and_then(|receipts| receipts.streams.get(&WorkerId(identity.worker_id)))
                .and_then(|stream| stream.pending.as_ref())
                .map(wire_receipt_certificate)
        });
        let Some(certificate) = certificate else { return Ok(()); };'''
mutations=[('implicit-absent-ack',before,after),('changed-wire-watermark','            effects_through: value.effects_through.0,','            effects_through: value.effects_through.0 + 1,')]
# The projection is one indentation level inside its constructor, independent
# of the prototype above; match its complete line without guessing cardinality.
mutations[1]=('changed-wire-watermark','        effects_through: value.effects_through.0,','        effects_through: value.effects_through.0 + 1,')
try:
 for label,before,after in mutations:
  assert original.count(before)==1,(label,original.count(before))
  source.write_text(original.replace(before,after,1))
  record,text=execute('mutation-'+label,command)
  record.update(baseline_sha256=hashlib.sha256(original.encode()).hexdigest(),replacement=dict(before=before,after=after),compiled='Running tests/authority_rpc_test.rs' in text,killed=record['exit']!=0 and 'test result: FAILED.' in text and 'panicked at' in text)
  records.append(record)
  source.write_text(original)
  (out/'adapter-mutations.json').write_text(json.dumps(records,indent=2)+'\n')
finally:
 source.write_text(original)
assert all(record['compiled'] and record['killed'] for record in records),records
restored,text=execute('adapter-restored',command)
(out/'adapter-restored.json').write_text(json.dumps(restored,indent=2)+'\n')
assert restored['exit']==0,'Restored baseline failed'
clippy=[]
for label,args in [('service-clippy-final',['-p','nativelink-service','--lib','--tests']),('worker-clippy-complete',['-p','nativelink-worker','--lib','--test','authority_rpc_test'])]:
 record,text=execute(label,['cargo','clippy','--locked','--profile','smol']+args+['--','-D','warnings'])
 clippy.append(record)
(out/'clippy-complete.json').write_text(json.dumps(clippy,indent=2)+'\n')
assert all(record['exit']==0 for record in clippy),'Strict clippy failed'
