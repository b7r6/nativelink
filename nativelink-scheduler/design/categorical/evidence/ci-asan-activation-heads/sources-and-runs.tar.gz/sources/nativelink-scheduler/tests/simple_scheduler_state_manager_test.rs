// Copyright 2026 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use core::ops::Bound;
use core::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use core::time::Duration;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::SystemTime;

use futures::{FutureExt, Stream, StreamExt, future, stream};
use mock_instant::thread_local::MockClock;
use nativelink_config::schedulers::SimpleSpec;
use nativelink_error::{Code, Error, ResultExt, make_err};
use nativelink_macro::nativelink_test;
use nativelink_metric::{
    MetricFieldData, MetricKind, MetricPublishKnownKindData, MetricsComponent,
};
use nativelink_proto::com::github::trace_machina::nativelink::remote_execution::UpdateForWorker;
use nativelink_scheduler::awaited_action_db::{
    AwaitedAction, AwaitedActionDb, AwaitedActionSubscriber, SortedAwaitedAction,
    SortedAwaitedActionState,
};
use nativelink_scheduler::default_scheduler_factory::memory_awaited_action_db_factory;
use nativelink_scheduler::simple_scheduler::SimpleScheduler;
use nativelink_scheduler::simple_scheduler_state_manager::{
    LISTING_READ_CONCURRENCY, SimpleSchedulerStateManager, TimeoutCause,
};
use nativelink_scheduler::worker::Worker;
use nativelink_scheduler::worker_registry::WorkerRegistry;
use nativelink_scheduler::worker_scheduler::WorkerScheduler;
use nativelink_util::action_messages::{
    ActionInfo, ActionResult, ActionStage, ActionState, ActionUniqueKey, ActionUniqueQualifier,
    OperationId, WorkerId,
};
use nativelink_util::common::DigestInfo;
use nativelink_util::digest_hasher::DigestHasherFunc;
use nativelink_util::instant_wrapper::MockInstantWrapped;
use nativelink_util::operation_state_manager::{
    ActionStateResult, ClientStateManager, MatchingEngineStateManager, OperationFilter,
    OperationStageFlags, OrderDirection, UpdateOperationType, WorkerStateManager,
};
use nativelink_util::platform_properties::PlatformProperties;
use tokio::sync::{Notify, mpsc};

#[nativelink_test]
async fn drops_missing_actions() -> Result<(), Error> {
    let task_change_notify = Arc::new(Notify::new());
    let awaited_action_db = memory_awaited_action_db_factory(
        0,
        &task_change_notify.clone(),
        MockInstantWrapped::default,
    );
    let state_manager = SimpleSchedulerStateManager::new(
        0,
        Duration::from_secs(10),
        Duration::from_secs(10),
        Duration::ZERO,
        awaited_action_db,
        SystemTime::now,
        None,
    );
    state_manager
        .update_operation(
            &OperationId::Uuid(uuid::Uuid::parse_str(
                "c458c1f4-136e-486d-b9cd-cea07460cde4",
            )?),
            &WorkerId::default(),
            UpdateOperationType::ExecutionComplete,
        )
        .await
        .unwrap();

    assert!(logs_contain(
        "Unable to update action due to it being missing, probably dropped operation_id=c458c1f4-136e-486d-b9cd-cea07460cde4"
    ));
    Ok(())
}

const NOW_TIME: u64 = 10_000;
const WORKER_TIMEOUT: Duration = Duration::from_mins(2);
const MAX_EXECUTING: Duration = Duration::from_mins(15);

fn make_system_time(add_time: u64) -> SystemTime {
    SystemTime::UNIX_EPOCH
        .checked_add(Duration::from_secs(NOW_TIME + add_time))
        .unwrap()
}

fn action_info(started: SystemTime) -> ActionInfo {
    let action_digest = DigestInfo::zero_digest();
    ActionInfo {
        command_digest: action_digest,
        input_root_digest: action_digest,
        timeout: Duration::ZERO,
        platform_properties: HashMap::default(),
        priority: 0,
        load_timestamp: SystemTime::UNIX_EPOCH,
        insert_timestamp: started,
        unique_qualifier: ActionUniqueQualifier::Uncacheable(ActionUniqueKey {
            execution_scope: None,
            instance_name: "main".to_string(),
            digest_function: DigestHasherFunc::Sha256,
            digest: action_digest,
        }),
    }
}

/// An action already assigned to `worker_id` and executing since `started`.
fn executing_action(worker_id: &WorkerId, started: SystemTime) -> AwaitedAction {
    let action_info = action_info(started);
    let action_digest = action_info.digest();
    let operation_id = OperationId::default();
    let mut action = AwaitedAction::new(operation_id.clone(), Arc::new(action_info), started);
    action.worker_set_state(
        Arc::new(ActionState {
            stage: ActionStage::Executing,
            client_operation_id: operation_id,
            action_digest,
            last_transition_timestamp: started,
        }),
        started,
    );
    action.set_worker_id(Some(worker_id.clone()), started);
    action
}

fn state_manager(
    registry: Arc<WorkerRegistry>,
) -> Arc<
    SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
> {
    state_manager_with_retries(registry, 5)
}

fn state_manager_with_retries(
    registry: Arc<WorkerRegistry>,
    max_job_retries: usize,
) -> Arc<
    SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
> {
    let task_change_notify = Arc::new(Notify::new());
    SimpleSchedulerStateManager::new(
        max_job_retries,
        WORKER_TIMEOUT,
        Duration::from_mins(5),
        MAX_EXECUTING,
        memory_awaited_action_db_factory(0, &task_change_notify, MockInstantWrapped::default),
        MockInstantWrapped::default,
        Some(registry),
    )
}

/// Same as above but with `max_action_executing_timeout_s` disabled, which is
/// its default.
fn state_manager_no_executing_ceiling(
    registry: Arc<WorkerRegistry>,
) -> Arc<
    SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
> {
    let task_change_notify = Arc::new(Notify::new());
    SimpleSchedulerStateManager::new(
        5,
        WORKER_TIMEOUT,
        Duration::from_mins(5),
        Duration::ZERO,
        memory_awaited_action_db_factory(0, &task_change_notify, MockInstantWrapped::default),
        MockInstantWrapped::default,
        Some(registry),
    )
}

/// An orphan must still be reaped when `max_action_executing_timeout_s` is
/// disabled, which is its default.
///
/// An HPA scaling a replica down leaves its workers' actions Executing in
/// shared state, naming worker ids no surviving instance recognises. If the
/// only ceiling for Unknown were the executing timeout, the default config
/// would never reap them and every scale-down would leak actions until the
/// client gave up.
#[nativelink_test]
async fn reaps_an_orphan_even_with_the_executing_ceiling_disabled() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let action = executing_action(
        &WorkerId::from(String::from("owner-was-scaled-down")),
        make_system_time(0),
    );
    let state_mgr = state_manager_no_executing_ceiling(Arc::new(WorkerRegistry::new()));

    // Past worker_timeout_s: still must not fire, this could be a healthy
    // action on a peer's worker.
    MockClock::advance(WORKER_TIMEOUT + Duration::from_mins(1));
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "must not reap at worker_timeout_s just because the ceiling is disabled"
    );

    // Past the orphan backstop: now it has to go, or it never will.
    MockClock::advance(Duration::from_mins(61));
    assert!(
        state_mgr.should_timeout_operation(&action).await,
        "an orphan must be reaped by the backstop when no ceiling is configured"
    );
    Ok(())
}

/// An action on a worker connected to a DIFFERENT scheduler instance must not
/// be timed out here. This instance never sees that worker's heartbeats, so
/// the action's timestamp looks frozen however healthy it is.
#[nativelink_test]
async fn does_not_time_out_a_peer_instances_worker() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    // Deliberately not registered here: it belongs to another instance.
    let action = executing_action(
        &WorkerId::from(String::from("owned-by-another-scheduler")),
        make_system_time(0),
    );
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));

    MockClock::advance(WORKER_TIMEOUT + Duration::from_mins(1));
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "must not time out an action on a peer instance's worker"
    );
    Ok(())
}

/// A worker registered here that stopped heartbeating is ours and looks dead,
/// so the short timeout must still fire.
#[nativelink_test]
async fn still_times_out_our_own_dead_worker() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("connected-to-us"));
    let action = executing_action(&worker_id, make_system_time(0));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    let state_mgr = state_manager(registry);

    MockClock::advance(WORKER_TIMEOUT + Duration::from_mins(1));
    assert!(
        state_mgr.should_timeout_operation(&action).await,
        "a registered worker that stopped heartbeating must time out"
    );
    Ok(())
}

/// A registered, heartbeating worker is bounded only by the executing ceiling.
#[nativelink_test]
async fn does_not_time_out_a_live_worker_mid_action() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("connected-to-us"));
    let action = executing_action(&worker_id, make_system_time(0));

    let elapsed = WORKER_TIMEOUT + Duration::from_mins(1);
    let registry = Arc::new(WorkerRegistry::new());
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(elapsed.as_secs()))
        .await;
    let state_mgr = state_manager(registry);

    MockClock::advance(elapsed);
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "a heartbeating worker's action must survive past worker_timeout_s"
    );
    Ok(())
}

/// `Action.timeout` for the deadline tests below. The grace is
/// `WORKER_TIMEOUT`, the state managers' `no_event_action_timeout`.
const ACTION_TIMEOUT: Duration = Duration::from_mins(1);

/// An action with `ACTION_TIMEOUT`, assigned to `worker_id` and executing
/// since `started`.
fn action_with_timeout(worker_id: &WorkerId, started: SystemTime) -> AwaitedAction {
    let mut info = action_info(started);
    info.timeout = ACTION_TIMEOUT;
    let action_digest = info.digest();
    let operation_id = OperationId::default();
    let mut action = AwaitedAction::new(operation_id.clone(), Arc::new(info), started);
    action.worker_set_state(
        Arc::new(ActionState {
            stage: ActionStage::Executing,
            client_operation_id: operation_id,
            action_digest,
            last_transition_timestamp: started,
        }),
        started,
    );
    action.set_worker_id(Some(worker_id.clone()), started);
    action
}

const fn action_timeout_cause() -> TimeoutCause {
    TimeoutCause::ActionTimeout {
        timeout: ACTION_TIMEOUT,
        grace: WORKER_TIMEOUT,
    }
}

/// Just short of `Action.timeout` plus the grace.
const WITHIN_GRACE: Duration =
    Duration::from_secs(ACTION_TIMEOUT.as_secs() + WORKER_TIMEOUT.as_secs() - 1);

/// Just past `Action.timeout` plus the grace.
const PAST_GRACE: Duration =
    Duration::from_secs(ACTION_TIMEOUT.as_secs() + WORKER_TIMEOUT.as_secs() + 1);

/// A heartbeating worker enforces `Action.timeout` itself, from when the
/// command starts, and reports a completed `DEADLINE_EXCEEDED` result. The
/// scheduler's clock starts at assignment, earlier, so ending the action at
/// `Action.timeout` would requeue every action that runs to its timeout onto
/// the worker still running it, and the worker's own result would then evict
/// it. The grace lets the live worker report first.
#[nativelink_test]
async fn gives_a_live_worker_the_grace_to_report_its_own_timeout() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("enforces-its-own-timeout"));
    let action = action_with_timeout(&worker_id, make_system_time(0));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(WITHIN_GRACE.as_secs()))
        .await;
    let state_mgr = state_manager_no_executing_ceiling(registry);

    MockClock::advance(WITHIN_GRACE);
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "a live worker's action past Action.timeout but within the grace is the worker's to end"
    );
    Ok(())
}

/// A heartbeating worker that never reports (a hung input fetch, an
/// unkillable child, a broken `timeout_handled_externally` wrapper) is timed
/// out by `Action.timeout` once the grace has passed, even with
/// `max_action_executing_timeout_s` disabled.
#[nativelink_test]
async fn times_out_a_live_but_wedged_worker_past_the_grace() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("heartbeats-but-never-reports"));
    let action = action_with_timeout(&worker_id, make_system_time(0));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(PAST_GRACE.as_secs()))
        .await;
    let state_mgr = state_manager_no_executing_ceiling(registry);

    MockClock::advance(PAST_GRACE);
    let cause = state_mgr.timeout_cause(&action).await;
    assert_eq!(
        cause,
        Some(action_timeout_cause()),
        "a live worker's action past Action.timeout plus the grace must time out"
    );
    assert!(
        cause
            .unwrap()
            .to_string()
            .contains("Action.timeout of 60 seconds"),
        "the client's error must name the deadline that fired"
    );
    Ok(())
}

/// The grace runs from the worker's last update when that is later than the
/// assignment, so it only has to cover the time since the worker last showed
/// signs of life.
#[nativelink_test]
async fn measures_the_grace_from_the_workers_last_update() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("updated-after-assignment"));
    let mut action = action_with_timeout(&worker_id, make_system_time(0));
    let updated = Duration::from_secs(30);
    let state = action.state().clone();
    action.worker_set_state(state, make_system_time(updated.as_secs()));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .update_worker_heartbeat(
            &worker_id,
            make_system_time((PAST_GRACE + updated).as_secs()),
        )
        .await;
    let state_mgr = state_manager_no_executing_ceiling(registry);

    MockClock::advance(PAST_GRACE);
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "the grace must run from the last worker update, not the assignment"
    );

    MockClock::advance(updated);
    assert_eq!(
        state_mgr.timeout_cause(&action).await,
        Some(action_timeout_cause()),
        "past Action.timeout plus the grace from the last update, the action must time out"
    );
    Ok(())
}

/// A peer instance's live worker enforces `Action.timeout` itself too, so it
/// gets the same grace here.
#[nativelink_test]
async fn gives_a_peer_instances_worker_the_grace() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    // Deliberately not registered here: it belongs to another instance.
    let action = action_with_timeout(
        &WorkerId::from(String::from("owned-by-another-scheduler")),
        make_system_time(0),
    );
    let state_mgr = state_manager_no_executing_ceiling(Arc::new(WorkerRegistry::new()));

    MockClock::advance(WITHIN_GRACE);
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "a peer's worker's action within the grace is the worker's to end"
    );
    Ok(())
}

/// An orphan nobody reaps, or a peer's worker that never reports, is timed
/// out by `Action.timeout` past the grace rather than waiting for the orphan
/// ceiling.
#[nativelink_test]
async fn times_out_an_orphan_on_action_timeout_past_the_grace() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let action = action_with_timeout(
        &WorkerId::from(String::from("owner-was-scaled-down")),
        make_system_time(0),
    );
    let state_mgr = state_manager_no_executing_ceiling(Arc::new(WorkerRegistry::new()));

    MockClock::advance(PAST_GRACE);
    assert_eq!(
        state_mgr.timeout_cause(&action).await,
        Some(action_timeout_cause()),
        "an orphan past Action.timeout plus the grace must time out, not wait an hour"
    );
    Ok(())
}

/// Registry heartbeats refresh only on keepalives, so a worker whose
/// keepalives lag reads Stale while its action is still running and still
/// updating. `Action.timeout` must not pre-empt it there either.
#[nativelink_test]
async fn gives_a_stale_worker_with_a_recent_update_the_grace() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("keepalives-lag"));
    let assigned = WORKER_TIMEOUT + Duration::from_secs(30);
    let action = action_with_timeout(&worker_id, make_system_time(assigned.as_secs()));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    let state_mgr = state_manager_no_executing_ceiling(registry);

    // Past Action.timeout, and less than worker_timeout_s since the action's
    // last update, so only Action.timeout could fire.
    MockClock::advance(assigned + ACTION_TIMEOUT + Duration::from_secs(1));
    assert!(
        !state_mgr.should_timeout_operation(&action).await,
        "a stale worker's recently updated action must get the grace too"
    );
    Ok(())
}

/// A Stale worker's action past `Action.timeout` plus the grace is timed out
/// for that reason, which is what the client is told.
#[nativelink_test]
async fn times_out_a_stale_worker_on_action_timeout_past_the_grace() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("connected-to-us"));
    let action = action_with_timeout(&worker_id, make_system_time(0));

    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    let state_mgr = state_manager_no_executing_ceiling(registry);

    MockClock::advance(PAST_GRACE);
    assert_eq!(
        state_mgr.timeout_cause(&action).await,
        Some(action_timeout_cause()),
        "a stale worker's action past Action.timeout plus the grace must name Action.timeout"
    );
    Ok(())
}

/// A heartbeating worker stuck on one action past the executing ceiling must
/// still be timed out, which is what `max_action_executing_timeout_s` is for.
#[nativelink_test]
async fn times_out_a_live_but_stuck_worker() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("alive-but-wedged"));
    let action = executing_action(&worker_id, make_system_time(0));

    let elapsed = MAX_EXECUTING + Duration::from_mins(1);
    let registry = Arc::new(WorkerRegistry::new());
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(elapsed.as_secs()))
        .await;
    let state_mgr = state_manager(registry);

    MockClock::advance(elapsed);
    assert!(
        state_mgr.should_timeout_operation(&action).await,
        "a worker stuck past max_action_executing_timeout_s must time out"
    );
    Ok(())
}

/// An orphan whose owning instance died permanently still gets reaped, on the
/// longer ceiling.
#[nativelink_test]
async fn eventually_times_out_an_orphan() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let action = executing_action(
        &WorkerId::from(String::from("owner-died-permanently")),
        make_system_time(0),
    );
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));

    MockClock::advance(MAX_EXECUTING + Duration::from_mins(1));
    assert!(
        state_mgr.should_timeout_operation(&action).await,
        "an orphaned action must still be reaped on max_action_executing_timeout_s"
    );
    Ok(())
}

/// The worker scheduler asks this to decide whether a worker should be told
/// to kill an operation, so it must be false for every way an operation can
/// leave a worker: requeued, reassigned, finished, or gone.
#[nativelink_test]
async fn is_executing_on_worker_follows_the_assignment() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));
    let worker_id = WorkerId::from(String::from("worker"));
    let other_worker_id = WorkerId::from(String::from("other-worker"));

    let _client_listener = state_mgr
        .add_action(
            OperationId::default(),
            Arc::new(action_info(make_system_time(0))),
        )
        .await?;
    let operation_id = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?
    .next()
    .await
    .expect("the queued operation")
    .as_state()
    .await?
    .0
    .client_operation_id
    .clone();

    // Queued: on nobody.
    assert!(
        !state_mgr
            .is_executing_on_worker(&operation_id, &worker_id)
            .await?
    );

    state_mgr
        .assign_operation(&operation_id, Ok(&worker_id))
        .await?;
    assert!(
        state_mgr
            .is_executing_on_worker(&operation_id, &worker_id)
            .await?
    );
    assert!(
        !state_mgr
            .is_executing_on_worker(&operation_id, &other_worker_id)
            .await?
    );

    // Requeued (a timeout), then picked up by another worker.
    state_mgr
        .assign_operation(
            &operation_id,
            Err(make_err!(Code::DeadlineExceeded, "timed out")),
        )
        .await?;
    assert!(
        !state_mgr
            .is_executing_on_worker(&operation_id, &worker_id)
            .await?
    );
    state_mgr
        .assign_operation(&operation_id, Ok(&other_worker_id))
        .await?;
    assert!(
        !state_mgr
            .is_executing_on_worker(&operation_id, &worker_id)
            .await?
    );
    assert!(
        state_mgr
            .is_executing_on_worker(&operation_id, &other_worker_id)
            .await?
    );

    // Finished.
    state_mgr
        .update_operation(
            &operation_id,
            &other_worker_id,
            UpdateOperationType::UpdateWithActionStage(ActionStage::Completed(
                ActionResult::default(),
            )),
        )
        .await?;
    assert!(
        !state_mgr
            .is_executing_on_worker(&operation_id, &other_worker_id)
            .await?
    );

    // Never existed.
    assert!(
        !state_mgr
            .is_executing_on_worker(&OperationId::default(), &worker_id)
            .await?
    );
    Ok(())
}

/// Counts what the matching engine would be handed.
async fn queued_count(
    state_mgr: &SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
) -> Result<usize, Error> {
    Ok(MatchingEngineStateManager::filter_operations(
        state_mgr,
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?
    .collect::<Vec<_>>()
    .await
    .len())
}

/// A queued action has no worker, so neither the worker-liveness timeout nor
/// the executing-stage ceiling can retire it. The only thing that does is a
/// filter pass reaching it, which is the matching engine's job and is exactly
/// what stops happening when these accumulate. The sweep retires them without
/// needing the matching engine to get there first.
#[nativelink_test]
async fn the_sweep_retires_queued_actions_no_client_is_waiting_on() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));

    let client_listener = state_mgr
        .add_action(
            OperationId::default(),
            Arc::new(action_info(make_system_time(0))),
        )
        .await?;

    // Nothing is retired while the client is still listening.
    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 0);
    assert_eq!(queued_count(state_mgr.as_ref()).await?, 1);

    // The client goes away and stops keeping the action alive.
    drop(client_listener);
    MockClock::advance(Duration::from_mins(6));

    // Retired without any matching pass having run.
    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 1);
    assert_eq!(
        queued_count(state_mgr.as_ref()).await?,
        0,
        "a retired action must stop being offered to the matching engine"
    );
    // And stays retired rather than being retired again on every pass.
    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 0);
    Ok(())
}

/// What a listing of the queue does after its first entry.
#[derive(Clone, Copy)]
enum Fault {
    /// The listing names a second entry whose record is gone, as after an
    /// eviction: the stream yields the read error in its place. The rest of
    /// the listing follows.
    LostRecord,
    /// The next page fails to load, as when the store goes away mid-read:
    /// the stream yields the error and ends.
    Transport,
    /// The second entry is listed but reading its record fails with this
    /// code, as when it expired or was evicted between the search and the
    /// read (`NotFound`), was damaged (`InvalidArgument`), or the store
    /// went away (`Unavailable`).
    BrokenRecord(Code),
    /// The store hands back a row it could not decode, as the Redis listing
    /// does for damaged JSON: an `InvalidArgument` item between two good
    /// ones, before any subscriber exists.
    UndecodableRow,
}

/// A subscriber whose record may be unreadable.
enum MaybeBroken<S> {
    Sound(S),
    Broken(Code),
}

impl<S: AwaitedActionSubscriber> AwaitedActionSubscriber for MaybeBroken<S> {
    async fn changed(&mut self) -> Result<AwaitedAction, Error> {
        match self {
            Self::Sound(subscriber) => subscriber.changed().await,
            Self::Broken(code) => Err(make_err!(*code, "record unreadable")),
        }
    }

    async fn borrow(&self) -> Result<AwaitedAction, Error> {
        match self {
            Self::Sound(subscriber) => subscriber.borrow().await,
            Self::Broken(code) => Err(make_err!(*code, "record unreadable")),
        }
    }
}

/// The memory database with one fault injected into every queue listing.
struct FaultyDb<T: AwaitedActionDb> {
    inner: T,
    fault: Fault,
}

impl<T: AwaitedActionDb> MetricsComponent for FaultyDb<T> {
    fn publish(
        &self,
        kind: MetricKind,
        field_metadata: MetricFieldData,
    ) -> Result<MetricPublishKnownKindData, nativelink_metric::Error> {
        self.inner.publish(kind, field_metadata)
    }
}

impl<T: AwaitedActionDb> FaultyDb<T> {
    /// The listing as the store hands it back, with the fault in place of
    /// or beside its second entry.
    fn inject(
        &self,
        listed: Vec<Result<T::Subscriber, Error>>,
    ) -> Vec<Result<MaybeBroken<T::Subscriber>, Error>> {
        let mut items = Vec::new();
        for (i, item) in listed.into_iter().enumerate() {
            if i == 1 {
                match self.fault {
                    Fault::LostRecord => {
                        items.push(Err(make_err!(Code::NotFound, "record evicted")));
                    }
                    Fault::UndecodableRow => {
                        items.push(Err(make_err!(
                            Code::InvalidArgument,
                            "In AwaitedAction::decode"
                        )));
                    }
                    Fault::Transport => {
                        items.push(Err(make_err!(Code::Unavailable, "FT.CURSOR READ failed")));
                        break;
                    }
                    Fault::BrokenRecord(code) => {
                        items.push(Ok(MaybeBroken::Broken(code)));
                        continue;
                    }
                }
            }
            items.push(item.map(MaybeBroken::Sound));
        }
        items
    }
}

impl<T: AwaitedActionDb> AwaitedActionDb for FaultyDb<T> {
    type Subscriber = MaybeBroken<T::Subscriber>;

    async fn get_awaited_action_by_id(
        &self,
        client_operation_id: &OperationId,
    ) -> Result<Option<Self::Subscriber>, Error> {
        Ok(self
            .inner
            .get_awaited_action_by_id(client_operation_id)
            .await?
            .map(MaybeBroken::Sound))
    }

    async fn get_all_awaited_actions(
        &self,
    ) -> Result<impl Stream<Item = Result<Self::Subscriber, Error>> + Send, Error> {
        let listed: Vec<_> = self.inner.get_all_awaited_actions().await?.collect().await;
        Ok(stream::iter(self.inject(listed)))
    }

    async fn get_by_operation_id(
        &self,
        operation_id: &OperationId,
    ) -> Result<Option<Self::Subscriber>, Error> {
        Ok(self
            .inner
            .get_by_operation_id(operation_id)
            .await?
            .map(MaybeBroken::Sound))
    }

    async fn get_range_of_actions(
        &self,
        state: SortedAwaitedActionState,
        start: Bound<SortedAwaitedAction>,
        end: Bound<SortedAwaitedAction>,
        desc: bool,
    ) -> Result<impl Stream<Item = Result<Self::Subscriber, Error>> + Send, Error> {
        let listed: Vec<_> = self
            .inner
            .get_range_of_actions(state, start, end, desc)
            .await?
            .collect()
            .await;
        Ok(stream::iter(self.inject(listed)))
    }

    async fn update_awaited_action(&self, new_awaited_action: AwaitedAction) -> Result<(), Error> {
        self.inner.update_awaited_action(new_awaited_action).await
    }

    async fn add_action(
        &self,
        client_operation_id: OperationId,
        action_info: Arc<ActionInfo>,
        no_event_action_timeout: Duration,
    ) -> Result<Self::Subscriber, Error> {
        Ok(MaybeBroken::Sound(
            self.inner
                .add_action(client_operation_id, action_info, no_event_action_timeout)
                .await?,
        ))
    }
}

fn faulty_state_manager(
    fault: Fault,
) -> Arc<
    SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
> {
    let task_change_notify = Arc::new(Notify::new());
    SimpleSchedulerStateManager::new(
        5,
        WORKER_TIMEOUT,
        Duration::from_mins(5),
        MAX_EXECUTING,
        FaultyDb {
            inner: memory_awaited_action_db_factory(
                0,
                &task_change_notify,
                MockInstantWrapped::default,
            ),
            fault,
        },
        MockInstantWrapped::default,
        Some(Arc::new(WorkerRegistry::new())),
    )
}

/// Three abandoned actions, and the listing reports a lost record between
/// the first and the second. The sweep retires all three.
#[nativelink_test]
async fn the_sweep_skips_a_lost_record_and_retires_the_rest() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::LostRecord);
    for _ in 0..3 {
        drop(
            state_mgr
                .add_action(
                    OperationId::default(),
                    Arc::new(action_info(make_system_time(0))),
                )
                .await?,
        );
    }
    MockClock::advance(Duration::from_mins(6));

    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 3);
    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 0);
    Ok(())
}

/// The listing's next page fails to load. That is not a lost entry, it is
/// an incomplete sweep, and it must say so rather than report a clean pass
/// over the entries it never reached.
#[nativelink_test]
async fn the_sweep_fails_when_the_listing_fails() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::Transport);
    for _ in 0..3 {
        drop(
            state_mgr
                .add_action(
                    OperationId::default(),
                    Arc::new(action_info(make_system_time(0))),
                )
                .await?,
        );
    }
    MockClock::advance(Duration::from_mins(6));

    let err = state_mgr
        .sweep_abandoned_queued_actions()
        .await
        .expect_err("a listing that failed part way is a failed sweep");
    assert_eq!(err.code, Code::Unavailable);
    Ok(())
}

/// Queues `n` actions and returns their client listeners.
async fn add_queued_actions(
    state_mgr: &impl ClientStateManager,
    n: usize,
) -> Result<Vec<Box<dyn ActionStateResult>>, Error> {
    let mut clients = Vec::with_capacity(n);
    for _ in 0..n {
        clients.push(
            state_mgr
                .add_action(
                    OperationId::default(),
                    Arc::new(action_info(make_system_time(0))),
                )
                .await?,
        );
    }
    Ok(clients)
}

/// Three abandoned actions, the second one's record unreadable when the
/// sweep goes to read it. The sweep retires the other two.
#[nativelink_test]
async fn the_sweep_skips_a_record_it_cannot_read() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::BrokenRecord(Code::NotFound));
    for _ in 0..3 {
        drop(
            state_mgr
                .add_action(
                    OperationId::default(),
                    Arc::new(action_info(make_system_time(0))),
                )
                .await?,
        );
    }
    MockClock::advance(Duration::from_mins(6));

    assert_eq!(state_mgr.sweep_abandoned_queued_actions().await?, 2);
    Ok(())
}

/// A listing that meets a record it cannot decode leaves it out and goes on,
/// so the provisioner and the admin API, which read this listing every few
/// seconds, still see every other queued action.
#[nativelink_test]
async fn the_listing_skips_a_record_it_cannot_read() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::BrokenRecord(Code::InvalidArgument));
    // Kept so the clients count as waiting.
    let _clients = add_queued_actions(state_mgr.as_ref(), 3).await?;

    let listed = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?
    .collect::<Vec<_>>()
    .await;
    assert_eq!(listed.len(), 2, "the unreadable record is left out");
    for operation in &listed {
        operation
            .as_state()
            .await
            .err_tip(|| "every listed operation is readable")?;
    }
    Ok(())
}

/// The Redis listing reports a row it cannot decode as an error item, before
/// any record is read. The queued listing leaves it out and lists the rest.
#[nativelink_test]
async fn the_listing_skips_a_row_it_cannot_decode() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::UndecodableRow);
    let _clients = add_queued_actions(state_mgr.as_ref(), 3).await?;

    let listed = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?
    .collect::<Vec<_>>()
    .await;
    assert_eq!(
        listed.len(),
        3,
        "the undecodable row is left out, the rest listed"
    );
    for operation in &listed {
        operation
            .as_state()
            .await
            .err_tip(|| "every listed operation is readable")?;
    }
    Ok(())
}

/// The listing of every operation, which collects the whole set before it
/// filters, also survives a row it cannot decode instead of failing whole.
#[nativelink_test]
async fn the_listing_of_every_operation_skips_a_row_it_cannot_decode() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::UndecodableRow);
    let _clients = add_queued_actions(state_mgr.as_ref(), 3).await?;

    let listed = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter::default(),
    )
    .await?
    .collect::<Vec<_>>()
    .await;
    assert_eq!(listed.len(), 3);
    Ok(())
}

/// The listing of every operation still fails when the store does, rather
/// than quietly listing whatever came before the failure.
#[nativelink_test]
async fn the_listing_of_every_operation_fails_when_the_store_does() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::Transport);
    let _clients = add_queued_actions(state_mgr.as_ref(), 3).await?;

    let err = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter::default(),
    )
    .await
    .err()
    .expect("a store failure fails the listing");
    assert_eq!(err.code, Code::Unavailable);
    Ok(())
}

/// A read that fails because the store is unreachable is not a lost record;
/// the listing reports it instead of quietly leaving the action out.
#[nativelink_test]
async fn the_listing_reports_a_store_failure_on_read() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = faulty_state_manager(Fault::BrokenRecord(Code::Unavailable));
    // Kept so the clients count as waiting.
    let _clients = add_queued_actions(state_mgr.as_ref(), 3).await?;

    let listed = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?
    .collect::<Vec<_>>()
    .await;
    let mut failures = 0;
    for operation in &listed {
        if let Err(err) = operation.as_state().await {
            assert_eq!(err.code, Code::Unavailable);
            failures += 1;
        }
    }
    assert_eq!(failures, 1, "the store failure reaches the reader");
    Ok(())
}

fn faulty_scheduler(fault: Fault) -> Arc<SimpleScheduler> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let task_change_notify = Arc::new(Notify::new());
    let spec = SimpleSpec {
        client_action_timeout_s: 1_000_000,
        ..Default::default()
    };
    let (scheduler, _worker_scheduler) = SimpleScheduler::new_with_callback(
        &spec,
        FaultyDb {
            inner: memory_awaited_action_db_factory(
                0,
                &task_change_notify,
                MockInstantWrapped::default,
            ),
            fault,
        },
        || async move {},
        task_change_notify,
        MockInstantWrapped::default,
        None,
    );
    scheduler
}

async fn three_queued_actions_and_a_worker(
    scheduler: &SimpleScheduler,
) -> Result<mpsc::Receiver<UpdateForWorker>, Error> {
    for _ in 0..3 {
        scheduler
            .add_action(
                OperationId::default(),
                Arc::new(action_info(make_system_time(0))),
            )
            .await?;
    }
    let (tx, mut rx) = mpsc::channel(64);
    scheduler
        .add_worker(Worker::new(
            WorkerId("worker".to_string()),
            PlatformProperties::default(),
            tx,
            NOW_TIME,
            0,
        ))
        .await?;
    // The connection result.
    rx.recv().await.unwrap();
    Ok(rx)
}

/// A lost record in the middle of the queue is skipped, and the actions
/// behind it are still dispatched in the same pass.
#[nativelink_test]
async fn the_matcher_skips_a_lost_record_and_dispatches_the_rest() -> Result<(), Error> {
    let scheduler = faulty_scheduler(Fault::LostRecord);
    let mut rx = three_queued_actions_and_a_worker(&scheduler).await?;

    scheduler.do_try_match_for_test().await?;
    for _ in 0..3 {
        rx.try_recv().expect("each real action reaches the worker");
    }
    assert!(rx.try_recv().is_err());
    Ok(())
}

/// A listing that fails part way is a failed pass, which the loop reruns
/// at once; it must not be read as one orphan and a clean pass.
#[nativelink_test]
async fn the_matcher_fails_the_pass_when_the_listing_fails() -> Result<(), Error> {
    let scheduler = faulty_scheduler(Fault::Transport);
    let _rx = three_queued_actions_and_a_worker(&scheduler).await?;

    let err = scheduler
        .do_try_match_for_test()
        .await
        .expect_err("a listing that failed part way is a failed pass");
    assert_eq!(err.code, Code::Unavailable);
    Ok(())
}

/// Adds a queued action through the client side and returns the operation
/// id the matching engine sees for it.
async fn queued_operation_id(
    state_mgr: &(impl ClientStateManager + MatchingEngineStateManager),
) -> Result<(OperationId, Box<dyn ActionStateResult>), Error> {
    let client = state_mgr
        .add_action(
            OperationId::default(),
            Arc::new(action_info(make_system_time(0))),
        )
        .await?;
    let mut queued = MatchingEngineStateManager::filter_operations(
        state_mgr,
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?;
    let operation = queued.next().await.expect("one queued operation");
    let operation_id = operation.as_state().await?.0.client_operation_id.clone();
    Ok((operation_id, client))
}

#[nativelink_test]
async fn fail_queued_operation_completes_a_queued_action() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));
    let (operation_id, client) = queued_operation_id(state_mgr.as_ref()).await?;

    let failed = state_mgr
        .fail_queued_operation(
            &operation_id,
            make_err!(Code::FailedPrecondition, "no worker"),
        )
        .await?;
    assert!(failed);

    let (state, _origin_metadata) = client.as_state().await?;
    let ActionStage::Completed(result) = &state.stage else {
        panic!("expected Completed, got {:?}", state.stage);
    };
    let err = result.error.as_ref().expect("error carried through");
    assert_eq!(err.code, Code::FailedPrecondition);
    assert_eq!(err.messages, vec!["no worker".to_string()]);
    assert_eq!(state.last_transition_timestamp, make_system_time(0));
    Ok(())
}

#[nativelink_test]
async fn fail_queued_operation_leaves_an_executing_action_alone() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));
    let (operation_id, client) = queued_operation_id(state_mgr.as_ref()).await?;
    let worker_id = WorkerId::from(String::from("worker"));
    state_mgr
        .assign_operation(&operation_id, Ok(&worker_id))
        .await?;

    let failed = state_mgr
        .fail_queued_operation(
            &operation_id,
            make_err!(Code::FailedPrecondition, "no worker"),
        )
        .await?;
    assert!(!failed);
    assert_eq!(client.as_state().await?.0.stage, ActionStage::Executing);
    Ok(())
}

#[nativelink_test]
async fn fail_queued_operation_ignores_an_unknown_action() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));

    let failed = state_mgr
        .fail_queued_operation(
            &OperationId::default(),
            make_err!(Code::FailedPrecondition, "no worker"),
        )
        .await?;
    assert!(!failed);
    Ok(())
}

#[nativelink_test]
async fn fail_queued_operation_ignores_a_completed_action() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let state_mgr = state_manager(Arc::new(WorkerRegistry::new()));
    let (operation_id, client) = queued_operation_id(state_mgr.as_ref()).await?;
    assert!(
        state_mgr
            .fail_queued_operation(&operation_id, make_err!(Code::FailedPrecondition, "first"))
            .await?
    );

    // A second failure must not overwrite the first result.
    let failed = state_mgr
        .fail_queued_operation(&operation_id, make_err!(Code::Internal, "second"))
        .await?;
    assert!(!failed);
    let (state, _origin_metadata) = client.as_state().await?;
    let ActionStage::Completed(result) = &state.stage else {
        panic!("expected Completed, got {:?}", state.stage);
    };
    assert_eq!(
        result.error.as_ref().unwrap().code,
        Code::FailedPrecondition
    );
    Ok(())
}

type TestStateManager<T> =
    SimpleSchedulerStateManager<T, MockInstantWrapped, fn() -> MockInstantWrapped>;

/// Queues one action on the state manager and assigns it to `worker_id`, as
/// the matching pass would, returning its operation id.
async fn queue_and_assign<T: AwaitedActionDb>(
    state_mgr: &TestStateManager<T>,
    worker_id: &WorkerId,
) -> Result<OperationId, Error> {
    let (operation_id, subscriber) = queue_and_assign_with_client(state_mgr, worker_id).await?;
    // No client stays attached: the client-driven timeout check never runs.
    drop(subscriber);
    Ok(operation_id)
}

/// Same, keeping the client attached so the test can read the final state.
async fn queue_and_assign_with_client<T: AwaitedActionDb>(
    state_mgr: &TestStateManager<T>,
    worker_id: &WorkerId,
) -> Result<(OperationId, Box<dyn ActionStateResult>), Error> {
    let started = make_system_time(0);
    let subscriber = state_mgr
        .add_action(OperationId::default(), Arc::new(action_info(started)))
        .await?;
    let mut queued = MatchingEngineStateManager::filter_operations(
        state_mgr,
        OperationFilter {
            stages: OperationStageFlags::Queued,
            ..Default::default()
        },
    )
    .await?;
    let listed = queued
        .next()
        .await
        .err_tip(|| "expected one queued action")?;
    let (state, _) = listed.as_state().await?;
    let operation_id = state.client_operation_id.clone();
    state_mgr
        .assign_operation(&operation_id, Ok(worker_id))
        .await?;
    Ok((operation_id, subscriber))
}

async fn count_in_stage<T: AwaitedActionDb>(
    state_mgr: &TestStateManager<T>,
    stage: OperationStageFlags,
) -> Result<usize, Error> {
    let stream = MatchingEngineStateManager::filter_operations(
        state_mgr,
        OperationFilter {
            stages: stage,
            ..Default::default()
        },
    )
    .await?;
    Ok(stream.collect::<Vec<_>>().await.len())
}

/// The executing sweep retires an action past the ceiling with no client
/// attached, which the client-driven check can never reach.
#[nativelink_test]
async fn executing_sweep_retires_a_silent_action_without_a_client() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("alive-but-wedged"));
    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    let state_mgr = state_manager(registry.clone());
    queue_and_assign(&state_mgr, &worker_id).await?;
    assert_eq!(
        count_in_stage(&state_mgr, OperationStageFlags::Executing).await?,
        1
    );

    // The worker keeps heartbeating and still holds the action; before the
    // ceiling nothing happens.
    let still_running = |_: WorkerId, _: OperationId| future::ready(Some(true)).boxed();
    let mut lost_since = HashMap::new();
    MockClock::advance(Duration::from_mins(5));
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(5 * 60))
        .await;
    let report = state_mgr
        .sweep_executing_actions(&still_running, &mut lost_since, Duration::from_mins(1))
        .await?;
    assert_eq!(report.retired, 0);
    assert_eq!(report.requeued, 0);
    // Five minutes executing: counted in the 5m to 15m bucket.
    assert_eq!(report.ages.counts(), [0, 0, 1, 0, 0, 0]);
    assert_eq!(report.ages.oldest(), Duration::from_mins(5));

    // Past the ceiling, silent since assignment: retired and queued again.
    MockClock::advance(MAX_EXECUTING);
    registry
        .update_worker_heartbeat(
            &worker_id,
            make_system_time(5 * 60 + MAX_EXECUTING.as_secs()),
        )
        .await;
    let report = state_mgr
        .sweep_executing_actions(&still_running, &mut lost_since, Duration::from_mins(1))
        .await?;
    assert_eq!(report.retired, 1);
    // Back in the queue, where the abandoned-client rule then completes it:
    // nobody has been listening for twenty minutes, and this db keeps no
    // completed records. Either way it is no longer executing.
    assert_eq!(
        count_in_stage(&state_mgr, OperationStageFlags::Executing).await?,
        0
    );
    Ok(())
}

/// An action its worker no longer runs has lost its result; after the grace
/// the sweep sends it back to the queue, untried.
#[nativelink_test]
async fn executing_sweep_requeues_an_action_its_worker_no_longer_runs() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("finished-but-unrecorded"));
    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    let state_mgr = state_manager(registry.clone());
    queue_and_assign(&state_mgr, &worker_id).await?;

    let not_running = |_: WorkerId, _: OperationId| future::ready(Some(false)).boxed();
    let grace = Duration::from_mins(1);
    let mut lost_since = HashMap::new();

    // Just assigned: inside the grace, the dispatch may still be on its way.
    let report = state_mgr
        .sweep_executing_actions(&not_running, &mut lost_since, grace)
        .await?;
    assert_eq!(report.requeued, 0);
    assert!(
        lost_since.is_empty(),
        "inside the grace nothing is tracked yet"
    );

    // Past the grace since assignment, first sighting: tracked, not moved.
    MockClock::advance(Duration::from_mins(2));
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(120))
        .await;
    let report = state_mgr
        .sweep_executing_actions(&not_running, &mut lost_since, grace)
        .await?;
    assert_eq!(report.requeued, 0);
    assert_eq!(lost_since.len(), 1);

    // Still not running a grace later: requeued, and no longer tracked.
    MockClock::advance(grace + Duration::from_secs(1));
    registry
        .update_worker_heartbeat(&worker_id, make_system_time(181))
        .await;
    let report = state_mgr
        .sweep_executing_actions(&not_running, &mut lost_since, grace)
        .await?;
    assert_eq!(report.requeued, 1);
    assert!(lost_since.is_empty());
    assert_eq!(
        count_in_stage(&state_mgr, OperationStageFlags::Queued).await?,
        1
    );

    // A peer's worker (None) is nobody's to judge here.
    queue_and_assign(&state_mgr, &WorkerId::from(String::from("peer-worker"))).await?;
    MockClock::advance(Duration::from_mins(2));
    let elsewhere = |_: WorkerId, _: OperationId| future::ready(None).boxed();
    let report = state_mgr
        .sweep_executing_actions(&elsewhere, &mut lost_since, grace)
        .await?;
    assert_eq!(report.requeued, 0);
    assert_eq!(report.retired, 0);
    Ok(())
}

/// A lost result spends one of the action's `max_job_retries`, so a store
/// that keeps refusing the result ends the action with an error the client
/// sees instead of running it again forever.
#[nativelink_test]
async fn executing_sweep_lost_result_counts_against_max_job_retries() -> Result<(), Error> {
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let worker_id = WorkerId::from(String::from("result-never-lands"));
    let registry = Arc::new(WorkerRegistry::new());
    registry
        .register_worker(&worker_id, make_system_time(0))
        .await;
    // No retries: the first lost result is one too many.
    let state_mgr = state_manager_with_retries(registry.clone(), 0);
    let (_operation_id, client) = queue_and_assign_with_client(&state_mgr, &worker_id).await?;

    let not_running = |_: WorkerId, _: OperationId| future::ready(Some(false)).boxed();
    let grace = Duration::from_mins(1);
    let mut lost_since = HashMap::new();
    for seconds in [120, 181] {
        MockClock::advance(Duration::from_secs(if seconds == 120 { 120 } else { 61 }));
        registry
            .update_worker_heartbeat(&worker_id, make_system_time(seconds))
            .await;
        state_mgr
            .sweep_executing_actions(&not_running, &mut lost_since, grace)
            .await?;
    }

    assert_eq!(
        count_in_stage(&state_mgr, OperationStageFlags::Queued).await?,
        0,
        "past max_job_retries the action is not queued again"
    );
    let (state, _origin_metadata) = client.as_state().await?;
    let ActionStage::Completed(result) = &state.stage else {
        panic!("expected Completed, got {:?}", state.stage);
    };
    let err = result.error.as_ref().expect("the client is told why");
    assert_eq!(err.code, Code::FailedPrecondition);
    assert!(
        err.messages
            .iter()
            .any(|m| m.contains("never reached the scheduler")),
        "the failure names the lost result: {err:?}"
    );
    Ok(())
}

/// How many record reads a listing has in flight, and the most it ever had.
#[derive(Default)]
struct ReadGauge {
    in_flight: AtomicUsize,
    peak: AtomicUsize,
}

/// A subscriber whose first record read takes `delay`, counted on the
/// gauge, as the Redis subscriber's keepalive round trip does; later reads
/// come from its copy, as they do there.
struct Slow<S> {
    inner: S,
    delay: Duration,
    read_once: AtomicBool,
    gauge: Arc<ReadGauge>,
}

impl<S: AwaitedActionSubscriber> AwaitedActionSubscriber for Slow<S> {
    async fn changed(&mut self) -> Result<AwaitedAction, Error> {
        self.inner.changed().await
    }

    async fn borrow(&self) -> Result<AwaitedAction, Error> {
        if !self.read_once.swap(true, Ordering::SeqCst) {
            let now = self.gauge.in_flight.fetch_add(1, Ordering::SeqCst) + 1;
            self.gauge.peak.fetch_max(now, Ordering::SeqCst);
            tokio::time::sleep(self.delay).await;
            self.gauge.in_flight.fetch_sub(1, Ordering::SeqCst);
        }
        self.inner.borrow().await
    }
}

/// The memory database behind a slow store: the record a listing hands back
/// first takes the longest to read, so reads finished out of order show up
/// as a listing out of order.
struct SlowDb<T: AwaitedActionDb> {
    inner: T,
    gauge: Arc<ReadGauge>,
}

impl<T: AwaitedActionDb> MetricsComponent for SlowDb<T> {
    fn publish(
        &self,
        kind: MetricKind,
        field_metadata: MetricFieldData,
    ) -> Result<MetricPublishKnownKindData, nativelink_metric::Error> {
        self.inner.publish(kind, field_metadata)
    }
}

impl<T: AwaitedActionDb> SlowDb<T> {
    fn slow(&self, subscriber: T::Subscriber, delay: Duration) -> Slow<T::Subscriber> {
        Slow {
            inner: subscriber,
            delay,
            read_once: AtomicBool::new(false),
            gauge: self.gauge.clone(),
        }
    }

    fn slow_listing(
        &self,
        listed: Vec<Result<T::Subscriber, Error>>,
    ) -> Vec<Result<Slow<T::Subscriber>, Error>> {
        let n = listed.len();
        listed
            .into_iter()
            .enumerate()
            .map(|(i, item)| {
                let delay = Duration::from_millis(u64::try_from(n - i).expect("fits"));
                item.map(|subscriber| self.slow(subscriber, delay))
            })
            .collect()
    }
}

impl<T: AwaitedActionDb> AwaitedActionDb for SlowDb<T> {
    type Subscriber = Slow<T::Subscriber>;

    async fn get_awaited_action_by_id(
        &self,
        client_operation_id: &OperationId,
    ) -> Result<Option<Self::Subscriber>, Error> {
        Ok(self
            .inner
            .get_awaited_action_by_id(client_operation_id)
            .await?
            .map(|subscriber| self.slow(subscriber, Duration::ZERO)))
    }

    async fn get_all_awaited_actions(
        &self,
    ) -> Result<impl Stream<Item = Result<Self::Subscriber, Error>> + Send, Error> {
        let listed: Vec<_> = self.inner.get_all_awaited_actions().await?.collect().await;
        Ok(stream::iter(self.slow_listing(listed)))
    }

    async fn get_by_operation_id(
        &self,
        operation_id: &OperationId,
    ) -> Result<Option<Self::Subscriber>, Error> {
        Ok(self
            .inner
            .get_by_operation_id(operation_id)
            .await?
            .map(|subscriber| self.slow(subscriber, Duration::ZERO)))
    }

    async fn get_range_of_actions(
        &self,
        state: SortedAwaitedActionState,
        start: Bound<SortedAwaitedAction>,
        end: Bound<SortedAwaitedAction>,
        desc: bool,
    ) -> Result<impl Stream<Item = Result<Self::Subscriber, Error>> + Send, Error> {
        let listed: Vec<_> = self
            .inner
            .get_range_of_actions(state, start, end, desc)
            .await?
            .collect()
            .await;
        Ok(stream::iter(self.slow_listing(listed)))
    }

    async fn update_awaited_action(&self, new_awaited_action: AwaitedAction) -> Result<(), Error> {
        self.inner.update_awaited_action(new_awaited_action).await
    }

    async fn add_action(
        &self,
        client_operation_id: OperationId,
        action_info: Arc<ActionInfo>,
        no_event_action_timeout: Duration,
    ) -> Result<Self::Subscriber, Error> {
        let subscriber = self
            .inner
            .add_action(client_operation_id, action_info, no_event_action_timeout)
            .await?;
        Ok(self.slow(subscriber, Duration::ZERO))
    }
}

fn slow_state_manager(
    gauge: Arc<ReadGauge>,
) -> Arc<
    SimpleSchedulerStateManager<
        impl AwaitedActionDb,
        MockInstantWrapped,
        fn() -> MockInstantWrapped,
    >,
> {
    let task_change_notify = Arc::new(Notify::new());
    SimpleSchedulerStateManager::new(
        5,
        WORKER_TIMEOUT,
        Duration::from_mins(5),
        MAX_EXECUTING,
        SlowDb {
            inner: memory_awaited_action_db_factory(
                0,
                &task_change_notify,
                MockInstantWrapped::default,
            ),
            gauge,
        },
        MockInstantWrapped::default,
        Some(Arc::new(WorkerRegistry::new())),
    )
}

/// Queues actions with priorities `0..n` and returns their client listeners.
async fn add_prioritised_actions(
    state_mgr: &impl ClientStateManager,
    n: i32,
) -> Result<Vec<Box<dyn ActionStateResult>>, Error> {
    let mut clients = Vec::new();
    for priority in 0..n {
        let mut info = action_info(make_system_time(0));
        info.priority = priority;
        clients.push(
            state_mgr
                .add_action(OperationId::default(), Arc::new(info))
                .await?,
        );
    }
    Ok(clients)
}

/// The listing reads its records many at a time, since on a Redis backend
/// each read is a round trip, and still hands them back in the store's
/// order, highest priority first.
#[nativelink_test]
async fn the_listing_reads_records_concurrently_in_the_stores_order() -> Result<(), Error> {
    const QUEUE: i32 = 100;
    MockClock::set_time(Duration::from_secs(NOW_TIME));
    let gauge = Arc::new(ReadGauge::default());
    let state_mgr = slow_state_manager(gauge.clone());
    // Kept so the clients count as waiting.
    let _clients = add_prioritised_actions(state_mgr.as_ref(), QUEUE).await?;

    let listed = MatchingEngineStateManager::filter_operations(
        state_mgr.as_ref(),
        OperationFilter {
            stages: OperationStageFlags::Queued,
            order_by_priority_direction: Some(OrderDirection::Desc),
            ..Default::default()
        },
    )
    .await?
    .collect::<Vec<_>>()
    .await;
    let mut priorities = Vec::with_capacity(listed.len());
    for operation in &listed {
        priorities.push(operation.as_action_info().await?.0.priority);
    }
    let expected: Vec<i32> = (0..QUEUE).rev().collect();
    assert_eq!(priorities, expected, "the listing keeps the store's order");
    assert_eq!(
        gauge.peak.load(Ordering::SeqCst),
        LISTING_READ_CONCURRENCY,
        "the reads run this many at a time"
    );
    Ok(())
}
