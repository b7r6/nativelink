// Copyright 2026 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#[path = "authority/reference.rs"]
mod m1;
#[path = "retention/protocol.rs"]
mod protocol;
#[path = "terminal_outcome/reference.rs"]
mod reference;
#[path = "retention/reference.rs"]
mod retention;
#[path = "terminal_outcome/types.rs"]
mod types;

mod cases {
    // Reuse every frozen assertion and its private fixture constructors without
    // modifying the original cases. The nested audit adds only new probes.
    include!("terminal_outcome/cases.rs");

    mod audit {
        include!("terminal_outcome/restore_audit.rs");
    }
}
