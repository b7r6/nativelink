#!/bin/bash
# Copyright 2026 The NativeLink Authors. All rights reserved.
#
# Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    See LICENSE file for details
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Sanity check for REAPI content-defined chunking: uploads a large blob via
# SpliceBlob (Bazel --experimental_remote_cache_chunking), verifies the
# server registered a chunk layout, then re-fetches the blob from the remote
# cache via the chunked download path and checks it is byte-identical.

if [[ $UNDER_TEST_RUNNER -ne 1 ]]; then
    echo "This script should be run under run_integration_tests.sh"
    exit 1
fi

# This test uploads a locally-built output to exercise the chunked write path
# (see CHUNKING_FLAGS below), which the repo-wide
# --remote_upload_local_results=false disables. To keep that anti-poisoning
# default intact for PR/developer lanes, this test runs only where local
# uploads are explicitly enabled: merges to main and the scheduled canary set
# NL_LOCAL_UPLOADS=1 (see main.yaml / nativelink-cloud-canary.yaml).
if [[ ${NL_LOCAL_UPLOADS:-0} != "1" ]]; then
    echo "Skipping $(basename "$0"): requires local cache uploads (main/canary lanes only)."
    exit 0
fi
set -x

# Bazel uploads cache entries in the background by default
# (--remote_cache_async, on since Bazel 8), so a build can return before the
# chunked upload and SpliceBlob complete. Force synchronous uploads so the
# chunk-index assertions below cannot race the upload.
#
# nativelink.bazelrc sets `build --remote_upload_local_results=false`
# repo-wide, and CI's setup-nativelink-cloud action writes the same into
# user.bazelrc for read-mode lanes. That suppresses the upload of this
# locally-built genrule output, so the server never registers a chunk layout
# and the index assertion below fails. Re-enable uploads for this test only
# (a command-line flag overrides the rc default); this is independent of the
# digest function -- chunking works under both sha256 and blake3.
CHUNKING_FLAGS=(--config self_test --experimental_remote_cache_chunking
    --remote_cache_async=false --remote_upload_local_results=true)
EXPECTED_SHA=$(seq 1 1000000 | sha256sum | awk '{print $1}')
# The test runner's working directory is not the workspace root, so resolve
# the output location through bazel itself.
ARTIFACT="$(bazel --output_base="$BAZEL_CACHE_DIR" info "${CHUNKING_FLAGS[@]}" bazel-bin)/chunking_test_artifact.txt"

# First build executes the action locally and uploads the ~6.9MB output as
# chunks (SpliceBlob).
bazel --output_base="$BAZEL_CACHE_DIR" build "${CHUNKING_FLAGS[@]}" //:chunking_test_artifact
FIRST_SHA=$(sha256sum "$ARTIFACT" | awk '{print $1}')
if [[ $FIRST_SHA != "$EXPECTED_SHA" ]]; then
    echo "Expected locally built artifact to have sha $EXPECTED_SHA, got $FIRST_SHA."
    exit 1
fi

# The server must have registered a chunk layout for the spliced blob. The
# index store is mounted from the host by docker-compose.
CHUNK_INDEX_DIR="${NATIVELINK_DIR:-$HOME/.cache/nativelink}/content_path-chunk-index"
if [[ -z $(find "$CHUNK_INDEX_DIR" -type f 2> /dev/null) ]]; then
    echo "Expected a chunk layout in $CHUNK_INDEX_DIR after a chunked upload."
    echo "SpliceBlob was likely not used; check that the server advertises"
    echo "chunking support and that bazel supports the chunking flag."
    echo "Diagnostics: contents of the mounted cache dir and root's default:"
    sudo find "${NATIVELINK_DIR:-$HOME/.cache/nativelink}" -maxdepth 1 2> /dev/null || true
    sudo find /root/.cache/nativelink -maxdepth 1 2> /dev/null || true
    exit 1
fi

# Clean our local cache and re-fetch from the remote cache through the
# chunked download path.
bazel --output_base="$BAZEL_CACHE_DIR" clean
OUTPUT=$(bazel --output_base="$BAZEL_CACHE_DIR" build "${CHUNKING_FLAGS[@]}" //:chunking_test_artifact 2>&1)
if [[ ! $OUTPUT =~ 'remote cache hit' ]]; then
    echo "Expected second bazel run to be a remote cache hit."
    echo "STDOUT:"
    echo "$OUTPUT"
    exit 1
fi
SECOND_SHA=$(sha256sum "$ARTIFACT" | awk '{print $1}')
if [[ $SECOND_SHA != "$EXPECTED_SHA" ]]; then
    echo "Artifact fetched through the chunked download path is corrupt:"
    echo "expected sha $EXPECTED_SHA, got $SECOND_SHA."
    exit 1
fi
