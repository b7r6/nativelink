from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
from urllib.parse import urlparse, unquote

E = Path('/tmp/nativelink-categorical-evidence/ci-asan-activation-heads-root')
R = Path('/tmp/nativelink-ci-asan-activation-heads-independent-review')
D = R / 'evidence'
D.mkdir(exist_ok=True)
ROOT = Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
HEAD = 'b46336cd132b7db82ab982d2c815203a5bb11da0'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def file_sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def js(p):
    return json.loads(p.read_bytes())

copied = []
for p in sorted(E.rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(E)
    dest = D / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert file_sha(p) == file_sha(dest)
    elif rel.parts[0] == 'binaries':
        os.link(p, dest)  # Only immutable retained copies, never Bazel outputs.
    else:
        shutil.copyfile(p, dest)
    assert file_sha(p) == file_sha(dest)
    copied.append({'path': str(rel), 'bytes': dest.stat().st_size, 'sha256': file_sha(dest)})

before = js(D / 'sources-before.json')
assert before == js(D / 'sources-after.json') and len(before) == 1387
context = js(D / 'context.json')
assert context['head'] == HEAD
paths = list(before)
request = ''.join(HEAD + ':' + p + '\n' for p in paths).encode()
raw = subprocess.check_output(['git', 'cat-file', '--batch'], input=request, cwd=ROOT)
offset = 0
for p in paths:
    end = raw.index(b'\n', offset)
    header = raw[offset:end].split()
    assert len(header) == 3 and header[1] == b'blob', (p, header)
    size = int(header[2])
    start = end + 1
    blob = raw[start:start + size]
    assert raw[start + size:start + size + 1] == b'\n'
    offset = start + size + 1
    b = (D / 'sources' / p).read_bytes()
    assert b == blob and size == before[p]['bytes'] and sha(b) == before[p]['sha256'], p
assert offset == len(raw)
tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', HEAD], cwd=ROOT).decode().splitlines()
expected = [p for p in tracked if not p.startswith('nativelink-scheduler/design/categorical/evidence/')]
assert set(expected) == set(paths)
generated = js(D / 'generated-configs.json')
for p, x in generated.items():
    b = (D / 'generated-configs' / p).read_bytes()
    assert len(b) == x['bytes'] and sha(b) == x['sha256']
    if p in before:
        assert (D / 'sources' / p).read_text() == x['target'] and before[p]['symlink']
    else:
        assert p not in tracked

command = js(D / 'command.json')
execution = js(D / 'execution.json')
assert '--nocache_test_results' in command and execution['exit_code'] == 0
assert js(D / 'capture-errors.json') == []
events = [json.loads(line) for line in (D / 'events.jsonl').read_text().splitlines()]
finished = [e['finished'] for e in events if 'finished' in e]
assert len(finished) == 1 and finished[0]['overallSuccess'] and finished[0]['exitCode'].get('code', 0) == 0
plain = [e for e in events if 'completed' in e and not e['id']['targetCompleted'].get('aspect')]
assert len(plain) == 1 and all(e['completed'].get('success') for e in plain)
sets = {e['id']['namedSet']['id']: e['namedSetOfFiles'] for e in events if 'namedSetOfFiles' in e}
recorded_bins = js(D / 'binaries.json')
bin_results = []
for e in plain:
    label = e['id']['targetCompleted']['label']
    groups = [g for g in e['completed']['outputGroup'] if g['name'] == 'default']
    assert len(groups) == 1 and len(groups[0]['fileSets']) == 1
    files = sets[groups[0]['fileSets'][0]['id']]['files']
    assert len(files) == 1
    f = files[0]
    x = recorded_bins[f['name']]
    p = D / 'binaries' / f['name']
    with p.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
    digest = file_sha(p)
    assert digest == f['digest'] == x['sha256']
    assert p.stat().st_size == int(f['length']) == x['bytes']
    assert f == x['bep']
    expected_name = 'nativelink' if label == '//:nativelink' else label[2:].replace(':', '/')
    assert f['name'] == expected_name
    bin_results.append({'target': label, 'sha256': digest, 'bytes': p.stat().st_size, 'retained_copy': str(p.relative_to(R)), 'bep_uri': f['uri']})

results = [e for e in events if 'testResult' in e]
summaries = [e for e in events if 'testSummary' in e]
assert len(results) == 1 and len(summaries) == 1
expected_counts = {'//nativelink-scheduler:publication_activation_v2_reference_test': (27, 0, 0)}
log_metadata = js(D / 'logs.json')
test_results = []
all_names = {}
for e in results:
    label = e['id']['testResult']['label']
    t = e['testResult']
    assert t['status'] == 'PASSED' and not t.get('cachedLocally', False)
    assert t['executionInfo']['strategy'] == 'linux-sandbox'
    rel = label[2:].replace(':', '/')
    for f in t['testActionOutput']:
        copied_path = 'testlogs/' + rel + '/' + f['name']
        meta = log_metadata[copied_path]
        assert f == meta['bep']
        b = (D / copied_path).read_bytes()
        assert sha(b) == meta['sha256']
        actual = Path(unquote(urlparse(f['uri']).path))
        assert actual.read_bytes() == b
    log = (D / 'testlogs' / rel / 'test.log').read_text()
    counts = [tuple(map(int, x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
    assert counts == [expected_counts[label]]
    names = re.findall(r'^test ([^ ]+) \.\.\. ok$', log, re.M)
    ignored = re.findall(r'^test ([^ ]+) \.\.\. ignored[^\n]*$', log, re.M)
    assert len(names) == counts[0][0] and len(set(names)) == len(names)
    assert len(ignored) == counts[0][2]
    all_names[label] = names
    summary = next(s['testSummary'] for s in summaries if s['id']['testSummary']['label'] == label)
    assert summary['overallStatus'] == 'PASSED' and summary['totalRunCount'] == 1 and summary['attemptCount'] == 1
    test_results.append({'target': label, 'passed': counts[0][0], 'failed': 0, 'ignored': ignored, 'fresh_linux_sandbox_execution': True, 'test_log_sha256': sha(log.encode())})

# Confirm the exact narrow source correction relative to the combined qualified root.
previous = Path('/tmp/nativelink-canonical-recovered-worker-root-independent-review/evidence')
prior_sources = js(previous / 'sources-before.json')
assert prior_sources.keys() == before.keys()
changed = [p for p in before if before[p] != prior_sources[p]]
test_path = 'nativelink-scheduler/tests/publication_activation_v2_reference_test.rs'
assert changed == [test_path]
old = (previous / 'sources' / test_path).read_text()
new = (D / 'sources' / test_path).read_text()
assert old.count('assert!(model.heads.is_empty());') == 4
assert old.replace('assert!(model.heads.is_empty());', 'assert_eq!(model.heads, Vec::<Head>::new());') == new
assert 'pub(crate) heads: Vec<Head>' in (D / 'sources/nativelink-scheduler/tests/publication_activation_v2/reference.rs').read_text()
parent = subprocess.check_output(['git', 'rev-parse', HEAD + '^'], cwd=ROOT, text=True).strip()
assert parent == '78ab50c3b632dc9a1b36db77f411a1aef277ef32'
assert subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', HEAD], cwd=ROOT, text=True).splitlines() == [test_path]
# The canonical parsed options record the active resolved Starlark flags, not merely available rc definitions.
canonical = [e['structuredCommandLine'] for e in events if e.get('structuredCommandLine', {}).get('commandLineLabel') == 'canonical']
assert len(canonical) == 1
options = [o for section in canonical[0]['sections'] for o in section.get('optionList', {}).get('option', [])]
active = {o['optionName']: o['optionValue'] for o in options if 'optionName' in o}
assert '--config=asan' in command and command[-1] in expected_counts
assert active['@@rules_rust+//rust/settings:extra_rustc_flags'] == '[-Zsanitizer=address]'
assert active['@@rules_rust+//rust/toolchain/channel:channel'] == 'nightly'
assert any(o.get('optionName') == 'config' and o.get('optionValue') == 'nightly' and o.get('source') == 'expanded from --config=asan' for o in options)
aspects = [e for e in events if 'completed' in e and e['id']['targetCompleted'].get('aspect')]
assert len(aspects) == 3 and all(e['completed'].get('success') for e in aspects)
assert {e['id']['targetCompleted']['aspect'].split('%')[-1] for e in aspects} == {'rustfmt_srcs_aspect', 'rustfmt_aspect', 'rust_clippy_aspect'}
binary = D / recorded_bins[next(iter(recorded_bins))]['bep']['name']
binary = D / 'binaries' / next(iter(recorded_bins))
data = binary.read_bytes()
markers = ['__asan_init', '__asan_report_load1', '__asan_report_store1', '__asan_version_mismatch_check_v8']
assert all(n.encode() + b'\0' in data for n in markers)
assert not any(s in (D / 'testlogs/nativelink-scheduler/publication_activation_v2_reference_test/test.log').read_text() for s in ['ERROR: AddressSanitizer', 'SUMMARY: AddressSanitizer'])
receipt = {
    'verdict': 'PASS for this focused nightly ASAN target after four equivalent empty-vector assertion rewrites.',
    'scope': 'Independent read-only source/Git/BEP/raw-log/actual-ELF audit. No compiler/build/test execution or root edits by reviewer.',
    'commit': HEAD,
    'parent_combined_root_commit': parent,
    'source_manifest_sha256': file_sha(D / 'sources-before.json'),
    'selected_tracked_sources_exact_before_after_copies_git': len(before),
    'excluded_tracked_prefix': 'nativelink-scheduler/design/categorical/evidence/',
    'generated_config_copies_exact': generated,
    'only_source_change_from_parent': test_path,
    'source_correction': 'Exactly4 assert!(model.heads.is_empty()) changed to assert_eq!(model.heads, Vec::<Head>::new()). heads is Vec<Head>; equality to empty checks the same condition without per-element comparisons. No model, production runtime or other oracle changes.',
    'execution': execution,
    'effective_sanitizer': active['@@rules_rust+//rust/settings:extra_rustc_flags'],
    'effective_toolchain_channel': active['@@rules_rust+//rust/toolchain/channel:channel'],
    'explicit_command_config': '--config=asan',
    'successful_aspects': [e['id']['targetCompleted']['aspect'] for e in aspects],
    'test_results': test_results,
    'passed': 27,
    'failed': 0,
    'ignored': 0,
    'uncached_linux_sandbox_test_targets': 1,
    'actual_bep_bound_ELFs': bin_results,
    'retained_ELF_contains_ASAN_symbol_strings': markers,
    'capture_errors': [],
    'reviewer_prerequisite': 'First reviewer script expected public field spelling pub heads; actual reference-model field is pub(crate) heads: Vec<Head>. Corrected exact visibility marker; original reviewer script retained. No source or test changes.',
    'limits': ['This gate qualifies one activation reference target with nightly address sanitizer and default Clippy/formatting aspects; it is not all-workspace sanitizer qualification or proof of memory safety.', 'Original failed CI run is retained/audited separately and is not rewritten or reclassified by this focused rerun.', 'Earlier combined378pass root boundary is parent78ab50c3..., not this subsequent assertion-only commit.']
}
(R / 'copied-evidence-manifest.json').write_text(json.dumps(copied, indent=2) + '\n')
b = (json.dumps(receipt, indent=2) + '\n').encode()
(R / 'review.json').write_bytes(b)
print(json.dumps({'review_sha256': sha(b), 'source_manifest_sha256': receipt['source_manifest_sha256'], 'sources': len(before), 'passed': 27, 'actual_ELFs': len(bin_results), 'copied_files': len(copied)}, indent=2))
