from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, time
from urllib.parse import unquote, urlparse

root = Path.cwd()
out = Path('/tmp/nativelink-categorical-evidence/ci-asan-activation-heads-root')
out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
shutil.copy2(__file__, out / 'run-bazel.py')

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

names = [n for n in subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0') if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]

def sources(copy=False):
    result = {}
    for name in names:
        path = root / name
        symlink = path.is_symlink()
        data = os.readlink(path).encode() if symlink else path.read_bytes()
        result[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'symlink': symlink}
        if copy:
            dest = out / 'sources' / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
    return result

before = sources(copy=True)
write('sources-before.json', before)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
write('context.json', {'head': head, 'cwd': str(root), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Focused nightly ASAN activation reference target after correcting four assertion-style lint failures. No full workspace sanitizer qualification.'})
generated = {}
for name in ('.pre-commit-config.yaml', '.bazelrc', '.bazelversion'):
    path = root / name
    if path.is_symlink() and path.exists():
        dest = out / 'generated-configs' / name
        dest.parent.mkdir(exist_ok=True)
        shutil.copyfile(path, dest)
        generated[name] = {'target': os.readlink(path), 'sha256': sha(dest), 'bytes': dest.stat().st_size}
write('generated-configs.json', generated)
cmd = ['bazel', 'test', '--config=asan', '--jobs=4', '--local_test_jobs=1', '--test_env=RUST_TEST_THREADS=1', '--test_output=errors', '--nocache_test_results', '--keep_going', '--build_event_json_file=' + str(out / 'events.jsonl'), '//nativelink-scheduler:publication_activation_v2_reference_test']
write('command.json', cmd)
print('Starting combined component qualification:', head, len(before), 'tracked inputs', flush=True)
start = time.monotonic()
with (out / 'bazel.log').open('w') as stream:
    code = subprocess.run(cmd, stdout=stream, stderr=subprocess.STDOUT).returncode
write('execution.json', {'exit_code': code, 'elapsed_seconds': time.monotonic() - start})
after = sources()
write('sources-after.json', after)
events = [json.loads(line) for line in (out / 'events.jsonl').read_text().splitlines()]
summaries, binaries, logs, errors = [], {}, {}, []
for event in events:
    if 'testSummary' in event:
        summaries.append({'label': event['id']['testSummary']['label'], **event['testSummary']})
    if 'testResult' in event:
        label = event['id']['testResult']['label']
        relative = label[2:].replace(':', '/')
        for file in event['testResult'].get('testActionOutput', []):
            uri = file.get('uri', '')
            if not uri.startswith('file://'):
                continue
            path = Path(unquote(urlparse(uri).path))
            dest = out / 'testlogs' / relative / file['name']
            try:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, dest)
                logs[str(dest.relative_to(out))] = {'sha256': sha(dest), 'bep': file}
            except OSError as error:
                errors.append({'path': str(path), 'error': repr(error)})
    for file in event.get('namedSetOfFiles', {}).get('files', []):
        uri = file.get('uri', '')
        if not uri.startswith('file://') or file['name'] in binaries:
            continue
        path = Path(unquote(urlparse(uri).path))
        try:
            with path.open('rb') as stream:
                magic = stream.read(4)
            if magic != b'\x7fELF':
                continue
            dest = out / 'binaries' / file['name']
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            digest = sha(dest)
            binaries[file['name']] = {'sha256': digest, 'bytes': dest.stat().st_size, 'bep': file, 'bep_digest_matches': digest == file.get('digest')}
        except OSError as error:
            errors.append({'path': str(path), 'error': repr(error)})
write('test-summaries.json', summaries)
write('binaries.json', binaries)
write('logs.json', logs)
write('capture-errors.json', errors)
counts = {}
for name in logs:
    if name.endswith('/test.log'):
        counts[name] = [list(map(int, match)) for match in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out / name).read_text())]
write('result.json', {'exit_code': code, 'head': head, 'source_inputs': len(before), 'sources_unchanged': before == after, 'summaries': summaries, 'rust_counts': counts, 'binaries': binaries, 'capture_errors': errors})
print('Finished:', code, 'targets', len(summaries), 'ELFs', len(binaries), 'unchanged', before == after, 'capture errors', len(errors), flush=True)
assert before == after
assert not errors
assert all(item['bep_digest_matches'] for item in binaries.values())
raise SystemExit(code)
