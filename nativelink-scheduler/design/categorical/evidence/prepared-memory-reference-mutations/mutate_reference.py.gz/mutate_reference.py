#!/usr/bin/env python3
"""Compile six selected faults against frozen independent-reference cases."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


FAULTS = [
    {
        "name": "ignore_catalogue_revision",
        "test": "incomplete_stale_retired_and_unready_preparation_cannot_refund_or_finalize",
        "patches": [
            (
                "if proof.catalogue_revision != facts.catalogue_revision\n            || !proof.fences.is_subset(&facts.fences)",
                "if !proof.fences.is_subset(&facts.fences)",
            )
        ],
    },
    {
        "name": "replace_observed_capacity_with_large_worker",
        "test": "preparation_never_caches_capacity_decision_in_either_direction",
        "patches": [
            (
                "// This is the only policy decision: the scheduler state at acceptance.\n",
                """// This is the only policy decision: the scheduler state at acceptance.
        self.schedule(a::Event::Capacity {
            worker: report.identity.worker,
            incarnation: report.identity.incarnation,
            session: a::SessionId(1),
            capacity: a::Resources { cpu_millis: 8000, memory_bytes: 8192, slots: 8 },
            available: a::Resources { cpu_millis: 8000, memory_bytes: 8192, slots: 8 },
            draining: false,
        })?;
""",
            )
        ],
    },
    {
        "name": "replace_terminal_reason_with_missing_growth",
        "test": "all_memory_terminal_reasons_preserve_original_graph_response",
        "patches": [
            (
                """            ) if result == &report.payload => Disposition::TerminalAccepted {
                terminal: terminal.clone(),
            },""",
                """            ) if result == &report.payload => Disposition::TerminalAccepted {
                terminal: a::TerminalResult::ResourceFailed {
                    result: report.payload.clone(),
                    reason: a::ResourceFailureReason::MissingGrowthEvidence,
                },
            },""",
            )
        ],
    },
    {
        "name": "protect_previously_cancelled_operation",
        "test": "graph_final_uses_exact_response_live_operations_and_no_ac_for_both_algorithms",
        "patches": [
            (
                "            // The transient result root transfers directly to operation roots.\n",
                """            for old_operation in before.operations.iter().filter(|op| {
                op.execution == execution
                    && op.terminal == Some(a::TerminalResult::Cancelled)
            }) {
                self.roots.push(h::Coverage {
                    root: h::Root::Operation(old_operation.id.0),
                    keys: members.clone(),
                    until: OPERATION_UNTIL,
                });
            }
            // The transient result root transfers directly to operation roots.
""",
            )
        ],
    },
    {
        "name": "drop_stage_protection_on_retry",
        "test": "prepared_retry_then_no_graph_final_retains_stage_without_invented_graph_root",
        "patches": [
            (
                "        let disposition = self.classify(&stage.report, execution, Some(arguments.clone()))?;\n",
                """        let disposition = self.classify(&stage.report, execution, Some(arguments.clone()))?;
        if matches!(disposition, Disposition::RetryScheduled { .. }) {
            self.roots.retain(|root| root.root != h::Root::Stage(arguments.stage));
        }
""",
            )
        ],
    },
    {
        "name": "ignore_invalid_replay_steps_and_encoding",
        "test": "restore_refuses_torn_history_conflicting_identity_downgrade_and_oversize",
        "patches": [
            (
                "            restored.apply(&step.command, &step.facts)?;\n",
                "            let _ = restored.apply(&step.command, &step.facts);\n",
            ),
            (
                """        if restored.snapshot()? != bytes {
            return Err(Refusal::Snapshot);
        }
        Ok(restored)""",
                "        Ok(restored)",
            ),
        ],
    },
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cargo", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--reference-sha256", required=True)
    parser.add_argument("--cases-sha256", required=True)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    source = args.worktree / "nativelink-scheduler/tests/prepared_memory/reference.rs"
    cases = args.worktree / "nativelink-scheduler/tests/prepared_memory/cases.rs"
    original = source.read_bytes()
    original_cases = cases.read_bytes()
    if sha(original) != args.reference_sha256 or sha(original_cases) != args.cases_sha256:
        raise SystemExit("freeze hashes do not match")
    mutated = {}
    for fault in FAULTS:
        code = original.decode()
        for old, new in fault["patches"]:
            if code.count(old) != 1:
                raise SystemExit(f"non-unique fault anchor: {fault['name']}")
            code = code.replace(old, new, 1)
        mutated[fault["name"]] = code.encode()
    if args.check_only:
        print(f"Verified {len(FAULTS)} source-anchored faults; no source changes or builds.")
        return
    args.output.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment["CARGO_TARGET_DIR"] = str(args.target)
    environment["CARGO_INCREMENTAL"] = "0"
    command = [str(args.cargo), "test", "--locked", "--offline", "--profile", "smol", "-j8", "-p", "nativelink-scheduler", "--test", "prepared_memory_reference_test"]

    def run(name, test=None):
        invocation = command + (["--", "--exact", "cases::" + test] if test else [])
        path = args.output / (name + ".log")
        started = time.monotonic()
        with path.open("wb") as output:
            result = subprocess.run(invocation, cwd=args.worktree, env=environment, stdout=output, stderr=subprocess.STDOUT, check=False)
        log = path.read_bytes()
        record = {"command": invocation, "exit_code": result.returncode, "elapsed_seconds": round(time.monotonic() - started, 3), "log": path.name, "log_sha256": sha(log)}
        executable = re.search(rb"Running tests/prepared_memory_reference_test\.rs \(([^)]+)\)", log)
        if executable:
            artifact = Path(os.fsdecode(executable.group(1)))
            record["test_executable_sha256"] = sha(artifact.read_bytes())
        summary = re.search(rb"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", log)
        if summary:
            record["test_result"] = {"status": summary.group(1).decode(), "passed": int(summary.group(2)), "failed": int(summary.group(3)), "ignored": int(summary.group(4))}
        if test:
            record["compiled_test_ran"] = b"running 1 test" in log and b"could not compile" not in log and "test_executable_sha256" in record
            record["detected"] = record["compiled_test_ran"] and result.returncode == 101 and b"test result: FAILED." in log and ("cases::" + test + " ... FAILED").encode() in log
        print(json.dumps({"run": name, **record}), flush=True)
        return record

    manifest = {"format": "independent-prepared-memory-selected-reference-faults-v1", "source_sha256": sha(original), "cases_sha256": sha(original_cases), "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=args.worktree, text=True).strip(), "faults": []}
    try:
        manifest["baseline"] = run("baseline")
        if manifest["baseline"]["exit_code"] != 0:
            raise RuntimeError("unmodified baseline failed")
        for fault in FAULTS:
            mutation = mutated[fault["name"]]
            source.write_bytes(mutation)
            record = run(fault["name"], fault["test"])
            manifest["faults"].append({**fault, "mutated_source_sha256": sha(mutation), **record})
            source.write_bytes(original)
    finally:
        source.write_bytes(original)
        manifest["restored_source_sha256"] = sha(source.read_bytes())
        manifest["unchanged_cases_sha256"] = sha(cases.read_bytes())
        (args.output / "results.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    manifest["restored"] = run("restored")
    (args.output / "results.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    if manifest["restored"]["exit_code"] != 0 or not all(row["detected"] for row in manifest["faults"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
