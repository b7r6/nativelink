import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/nativelink-categorical-runtime')
out=pathlib.Path('/tmp/nativelink-categorical-evidence/replicated-rpc')
env=dict(os.environ,CARGO_BUILD_JOBS='8',CARGO_TARGET_DIR='/tmp/nativelink-categorical-runtime-target')
command=['cargo','test','--locked','--profile','smol','-p','nativelink-worker','--test','authority_replicated_rpc_test','--','--show-output']
records=[]
def run(label,cmd):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 content=(out/(label+'.log')).read_text()
 record=dict(label=label,command=cmd,exit=result.returncode,seconds=time.monotonic()-start)
 records.append(record)
 (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 print('\n'.join(s for s in content.splitlines() if s.startswith('test result:') or s.startswith('AUTHORITY_') or s.startswith('error') or 'panicked at' in s),flush=True)
 return record,content
record,content=run('qualified-baseline',command);assert record['exit']==0
cases=[
 ('reused-session','nativelink-worker/src/authority_worker_transport.rs','session = session.checked_add(1)','session = session.checked_add(0)'),
 ('altered-candidate','nativelink-service/src/authority_server.rs','Some(authority_attempt_report::Result::ExecuteResponse(response)) => Some(response),','Some(authority_attempt_report::Result::ExecuteResponse(mut response)) => { response.message.push_str("changed at ingress"); Some(response) },'),
]
mutants=[]
for label,name,before,after in cases:
 source=root/name;original=source.read_text();assert original.count(before)==1
 try:
  source.write_text(original.replace(before,after,1))
  record,content=run('mutation-'+label,command)
  record.update(path=name,source_sha256=hashlib.sha256(original.encode()).hexdigest(),replacement=dict(before=before,after=after),compiled='Running tests/authority_replicated_rpc_test.rs' in content,killed=record['exit']!=0 and 'test result: FAILED.' in content and 'panicked at' in content)
  mutants.append(record)
  (out/'mutations.json').write_text(json.dumps(mutants,indent=2)+'\n')
 finally:source.write_text(original)
assert len(mutants)==2 and all(x['compiled'] and x['killed'] for x in mutants)
record,content=run('qualified-restored',command);assert record['exit']==0
record,content=run('strict-clippy',['cargo','clippy','--locked','--profile','smol','-p','nativelink-worker','--test','authority_replicated_rpc_test','--','-D','warnings']);assert record['exit']==0
