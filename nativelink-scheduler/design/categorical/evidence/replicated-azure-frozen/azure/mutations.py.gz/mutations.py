import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-categorical-azurite')
evidence = Path('/tmp/nativelink-categorical-evidence/physical-azurite')
source = root / 'nativelink-store/tests/physical_azure/adapter.rs'
baseline = source.read_text()
env = dict(os.environ, CARGO_BUILD_JOBS='8',
           CARGO_TARGET_DIR='/tmp/nativelink-categorical-physical/target',
           CARGO_MANIFEST_DIR=str(root / 'nativelink-store'))
test_name = 'local_azurite_exact_generation_contract'
records = []


def qualify(name, text, should_pass):
    source.write_text(text)
    compiled = subprocess.run(
        ['cargo', 'test', '-p', 'nativelink-store', '--test', 'physical_azure_test',
         '--no-run', '--message-format=json'],
        cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=300)
    (evidence / f'{name}-compile.log').write_text(compiled.stdout)
    record = {'name': name, 'source_sha256': hashlib.sha256(text.encode()).hexdigest(),
              'compile_exit': compiled.returncode, 'test_exit': None}
    records.append(record)
    if compiled.returncode:
        raise AssertionError(f'{name} did not compile; not a detected semantic mutant')
    executable = None
    for line in compiled.stdout.splitlines():
        try:
            artifact = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (artifact.get('reason') == 'compiler-artifact'
                and artifact.get('target', {}).get('name') == 'physical_azure_test'
                and artifact.get('executable')):
            executable = artifact['executable']
    assert executable is not None
    if name == 'baseline':
        with (evidence / 'ordinary-suite.log').open('w') as log:
            normal = subprocess.run([executable], cwd=root, env=env,
                                    stdout=log, stderr=subprocess.STDOUT, timeout=120)
        assert normal.returncode == 0
    with (evidence / f'{name}-live.log').open('w') as log:
        live = subprocess.run([executable, '--ignored', '--exact', test_name, '--nocapture'],
                              cwd=root, env=env, stdout=log,
                              stderr=subprocess.STDOUT, timeout=120)
    record['test_exit'] = live.returncode
    output = (evidence / f'{name}-live.log').read_text()
    assert f'test {test_name} ...' in output, name
    assert (live.returncode == 0) == should_pass, name
    if not should_pass:
        assert "panicked at nativelink-store/tests/physical_azure_test.rs" in output, name
    print(json.dumps(record), flush=True)


mutants = [
    ('overwrite-immutable', '\n    .if_not_exists()', '', 1),
    ('foreign-incarnation', 'if key.incarnation != self.incarnation {',
     'if false && key.incarnation != self.incarnation {', 1),
    ('skip-whole-object-digest',
     'if ObjectId::for_bytes(object.algorithm, &bytes[HEADER_SIZE..]) != object {',
     'if false && ObjectId::for_bytes(object.algorithm, &bytes[HEADER_SIZE..]) != object {', 1),
    ('unconditional-delete',
     'if_match: Some(etag),\n                    timeout: Some(10),',
     'if_match: None,\n                    timeout: Some(10),', 1),
    ('container404-is-missing',
     'if code == "BlobNotFound" => FailureKind::Missing,',
     'if code == "BlobNotFound" || code == "ContainerNotFound" => FailureKind::Missing,', 1),
    ('incarnation-prefix-alias',
     'key.incarnation.directory_name(),',
     'Incarnation::new([7; 16]).unwrap().directory_name(),', 1),
]
try:
    qualify('baseline', baseline, True)
    for name, before, after, count in mutants:
        assert baseline.count(before) == count, (name, baseline.count(before))
        qualify(name, baseline.replace(before, after, count), False)
finally:
    source.write_text(baseline)
    (evidence / 'mutation-results.json').write_text(json.dumps(records, indent=2) + '\n')
qualify('restored', baseline, True)
(evidence / 'mutation-results.json').write_text(json.dumps(records, indent=2) + '\n')
