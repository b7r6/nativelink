# Independent source review: publication real requests

Scope: original Request and ActionKey preservation, trusted principal and semantic
execution configuration, in-flight scope versus completed-cache identity, result
algorithm binding, private snapshot versions, and accidental broader authority.
The review did not edit or compile the author's worktree. The author independently
compiled the two proposed regression sequences, preserved failures, and corrected
them. Production multi-context routing, process-to-gateway execution and durable
publication activation are outside this review.

## Finding 1: joined operation original request was unchecked

The outer operation invariant checked the representative execution request a
second time. State privately retains each operation's original request, and its
compatibility predicate can join non-Buck2 requests from different principals
when invocation scope is absent. The outer trusted context was therefore not
validated against every retained caller on restore.

Regression: admit two non-Buck2 principal-P requests into one execution; in the
nested scheduler snapshot, replace only operation 2's original_request with a
valid recaptured principal-Q Request using the same Action and Command. The
actual State restore accepts it. Canonicalize that nested State snapshot and
replace its byte array in the original outer snapshot. The original outer
restore accepts the foreign retained caller. No execution principal is changed.

Correction reviewed: add read-only State::operation_request and use the shared
request-to-action binding check for each original operation request, as well as
for its representative execution. The new regression covers SHA-256 and BLAKE3.

The separate retained-inventory adapter had the same projection assumption.
Its own independent valid-State regression failed against the frozen adapter;
an additive correction now preserves every original operation request and checks
the operation's own principal and qualified action before projecting it.

## Finding 2: real payloads survived a synthetic-mode downgrade

A real action label may equal the original ActionKey.instance. Deleting the
real-binding metadata and changing private version 2 to version 1 then passed
synthetic instance/policy checks while retaining captured request payloads. The
restored object could enable synthetic admission or direct-client authorization.

Regression: construct that label, admit a real request, remove metadata.real,
and change only the outer version to 1 while preserving canonical serialization.
The original restore accepts it for both digest algorithms.

Correction reviewed: synthetic request matching requires an absent captured
payload, which matches the historical synthetic constructor. Retained real
requests therefore cannot silently fall back to that mode. The private format
still does not authenticate a coherently replaced history; trusted mode/context
selection for production recovery is a separate obligation.

## Other reviewed boundaries

The real admission route requires the original captured payload and canonical
projection, then submits the unchanged Request to actual State. The external
trusted context is restricted to one principal/configuration per authority;
RequestMetadata cannot supply either. Original invocation scope is unchanged and
excluded from the completed-cache action binding. The full ActionKey and complete
selected immutable platform are retained; resource fields here are source Action
or Command facts, not a changing scheduler grant.

Worker candidates bind actual attempt, execution, worker and incarnation to that
request and use its digest algorithm for the result and every closure member.
Real mode excludes synthetic admission and direct-client publication. Private
v1 snapshots omit real metadata; v2 requires it, and both retain canonical byte
checks. The corrected per-operation and synthetic-mode invariants close the two
identified relational gaps. Final compilation and integration are owned by the
author and root; this source review does not replace those checks.
