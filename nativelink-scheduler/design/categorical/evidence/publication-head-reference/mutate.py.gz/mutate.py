#!/usr/bin/env python3
"""Each mutation must compile before unchanged semantic assertions are run."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-publication-head-reference')
out = Path('/tmp/nativelink-publication-head-evidence')
source = root / 'nativelink-scheduler/tests/publication_head/reference.rs'
original = source.read_text()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-differential-target')
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p',
           'nativelink-scheduler', '--test', 'publication_head_reference_test', '--no-run']
binary = Path(env['CARGO_TARGET_DIR']) / 'smol/deps/publication_head_reference_test-1797822e9afb6e44'
mutants = [
    ('prepared-stale-attempt-can-publish', [('current.attempt != Some(attempt)', 'false', 1)]),
    ('prepared-old-incarnation-can-publish', [('self.workers.get(&attempt.worker) != Some(&attempt.incarnation)', 'false', 2)]),
    ('expired-stage-can-transfer', [('row.state != StageState::Open || row.until <= self.now', 'row.state != StageState::Open', 2)]),
    ('ignore-catalogue-and-retirement-fences', [('proof.catalogue_revision != facts.catalogue_revision\n        || !proof.fences.is_subset(&facts.fences)', 'false', 1)]),
    ('accept-incomplete-typed-proof', [('proof.typed != candidate.required || proof.protected != keys(candidate)', 'proof.protected != keys(candidate)', 1)]),
    ('retired-bytes-are-ready', [('physical.object != member.object || !physical.ready || physical.retired', 'physical.object != member.object || !physical.ready', 1)]),
    ('omit-operation-protection', [('self.protect(Root::Operation(id), members.clone(), *until);', '', 1)]),
    ('skip-lookup-disables-publication', [('&& candidate.error_free;', '&& candidate.error_free && !self.operations.values().any(|operation| operation.request.skip_lookup && operation.request.action == candidate.action);', 2)]),
    ('noncacheable-requests-coalesce', [('if !noncacheable\n                    && let Some((&execution, _))', 'if let Some((&execution, _))', 1)]),
    ('canceled-subscriber-gets-worker-result', [('(op.state == OperationState::Waiting(execution)).then_some(*id)', '(op.state == OperationState::Waiting(execution) || (matches!(op.state, OperationState::Canceled(_)) && op.request.action == candidate.action)).then_some(*id)', 1)]),
    ('late-materialization-selects-old-head', [('Event::Materialize(publication) => {\n                let candidate = self.candidate(*publication)?;', 'Event::Materialize(publication) => {\n                let candidate = self.candidate(*publication)?.clone();\n                self.heads.insert(candidate.action.clone(), *publication);', 1)]),
    ('stale-index-authorizes-serving', [
        ('*barrier != self.applied || self.heads.get(action) != Some(expected)', '*barrier != self.applied || self.index.get(action) != Some(expected)', 1),
        ('if self.live_head(action) != Some(*expected) {', 'if self.index.get(action) != Some(expected) {', 1)]),
    ('head-replacement-revokes-grant', [('self.release(Root::Result(old));', 'self.release(Root::Result(old));\n                    let grants: Vec<_> = self.grants.iter().filter_map(|(id, grant)| (grant.publication == old).then_some(*id)).collect();\n                    for id in grants { self.release(Root::Serving(id)); }', 1)]),
    ('index-rebuild-revives-expired-head', [('.filter_map(|action| self.live_head(action).map(|id| (action.clone(), id)))', '.map(|action| (action.clone(), self.heads[action]))', 1)]),
    ('unauthorized-direct-update-publishes', [('if !self.clients.contains(&principal) {', 'if false {', 1)]),
    ('truncate-physical-incarnation', [('.find(|row| row.key == key)', '.find(|row| row.key.namespace == key.namespace && row.key.generation == key.generation)', 1)]),
]

def run(name, changed):
    folder = out / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    source.write_text(changed)
    (folder / 'reference.rs').write_text(changed)
    with (folder / 'compile.log').open('wb') as log:
        compiled = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'source_sha256': hashlib.sha256(changed.encode()).hexdigest(),
              'compile_command': command, 'compile_status': compiled.returncode,
              'test_sha256': hashlib.sha256((root / 'nativelink-scheduler/tests/publication_head_reference_test.rs').read_bytes()).hexdigest(),
              'types_sha256': hashlib.sha256((root / 'nativelink-scheduler/tests/publication_head/types.rs').read_bytes()).hexdigest()}
    if compiled.returncode:
        result['classification'] = 'COMPILE_REJECTED_NOT_A_KILL'
    else:
        result['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        with (folder / 'test.log').open('wb') as log:
            tested = subprocess.run([str(binary)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        result['test_status'] = tested.returncode
        result['classification'] = 'PASS' if not tested.returncode else 'COMPILED_ASSERTION_KILL'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

results = []
baseline = None
try:
    baseline = run('baseline', original)
    assert baseline['classification'] == 'PASS', baseline
    for name, replacements in mutants:
        changed = original
        for old, new, count in replacements:
            assert changed.count(old) == count, (name, old, changed.count(old), count)
            changed = changed.replace(old, new)
        results.append(run(name, changed))
finally:
    source.write_text(original)
    restored = run('restored', original)
    (out / 'mutation-results.json').write_text(json.dumps({'baseline': baseline,
        'mutants': results, 'restored': restored,
        'source_restored_exactly': source.read_text() == original}, indent=2) + '\n')
assert restored['classification'] == 'PASS', restored
assert all(row['classification'] == 'COMPILED_ASSERTION_KILL' for row in results), results
