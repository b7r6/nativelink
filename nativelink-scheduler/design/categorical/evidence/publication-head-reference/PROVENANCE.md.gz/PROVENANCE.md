# Independent publication acceptance and head reference

Sources were authored in `/tmp/nativelink-publication-head-reference`, an isolated
worktree at `b79dfeae06`. The full base hash is recorded in the manifests. No new
publication candidate exists in this qualification, and none was read. No
production scheduler reducer, provider, closure preparer, coarse retention
implementation, or earlier reference implementation was copied into this model.
The normative contracts read were `source-plan.md`, `retention-contract.md`, and
`typed-retention-bridge.md`; copies and hashes are archived. Repository Rust and
Bazel verification skills guided focused checks, without widening this independent
reference into production implementation work.

The root agent clarified four contract points before freezing:

- Successful preparation cannot authorize Publish after attempt/incarnation
  replacement or expiry of provisional staging protection.
- Action keys are opaque full qualified identities, not digest-only aliases.
- A canceled joined operation must not receive the later worker terminal
  association. This model handles that case only when another operation waits.
- The worker success/error-free policy does not settle every direct AC update
  policy. Direct fixtures cover canonical successful cacheable ActionResult cases;
  response bytes are scenario-owned expected operation encoding, not a claimed
  UpdateActionResult RPC field. Other direct policies remain outside the alphabet.

The first implementation passed 16 tests. A self-audit added closed worker
incarnation watermarks, protection of waiting operation deadlines, stricter
restore checks for operation/staging coverage, and a 2 MiB snapshot cap covering
the bounded payload envelope. The resulting 17 tests passed. A final audit added
every snapshot cut through the full staging/acceptance sequence, yielding 18
tests. Earlier sources and qualification outputs are preserved separately.
These changes happened before candidate exposure and did not alter expectations
to make a candidate pass.

Strict Clippy initially reported ordinary style and helper-signature issues.
The fixes and failed output are retained. A local Rust warning allowance on the
32-byte worker provenance variant avoids inventing client attempt fields or
padding solely to equalize enum sizes; its reason is in the source. No semantic
lint suppressions were added. Source, tests, and types passed strict Clippy after
the final replay case.

Cargo used the existing warm target directory
`/tmp/nativelink-history-differential-target`, eight jobs, and the `smol` profile.
Bazel used the warm standalone workspace
`/tmp/nativelink-accepted-history-reference` at older base `c32897774415d514ad30427f0f331ed36fd84808`.
The standalone target and Rust files are identical there, with no production
NativeLink dependency in that target. Before/after hashes verify that the frozen
accepted-history and activation references were untouched. The warm-workspace
README hash predates final qualification prose only; final source hashes are
recorded separately.

All sixteen semantic mutants compiled before running the unchanged tests. Each
failed semantic assertions. Baseline and restored source passed all 18 tests,
with identical source and binary hashes. Exact mutants, deltas, compiler logs,
test logs, commands, test/types hashes, and classifications are retained. The
earlier 17-test campaign also killed all sixteen mutants and is archived under
`pre-complete-replay-cuts`. Some mutants violate both the transition and its
internal restore invariant: their valid positive scenario then rejects. Those
are positive-behavior regression kills, not claims that an internal guard is
absent. Compiler rejection never counts as a semantic kill.

This is finite single-authority transition evidence, not a production M6 release.
Time is committed logical time. Ignored and rejected events preserve full model
state; the model position is the last state-changing position and does not
prescribe Raft duplicate-entry accounting. Serving is modeled conservatively as
an ordered coverage transition. There is no production RPC, optimized read
barrier, provider timing, graph traversal, root retirement, M7 progress,
power-loss, shared-authority budget, or cryptographic proof-authenticity claim.
Retained rows count toward finite caps; infinite-churn compaction is absent.
The direct-update policy limitation and last-operation cancellation remain
explicit. The earlier activation reference's cached-terminal scope gap is
documented separately and is not silently repaired by this publication oracle.
