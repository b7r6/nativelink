from pathlib import Path
import subprocess, os, hashlib, json, re, time
W=Path('/tmp/nativelink-authority-canonical-binding')
E=Path('/tmp/nativelink-authority-canonical-binding-evidence')
CARGO='/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo'
ENV=os.environ.copy();ENV['CARGO_TARGET_DIR']='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target';ENV['CARGO_INCREMENTAL']='0'
J='nativelink-scheduler/src/authority/journal.rs';M='nativelink-scheduler/src/authority/canonical_binding.rs'
FAULTS=[
 ('omit_applied_identity',J,'if self.canonical_contract != expected {','if false && self.canonical_contract != expected {','live_applied_binding_mismatch_refuses_reads_apply_and_snapshot_build'),
 ('omit_metadata_identity_presence',M,'if contract != expected || phase.is_some() != expected.is_some() {','if false && (contract != expected || phase.is_some() != expected.is_some()) {','generic_paths_refuse_every_partial_binding_before_admission_or_mutation'),
 ('allow_preparing_reopen',M,'if require_sealed && expected.is_some() && phase != Some(CanonicalBootstrap::Sealed) {','if false && require_sealed && expected.is_some() && phase != Some(CanonicalBootstrap::Sealed) {','cold_binding_is_atomic_and_parent_failure_never_seals_or_adopts'),
 ('snapshot_trusts_own_identity',J,'let state = self.applied.state(epoch, reader, canonical)?;','let state = self.applied.state(epoch, reader, self.applied.canonical_contract)?;','snapshot_import_and_retained_snapshot_reject_legacy_or_foreign_binding_before_writes'),
 ('omit_recovery_snapshot_identity',J,'saved.applied.validate_contract(None)?;','// Intentional fault: omit retained snapshot identity validation.','snapshot_import_and_retained_snapshot_reject_legacy_or_foreign_binding_before_writes'),
]
FIXED={p:(W/p).read_bytes() for p in [J,M]}
RESULTS=[]
for name,path,old,new,test in FAULTS:
    target=W/path;fixed=FIXED[path];text=fixed.decode();assert text.count(old)==1,(name,text.count(old))
    fault=text.replace(old,new,1).encode();out=E/'faults'/name;out.mkdir(parents=True,exist_ok=True)
    (out/'mutant.rs').write_bytes(fault)
    command=[CARGO,'test','-p','nativelink-scheduler','--lib','--locked','--offline','--profile','smol','-j8',test,'--','--nocapture']
    rec={'id':name,'file':path,'fixed_sha256':hashlib.sha256(fixed).hexdigest(),'mutant_sha256':hashlib.sha256(fault).hexdigest(),'replacement':{'before':old,'after':new},'command':command,'environment':{'CARGO_TARGET_DIR':ENV['CARGO_TARGET_DIR'],'CARGO_INCREMENTAL':'0'}}
    print('START '+name,flush=True);start=time.monotonic()
    try:
        target.write_bytes(fault)
        with (out/'cargo.log').open('wb') as log:
            result=subprocess.run(command,cwd=W,env=ENV,stdout=log,stderr=subprocess.STDOUT)
        output=(out/'cargo.log').read_text();rec['exit_code']=result.returncode;rec['elapsed_seconds']=time.monotonic()-start
        rec['compilation_observed']='Compiling nativelink-scheduler' in output
        rec['test_failure_observed']='test result: FAILED' in output
        rec['compile_failure_observed']='could not compile' in output
        binary=re.search(r'Running unittests[^\n]*\(([^\n)]+)\)',output)
        if binary:
            b=Path(binary.group(1));rec['executed_binary_sha256']=hashlib.sha256(b.read_bytes()).hexdigest();rec['executed_binary_bytes']=b.stat().st_size
        rec['expected_detection']=result.returncode==101 and rec['compilation_observed'] and rec['test_failure_observed'] and not rec['compile_failure_observed']
        (out/'attempt.json').write_text(json.dumps(rec,indent=2)+'\n');RESULTS.append(rec)
        (E/'fault-attempts.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
        print('END '+name+' '+json.dumps({k:rec[k] for k in ['exit_code','compilation_observed','test_failure_observed','compile_failure_observed','expected_detection']}),flush=True)
        if not rec['expected_detection']:
            raise RuntimeError('Unexpected fault result: '+name)
    finally:
        for p,data in FIXED.items():
            (W/p).write_bytes(data)
        assert all((W/p).read_bytes()==data for p,data in FIXED.items())
print('ALL FIVE FAULTS DETECTED; fixed runtime restored',flush=True)
