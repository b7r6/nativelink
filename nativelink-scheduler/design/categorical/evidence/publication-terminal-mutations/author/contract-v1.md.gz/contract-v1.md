# Additive terminal-outcome contract v1

Status: design contract only. No new candidate implementation is authorized by
this file. The next independent reference will reuse the existing independent
M1 relational scheduler oracle for scheduling, memory growth, cancellation,
expiry, reservations and stable operation terminals. It will not treat the
activation-v2 retained inventory as a transition oracle. The current actual-State
and Coarse composition remains the candidate, with its existing graph publication
path unchanged.

## Minimum extension

Add a distinct bounded authority record for an accepted terminal outcome with no
result graph. It is not an immutable ActionResult publication and cannot select
an AC head. The record preserves exact captured ExecuteResponse bytes, the actual
Completed or ResourceFailed terminal variant, the exact ResourceFailureReason,
its acceptance position and logical time, and the original worker execution,
attempt, worker and incarnation. A diagnostic response fingerprint is not a CAS
object identifier. Do not fabricate an empty ActionResult, publication root,
operation root, closure, physical readiness observation, or publication history.

The no-graph precondition applies to Complete and MemoryFailure alike: the exact
captured response must validate and decode under the pinned protocol with
result=None. An ActionResult is graph-bearing even if it has no output fields or
comes with a nonzero exit/status. Such a report is refused unchanged by the new
path. Existing graph-bearing Completed results continue through prepared Publish.
Graph-bearing ResourceFailed needs a later prepared-outcome extension. Unsupported
wire encodings are retained by the caller and refused; no normalization may turn
a graph-bearing response into an accepted no-graph outcome.

Feature-3 accepted history stays excluded. The composition continues refusing
history-enabled State. If history is later enabled, its exact diagnostic object,
accepted origin, pending write and independent history root must be added; no-graph
execution outcomes do not imply that a history object has no retention obligation.

## Neutral command and observation API

The contract exposes these conceptual commands; names may differ in the candidate:

- Admit the complete original Request and operation identity through the existing
  admission boundary. Qualified action and trusted context checks still apply to
  every original operation request, including joined callers.
- ReportNoGraph(report_id, worker_identity, kind, captured_payload). Kind is
  Complete or MemoryFailure { original_charged, peak_memory_bytes, quiescent }.
  Memory classification is explicit trusted adapter evidence, never inferred
  from an exit code, status, stderr, or message.
- Cancel(operation), RenewInterest(operation), ExpireInterest(operation,
  deadline_generation), ExpireAttempt(attempt, deadline_generation), and
  ExpireExecution(attempt). These are actual scheduler events. Advance(now)
  changes both logical clocks only; it does not invent expiry or cancellation.
- Existing registration, worker acceptance, progress, worker unavailability,
  matching and Cleanup events retain their current meanings. Observe/reconnect
  neither adds interest nor cancels a handle.
- Existing Stage, late write observation, explicit Abandon and stage-expiry
  observations retain stable identities and ownership. No-graph acceptance does
  not authorize a result publication from those stages.

A report observation is one of Rejected, Duplicate, RetryScheduled, or
TerminalAccepted(exact terminal, recorded origin). Applying MemoryFailure decides
retry versus final inside the independent M1 or actual State transition. It must
not be predicted from the response, coerced into Complete, or forced final by the
outer layer. Retry records are classified reports, not accepted terminal results
or AC publications. Retain a bounded report identity and exact evidence so a
repeated identical report cannot consume another row; conflicting reuse refuses.

The reference may expose its complete scheduler view, original operation request
map, classified-report records, accepted terminal records, stage/write obligations,
existing retention view, logical credits, and canonical snapshot. These are
observation data, not implementation sharing with the candidate.

## Atomic transition and ownership rules

Each command applies to an outer clone. For ReportNoGraph, validate the exact
no-graph payload and bounded evidence, apply the genuine scheduler event, inspect
its actual result, record the report and any terminal acceptance, reconcile
logical credits and operation links, check invariants and snapshot byte bound,
then expose one new state. Any failure leaves both engines and metadata unchanged.

A final worker report records provenance from the accepted current attempt at
that transition. Later worker revocation cannot undo or reauthorize it. A retry
keeps interested operations nonterminal and creates no terminal acceptance. The
next match must obtain its own bounded stage credit before becoming visible.

An operation retains its own terminal. Canceling one joined handle leaves the
execution available to the others. A later accepted worker terminal attaches only
to operations that the scheduler actually terminates with that exact value.
Cancel after an accepted terminal is ignored and preserves that terminal and any
existing protection. No membership-based inference may overwrite a cancellation.

Last-interest cancellation and final attempt exhaustion close execution authority
but do not prove physical quiescence. The original reservation and cancellation
outbox remain until actual Cleanup/reconciliation releases them. MemoryFailure
requires the original charged vector and confirmed quiescence before the scheduler
may release that reservation. Never recompute the refund from a new worker capacity
or a retry target. Duplicate cleanup cannot refund twice or close a successor.

No-graph terminal acceptance acquires zero CAS roots. Existing roots for other
accepted results, operation handles and serving grants retain their promises.
Existing stage guards and every stable write/outcome record survive cancellation,
retry, expiry and final outcomes. A stage may subsequently be explicitly abandoned
or expire under its original bounded guard. Expiry is not write quiescence, a
successful delete, collector ownership, or permission to forget a late request.
Late write success cannot create terminal acceptance, change a terminal or AC head,
or resurrect a retired physical generation. This slice adds no collector path.

Distinguish unused logical admission credit from physical reservation or storage
ownership. Close unused future stage/member credit when an execution becomes
terminal, including through already-allowed WorkerUnavailable events. Retain all
credit associations needed to account for existing/prior stage rows and writes.
Do not let a terminal execution with nonzero unused credit make the outer invariant
reject otherwise legitimate cancellation or exhaustion. No new row may consume
credit reserved for another admitted execution's completion.

## Representation and compatibility

Keep existing graph-publication metadata separate. A small tagged operation
outcome link can distinguish Waiting, IndependentCancellation, GraphPublication,
and NoGraphTerminalAcceptance; alternatively an additive acceptance reference
must have equally strict mutually exclusive invariants. A payload without a
publication/root is legal only when linked to the exact accepted no-graph terminal.
Cancelled and Exhausted carry no fabricated ResultPayload or worker acceptance.
The scheduler retains authoritative terminal values and versions.

The independent reference composes the frozen M1 relational oracle with the
independent retention oracle where stage/root obligations are exercised. It
imports their public vocabulary, not production State, Coarse, the publication
candidate reducer or its new tests. Typed stage closure/preparation is explicit
scenario evidence; this slice does not re-prove protobuf graph traversal or a
provider. Existing graph publication is a separate qualified transition alphabet,
not silently implemented by a terminal model.

Use finite caps aligned with the current experiment where applicable: at most
8 executions/workers/stages/terminal acceptances, 16 operations, 64 generations,
8 members per stage, and 3 reports per execution (the M1 attempt bound). Stable
write rows remain bounded by existing stage and bootstrap caps. Admission reserves
terminal/report/link row capacity, and the model rejects over-capacity commands
atomically. Check the complete proposed canonical snapshot before every commit;
retain the 2 MiB outer ceiling unless a separate measured contract change is made.
This is not yet a proof that all future outer bytes or retry-stage physical slots
are prepaid, nor a production throughput or infinite-churn progress claim.

The new private test format must distinguish terminal-outcome sections. Preserve
frozen v1 synthetic and v2 real-request fixture bytes/readers in separate artifacts;
no silent loss or reinterpretation of retained stages, operation requests or
outcomes during conversion. A test-only successor format does not activate M3a/M6
production command or snapshot writers.

## Required qualification matrix

| History | Required check |
| --- | --- |
| Error Complete with result=None, SHA-256 and BLAKE3 requests | Exact Completed response and current worker origin; zero new result/operation roots; no head; no M4 sink effect. |
| Final MemoryFailure with result=None | Each actual reason: MissingGrowthEvidence, NoLargerEligibleWorker, AttemptBudgetExhausted; exact ResourceFailed value and origin; exact original refund once. |
| MemoryFailure with growth available | RetryScheduled, larger actual memory target, no terminal/publication; original request unchanged; next attempt gets separate authority/credit. |
| Complete or final MemoryFailure with ActionResult present | New path refuses unchanged, including empty ActionResult and nonzero status; old prepared Completed publication remains independently covered. |
| Wrong current attempt/incarnation, wrong original grant, nonquiescent report | No scheduler, retention, terminal, credit or outbox mutation. |
| Cancel one joined handle then report; reverse order | Independent cancellation survives later execution terminal; accepted terminal survives late cancellation; other owners/protection unchanged. |
| Last cancel before dispatch and during active work | Correct execution terminal, stable operation versions; active work remains charged and cancellation intent remains until Cleanup. |
| Renew interest then stale timer; early/current timer | Generation-fenced expiry; Advance alone never expires; last-interest expiry follows the same cancellation ownership rules. |
| Attempt/progress and execution-timeout expiry | Wrong generation/attempt cannot revoke successor; retry then exact final Exhausted; revoked reservations remain charged until cleanup. |
| Existing stage with unknown write, then cancel/retry/final/expiry | Stable stage/write records survive; late outcomes cannot publish, change terminal, or refund a successor. |
| Existing protected graph roots across a no-graph transition | Roots and serving promises unchanged; no new empty root or fake publication is created. |
| Every snapshot/suffix cut, conflicting duplicates, capacity edge | Same exact terminals, recorded origin, operation originals, charges, pending writes and credits; rejection/ignored events preserve the snapshot. |

Mutations must separately target classification-as-Complete, false finalization,
missing no-graph gate, overwritten canceled operation, early physical refund,
dropped old write, stale timer acceptance, reauthorized accepted origin, omitted
operation-original binding, and missing outer byte admission. Count only compiled
mutants that fail unchanged assertions.

## Frozen scope differences

The publication-head reference requires an ActionResult and excludes final memory
failure, last-interest cancellation and expiry; it also has an acknowledged opaque
response-token limitation. Keep it frozen. Activation v2 represents retained
ResourceFailed/cancellation/no-result facts and roots, but is a migration inventory
model, not this transition contract. Its separate snapshot-byte admission guard
remains necessary. M1 supplies the actual lifecycle decisions independently;
the new reference's responsibility is their atomic relation to terminal provenance,
operation associations and retained storage obligations.
