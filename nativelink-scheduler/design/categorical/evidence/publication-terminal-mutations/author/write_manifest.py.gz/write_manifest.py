#!/usr/bin/env python3
"""Write the final receipt without modifying the pre-mutant freeze."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/nativelink-categorical-evidence/publication-terminal-tests')
WORKTREE = Path('/tmp/nativelink-publication-terminal')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

freeze = json.loads((ROOT / 'final-freeze/freeze.json').read_text())
mutants = json.loads((ROOT / 'mutants/results.json').read_text())
assert len(mutants) == 10
assert all(row['compiled'] for row in mutants)
assert sum(row['detected'] for row in mutants) == 9
assert sum(row['survived'] for row in mutants) == 1
assert next(row for row in mutants if row['survived'])['name'] == '08-no-snapshot-byte-guard'
restored = (ROOT / 'restored-baseline-final.log').read_text()
result_lines = [line for line in restored.splitlines() if line.startswith('test result:')]
assert len(result_lines) == 3, result_lines
assert all('test result: ok.' in line for line in result_lines), result_lines
assert all(f'{count} passed' in line for count,line in zip((54,8,9), result_lines))
for path, expected in freeze['frozen_source_sha256'].items():
    assert sha(WORKTREE / path) == expected, path
    assert sha(ROOT / 'final-freeze/source' / path) == expected, path

evidence = {}
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in {'manifest.json', 'manifest.sha256'}:
        evidence[str(path.relative_to(ROOT))] = sha(path)

manifest = {
    'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'slice': 'Test-only private-v4 exact no-graph worker terminal outcomes and lifecycle integration',
    'worktree': str(WORKTREE),
    'worktree_base_commit': freeze['worktree_base_commit'],
    'freeze_sha256': sha(ROOT / 'final-freeze/freeze.json'),
    'patch_sha256': sha(ROOT / 'final-freeze/publication-terminal-rust.patch'),
    'contract_sha256': sha(ROOT / 'contract-v1.md'),
    'source_restored_and_verified': freeze['frozen_source_sha256'],
    'baseline': {
        'pre_mutation_log': 'baseline-final.log',
        'post_mutation_log': 'restored-baseline-final.log',
        'post_mutation_results': result_lines,
        'command': 'CARGO_TARGET_DIR=/tmp/nativelink-history-mutations-target CARGO_BUILD_JOBS=8 cargo test --locked --offline --profile=smol -p nativelink-scheduler --test publication_candidate_test --test publication_differential_test --test publication_physical_test',
        'strict_clippy': 'clippy-scheduler-second.log; three targets passed before immutable freeze, exact source restored after mutants',
        'format_checks': ['fmt-final.log', 'buildifier-final.log', 'diff-final.log'],
        'worker_validation': 'Owned by root through warm Bazel; no worker Cargo build in this worktree',
    },
    'scenario_count': 16,
    'initial_independent_scenario_source': 'ten-scenarios-before-implementation.rs',
    'test_corrections': freeze['test_corrections'],
    'reproduced_pre_fix_failures': [
        {'source': 'downgrade-repro-source.json', 'log': 'downgrade-repro.log',
         'claim': 'Four ResourceFailed v4 snapshots incorrectly restored after deleting terminal metadata and downgrading private version.'},
        {'source': 'memory-relations-repro-source.json', 'log': 'memory-relations-repro.log',
         'claim': 'Ten local memory-evidence/target/attempt-order corruptions incorrectly restored across both digest algorithms.'},
        {'source': 'lost-authority-repro-tests.json', 'log': 'lost-authority-repro.log',
         'claim': 'Six retained retry/last-cancellation authority-erasure snapshots incorrectly restored across both algorithms.'},
        {'source': 'idempotence-global-time-repro-tests.json', 'log': 'idempotence-global-time-repro.log',
         'claim': 'Four global report/graph time inversions incorrectly restored; duplicate settled observation also changed snapshot and invalidated preparation under both algorithms.'},
    ],
    'compiled_mutation_results': {
        'compiled': 10, 'detected': 9, 'survived': 1, 'invalid_runs': 0,
        'runs': mutants,
        'survivor_interpretation': 'Removing only serialized snapshot byte-length admission refusal survives all 54 candidate tests. Invariants, transaction snapshot validation, and restore byte guard remained. No cap/assertion changes were made. No aggregate-overflow witness or complete future outer-metadata byte-reservation proof is established.',
        'actual_state_fence_mutant_limit': 'Generation-fence mutant is detected when a stale old-generation expiry wrongly returns TooEarly rather than Ignored before the renewed deadline. This case alone does not demonstrate a stale timer canceling after the renewed deadline.',
    },
    'independence': {
        'terminal_reference_implementation_or_tests_opened': False,
        'frozen_before_mutations_and_external_comparison': True,
        'incidental_search_exposure': 'After final source freeze, an overly broad rg for mutation locations returned path/line matches from existing publication_head/reference.rs (MAX_SNAPSHOT guards only) and other reference paths. No such reference file was opened; this exposure informed no source/test change. Later searches were scoped to candidate and actual State files.',
    },
    'qualified_scope': [
        'Actual scheduler State decides Complete and MemoryFailure retry/final reasons from bounded captured requests and exact response bytes.',
        'No-graph result=None gate, stable origin, report identity/idempotence, operation-specific cancellation, interest/progress/execution timer fencing, and physical charge lifetime have scenario evidence.',
        'Unknown stage/write ownership survives cancellation, retry, final failure, expiry and late write observations without synthetic graph publication.',
        'Local retained evidence consistency, canonical restore, private version gating and existing direct-client graph/head/serving preservation have scenario evidence.',
        'All assertions run under SHA256 and BLAKE3 where the scenario varies digest algorithm.',
    ],
    'remaining_boundaries': [
        'Test-only private snapshot v4, no production RPC/authentication activation.',
        'Durable accepted-history feature3 remains disabled and unqualified.',
        'Worker report classification, quiescence and typed output closure remain trusted fixture inputs.',
        'No snapshot authenticity or historical worker-capacity reconstruction claim.',
        'Finite capacity scenarios do not prove complete future outer metadata byte reserve; pure byte guard mutation survived.',
        'This evidence does not establish global scheduler/storage replacement or full categorical elimination.',
    ],
    'artifact_sha256': evidence,
}
output = ROOT / 'manifest.json'
output.write_text(json.dumps(manifest, indent=2) + '\n')
digest = sha(output)
(ROOT / 'manifest.sha256').write_text(digest + '  manifest.json\n')
print(digest)
print('\n'.join(result_lines))
print(f'{len(evidence)} archived artifact hashes; 16 frozen sources exact; 10 compiled mutants, 9 detected, 1 survivor')
