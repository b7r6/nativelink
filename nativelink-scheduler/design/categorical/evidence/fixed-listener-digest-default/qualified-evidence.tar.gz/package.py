#!/usr/bin/env python3
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

ROOT = pathlib.Path('/tmp/nativelink-fixed-digest-default-evidence')
WORKTREE = pathlib.Path('/tmp/nativelink-fixed-digest-default')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((ROOT/name).read_text())
def descriptor(name):
    path = ROOT/name
    return {'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)}

source = read('qualified-source/manifest.json')
for entry in source['inputs']:
    assert sha(WORKTREE/entry['path']) == entry['sha256']
    assert sha(ROOT/'qualified-source'/entry['path']) == entry['sha256']
commit = read('source-commit.json')['commit']
assert commit == 'b1528c114d39fdfebee07d5cd86e7346d98e47b1'
original = read('original-corrected-phases/results.json')
assert len(original['cases']) == 15
assert sum(case['exit_code'] == 101 for case in original['cases']) == 13
assert all(case['phase_reached'] and case['exit_code'] == case['expected_exit_code'] for case in original['cases'])
mutants = read('mutants/attempts.json')
assert len(mutants) == 12
assert all(case['build_exit'] == 0 and case['compiler_observed'] and case['detected'] for case in mutants)
assert all(run['phase_reached'] and run['exit_code'] == run['expected_exit_code'] for case in mutants for run in case['executions'])
restored = read('restored-canonical.json')
assert restored['exit_code'] == 0
shutil.copytree('/tmp/nativelink-fixed-digest-default-independent-root-review', ROOT/'independent-root-review', dirs_exist_ok=True)

receipt = {
 'scope': 'Fixed experimental listener digest-default selection and ByteStream transfer facade; no production constructor or deployment qualification.',
 'source_commit': commit,
 'base_commit': source['base_commit'],
 'source_snapshots': [descriptor(name+'/manifest.json') for name in ['tests-first', 'precompile-tests', 'qualified-source']],
 'approved_audit': descriptor('approved-audit/proposal.json'),
 'source_review': descriptor('independent-root-review/review.json'),
 'source_commit_binding': read('source-commit.json'),
 'change': [
  'Private fixed CAS/AC selection maps only protobuf Unknown(0) to explicit SHA256 before context construction; public legacy constructors and explicit algorithm handling are preserved.',
  'A private ByteStream flag and crate-private fixed constructor resolve omitted resource algorithms to SHA256. Fixed requests bypass three direct GrpcStore forwarding shortcuts and use the local typed-context transfer path. Legacy direct forwarding remains available.',
  'Fixed explicit BLAKE3 remains supported; fixed services omit irrelevant advice to change the legacy global default. The global default getter, setter and storage implementation are unchanged.',
 ],
 'test_count_boundary': 'The new integration binary has exactly one Rust test. It runs15 sequential named phases normally; a validated selector permits one phase per fresh process for original-source and mutation controls. The existing standalone library contributes24 separate Rust tests.',
 'original_initial': read('baseline-initial.json'),
 'original_initial_selected_phases': descriptor('original-phases/results.json'),
 'initial_fixed_oracle_failure': {
  'execution': read('fixed-initial.json'),
  'classification': 'Harness defect, not an additional runtime regression: omitted-algorithm ByteStream write succeeded, then the oracle requested65555bytes via fixed CAS BatchRead, exceeding its existing64KiB admission limit.',
  'correction': 'Verify that upload using explicit-SHA ByteStream read. Preserve the original failure and freeze the patch. Standalone lint also required OnceLock backticks, traced background_spawn macros and a narrow justified runtime-construction lint expectation for the isolated synchronous test.',
  'harness_patch': descriptor('harness-corrections.patch'),
 },
 'original_corrected': read('baseline-corrected.json'),
 'original_corrected_selected_phases': {
  'receipt': descriptor('original-corrected-phases/results.json'),
  'claim': 'All15 phase-selected fresh-process tests reached their named phase:13 exposed the original defect; Execute and legacy controls passed. The ordinary unselected original run stops at the first CAS update failure, so later phase reachability derives only from these separate executions.',
 },
 'fixed_qualification': [read(name+'.json') for name in ['fixed-corrected', 'full-canonical', 'clippy-initial', 'clippy-corrected', 'service-clippy', 'restored-canonical']],
 'library_binary': read('full-canonical-library-binary.json'),
 'compiled_mutations': mutants,
 'mutation_scope': 'Four CAS mappings, two AC mappings, three ByteStream mappings and three remote shortcuts. The restored read shortcut is tested against both namespace and framing oracles. Each compiled variant also passes independent legacy and Execute positive controls. Compilation failures are not counted as detection.',
 'restoration': descriptor('mutants/restoration.json'),
 'mutation_assertion_audit': descriptor('mutants/assertion-audit.json'),
 'transport_claims': [
  'Actual loopback tonic HTTP/2 services with globalBLAKE3 initialized before the runtime or fixture accesses it. Fixed Unknown/omitted requests select SHA256; explicit BLAKE3, legacy global defaults and identical-key AC namespace isolation remain exercised.',
  'Actual upstream legacy CAS/ByteStream services backed by canonical storage and a modern GrpcStore with explicit resource names. Remote completed QueryWriteStatus uses the fixed local has path, which GrpcStore implements through FindMissingBlobs; this is not forwarding the upstream QueryWriteStatus RPC.',
  'Remote read framing first witnesses upstream frames larger than64KiB, then requires fixed front frames <=64KiB while a legacy front retains upstream framing. Read batching and remote wire compression are disabled in this witness.',
 ],
 'non_claims': [
  'GrpcStore use_legacy_resource_names=true remains unsupported/unqualified for a canonical closed constructor; generic legacy-name behavior is unchanged.',
  'Active/idle upload identity and UUID-only QueryWriteStatus lookup are separate residuals outside this repair.',
  'The uncompressed EOF producer-completion issue is repaired separately by root; this source commit retains its original inner_read and does not qualify late producer errors.',
  'No TLS, authentication, worker process, journal binding, production bootstrap, storage-controller durability or aggregate resource-bound qualification.',
  'SplitBlob/SpliceBlob remain unavailable in fixed services; their wrappers use the same mapped context but this packet does not claim a new enabled operation or a behavioral default-selection oracle for their refusal paths.',
  'Root integrated Bazel results are separate from author Cargo evidence and independent source review.',
 ],
 'binaries': 'Exact executable files retained externally at receipt paths with SHA256; excluded from repository archive.',
}
(ROOT/'author-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
out = WORKTREE/'nativelink-scheduler/design/categorical/evidence/fixed-listener-digest-default'
out.mkdir(parents=True, exist_ok=True)
files=[]
executables=[]
for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts: continue
    if path.read_bytes()[:4] == b'\x7fELF':
        executables.append(str(path.relative_to(ROOT)))
    else: files.append(path)
archive=out/'qualified-evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for path in files:
                data=path.read_bytes(); info=tarfile.TarInfo(str(path.relative_to(ROOT)))
                info.size=len(data); info.mode=0o644; info.mtime=0
                tar.addfile(info,io.BytesIO(data))
manifest={'source_commit':commit, 'author_receipt_sha256':sha(ROOT/'author-receipt.json'),
          'archive':archive.name, 'archive_sha256':sha(archive), 'archive_bytes':archive.stat().st_size,
          'scope':receipt['scope'],
          'qualification':'One isolated15-phase HTTP/2 test plus24 existing tests; exact original13fail2pass selected controls;12 compiled faults; strict standalone andservice Clippy; independent frozen source review. Root integrated Bazel separate.',
          'members':[descriptor(str(path.relative_to(ROOT))) for path in files],
          'external_executable_paths':executables}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(files)
    for entry in manifest['members']:
        data=tar.extractfile(entry['path']).read()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
print(json.dumps({'source_commit':commit, 'receipt_sha256':manifest['author_receipt_sha256'],
                  'manifest_sha256':sha(out/'manifest.json'), 'archive_sha256':sha(archive),
                  'archive_bytes':archive.stat().st_size, 'verified_members':len(files)},indent=2))
