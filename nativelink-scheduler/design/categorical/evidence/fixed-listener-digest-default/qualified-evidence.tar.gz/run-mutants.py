#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/tmp/nativelink-fixed-digest-default-evidence')
WORKTREE = pathlib.Path('/tmp/nativelink-fixed-digest-default')
SNAPSHOT = ROOT / 'qualified-source'
CARGO = '/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo'
OUT = ROOT / 'mutants'
OUT.mkdir(exist_ok=True)
manifest = json.loads((SNAPSHOT / 'manifest.json').read_text())
paths = [entry['path'] for entry in manifest['inputs'] if entry['path'].startswith('nativelink-service/src/')]
fixed = {path: (SNAPSHOT/path).read_text() for path in paths}
test_path = 'tools/canonical-store/tests/fixed_digest_default.rs'
test_hash = hashlib.sha256((SNAPSHOT/test_path).read_bytes()).hexdigest()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def replace_after(source, start, old, new):
    position = source.index(start)
    position = source.index(old, position)
    return source[:position] + new + source[position+len(old):]

variants = []
for file, methods in [
    ('cas_server.rs', [('find_missing_blobs', 'cas-find'), ('batch_update_blobs', 'cas-update'),
                       ('batch_read_blobs', 'cas-read'), ('get_tree', 'cas-tree')]),
    ('ac_server.rs', [('get_action_result', 'ac-get'), ('update_action_result', 'ac-update')]),
]:
    path = 'nativelink-service/src/' + file
    for method, phase in methods:
        mutated = replace_after(fixed[path], 'async fn '+method+'(',
                                'let digest_function = self.digest_function(request.digest_function);',
                                'let digest_function = request.digest_function;')
        variants.append((phase+'-inherits-global', path, mutated, [phase]))

path = 'nativelink-service/src/bytestream_server.rs'
for method, phase in [('inner_query_write_status', 'bs-query'), ('read', 'bs-read'), ('write', 'bs-write')]:
    old, new = ('|| Ok(self.default_digest_function()),', '|| Ok(default_digest_hasher_func()),')
    if method == 'write':
        old, new = ('let default_digest_function = self.default_digest_function();',
                    'let default_digest_function = default_digest_hasher_func();')
    variants.append((phase+'-inherits-global', path,
                     replace_after(fixed[path], 'async fn '+method+'(', old, new), [phase]))
for method, phases in [('inner_query_write_status', ['remote-query']),
                       ('read', ['remote-read', 'remote-chunks']), ('write', ['remote-write'])]:
    variants.append(('restore-grpc-'+method+'-shortcut', path,
                     replace_after(fixed[path], 'async fn '+method+'(', 'if !self.authority_admission', 'if true'), phases))

environment = dict(os.environ, CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target', CARGO_INCREMENTAL='0')
build_command = [CARGO, 'test', '--manifest-path', 'tools/canonical-store/Cargo.toml', '--locked',
                 '--offline', '--profile', 'smol', '-j8', '--test', 'fixed_digest_default',
                 '--no-run', '--message-format=json']
receipts = []
try:
    for name, path, mutated, phases in variants:
        for check, text in fixed.items():
            assert (WORKTREE/check).read_text() == text
        assert digest((WORKTREE/test_path).read_bytes()) == test_hash
        directory = OUT / name
        directory.mkdir(exist_ok=True)
        (directory/'mutated.rs').write_text(mutated)
        (WORKTREE/path).write_text(mutated)
        started = time.monotonic()
        result = subprocess.run(build_command, cwd=WORKTREE, env=environment,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (directory/'build.log').write_bytes(result.stdout)
        receipt = {'name': name, 'source_path': path,
                   'fixed_source_sha256': digest(fixed[path].encode()), 'mutated_source_sha256': digest(mutated.encode()),
                   'test_sha256': test_hash, 'build_command': build_command, 'build_exit': result.returncode,
                   'build_log_sha256': digest(result.stdout), 'build_seconds': time.monotonic()-started}
        receipts.append(receipt)
        (OUT/'attempts.json').write_text(json.dumps(receipts, indent=2)+'\n')
        assert result.returncode == 0, 'compilation failure is not mutation detection'
        artifact = None
        for line in result.stdout.splitlines():
            try: item = json.loads(line)
            except ValueError: continue
            if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'fixed_digest_default' and item.get('executable'):
                artifact = item
        assert artifact and artifact['fresh'] is False
        binary = directory/'test-binary'
        shutil.copy2(artifact['executable'], binary)
        receipt.update(binary_sha256=digest(binary.read_bytes()), compiler_observed=True, executions=[])
        for phase in phases + ['legacy', 'execute']:
            command = [str(binary), '--exact', 'fixed_roles_ignore_process_blake3_default_and_preserve_legacy',
                       '--test-threads=1', '--nocapture']
            execution = subprocess.run(command, env=dict(environment, NL_FIXED_DIGEST_CASE=phase),
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=95)
            (directory/(phase+'.log')).write_bytes(execution.stdout)
            output = execution.stdout.decode(errors='replace')
            expected = 0 if phase in ['legacy', 'execute'] else 101
            record = {'phase': phase, 'command': command, 'environment': {'NL_FIXED_DIGEST_CASE': phase},
                      'exit_code': execution.returncode, 'expected_exit_code': expected,
                      'phase_reached': ('digest phase: '+phase) in output,
                      'behavioral_failure': 'test result: FAILED' in output,
                      'log_sha256': digest(execution.stdout)}
            receipt['executions'].append(record)
            (OUT/'attempts.json').write_text(json.dumps(receipts, indent=2)+'\n')
            assert record['phase_reached'] and execution.returncode == expected
            if expected: assert record['behavioral_failure']
        receipt['detected'] = True
        (OUT/'attempts.json').write_text(json.dumps(receipts, indent=2)+'\n')
        (WORKTREE/path).write_text(fixed[path])
        print(json.dumps({'name': name, 'detected': True, 'build_seconds': receipt['build_seconds']}), flush=True)
finally:
    for path, text in fixed.items():
        (WORKTREE/path).write_text(text)
    restored = [{'path': path, 'sha256': digest((WORKTREE/path).read_bytes())} for path in paths]
    assert all((WORKTREE/path).read_text() == text for path, text in fixed.items())
    assert digest((WORKTREE/test_path).read_bytes()) == test_hash
    (OUT/'restoration.json').write_text(json.dumps({'runtime_inputs': restored, 'test_sha256': test_hash}, indent=2)+'\n')
