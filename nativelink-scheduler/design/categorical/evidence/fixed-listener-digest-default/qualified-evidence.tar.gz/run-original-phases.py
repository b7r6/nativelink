#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

binary = pathlib.Path(sys.argv[1])
root = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else pathlib.Path('/tmp/nativelink-fixed-digest-default-evidence/original-phases')
root.mkdir(exist_ok=True)
phases = ['cas-update', 'cas-read', 'cas-find', 'cas-tree', 'ac-get', 'ac-update',
          'bs-read', 'bs-write', 'bs-query', 'execute', 'legacy',
          'remote-read', 'remote-write', 'remote-query', 'remote-chunks']
receipts = []
for phase in phases:
    command = [str(binary), '--exact', 'fixed_roles_ignore_process_blake3_default_and_preserve_legacy',
               '--test-threads=1', '--nocapture']
    environment = dict(os.environ, NL_FIXED_DIGEST_CASE=phase)
    start = time.monotonic()
    result = subprocess.run(command, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=95)
    (root / (phase + '.log')).write_bytes(result.stdout)
    output = result.stdout.decode(errors='replace')
    expected = 0 if phase in ['execute', 'legacy'] else 101
    receipt = {'phase': phase, 'command': command, 'environment': {'NL_FIXED_DIGEST_CASE': phase},
               'exit_code': result.returncode, 'expected_exit_code': expected,
               'phase_reached': ('digest phase: '+phase) in output,
               'behavioral_failure': 'test result: FAILED' in output,
               'log_sha256': hashlib.sha256(result.stdout).hexdigest(), 'seconds': time.monotonic()-start}
    receipts.append(receipt)
    (root / 'results.json').write_text(json.dumps({'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'cases': receipts}, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)
    assert receipt['phase_reached'] and result.returncode == expected
    if expected: assert receipt['behavioral_failure']
