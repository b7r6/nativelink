#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/tmp/nativelink-fixed-digest-default-evidence')
WORKTREE = pathlib.Path('/tmp/nativelink-fixed-digest-default')
CARGO = '/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo'

name, *arguments = sys.argv[1:]
command = [CARGO, *arguments]
environment = dict(os.environ, CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target', CARGO_INCREMENTAL='0')
started = time.monotonic()
result = subprocess.run(command, cwd=WORKTREE, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
log = ROOT / (name + '.log')
log.write_bytes(result.stdout)
receipt = {'command': command, 'exit_code': result.returncode, 'seconds': time.monotonic()-started,
           'log_sha256': hashlib.sha256(result.stdout).hexdigest(),
           'executed_phases': [line for line in result.stdout.decode(errors='replace').splitlines() if line.startswith('digest phase:')],
           'test_results': [line for line in result.stdout.decode(errors='replace').splitlines() if line.startswith('test result:')]}
for line in result.stdout.splitlines():
    try:
        item = json.loads(line)
    except ValueError:
        continue
    if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'fixed_digest_default' and item.get('executable'):
        binary = ROOT / (name + '-test-binary')
        shutil.copy2(item['executable'], binary)
        receipt.update(binary=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), compiler_fresh=item.get('fresh'))
(ROOT / (name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2), flush=True)
sys.exit(result.returncode)
