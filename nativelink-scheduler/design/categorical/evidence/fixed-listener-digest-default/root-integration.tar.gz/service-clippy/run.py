from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path.cwd()
out = Path('/tmp/nativelink-fixed-digest-default-integration/service-clippy')
out.mkdir(exist_ok=True)
names = [p for p in subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0') if p and not p.startswith('nativelink-scheduler/design/categorical/evidence/')]
def snapshot():
    return {p: hashlib.sha256(os.readlink(root/p).encode() if (root/p).is_symlink() else (root/p).read_bytes()).hexdigest() for p in names}
before = snapshot()
(out/'sources-before.json').write_text(json.dumps(before, indent=2)+'\n')
(out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'], text=True))
for p in names:
    if p.endswith('.rs'):
        os.utime(root/p, None)
cmd = ['cargo','clippy','-p','nativelink-service','--lib','--tests','--locked','--offline','--profile','smol','-j4','--','-D','warnings']
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_TARGET_DIR=str(root/'target'))
(out/'command.json').write_text(json.dumps({'argv':cmd,'environment':{'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(root/'target')}},indent=2)+'\n')
t = time.monotonic()
with (out/'clippy.log').open('w') as f:
    code = subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
after = snapshot()
(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n')
result = {'exit':code,'elapsed_seconds':time.monotonic()-t,'source_count':len(before),'sources_unchanged':before==after}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
assert before==after
raise SystemExit(code)
