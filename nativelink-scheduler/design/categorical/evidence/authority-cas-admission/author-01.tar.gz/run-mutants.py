import hashlib,json,os,re,shutil,subprocess
from pathlib import Path
root=Path('/tmp/nativelink-authority-cas-admission')
evidence=Path('/tmp/nativelink-categorical-evidence/authority-cas-admission')
source=root/'nativelink-service/src/cas_server/authority.rs'
baseline=source.read_text()
assert hashlib.sha256(baseline.encode()).hexdigest()=='9d5f42f2fe5c6e8f66170996d2fc128f615a5a8673849e09e35c8d0f68ef9363'
def change(old,new,count=1):
 assert baseline.count(old)>=count,(old,baseline.count(old))
 return baseline.replace(old,new,count)
mutants=[]
def add(name,changed,test):
 mutants.append((name,changed,'cas_admission::'+test))
batch='fixed_batch_admission_precedes_all_store_calls_both_roles_and_hashes'
tree='fixed_tree_budgets_cover_whole_walk_frontier_and_missing_attempts'
paging='fixed_tree_pagination_advances_repeated_dag_occurrences_and_binds_tokens'
add('write_before_admission',change('        check_entries(request.requests.len())?;', '''        if let Some(entry) = request.requests.first() {
            let digest = parse_digest(entry.digest.as_ref())?;
            self.authority_store(&request.instance_name)?.update_oneshot(digest, entry.data.clone()).await?;
        }
        check_entries(request.requests.len())?;'''),batch)
add('batch_bytes',change('.filter(|total| *total <= CONTENT_BYTES)','.filter(|total| *total <= CONTENT_BYTES * 2)'),batch)
add('batch_entries',change('if count > ENTRIES {','if count > ENTRIES + 1 {'),batch)
start=baseline.index('async fn verified_read(');end=baseline.index('\nimpl CasServer {',start)
prefix='''async fn verified_read(store: &Store, digest: DigestInfo) -> Result<Bytes, Error> {
    let bytes = store.get_part_unchunked(digest, 0, Some(digest.size_bytes())).await?;
    let mut hasher = digest_hasher_func_from_context().hasher();
    hasher.update(&bytes);
    if hasher.finalize_digest() != digest {
        return Err(make_err!(Code::DataLoss, "CAS object length or hash mismatch"));
    }
    Ok(bytes)
}
'''
add('range_prefix_without_eof',(baseline[:start]+prefix+baseline[end:]).replace('use bytes::{Bytes, BytesMut};','use bytes::Bytes;').replace('use nativelink_util::buf_channel::make_buf_channel_pair;\n',''),'fixed_reads_reject_extra_tail_even_when_range_prefix_is_valid')
add('read_hash',change('if hasher.finalize_digest() != digest {','if false && hasher.finalize_digest() != digest {'),'fixed_reads_require_whole_verified_objects_and_cancel_excess_producers')
count='''        self.occurrences = self
            .occurrences
            .checked_add(1)
            .filter(|count| *count <= ENTRIES)
            .ok_or_else(|| make_err!(Code::ResourceExhausted, "Fixed GetTree directory limit"))?;
'''
visited=change(count,'')
visited=visited.replace('        while let Some(digest) = walk.pending.pop_front() {','''        while let Some(digest) = walk.pending.pop_front() {
            walk.occurrences += 1;
            if walk.occurrences > ENTRIES {
                return Err(make_err!(Code::ResourceExhausted, "Fixed GetTree directory limit"));
            }''',1)
add('charge_only_visited',visited,tree)
add('tree_bytes',change('.filter(|bytes| *bytes <= CONTENT_BYTES)','.filter(|bytes| *bytes <= CONTENT_BYTES * 2)'),tree)
add('token_binding',change('if parts.next() != Some("v1") || parts.next() != Some(binding) {','if parts.next() != Some("v1") || parts.next().is_none() {').replace("binding: &str) -> Result<Option<(&'a str, usize)>, Error>","_binding: &str) -> Result<Option<(&'a str, usize)>, Error>"),paging)
add('token_nonprogress',change('            start\n        } else {','            0\n        } else {'),paging)
add('tree_availability',change('if expected != fingerprint {','if false && expected != fingerprint {'),'fixed_tree_omits_missing_descendants_and_refuses_changed_continuations')
forward='''    ) -> Result<BatchReadBlobsResponse, Error> {
        if let Some(grpc) = self.authority_store(&request.instance_name)?.downcast_ref::<nativelink_store::grpc_store::GrpcStore>(None) {
            return Ok(grpc.batch_read_blobs(tonic::Request::new(request)).await?.into_inner());
        }
'''
add('grpc_forwarding',change('    ) -> Result<BatchReadBlobsResponse, Error> {\n',forward),'fixed_grpc_store_reads_do_not_trust_forwarded_cas_responses')
env=os.environ.copy();env.update(CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
results=[item for item in json.loads((evidence/'mutants'/'results.json').read_text()) if item['detected']]
try:
 for name,changed,test in mutants:
  if any(item['name']==name for item in results): continue
  path=evidence/'mutants'/name;path.mkdir(parents=True,exist_ok=True)
  source.write_text(changed);(path/'authority.rs').write_text(changed)
  command=['cargo','test','-p','nativelink-service','--test','authority_listener_test','--locked','--offline','--profile','smol','-j8',test,'--','--exact']
  print('START',name,flush=True)
  with (path/'run.log').open('w') as log:
   completed=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(path/'run.log').read_text()
  matches=re.findall(r'Running .*?\((/[^)]+)\)',output)
  compiled=bool(matches) and 'Finished' in output
  result={'name':name,'command':command,'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'exit_code':completed.returncode,'compiled':compiled,'detected':compiled and completed.returncode!=0 and '1 failed' in output}
  if compiled:
   binary=Path(matches[-1]);shutil.copy2(binary,path/'test-binary');result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
  results.append(result);(evidence/'mutants'/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print('DONE',name,json.dumps(result),flush=True)
  if not result['detected']: raise SystemExit('mutant not detected: '+name)
finally:
 source.write_text(baseline)
 assert source.read_text()==baseline
 print('BASELINE_RESTORED',hashlib.sha256(baseline.encode()).hexdigest(),flush=True)
