from pathlib import Path
import hashlib,json,os,re,subprocess,shutil
root=Path('/tmp/nativelink-authority-cas-admission');out=Path('/tmp/nativelink-categorical-evidence/authority-cas-admission')
assert hashlib.sha256((root/'nativelink-service/src/cas_server/authority.rs').read_bytes()).hexdigest()=='9d5f42f2fe5c6e8f66170996d2fc128f615a5a8673849e09e35c8d0f68ef9363'
env=os.environ.copy();env.update(CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
commands=[
 ('restored-service',['cargo','test','-p','nativelink-service','--test','authority_listener_test','--test','cas_server_test','--test','capabilities_server_test','--locked','--offline','--profile','smol','-j8']),
 ('restored-canonical',['cargo','test','--manifest-path','tools/canonical-store/Cargo.toml','--locked','--offline','--profile','smol','-j8']),
 ('restored-service-clippy',['cargo','clippy','-p','nativelink-service','--lib','--test','authority_listener_test','--locked','--offline','--profile','smol','-j8','--','-D','warnings']),
 ('restored-canonical-clippy',['cargo','clippy','--manifest-path','tools/canonical-store/Cargo.toml','--all-targets','--locked','--offline','--profile','smol','-j8','--','-D','warnings']),
]
records=[]
for name,cmd in commands:
 print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as log: result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':cmd,'exit_code':result.returncode,'binaries':{}}
 output=(out/(name+'.log')).read_text()
 for binary in re.findall(r'Running .*?\((/[^)]+)\)',output):
  p=Path(binary);dest=out/'restored-binaries'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);record['binaries'][p.name]=hashlib.sha256(dest.read_bytes()).hexdigest()
 records.append(record);(out/'final-verification.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE',name,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
print('ALL_FINAL_CHECKS_PASSED',flush=True)
