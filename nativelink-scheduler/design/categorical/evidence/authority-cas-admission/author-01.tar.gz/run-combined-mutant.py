from pathlib import Path
import hashlib,json,os,re,subprocess,shutil
root=Path('/tmp/nativelink-authority-cas-admission');out=Path('/tmp/nativelink-categorical-evidence/authority-cas-admission/mutants/combined_total_reset');out.mkdir(parents=True,exist_ok=True)
p=root/'nativelink-service/src/cas_server/authority.rs';original=p.read_text();assert original.count('.checked_add(amount)')==1
changed=original.replace('.checked_add(amount)','.checked_add(amount).map(|_| amount)')
test=root/'nativelink-service/tests/authority_listener/cas_admission.rs';shutil.copy2(test,out/'cas_admission.rs')
command=['cargo','test','-p','nativelink-service','--test','authority_listener_test','--locked','--offline','--profile','smol','-j8','cas_admission::fixed_combined_batch_content_counts_duplicates_and_both_upload_sizes','--','--exact']
env=os.environ.copy();env.update(CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
try:
 p.write_text(changed);(out/'authority.rs').write_text(changed)
 with (out/'run.log').open('w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 s=(out/'run.log').read_text();matches=re.findall(r'Running .*?\((/[^)]+)\)',s);compiled=bool(matches) and 'Finished' in s
 record={'name':'combined_total_reset','command':command,'compiled':compiled,'detected':compiled and result.returncode!=0 and '1 failed' in s,'exit_code':result.returncode,'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'fixture_sha256':hashlib.sha256(test.read_bytes()).hexdigest()}
 if compiled:
  shutil.copy2(matches[-1],out/'test-binary');record['binary_sha256']=hashlib.sha256((out/'test-binary').read_bytes()).hexdigest()
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
 assert record['detected']
finally:
 p.write_text(original);print('BASELINE_RESTORED',hashlib.sha256(original.encode()).hexdigest(),flush=True)
