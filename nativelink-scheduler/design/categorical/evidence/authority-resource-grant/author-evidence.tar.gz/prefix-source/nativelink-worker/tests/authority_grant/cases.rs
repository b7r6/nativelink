// Copyright 2026 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Real-process grant binding: no RPC memory classification is enabled here.
use std::collections::HashMap;

use nativelink_config::cas_server::EnvironmentSource;
use nativelink_proto::build::bazel::remote::execution::v2::command::EnvironmentVariable;
use nativelink_proto::build::bazel::remote::execution::v2::platform::Property;
use nativelink_proto::com::github::trace_machina::nativelink::remote_execution::ResourceOutcome;
use nativelink_worker::running_actions_manager::{MemoryLimit, ResourceEnforcement};

use super::*;

const MIB: u64 = 1024 * 1024;
const ORIGINAL: u64 = 128 * MIB;
const CHILD_ENV: &str = "NATIVELINK_AUTHORITY_GRANT_ALLOCATOR_CHILD";

#[test]
fn allocator_child() {
    if std::env::var_os(CHILD_ENV).is_none() {
        return;
    }
    let mut bytes = vec![0_u8; 192 * 1024 * 1024];
    for byte in bytes.iter_mut().step_by(4096) {
        *byte = 17;
    }
    std::hint::black_box(&bytes);
    std::thread::sleep(Duration::from_secs(2));
    println!(
        "GRANT_CHILD_COMPLETED;platform={}",
        std::env::var("ORIGINAL_MEMORY").unwrap()
    );
    std::hint::black_box(bytes);
}

#[nativelink_test]
async fn same_request_larger_typed_grant_changes_actual_memory_enforcement() {
    assert!(
        namespace_utils::namespaces_supported(false, false),
        "This qualification requires actual namespace quiescence"
    );
    for algorithm in [DigestHasherFunc::Sha256, DigestHasherFunc::Blake3] {
        let configuration = ExecutionConfiguration {
            persistent_workers: PersistentWorkersSettings {
                enabled: false,
                ..PersistentWorkersSettings::default()
            },
            resource_enforcement: Some(ResourceEnforcement {
                memory: Some(MemoryLimit {
                    property_name: "memory_kb".into(),
                    headroom_percent: 20,
                }),
                disk_property_name: None,
                disk_soft: false,
                disk_headroom_percent: 0,
            }),
            additional_environment: Some(HashMap::from([(
                "ORIGINAL_MEMORY".into(),
                EnvironmentSource::Property("memory_kb".into()),
            )])),
            ..ExecutionConfiguration::default()
        };
        let context = setup_configured(
            false,
            4,
            true,
            AuthorityResources {
                cpu_millis: 8000,
                memory_bytes: 512 * MIB,
                slots: 2,
            },
            configuration,
        )
        .await;
        context.worker.negotiate(&negotiation(1)).unwrap();
        let command = Command {
            arguments: vec![
                std::env::current_exe()
                    .unwrap()
                    .to_string_lossy()
                    .into_owned(),
                "--exact".into(),
                "grant::allocator_child".into(),
                "--nocapture".into(),
            ],
            environment_variables: vec![EnvironmentVariable {
                name: CHILD_ENV.into(),
                value: "1".into(),
            }],
            ..Command::default()
        };
        let command_bytes = command.encode_to_vec();
        let command_digest =
            serialize_and_upload_message(&command, context.cas.as_pin(), &mut algorithm.hasher())
                .await
                .unwrap();
        let root = serialize_and_upload_message(
            &Directory::default(),
            context.cas.as_pin(),
            &mut algorithm.hasher(),
        )
        .await
        .unwrap();
        let platform = Platform {
            properties: vec![Property {
                name: "memory_kb".into(),
                value: (ORIGINAL / 1024).to_string(),
            }],
        };
        let action = Action {
            command_digest: Some(command_digest.into()),
            input_root_digest: Some(root.into()),
            platform: Some(platform.clone()),
            ..Action::default()
        };
        let action_bytes = action.encode_to_vec();
        let action_digest =
            serialize_and_upload_message(&action, context.cas.as_pin(), &mut algorithm.hasher())
                .await
                .unwrap();
        let request = ExecuteRequest {
            action_digest: Some(action_digest.into()),
            digest_function: algorithm.proto_digest_func().into(),
            ..ExecuteRequest::default()
        };
        let request_bytes = request.encode_to_vec();
        for attempt in 1..=2 {
            let grant = AuthorityResources {
                cpu_millis: 1000,
                memory_bytes: ORIGINAL * attempt,
                slots: 1,
            };
            let command = AuthorityCommand {
                attempt: Some(target(attempt)),
                effect_id: attempt * 2,
                command: Some(authority_command::Command::Dispatch(AuthorityDispatch {
                    reservation_id: attempt,
                    execute_request: Some(request.clone()),
                    queued_timestamp: Some(prost_types::Timestamp {
                        seconds: 1,
                        nanos: 0,
                    }),
                    platform: Some(platform.clone()),
                    reserved_resources: Some(grant),
                    ..AuthorityDispatch::default()
                })),
            };
            context.worker.command(1, command.clone()).unwrap();
            let mut conflict = command.clone();
            let Some(authority_command::Command::Dispatch(dispatch)) = &mut conflict.command else {
                unreachable!()
            };
            dispatch.reserved_resources.as_mut().unwrap().memory_bytes += 1;
            assert!(context.worker.command(1, conflict).is_err());
            let report = wait_result(&context.worker, attempt).await;
            assert_eq!(report.phase, AuthorityAttemptPhase::Quiescent as i32);
            assert_eq!(context.worker.command(1, command).unwrap(), report);
            let usage = report
                .resource_usage
                .as_ref()
                .expect("completed upload retains usage");
            let Some(authority_attempt_report::Result::ExecuteResponse(response)) = &report.result
            else {
                panic!("expected exact response: {report:?}")
            };
            if attempt == 1 {
                assert_eq!(usage.outcome, ResourceOutcome::KilledMemory as i32);
                assert!(usage.enforced);
                assert_ne!(response.status.as_ref().map_or(0, |s| s.code), 0);
            } else {
                assert_eq!(
                    usage.outcome,
                    ResourceOutcome::Completed as i32,
                    "A doubled immutable grant must not enforce the original Action string; {usage:?}"
                );
                assert!(!usage.enforced);
                assert_eq!(response.result.as_ref().unwrap().exit_code, 0);
                let digest: nativelink_util::common::DigestInfo = response
                    .result
                    .as_ref()
                    .unwrap()
                    .stdout_digest
                    .clone()
                    .unwrap()
                    .try_into()
                    .unwrap();
                let stdout = context
                    .cas
                    .get_part_unchunked(digest, 0, None)
                    .await
                    .unwrap();
                assert!(
                    String::from_utf8(stdout.to_vec())
                        .unwrap()
                        .contains(&format!(
                            "GRANT_CHILD_COMPLETED;platform={}",
                            ORIGINAL / 1024
                        ))
                );
            }
            assert_eq!(
                context
                    .cas
                    .get_part_unchunked(action_digest, 0, None)
                    .await
                    .unwrap()
                    .as_ref(),
                action_bytes
            );
            assert_eq!(
                context
                    .cas
                    .get_part_unchunked(command_digest, 0, None)
                    .await
                    .unwrap()
                    .as_ref(),
                command_bytes
            );
            assert_eq!(request.encode_to_vec(), request_bytes);
        }
        eprintln!(
            "AUTHORITY_TYPED_GRANT_REAL_PROCESS: {algorithm:?}; same request R, explicit grants R/2R; first killed, second complete; namespace quiescent; original platform environment and CAS bytes retained"
        );
    }
}
