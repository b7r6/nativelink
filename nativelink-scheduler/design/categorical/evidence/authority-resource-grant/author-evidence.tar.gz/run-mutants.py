import difflib, hashlib, json, os, pathlib, subprocess, time
root=pathlib.Path('/tmp/nativelink-authority-memory-grant')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-memory-grant')
path=root/'nativelink-worker/src/running_actions_manager.rs'
base=path.read_text()
(evidence/'mutants').mkdir(exist_ok=True)
(evidence/'mutants'/'baseline-running_actions_manager.rs').write_text(base)
cases=[
 ('ignore_typed_threshold','let memory_reservation = if let Some(resources) = self.authority_resources {','let memory_reservation = if let Some(resources) = None::<AuthorityResourceLimits> {','same_request_larger_typed_grant_changes_actual_memory_enforcement'),
 ('floor_kib_ceiling','Some(bytes.div_ceil(1024))','Some(bytes / 1024)','exact_grant_and_conservative_kib_ceiling_validate_before_launch'),
 ('omit_headroom','.checked_mul(100 + u128::from(memory.headroom_percent))','.checked_mul(100)','exact_grant_and_conservative_kib_ceiling_validate_before_launch'),
 ('saturate_headroom_overflow','.and_then(|bytes| u64::try_from(bytes).ok())','.map(|bytes| u64::try_from(bytes).unwrap_or(u64::MAX))','exact_grant_and_conservative_kib_ceiling_validate_before_launch'),
]
cases += [('floor_percent_before_kib','.map(|product| product.div_ceil(100))','.map(|product| product / 100)','exact_grant_and_conservative_kib_ceiling_validate_before_launch')]
selected=os.environ.get('GRANT_MUTANT_ONLY')
results=json.loads((evidence/'mutants'/'results.json').read_text()) if selected else []
env=dict(os.environ,CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target',CARGO_INCREMENTAL='0')
try:
 for name,old,new,test in cases:
  if selected and name != selected:
   continue
  assert base.count(old)==1,(name,base.count(old))
  changed=base.replace(old,new)
  path.write_text(changed)
  target=evidence/'mutants'/name
  target.mkdir(exist_ok=True)
  (target/'mutation.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),changed.splitlines(True),fromfile='baseline',tofile=name)))
  (target/'source.rs').write_text(changed)
  (target/'cases.rs').write_bytes((root/'nativelink-worker/tests/authority_grant/cases.rs').read_bytes())
  command=['cargo','test','--locked','--offline','--profile','smol','-p','nativelink-worker','--test','authority_worker_test','-j4',test,'--','--nocapture']
  with (target/'run.log').open('w') as output:
   run=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
  log=(target/'run.log').read_text()
  compiled='Finished `smol` profile' in log and 'Running tests/authority_worker_test.rs' in log
  detected=compiled and run.returncode!=0 and 'test result: FAILED. 0 passed; 1 failed;' in log
  record=dict(name=name,command=command,returncode=run.returncode,compiled=compiled,detected=detected,source_sha256=hashlib.sha256(changed.encode()).hexdigest())
  results.append(record)
  (evidence/'mutants'/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(record),flush=True)
  if not detected:
   raise RuntimeError('mutant did not produce a qualified failure: '+name)
finally:
 path.write_text(base)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==hashlib.sha256(base.encode()).hexdigest()
 print('RESTORED '+hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
