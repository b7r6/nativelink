# Independent adapter review

Reviewed by storage_review after the candidate and reference freezes. This is a read-only review of the comparison adapter, fixtures, observations, cases and scope document; the reviewer did not edit these sources or run Cargo while the author held the build target. The reviewer authored the prepared-memory candidate and subsequently the five reference-audit corrections, so this is an independent adapter-author review, not blind independent engine authorship.

Status: no remaining blocking finding for the documented bounded comparison. All seven files exactly match the supplied review-freeze manifest at review completion. Commit: `1c4f6411776788b3392556c379628cbab245efb7`.

The fixture supplies expected typed graph membership, bytes, object identities and physical facts independently of candidate traversal. Common inputs use production request/result capture only to construct wire values; the oracle computes expected classification through its independent M1 relation. Retry target extraction from candidate state is confined to the actual-result projection. Stage deadlines now use the model clock.

The adapter applies each common command to both engines. Candidate rejection is not fabricated by prechecking oracle state. Unsupported neutral-only preparation fields, scenario payload/attempt/worker identity and execution identity are asserted as domain restrictions. The independently variable invalid incarnation, epoch, original charge and quiescence cases remain executable. Error categories are intentionally collapsed to refusal, with both native errors and full history retained on disagreement. Refusal and duplicate paths require both canonical snapshots to remain byte-identical.

Observation covers the complete scheduler view; caller request bytes; qualified action context; retained stages, reports, exact payloads, classification targets/reasons and provenance; acceptance arguments and positions; operations; absence of cache heads/grants; every retained root/write; live root ownership, closure and deadlines; protected-key union; physical readiness/retirement and successful-write revision. Duplicate live coverage owners cannot disappear during map conversion: both source row counts must equal map sizes. Native acceptance positions equal the engine commit, then map to the first common command ordinal at that commit. Restore and derived-index rebuild occur after every command, including refusal/no-op.

Credit observations explicitly check pending/current/prior stages and the fixed unused physical credit (eight while open, zero closed). They do not qualify execution-owned physical allocation or global capacity: this suite preinstalls all physical rows unowned and uses one execution, three attempts and ready objects. The scope document states this limit, as well as fixed scenario payloads, fixed operation leases, nonzero report IDs, no collector/fence transitions and the bounded event history.

All five frozen-audit disagreements are present in cases: overlong preparation, stage-local external write-ID reuse, repeated abandonment, duplicate admission, and ordinary resolved cache-miss admission. The ten tests additionally cover both digest algorithms, capacity changes at acceptance, all resource-failure reasons, zero peak, mixed graph/no-graph paths, cancellation, stale/incomplete proof, insufficient operation coverage, publication-ID reuse, late receipts, and exact replay through prefix restores.

During review, requested additions were applied by the adapter author: explicit preparation result identity; asserted fixed Stage payload/identity domain; both live-root multiplicity assertions; model-clock input generation; and credit current/prior/remaining projections. These are adapter boundary/observation improvements. They do not erase or reclassify the separately preserved original engine counterexamples.

The author reports strict Clippy success; test and fault-injection receipts are separate. This review makes no claim of unbounded equivalence, production activation, hostile-writer filesystem safety, or mutation coverage beyond those separate receipts.

Reviewed SHA-256 values:

- `nativelink-scheduler/tests/prepared_memory_differential/adapter.rs`: `9c3f4b949bb769d174510f349358ceb9131246827de55f5bb44900ae387e4061`
- `nativelink-scheduler/tests/prepared_memory_differential/fixtures.rs`: `b256b3809ad961c633709fa81b7256c45b50d922cf4305321b625af972db6234`
- `nativelink-scheduler/tests/prepared_memory_differential/observations.rs`: `a6bfbf294d9ce2f37985faa26624b367ff2a567305afe504228a0336fc5968a2`
- `nativelink-scheduler/tests/prepared_memory_differential/cases.rs`: `7476b84473b13c30aca71f1c836874ae085c78c9199b0f65b5737a7aacbc8d71`
- `nativelink-scheduler/tests/prepared_memory_differential_test.rs`: `8ab85b42845ca800f2a0d604abfdb2b0668076726ac5a7fe92bb68ba3add2660`
- `nativelink-scheduler/BUILD.bazel`: `360d63f61be48d24ed660a1f1466272c304ce38b2e223baa8909c28207a6d7fa`
- `nativelink-scheduler/design/categorical/prepared-memory-differential.md`: `f0a12c0cd74d677605daf0fa562cf805ffcaf8b10734c73f61403298f85372cd`
