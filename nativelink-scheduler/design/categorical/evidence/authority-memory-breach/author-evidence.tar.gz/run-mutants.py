import difflib, hashlib, json, os, pathlib, subprocess
root=pathlib.Path('/tmp/nativelink-authority-memory-evidence')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-memory-breach')
path=root/'nativelink-worker/src/running_actions_manager.rs'
base=path.read_text()
(evidence/'mutants').mkdir(exist_ok=True)
(evidence/'mutants'/'baseline.rs').write_text(base)
cases=[
('overwrite_first_stop', 'if self.selected.is_some() {\n            return false;\n        }', '', ['--lib','authority_memory_first_stop_wins_without_relabeling']),
('ignore_live_probe', '|| !matches!(live_probe, Ok(None))', '|| false', ['--lib','authority_memory_requires_a_live_probe_and_preserves_later_cancel']),
('ignore_kill_failure', 'kill_completed.then_some(AuthorityMemoryBreach {', 'true.then_some(AuthorityMemoryBreach {', ['--lib','authority_memory_requires_grant_breach_no_cancel_and_completed_kill']),
('derive_from_heuristic', 'self.state.lock().authority_memory_breach\n    }', 'let state = self.state.lock();\n        if state.authority_memory_breach.is_some() { return state.authority_memory_breach; }\n        let resources = self.authority_resources?;\n        let usage = state.resource_usage.as_ref()?;\n        (usage.outcome == ResourceOutcome::KilledMemory as i32).then_some(AuthorityMemoryBreach { charged: resources.charged, limit_kb: resources.memory_limit_kb.unwrap_or(0), observed_kb: usage.peak_memory_kb })\n    }', ['--test','authority_worker_test','authority_memory_heuristic_sigkill_does_not_mint_a_receipt']),
('lose_receipt_on_upload_error', 'Err(e) => return Err(e).err_tip(|| "Error while uploading results"),', 'Err(e) => { self.state.lock().authority_memory_breach = None; return Err(e).err_tip(|| "Error while uploading results"); },', ['--test','authority_worker_test','authority_memory_receipt_survives_upload_failure_without_a_finished_result']),
]
env=dict(os.environ,CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target',CARGO_INCREMENTAL='0')
results=[]
try:
 for name,old,new,selection in cases:
  assert base.count(old)==1,(name,base.count(old))
  changed=base.replace(old,new)
  path.write_text(changed)
  target=evidence/'mutants'/name; target.mkdir(exist_ok=True)
  (target/'source.rs').write_text(changed)
  (target/'mutation.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),changed.splitlines(True),fromfile='baseline',tofile=name)))
  command=['cargo','test','--locked','--offline','--profile','smol','-p','nativelink-worker','-j4']+selection+['--','--nocapture']
  with (target/'run.log').open('w') as output:
   run=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
  log=(target/'run.log').read_text()
  compiled='Finished `smol` profile' in log and ('Running unittests src/lib.rs' in log or 'Running tests/authority_worker_test.rs' in log)
  detected=compiled and run.returncode!=0 and 'test result: FAILED. 0 passed; 1 failed;' in log
  record=dict(name=name,command=command,returncode=run.returncode,compiled=compiled,detected=detected,source_sha256=hashlib.sha256(changed.encode()).hexdigest())
  results.append(record); (evidence/'mutants'/'results.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(record),flush=True)
  if not detected: raise RuntimeError('Unqualified mutant failure: '+name)
finally:
 path.write_text(base)
 print('RESTORED '+hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
