from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/tmp/nativelink-authority-memory-evidence')
evidence=Path('/tmp/nativelink-categorical-evidence/authority-memory-breach')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((evidence/'final-source-manifest.json').read_text())
for name,digest in source.items():
 assert sha(root/name)==digest,(name,'source drift')
 assert sha(evidence/'final-source'/name)==digest,(name,'archive drift')
log=(evidence/'restored-tests.log').read_text()
for count in [53,25,97]:
 assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in log
assert 'Finished `smol` profile' in (evidence/'clippy-final.log').read_text()
mutants=json.loads((evidence/'mutants/results.json').read_text())
assert len(mutants)==5 and all(x['compiled'] and x['detected'] for x in mutants)
assert sha(evidence/'mutants/baseline.rs')==source['nativelink-worker/src/running_actions_manager.rs']
for name in ['independent-runtime-review.json','independent-runtime-clippy-delta-review.json','test-review.json']:
 assert (evidence/name).is_file(),name
assert sha(evidence/'preimplementation-design-review.json')=='bc5338bb022cf6e310a095e354a6b1f122bba040a7755dbbe335c31996966c43'
record={
 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Rust-only local authority memory-policy receipt; no protocol/coordinator/retry policy changes',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'base_commit':'089f0b5e449354a4c4821860486088efdba62889',
 'files':source,
 'checks':{
  'cargo_args':'--locked --offline --profile smol -p nativelink-worker -j4',
  'final_tests':{'log':'restored-tests.log','lib':53,'authority_worker_test':25,'running_actions_manager_test':97},
  'clippy':{'log':'clippy-final.log','targets':['--lib','--test authority_worker_test','--test running_actions_manager_test'],'deny_warnings':True},
  'hooks':{'log':'hooks-final.log','changed_files':5},
  'mutants':mutants,
  'mutant_oracles':json.loads((evidence/'mutation-oracles.json').read_text()),
  'frozen_baseline_binaries':json.loads((evidence/'binaries.json').read_text()),
  'independent_reviews':['independent-runtime-review.json','independent-runtime-clippy-delta-review.json','test-review.json'],
 },
 'claims':[
  'Receipt requires a positive exact captured grant, strict sampled ceiling breach, no earlier selected authority stop, live-child probe and a completed kill procedure.',
  'First selected stop owns authority cause while later termination requests still execute; legacy kill behavior remains unchanged.',
  'Private receipt captures charged vector, checked ceiling and observed KiB before namespace closure, drain and upload.',
  'Real namespace R/2R cases for SHA-256 and BLAKE3 preserve stdout/stderr/output bytes and original request.',
  'Actual upload failure leaves receipt available and no finished result.',
  'Actual external SIGKILL near the ceiling qualifies existing heuristic telemetry with enforced=false and produces no receipt.',
 ],
 'limitations':[
  'Receipt does not prove exclusive physical exit cause, hard memory isolation, namespace closure, directory cleanup, upload success or authoritative acceptance.',
  'Ordering, exited/error probes and kill-result failures use deterministic private decision seams; exhaustive OS scheduling and OS kill-error injection are not claimed.',
  'Protocol still uses the existing Complete path; no wire receipt, coordinator MemoryFailure classification or M6 retention change.',
  'Initial fixture self-SIGKILL was ignored by namespace PID1 and failed its oracle; it was corrected to supervisor SIGKILL with real launch PID. Initial failure remains in focused-tests.log.',
  'Bazel integration is performed separately by parent; this isolated receipt qualification uses Cargo with repository lints.',
 ],
}
(evidence/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
files={str(p.relative_to(evidence)):sha(p) for p in sorted(evidence.rglob('*')) if p.is_file() and p.name!='receipts.json'}
(evidence/'receipts.json').write_text(json.dumps(files,indent=2)+'\n')
print('verification.json',sha(evidence/'verification.json'))
print('receipts.json',sha(evidence/'receipts.json'),'files',len(files))
