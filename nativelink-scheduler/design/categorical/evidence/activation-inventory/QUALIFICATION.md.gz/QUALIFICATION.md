# Actual-State retained inventory qualification

Candidate base is commit 27d010a3ef19b1a24d76b760625323b5bce3a51c. The frozen
publication activation v2 source and bounded admission helper are unchanged.
The helper lives under publication_activation_v2 so Cargo does not mistake it
for a separate integration test. The read-only captured-principal accessor is a
separate prerequisite authored by the real-request workstream. No production
activation or service selection is changed by this patch.

Final Cargo qualification: 16 tests pass. Twelve candidate mutants compile and
fail unchanged assertions; baseline and exact restored candidate pass. Final
Clippy with -D warnings passes. Pinned rustfmt, buildifier, typos, Vale and diff
whitespace checks pass. Actual-State Bazel integration passes all 16 cases in root's current workspace,
including the Bazel Clippy action. Its adapter, test and README bytes match this
candidate exactly. Full root workspace Cargo validation is a separate root-owned
gate and is not claimed here. Older independent reference workspaces are not
substituted for actual-State integration.

The source snapshot/view anchor, exact captured terminals, independent canceled
operation, qualified action identity, whole namespace identity, shared physical
result/history namespace, typed Tree closure, opaque materialized history and
old-domain exposure, resource-failure reason, canonical projection refusal, and
captured-principal agreement all have direct regression assertions. Twelve
mutants target these boundaries. Mutant binaries and changed adapter bytes have
hashes in per-mutant JSON; compile and test logs are preserved.

The final explicit Timestamp type is a lint-only fixture correction after the
mutation run. The original mutation fixture is archived. No expected value,
assertion or candidate source changed. Cargo and Clippy passed again afterward.

Earlier failed or interrupted runs are retained. The first compile needed a
Bytes conversion and an unused import removed. The first semantic fixture used
a nonzero original memory grant and incorrectly expected missing growth evidence;
actual State correctly retried. The fixture was corrected to zero original memory
and absent peak, preserving the frozen expected failure reason. Earlier Clippy
runs reported const, eager-expression, formatting and default-type style issues,
all corrected without changing the candidate contract. One expanded Cargo run
accidentally used a cold target directory, was interrupted, and was rerun against
the shared warm target. It is not counted as a passing qualification.

SourceInventory remains the lossless artifact even when projection refuses.
Physical verified reads and catalogues are explicit trusted inputs; readiness,
protection and collector ownership are separate model facts. This test does not
establish real deployment fences, complete historical request inventories, or
production migration safety. Known old exposure stays opaque. Pending history
without physical preparation can block projection while retaining its exact bytes.
