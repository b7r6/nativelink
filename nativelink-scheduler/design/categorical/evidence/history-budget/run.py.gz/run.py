#!/usr/bin/env python3
"""Freeze exact build inputs and retain all output from one owned matrix run."""
from pathlib import Path
import hashlib,json,subprocess,time,sys,os
E=Path(__file__).resolve().parent
W=Path('/tmp/nativelink-history-budget-candidate')
B=Path('/tmp/nativelink-history-mutations-target/smol/examples/history_budget')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def processes():
 return subprocess.check_output(['ps','-eo','pid,ppid,stat,comm,pcpu','--sort=-pcpu'],text=True)
def host():
 return {'unix_time_ns':time.time_ns(),'loadavg':Path('/proc/loadavg').read_text(),'processes':processes(),'disk':subprocess.check_output(['df','-B1',str(E)],text=True)}
name=sys.argv[1]
assert name.startswith('run-') and '/' not in name
out=E/name
assert not out.exists()
sources=json.loads((E/'build-source-hashes.json').read_text())
assert all(sha(W/f)==h for f,h in sources.items()),'sources changed after build'
cmd=[str(B),str(out),'smol',str(W)]
start=host()
active=[row for row in start['processes'].splitlines()[1:] if len(row.split())>=5 and not row.split()[2].startswith('Z') and row.split()[3] in {'rustc','clippy-driver','rust-lld','ld','cc1','clang','gcc'}]
if active:
 (E/(name+'-preflight-refusal.json')).write_text(json.dumps({'measurement_started':False,'active_compilers':active,'host':start},indent=2)+'\n')
 raise SystemExit('active compiler guard refused measurement')
receipt={'argv':cmd,'profile':{'inherits':'dev','debug':False,'opt_level':'z','strip':True},'source_manifest_sha256':sha(E/'build-source-hashes.json'),'binary_sha256':sha(B),'start':start,'host_samples':[]}
with (E/(name+'.log')).open('x') as log:
 process=subprocess.Popen(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT)
 while True:
  try:receipt['exit_code']=process.wait(timeout=5);break
  except subprocess.TimeoutExpired:receipt['host_samples'].append(host())
receipt['end']=host()
receipt['sources_unchanged']=all(sha(W/f)==h for f,h in sources.items())
receipt['artifacts']={str(f.relative_to(E)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()}
receipt['log_sha256']=sha(E/(name+'.log'))
(E/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'run':name,'exit_code':receipt['exit_code'],'source_unchanged':receipt['sources_unchanged'],'artifacts':len(receipt['artifacts'])}),flush=True)
raise SystemExit(receipt['exit_code'] or not receipt['sources_unchanged'])
