#!/usr/bin/env python3
"""Pair the fixed matrix; keep diagnostic probes separate from workload cost."""
from pathlib import Path
import json,statistics,hashlib,sys
root=Path(sys.argv[1]);e=root.parent
summary=json.loads((root/'summary.json').read_text())
assert summary['cases']==24
rows=summary['measurements']
assert len(rows)==24
pairs={}
for row in rows:
 key=(row['algorithm'],row['width'],row['stdout_payload_bytes'])
 feature=bool(row['features'])
 assert feature not in pairs.setdefault(key,{})
 pairs[key][feature]=row
 label=f"{key[0]}-{key[1]}-{key[2]}-{int(feature)}"
 raw=(root/label/'response.pb').read_bytes()
 assert len(raw)==row['captured_response_bytes']
 assert hashlib.sha256(raw).hexdigest()==row['captured_response_sha256']
 assert row['normal_proposals']==(11 if feature else 9)*row['width']+2
 recipes=row['history_metadata']['recipes']
 assert len(recipes)==(row['width'] if feature else 0)
 credit=row['history_metadata']['additional_prepaid_component_bytes_from_pinned_contract']
 assert row['history_metadata']['component_json_bytes']<=credit

def stat(values):
 return {'count':len(values),'min':min(values),'median':statistics.median(values),'max':max(values),'sum':sum(values)}
def costs(row):
 command={}
 entries={entry['index']:entry for entry in row['final_rows']['log_entries']}
 for sample in row['samples']:
  c=command.setdefault(sample['command'],{'latency':[],'bytes':[],'commit_ns':{},'durable_commits':{}})
  c['latency'].append(sample['proposal_to_durable_apply_ns']);c['bytes'].append(entries[sample['log_index']]['envelope_bytes'])
  for name,delta in sample['journal_operation_delta'].items():
   c['commit_ns'].setdefault(name,[]).append(delta['commit_elapsed_ns'])
   c['durable_commits'].setdefault(name,[]).append(delta['durable_commits'])
 return {name:{'proposal_ns':stat(c['latency']),'log_envelope_bytes':stat(c['bytes']),'commit_ns':{n:stat(v) for n,v in c['commit_ns'].items()},'durable_commits':{n:sum(v) for n,v in c['durable_commits'].items()}} for name,c in command.items()}
comparisons=[]
for (alg,width,padding),pair in pairs.items():
 base,history=pair[False],pair[True]
 for field in ['limits','captured_response_bytes','captured_response_sha256','result_json_bytes']:
  assert base[field]==history[field],field
 bc,hc=costs(base),costs(history)
 for name in bc:assert bc[name]['proposal_ns']['count']==hc[name]['proposal_ns']['count']
 assert set(hc)-set(bc)=={'pending_history_retirement_refusal','synthetic_history_stored_ack'}
 comparisons.append({'algorithm':alg,'width':width,'stdout_bytes':padding,'captured_bytes':base['captured_response_bytes'],'payload_json_bound':base['limits']['max_payload_bytes'],
  'base':{'commands':bc,'pending_core_snapshot_bytes':base['pending_snapshot']['core_snapshot_bytes'],'pending_persisted_snapshot_bytes':base['pending_snapshot']['persisted_snapshot_bytes'],'normal_log_envelope_bytes':base['measured_normal_log_envelope_bytes']},
  'history':{'commands':hc,'pending_core_snapshot_bytes':history['pending_snapshot']['core_snapshot_bytes'],'pending_persisted_snapshot_bytes':history['pending_snapshot']['persisted_snapshot_bytes'],'normal_log_envelope_bytes_including_probes':history['measured_normal_log_envelope_bytes'],
  'normal_log_envelope_bytes_excluding_probes':history['measured_normal_log_envelope_bytes']-hc['pending_history_retirement_refusal']['log_envelope_bytes']['sum'],'component':history['history_metadata']},
  'note':'Activation and recovery excluded; history retirement refusals are separately labeled qualification probes, not workload overhead.'})
capacity=json.loads((root/'capacity.json').read_text())
assert [row['admitted'] for row in capacity]==[64,56]
assert 'refused after committed abort' in capacity[0]['full_base_activation']['outcome']['Err']
result={'matrix':str(root),'paired_cases':len(comparisons),'capacity':{'default_effect_slots':512,'base_admitted':64,'history_admitted':56,'drop_percent':12.5},'comparisons':comparisons,'interpretation':'Single fixed pass; descriptive samples on disclosed shared host, no capacity/SLO inference.'}
(e/(root.name+'-comparisons.json')).write_text(json.dumps(result,indent=2)+'\n')
print('validated',len(comparisons),'pairs, byte-identical captured responses and identical limits')
for r in comparisons:
 b,h=r['base'],r['history']
 print(r['algorithm'],r['width'],r['stdout_bytes'],'core',b['pending_core_snapshot_bytes'],h['pending_core_snapshot_bytes'],'log excluding probes',b['normal_log_envelope_bytes'],h['normal_log_envelope_bytes_excluding_probes'],'complete median ns',b['commands']['complete']['proposal_ns']['median'],h['commands']['complete']['proposal_ns']['median'])
