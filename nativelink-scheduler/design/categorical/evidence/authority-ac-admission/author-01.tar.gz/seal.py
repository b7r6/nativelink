import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

p = Path(__file__).resolve().parent
w = Path('/tmp/nativelink-authority-ac-admission')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(name):
    return json.loads((p / name).read_text())


def write(name, value):
    (p / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


source = read('source-commit.json')
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip()
assert commit == source['commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=w, text=True)
for name, digest in source['files'].items():
    assert sha(w / name) == digest, name
    assert sha(p / 'pre-qualification-source' / name) == digest, name
assert read('restored-source-check.json')['all_eight_hashes_restored']

counts = {
    'focused-fixed': (12, 0),
    'service-restored': (38, 0),
    'legacy-ac': (4, 0),
    'listener-restored': (15, 1),
    'canonical-restored': (20, 0),
}
checks = {}
for name in [*counts, 'service-clippy', 'canonical-clippy', 'hooks-final', 'tls-runner']:
    receipt = read(name + '.json')
    assert receipt['returncode'] == 0, name
    entry = dict(receipt= name + '.json', log=name + '.log', **receipt)
    if name in counts:
        passed, ignored = counts[name]
        log = (p / (name + '.log')).read_text()
        expected = f'test result: ok. {passed} passed; 0 failed; {ignored} ignored;'
        assert expected in log, name
        entry.update(passed=passed, failed=0, ignored=ignored)
    checks[name] = entry

binaries = read('binaries.json')
assert len(binaries) == 4
for binary in binaries.values():
    assert sha(p / binary['copy']) == binary['sha256']

tls = read('tls/manifest.json')
assert tls['passed'] and tls['test_exit_code'] == 0
assert not tls['private_keys_archived']
assert tls['temporary_certificate_directory_removed']
assert tls['test_binary_sha256'] == binaries['listener-restored']['sha256']
assert sha(p / 'tls/observations.json') == tls['observations_sha256']
assert sha(p / 'tls/test.log') == tls['test_log_sha256']
for name, digest in tls['source_sha256'].items():
    blob = subprocess.check_output(['git', 'show', f'{commit}:{name}'], cwd=w)
    assert hashlib.sha256(blob).hexdigest() == digest, name
    dest = p / 'tls-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(blob)

mutants = read('mutants.json')
assert len(mutants) == 8
for mutant in mutants:
    d = p / 'mutants' / mutant['name']
    assert mutant['returncode'] == 101
    assert sha(d / 'source.rs') == mutant['source_sha256']
    assert sha(d / 'test-binary') == mutant['binary_sha256']
    log = (d / 'run.log').read_text()
    assert 'running 1 test' in log
    assert 'test result: FAILED. 0 passed; 1 failed;' in log

baseline_service = 'root-baseline/service-baseline-test.log'
baseline_canonical = 'root-baseline/initial-double-arc-compile-failure/canonical-baseline-test.log'
assert 'test result: FAILED. 0 passed; 12 failed;' in (p / baseline_service).read_text()
assert 'test result: FAILED. 0 passed; 1 failed;' in (p / baseline_canonical).read_text()

verification = {
    'schema_version': 1,
    'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Finite fixed Action Cache admission at the private client listener; author Cargo qualification plus separately attributed root original-baseline execution and independent source review.',
    'source_commit': commit,
    'base_commit': subprocess.check_output(['git', 'rev-parse', source['base']], cwd=w, text=True).strip(),
    'worktree': str(w),
    'source_clean_before_sealing': True,
    'changed_source_files': source['files'],
    'all_eight_source_hashes_restored_after_mutants_and_final_checks': True,
    'aggregate_source_patch': 'source.patch',
    'checks': checks,
    'final_regression_tests': 78,
    'test_count_explanation': '38 service + 4 legacy AC + 15 ordinary listener + 20 canonical + 1 explicitly selected TLS test. The preliminary 12 focused tests are repeated within the final service run and are not added again. The one ordinarily ignored TLS test was executed explicitly in four SHA256/BLAKE3 x isolated/shared-trust cases.',
    'final_binaries': binaries,
    'tls_manifest': 'tls/manifest.json',
    'tls_cases': 4,
    'root_original_baseline': {
        'service': {'log': baseline_service, 'passed': 0, 'failed': 12, 'commands': 'root-baseline/baseline-results.json'},
        'canonical': {'log': baseline_canonical, 'passed': 0, 'failed': 1, 'commands': 'root-baseline/initial-double-arc-compile-failure/baseline-results.json'},
        'service_compile_prerequisites': [
            'Initial service fixture had a redundant Arc around GrpcStore::new, which already returns Arc. No service tests executed on that attempt. The independent canonical test did execute and fail its early-admission oracle.',
            'Second service attempt failed strict await_holding_lock lint. No service tests executed on that attempt. A lexical guard scope and start_paused test attribute corrected fixture mechanics.',
        ],
        'test_only_commits': [
            '5ca79303fdefe6ec63c45e4df73f9855d51f5820',
            'd8688895bf88b5e87abe500c5d4f28a4b156c605',
            'f3997efded48fa21c2cc6a808c7b8870eba7a8bb',
            '91f5239f8f218108a964d8056ed54692e6961824',
        ],
        'provenance': 'Root ran the final 12 fixtures against the original AC path through the test-only constructor shim. Its tree also contained an independently qualified storage digest-context change. Author final qualification uses the isolated source commit above; later combined-root Bazel integration is a separate receipt.',
    },
    'mutants': mutants,
    'mutant_oracles': 'mutant-oracles.json',
    'mutant_limits': [
        'ignored-producer-result is detected at the Error-before-EOF case (Internal rather than Unavailable); this mutant does not independently reach the later EOF-then-error case. The restored full test executes and passes that later case.',
        'Each mutant compiles and executes exactly one selected failing test. Mutant source and executable bytes are retained. No claim that eight single faults exhaust all defects.',
    ],
    'independent_source_review': {
        'path': 'independent-review/review.json',
        'sha256': sha(p / 'independent-review/review.json'),
        'reviewer': 'root',
        'findings': [],
    },
    'evidence_labels': {
        'baseline-source': 'Initial test-only snapshot before later fixture additions and corrections; not the final implementation.',
        'baseline-final-source': 'Intermediate f399 fixture snapshot before lexical-lock correction; retained as historical evidence, not the final baseline execution source.',
        'pre-qualification-source': 'All eight exact final source files at a1063f, rechecked after mutation and full qualification.',
        'planned-authority.rs and planned-document.md': 'Planning drafts; final authoritative source is pre-qualification-source plus source_commit.',
        'root-baseline': 'Copied root original-path receipts and immutable source hashes; original failures retained.',
        'tls-source': 'Exact git blobs matching the TLS runner manifest and final source commit.',
    },
    'limits': [
        'CAP+1 range reasoning requires a producer that returns every available byte in that requested range before EOF and success. Generic Store cannot prove that contract for an arbitrary backend.',
        'Logical retained raw bytes and encoded response are limited to 1 MiB. This is not an exact heap, aggregate concurrency, physical IO, or disk-lifetime bound; decoded object allocation can exceed serialized bytes.',
        'GrpcStore decodes and normalizes upstream messages before this collector; unknown fields can disappear there. Its upstream decoder, retries, allocations and concurrency require separate bounds.',
        'The thirty-second Tokio deadline is cooperative. It cannot preempt synchronous decode or blocking work, and a timed-out remote or blocking mutable update may complete later.',
        'The exact 1 MiB ActionResult update boundary is a direct-handler fixture. An actual UpdateActionResult RPC must also fit its request envelope under the existing 1 MiB wire ceiling.',
        'Action digests remain opaque mutable keys; client writes remain authorized and worker AC methods remain absent. This does not establish immutable publication, latest-writer ordering, M6 acceptance, or definitive timed-out write outcomes.',
        'No process quiescence, cold recovery, power-loss, workload budget, deployed TLS topology, or production activation is qualified by these fixtures.',
        'Author baseline predates the independently integrated storage digest-context change. Parent combined-tree Bazel regression and server build receipts are separate and are not claimed by this author manifest.',
    ],
}
write('verification.json', verification)
files = {}
for path in sorted(p.rglob('*')):
    if path.is_file() and path != p / 'receipts.json':
        files[str(path.relative_to(p))] = {'sha256': sha(path), 'bytes': path.stat().st_size}
write('receipts.json', {
    'schema_version': 1,
    'scope': 'Every regular artifact under the evidence directory, except this self-referential manifest.',
    'source_commit': commit,
    'verification_sha256': sha(p / 'verification.json'),
    'files': files,
})
print(json.dumps({'verification_sha256': sha(p / 'verification.json'), 'receipts_sha256': sha(p / 'receipts.json'), 'artifacts': len(files), 'bytes': sum(v['bytes'] for v in files.values())}, indent=2))
