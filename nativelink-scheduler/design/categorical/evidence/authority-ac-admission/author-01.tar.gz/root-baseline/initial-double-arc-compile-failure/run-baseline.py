from pathlib import Path
import json,hashlib,subprocess,shutil
r=Path.cwd();o=Path(__file__).parent;names=json.loads((o/'source-names.json').read_text())
def sources():return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names}
before=sources();(o/'baseline-sources-before.json').write_text(json.dumps(before,indent=2)+'\n');(o/'baseline-head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
results=[]
for group,filter,label in [('service','authority_tests::','//nativelink-service:unit_test'),('canonical','fixed_roles_refuse_large_cas_batches_and_bound_ac_before_decode','//tools/canonical-store:canonical_store_test')]:
 cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','--test_arg='+filter,label]
 path=o/(group+'-baseline.log')
 with path.open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 fresh='Executed 1 out of 1 test' in path.read_text()
 if fresh:shutil.copyfile(r/'bazel-testlogs'/label[2:].replace(':','/')/'test.log',o/(group+'-baseline-test.log'))
 results.append({'group':group,'command':cmd,'exit_code':code,'executed':fresh});print(results[-1],flush=True)
 assert sources()==before
(o/'baseline-results.json').write_text(json.dumps(results,indent=2)+'\n');(o/'baseline-sources-after.json').write_text(json.dumps(sources(),indent=2)+'\n')
