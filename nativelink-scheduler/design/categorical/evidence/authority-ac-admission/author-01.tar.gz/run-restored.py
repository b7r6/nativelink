import datetime,hashlib,json,pathlib,re,shutil,subprocess,sys
p=pathlib.Path(__file__).parent;w=pathlib.Path('/tmp/nativelink-authority-ac-admission')
expected=json.loads((p/'pre-qualification-source.json').read_text())['files']
for f,want in expected.items():assert hashlib.sha256((w/f).read_bytes()).hexdigest()==want,f
(p/'restored-source-check.json').write_text(json.dumps({'all_eight_hashes_restored':True,'files':expected},indent=2)+'\n')
base=['cargo','test','--locked','--offline','--profile','smol','-j4']
checks=[
 ('service-restored',base+['-p','nativelink-service','--lib','--','--test-threads=1']),
 ('legacy-ac',base+['-p','nativelink-service','--test','ac_server_test','--','--test-threads=1']),
 ('listener-restored',base+['-p','nativelink-service','--test','authority_listener_test','--','--test-threads=1']),
 ('canonical-restored',base+['--manifest-path','tools/canonical-store/Cargo.toml','--lib','--','--test-threads=1']),
 ('service-clippy',['cargo','clippy','--locked','--offline','--profile','smol','-j4','-p','nativelink-service','--lib','--tests','--','-D','warnings']),
 ('canonical-clippy',['cargo','clippy','--locked','--offline','--profile','smol','-j4','--manifest-path','tools/canonical-store/Cargo.toml','--all-targets','--','-D','warnings']),
]
binaries={}
for name,cmd in checks:
 r=subprocess.run(['python3',str(p/'run-check.py'),name,*cmd]);
 if r.returncode:sys.exit(r.returncode)
 match=re.search(r'Running [^\n]+ \(([^\n]+)\)',(p/(name+'.log')).read_text())
 if match:
  src=pathlib.Path(match.group(1));dst=p/'binaries'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copy2(src,dst)
  binaries[name]={'original':str(src),'copy':str(dst.relative_to(p)),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size}
  (p/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
for f,want in expected.items():assert hashlib.sha256((w/f).read_bytes()).hexdigest()==want,f
print('Restored qualification complete; final binaries frozen before Cargo release',flush=True)
