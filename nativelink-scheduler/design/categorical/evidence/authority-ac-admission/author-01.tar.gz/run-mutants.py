import datetime,hashlib,json,os,pathlib,re,shutil,subprocess
p=pathlib.Path(__file__).parent; w=pathlib.Path('/tmp/nativelink-authority-ac-admission'); source=w/'nativelink-service/src/ac_server/authority.rs'; original=source.read_bytes(); text=original.decode()
env=os.environ.copy();env['CARGO_INCREMENTAL']='0';env['CARGO_TARGET_DIR']='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
def once(old,new):
 assert text.count(old)==1,(old,text.count(old));return text.replace(old,new,1)
raw='''            if chunk.len() > VALUE_BYTES - bytes.len() {
                return Err(make_err!(
                    Code::ResourceExhausted,
                    "Fixed Action Cache value limit"
                ));
            }
'''
checks='        check_encoded(&value)?;'
assert text.count(checks)==2
last=text.rfind(checks)
mutants=[
 ('missing-sentinel',once('Some(VALUE_BYTES as u64 + 1)','Some(VALUE_BYTES as u64)'),'sentinel_detects_valid_cap_prefix_with_semantic_tail'),
 ('unchecked-raw-value',once(raw,''),'raw_unknown_fields_are_bounded_before_decode'),
 ('ignored-producer-result',once('    let (bytes, ()) = futures::try_join!(receive, send)?;','    let (bytes, _outcome) = futures::join!(receive, send);\n    let bytes = bytes?;'),'complete_range_requires_eof_and_successful_producer_and_bounds_diagnostics'),
 ('missing-eof-accepted',once('reader.recv().await?','reader.recv().await.unwrap_or_default()'),'complete_range_requires_eof_and_successful_producer_and_bounds_diagnostics'),
 ('unchecked-response-growth',text.replace(checks,'',1),'decoded_response_growth_is_checked_before_encoding'),
 ('unchecked-update-size',text[:last]+text[last:].replace(checks,'',1),'grpc_update_refuses_before_upstream_write_and_returns_original_bounded_value'),
 ('restored-grpc-get-shortcut',once('        // The store facade supplies no inline hints; there is no CAS fetch here.', '''        if let Some(grpc) = store.store.downcast_ref::<nativelink_store::grpc_store::GrpcStore>(Some(digest.into())) {
            return grpc.get_action_result(tonic::Request::new(request)).await;
        }
        // The store facade supplies no inline hints; there is no CAS fetch here.'''),'grpc_facade_omits_inline_hints_and_applies_fixed_response_limit'),
 ('extended-request-deadline',once('Duration::from_secs(30)','Duration::from_secs(60)'),'fixed_timeout_cancels_incomplete_range'),
]
receipts=[]
try:
 for name,mutated,selected in mutants:
  d=p/'mutants'/name;d.mkdir(parents=True,exist_ok=True)
  source.write_text(mutated);(d/'source.rs').write_text(mutated)
  cmd=['cargo','test','--locked','--offline','--profile','smol','-j4','-p','nativelink-service','--lib',selected,'--','--nocapture','--test-threads=1']
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (d/'run.log').open('w') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
  log=(d/'run.log').read_text()
  ran=re.search(r'Running [^\n]+ \(([^\n]+)\)',log)
  assert ran,(name,'did not execute',log[-2000:])
  shutil.copy2(ran.group(1),d/'test-binary')
  receipt={'name':name,'command':cmd,'returncode':r.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'binary_sha256':hashlib.sha256((d/'test-binary').read_bytes()).hexdigest()}
  assert r.returncode==101 and 'panicked at' in log and 'test result: FAILED. 0 passed; 1 failed' in log,(name,'not detected at expected executable assertion',log[-2000:])
  receipt['oracle']='selected compiled test panicked; exactly one failed test'
  receipts.append(receipt);(p/'mutants.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(json.dumps(receipt),flush=True)
finally:
 source.write_bytes(original)
 assert source.read_bytes()==original
 print('Restored authority.rs SHA256 '+hashlib.sha256(original).hexdigest(),flush=True)
