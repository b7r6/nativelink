import datetime,json,os,pathlib,subprocess,sys
p=pathlib.Path(__file__).parent
name=sys.argv[1];command=sys.argv[2:]
env=os.environ.copy();env['CARGO_INCREMENTAL']='0';env['CARGO_TARGET_DIR']='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/(name+'.log')).open('w') as log:
 r=subprocess.run(command,cwd='/tmp/nativelink-authority-ac-admission',env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':command,'returncode':r.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}}
(p/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
for line in (p/(name+'.log')).read_text().splitlines()[-24:]:print(line[:1500])
raise SystemExit(r.returncode)
