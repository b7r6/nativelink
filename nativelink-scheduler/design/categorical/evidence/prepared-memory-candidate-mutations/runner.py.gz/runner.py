#!/usr/bin/env python3
"""Run explicit compiled faults against a frozen private-v5 candidate checkout.

The caller supplies an isolated clean worktree and the shared Cargo token.
Compilation failure, timeout, missing tests and process errors are not kills.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

PREFIX = "cases::real_request_tests::terminal_tests::prepared_memory_tests::"
MEMORY = "nativelink-scheduler/tests/publication_candidate/prepared_memory.rs"
TERMINAL = "nativelink-scheduler/tests/publication_candidate/terminal.rs"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--mutations", type=Path, required=True)
    args = parser.parse_args()
    work = args.worktree.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    mutants = json.loads(args.mutations.read_text())
    originals = {row["source"]: (work / row["source"]).read_bytes() for row in mutants}
    for row in mutants:
        if originals[row["source"]].decode().count(row["before"]) != 1:
            raise ValueError(f"{row['name']}: anchor must be unique")
    source_paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=work).decode().split("\0")
    report = {
        "scope": "Private-v5 candidate compiled fault fixtures; not production qualification",
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=work, text=True).strip(),
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "source_sha256": {
            p: sha((work / p).read_bytes()) for p in source_paths
            if p and ((p.endswith(".rs") and p.startswith("nativelink-scheduler/"))
                      or p in ["Cargo.toml", "Cargo.lock", "nativelink-scheduler/Cargo.toml"])
        },
        "commands": [], "mutants": [],
    }
    (output / "runner.py").write_bytes(Path(__file__).read_bytes())
    (output / "mutations.json").write_bytes(args.mutations.read_bytes())
    for path, contents in originals.items():
        destination = output / "original" / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(contents)
    env = dict(os.environ, CARGO_TARGET_DIR=str(args.target_dir.resolve()), CARGO_INCREMENTAL="0")
    build = ["cargo", "test", "--locked", "--offline", "--profile", "smol", "-p",
             "nativelink-scheduler", "--test", "publication_candidate_test", "-j8",
             "--no-run", "--message-format=json"]

    def save():
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    def run(name, command, timeout):
        log = output / f"{name}.log"
        started = time.monotonic()
        try:
            with log.open("wb") as stream:
                result = subprocess.run(command, cwd=work, env=env, stdout=stream,
                                        stderr=subprocess.STDOUT, timeout=timeout, check=False)
            status = result.returncode
        except subprocess.TimeoutExpired:
            status = "timeout"
        report["commands"].append({"name": name, "command": command, "status": status,
                                   "seconds": time.monotonic() - started,
                                   "log": log.name, "sha256": sha(log.read_bytes())})
        save()
        return status, log.read_text(errors="replace")

    def compile(name):
        status, log = run(name + "-compile", build, 900)
        binaries = []
        for line in log.splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("reason") == "compiler-artifact" and row.get("executable") \
                    and row.get("target", {}).get("name") == "publication_candidate_test":
                binaries.append(row["executable"])
        return status, binaries[-1] if binaries else None

    def restore_sources():
        for path, contents in originals.items():
            (work / path).write_bytes(contents)

    try:
        status, binary = compile("baseline")
        if status != 0 or binary is None:
            raise RuntimeError("baseline compilation failed")
        status, log = run("baseline-test", [binary, "--test-threads=4"], 180)
        tests = set(re.findall(r"^test (\S+) \.\.\. ok$", log, re.MULTILINE))
        required = {row["test"] for row in mutants}
        report["baseline_tests"] = sorted(tests)
        report["baseline_passed"] = status == 0 and required <= tests
        save()
        if not report["baseline_passed"]:
            raise RuntimeError("baseline did not pass and execute every named test")
        for mutant in mutants:
            restore_sources()
            changed = originals[mutant["source"]].decode().replace(mutant["before"], mutant["after"], 1)
            (work / mutant["source"]).write_text(changed)
            destination = output / mutant["name"] / Path(mutant["source"]).name
            destination.parent.mkdir(parents=True)
            destination.write_text(changed)
            row = dict(mutant, sha256=sha(changed.encode()))
            status, binary = compile(mutant["name"])
            if status != 0 or binary is None:
                row["classification"] = "compile_or_process_error"
            else:
                row["binary_sha256"] = sha(Path(binary).read_bytes())
                status, log = run(mutant["name"] + "-test", [binary, mutant["test"], "--exact"], 90)
                if status == 0 and f"test {mutant['test']} ... ok" in log:
                    row["classification"] = "survived"
                elif isinstance(status, int) and status > 0 and "running 1 test" in log \
                        and f"test {mutant['test']} ... FAILED" in log \
                        and "panicked at" in log and "test result: FAILED" in log:
                    row["classification"] = "semantic_kill"
                else:
                    row["classification"] = "process_or_coverage_error"
            report["mutants"].append(row)
            save()
            print(json.dumps({"name": row["name"], "classification": row["classification"]}), flush=True)
    finally:
        restore_sources()
        status, binary = compile("restored")
        if status == 0 and binary:
            status, log = run("restored-test", [binary, "--test-threads=4"], 180)
            restored = set(re.findall(r"^test (\S+) \.\.\. ok$", log, re.MULTILINE))
            report["restored_passed"] = status == 0 and restored == set(report.get("baseline_tests", [])) and bool(restored)
        else:
            report["restored_passed"] = False
        report["sources_restored"] = all((work / p).read_bytes() == v for p, v in originals.items())
        report["all_killed"] = report.get("baseline_passed", False) and report["restored_passed"] \
            and report["sources_restored"] and len(report["mutants"]) == len(mutants) \
            and all(row["classification"] == "semantic_kill" for row in report["mutants"])
        save()
    raise SystemExit(0 if report["all_killed"] else 1)


if __name__ == "__main__":
    main()
