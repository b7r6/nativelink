#!/usr/bin/env python3
"""Independent later-directory EIO witnesses against the frozen author binary."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = Path('/tmp/nativelink-canonical-store-evidence')
BINARY = AUTHOR / 'qualified/canonical_store_test'
EXPECTED_BINARY = 'f5a89ae65a9bd1616e85336155980e495da87bd342b0385305e84d124b351638'
assert hashlib.sha256(BINARY.read_bytes()).hexdigest() == EXPECTED_BINARY
CASES = [
    ('upload', 'content', 11),
    ('upload', 'content.exec', 12),
    ('has', 'content', 15),
    ('has', 'content.exec', 16),
    ('duplicate', 'content', 16),
    ('duplicate', 'content.exec', 17),
]
rows = []
for scenario, directory, occurrence in CASES:
    name = f'{scenario}-{directory}-eio'
    trace = HERE / f'{name}.strace'
    command = [
        '/run/current-system/sw/bin/strace', '-f', '-yy', '-e',
        'trace=fsync,renameat,renameat2', '-o', str(trace), '-e',
        f'inject=fsync:error=EIO:when={occurrence}', str(BINARY),
        '--exact', 'tests::rpc::syscall_fsync_rpc_witness', '--nocapture',
        '--test-threads=1',
    ]
    env = os.environ.copy()
    env['CANONICAL_STORE_FSYNC_SCENARIO'] = scenario
    env['CANONICAL_STORE_EXPECT_FSYNC_ERROR'] = 'directory'
    result = subprocess.run(
        command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=30, check=False,
    )
    log = HERE / f'{name}.log'
    log.write_text(result.stdout)
    lines = trace.read_text().splitlines()
    injected = [line for line in lines if '(INJECTED)' in line]
    assert result.returncode == 0, (name, result.stdout)
    assert len(injected) == 1, (name, injected)
    assert f'/cas/{directory}>' in injected[0], (name, injected)
    assert '= -1 EIO ' in injected[0], (name, injected)
    wanted = f'syscall witness: scenario={scenario} status=14 content=1 temporary={int(scenario == "duplicate")}'
    assert wanted in result.stdout, (name, result.stdout)
    assert 'test result: ok. 1 passed; 0 failed;' in result.stdout
    successful_renames = [line for line in lines if 'renameat2(' in line and 'RENAME_NOREPLACE) = 0' in line]
    assert len(successful_renames) == 1, (name, successful_renames)
    rows.append({
        'name': name,
        'command': command,
        'environment_overrides': {
            'CANONICAL_STORE_FSYNC_SCENARIO': scenario,
            'CANONICAL_STORE_EXPECT_FSYNC_ERROR': 'directory',
        },
        'returncode': result.returncode,
        'binary_sha256': EXPECTED_BINARY,
        'injected': injected[0],
        'successful_renames': successful_renames,
        'witness': wanted,
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
        'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
    })
    print(json.dumps(rows[-1]), flush=True)
(HERE / 'later-barrier-results.json').write_text(json.dumps(rows, indent=2) + '\n')
