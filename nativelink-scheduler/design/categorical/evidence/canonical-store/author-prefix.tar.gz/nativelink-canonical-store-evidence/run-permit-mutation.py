#!/usr/bin/env python3
"""Compile one intentionally invalid permit lifetime, then restore and recheck."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

worktree = Path('/tmp/nativelink-canonical-store')
root = Path(__file__).resolve().parent
out = root / 'permit-mutation'
out.mkdir(exist_ok=True)
source = worktree / 'tools/canonical-store/src/lib.rs'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == 'ab8c56587d1e7ddda9d5248dc441c3e8172933df2fba9d8937a5e3716bd895bf'
(out / 'original-lib.rs').write_bytes(original)
needle = b'        for chunk in verified.bytes.chunks(IO_BUFFER_BYTES) {'
assert original.count(needle) == 1
mutant = original.replace(needle, b'        drop(permit); // Deliberate invalid lifetime mutation.\n' + needle)
mutant = mutant.replace(b'        drop(verified);\n        drop(permit);', b'        drop(verified);')
(out / 'mutant-lib.rs').write_bytes(mutant)
(out / 'tests.rs').write_bytes((worktree / 'tools/canonical-store/src/tests.rs').read_bytes())
env = os.environ.copy()
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_TARGET_DIR'] = '/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
base = ['cargo', 'test', '--manifest-path', 'tools/canonical-store/Cargo.toml', '--locked', '--offline', '--profile', 'smol', '-j8', '--lib']
commands = []
try:
    source.write_bytes(mutant)
    cmd = base + ['tests::independent_held_reads_share_admission_and_retain_each_root_until_cancelled', '--', '--exact']
    run = subprocess.run(cmd, cwd=worktree, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180, check=False)
    (out / 'mutant.log').write_text(run.stdout)
    commands.append({'phase': 'mutant', 'command': cmd, 'returncode': run.returncode})
    binary = re.search(r'Running unittests src/lib.rs \(([^)]+)\)', run.stdout).group(1)
    shutil.copy2(binary, out / 'mutant-test-binary')
    assert run.returncode == 101 and 'an `Ok` value: Some(524288)' in run.stdout, run.stdout
finally:
    source.write_bytes(original)
assert source.read_bytes() == original
run = subprocess.run(base, cwd=worktree, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180, check=False)
(out / 'restored.log').write_text(run.stdout)
commands.append({'phase': 'restored', 'command': base, 'returncode': run.returncode})
assert run.returncode == 0 and '17 passed' in run.stdout, run.stdout
binary = re.search(r'Running unittests src/lib.rs \(([^)]+)\)', run.stdout).group(1)
final = root / 'final'
final.mkdir(exist_ok=True)
shutil.copy2(binary, final / 'canonical_store_test')
(out / 'results.json').write_text(json.dumps(commands, indent=2) + '\n')
print(json.dumps(commands, indent=2))
