// Independent cancellation witness written after reading the frozen adapter.
// Append to canonical-store/src/tests.rs; uses its existing test fixture only.
#[nativelink_macro::nativelink_test]
async fn independent_held_reads_share_admission_and_retain_each_root_until_cancelled() {
    let (fixture, stores) = Fixture::new().await;
    let payload = Bytes::from(vec![0x6d; IO_BUFFER_BYTES * 8]);
    let key = digest(DigestHasherFunc::Sha256, &payload);
    pin(&stores.cas)
        .update_oneshot(key.into(), payload.clone())
        .await
        .unwrap();
    pin(&stores.sink)
        .update_oneshot(key.into(), payload.clone())
        .await
        .unwrap();

    let mut tasks = Vec::new();
    let mut readers = Vec::new();
    for index in 0..MAX_ACTIVE_OPERATIONS {
        let store: Arc<dyn StoreDriver> = if index % 2 == 0 {
            stores.cas.clone()
        } else {
            stores.sink.clone()
        };
        let (mut writer, mut reader) = make_buf_channel_pair();
        let mut task = spawn!("independent_held_read", async move {
            Pin::new(store.as_ref())
                .get_part(key.into(), &mut writer, 0, None)
                .await
        });
        // Receiving a first chunk witnesses completion of whole-object
        // verification. Eight chunks cannot fit the two-element output queue,
        // even after this single receive, so these reads remain in output.
        let first = timeout(Duration::from_secs(5), reader.recv())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(first.as_ref(), &payload[..IO_BUFFER_BYTES]);
        assert!(timeout(Duration::from_millis(20), &mut task).await.is_err());
        tasks.push(task);
        readers.push(reader);
    }
    assert_eq!(
        pin(&stores.cas).has(key.into()).await.unwrap_err().code,
        Code::ResourceExhausted,
        "held CAS and sink outputs consume the same four-operation admission"
    );

    drop(tasks.pop().unwrap());
    timeout(Duration::from_secs(5), async {
        loop {
            match pin(&stores.cas).has(key.into()).await {
                Ok(size) => {
                    assert_eq!(size, Some(payload.len() as u64));
                    break;
                }
                Err(error) => assert_eq!(error.code, Code::ResourceExhausted),
            }
            tokio::task::yield_now().await;
        }
    })
    .await
    .unwrap();

    let probes = [
        &fixture.manifest.authority.journal_root,
        &fixture.manifest.cas.root,
        &fixture.manifest.temporary_action_cache.root,
        &fixture.manifest.worker.root,
    ]
    .map(|path| fs::File::open(path).unwrap());
    drop(stores);
    for file in &probes {
        assert!(
            matches!(file.try_lock(), Err(fs::TryLockError::WouldBlock)),
            "a pending output retains each namespace lock independently"
        );
    }
    drop(tasks);
    drop(readers);
    timeout(Duration::from_secs(5), async {
        for file in &probes {
            loop {
                match file.try_lock() {
                    Ok(()) => break,
                    Err(fs::TryLockError::WouldBlock) => tokio::task::yield_now().await,
                    Err(error) => panic!("unexpected namespace lock error: {error:?}"),
                }
            }
        }
    })
    .await
    .unwrap();
    drop(probes);
    assert!(Ownership::reopen(&fixture.manifest).is_ok());
}
