#!/usr/bin/env python3
"""Run actual fsync EIO through frozen RPC test binary; never recompiles."""
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
out = root / 'final/syscalls'
out.mkdir(exist_ok=True)
binary = root / 'final/canonical_store_test'
cases = [
    ('upload-baseline', 'upload', None, None),
    ('upload-file-eio', 'upload', 9, 'file'),
    ('upload-directory-eio', 'upload', 10, 'directory'),
    ('has-baseline', 'has', None, None),
    ('has-file-eio', 'has', 13, 'file'),
    ('has-directory-eio', 'has', 14, 'directory'),
    ('duplicate-baseline', 'duplicate', None, None),
    ('duplicate-file-eio', 'duplicate', 14, 'file'),
    ('duplicate-directory-eio', 'duplicate', 15, 'directory'),
    ('upload-content-eio', 'upload', 11, 'directory'),
    ('upload-executable-eio', 'upload', 12, 'directory'),
    ('has-content-eio', 'has', 15, 'directory'),
    ('has-executable-eio', 'has', 16, 'directory'),
    ('duplicate-content-eio', 'duplicate', 16, 'directory'),
    ('duplicate-executable-eio', 'duplicate', 17, 'directory'),
]
results = []
for name, scenario, occurrence, failure in cases:
    trace = out / f'{name}.strace'
    cmd = ['/run/current-system/sw/bin/strace', '-f', '-yy', '-e', 'trace=fsync,renameat,renameat2', '-o', str(trace)]
    if occurrence:
        cmd += ['-e', f'inject=fsync:error=EIO:when={occurrence}']
    cmd += [str(binary), '--exact', 'tests::rpc::syscall_fsync_rpc_witness', '--nocapture', '--test-threads=1']
    env = os.environ.copy()
    env['CANONICAL_STORE_FSYNC_SCENARIO'] = scenario
    env.pop('CANONICAL_STORE_EXPECT_FSYNC_ERROR', None)
    if failure:
        env['CANONICAL_STORE_EXPECT_FSYNC_ERROR'] = failure
    run = subprocess.run(cmd, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30, check=False)
    (out / f'{name}.log').write_text(run.stdout)
    lines = trace.read_text().splitlines()
    injected = [line for line in lines if '(INJECTED)' in line]
    assert run.returncode == 0, (name, run.stdout)
    assert len(injected) == (1 if occurrence else 0), (name, injected)
    if failure == 'directory':
        expected_path = '/cas/content.exec>' if 'executable' in name else ('/cas/content>' if 'content' in name else '/cas/temp>')
        assert expected_path in injected[0], (name, injected)
    elif scenario == 'upload' and failure:
        assert '/cas/temp/pending-' in injected[0], (name, injected)
    elif failure:
        assert '/cas/content/sha256-' in injected[0], (name, injected)
    receipt = {'name': name, 'scenario': scenario, 'injected_per_thread_fsync_number': occurrence,
               'command': cmd, 'returncode': run.returncode, 'injected': injected,
               'witness': [line for line in run.stdout.splitlines() if 'syscall witness:' in line]}
    results.append(receipt)
    print(json.dumps(receipt), flush=True)
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
