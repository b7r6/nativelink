// Copyright 2024-2025 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use core::ops::RangeBounds;
use core::pin::Pin;
use core::time::Duration;
use std::collections::HashMap;
use std::sync::Arc;

use bytes::{Bytes, BytesMut};
use futures::TryStreamExt;
use nativelink_config::stores::{ExistenceCacheSpec, RedisMode, RedisSpec, StoreSpec};
use nativelink_error::{Code, Error, ErrorContext, ResultExt, make_err};
use nativelink_macro::nativelink_test;
use nativelink_redis_tester::{
    ReadOnlyRedis, SubscriptionManagerNotify, add_lua_script, add_to_response, add_to_response_raw,
    fake_redis_sentinel_master_stream, fake_redis_sentinel_stream, fake_redis_stream,
    make_fake_redis_with_responses,
};
use nativelink_store::cas_utils::ZERO_BYTE_DIGESTS;
use nativelink_store::existence_cache_store::ExistenceCacheStore;
use nativelink_store::redis_store::{
    ClusterRedisManager, DEFAULT_MAX_CHUNK_UPLOADS_PER_UPDATE, DEFAULT_MAX_COUNT_PER_CURSOR,
    LUA_VERSION_SET_SCRIPT, RedisStore, RedisSubscriptionManager, decode_key,
};
use nativelink_util::buf_channel::make_buf_channel_pair;
use nativelink_util::common::DigestInfo;
use nativelink_util::health_utils::HealthStatus;
use nativelink_util::store_trait::{
    FalseValue, RemoveItemCallback, SchedulerCurrentVersionProvider, SchedulerIndexProvider,
    SchedulerStore, SchedulerStoreDataProvider, SchedulerStoreDecodeTo, SchedulerStoreKeyProvider,
    SchedulerSubscription, SchedulerSubscriptionManager, Store, StoreDriver, StoreKey, StoreLike,
    TrueValue, UploadSizeInfo,
};
use pretty_assertions::assert_eq;
use redis::{PushInfo, RedisError, Value, make_extension_error};
use redis_test::{MockCmd, MockRedisConnection};
use tokio::sync::mpsc::UnboundedReceiver;
use tokio::time::{sleep, timeout};
use tracing::{Instrument, info, info_span};

const VALID_HASH1: &str = "3031323334353637383961626364656630303030303030303030303030303030";
const TEMP_UUID: &str = "550e8400-e29b-41d4-a716-446655440000";

const DEFAULT_READ_CHUNK_SIZE: usize = 1024;
const DEFAULT_SCAN_COUNT: usize = 10_000;
const DEFAULT_MAX_PERMITS: usize = 100;

fn mock_uuid_generator() -> String {
    uuid::Uuid::parse_str(TEMP_UUID).unwrap().to_string()
}

fn make_temp_key(final_name: &str) -> String {
    format!("temp-{TEMP_UUID}-{{{final_name}}}")
}

/// What `FT.INFO` says while the index created a moment ago is still
/// scanning existing keys (`indexing 1`) and once it is done (`0`).
fn make_ft_info(index: &str, indexing: i64) -> MockCmd {
    MockCmd::new(
        redis::cmd("FT.INFO").arg(index),
        Ok(Value::Array(vec![
            Value::BulkString(b"num_docs".to_vec()),
            Value::Int(3),
            Value::BulkString(b"indexing".to_vec()),
            Value::Int(indexing),
        ])),
    )
}

async fn make_mock_store(
    commands: Vec<MockCmd>,
) -> RedisStore<MockRedisConnection, ClusterRedisManager<MockRedisConnection>> {
    make_mock_store_with_prefix(commands, String::new()).await
}

const FAKE_SCRIPT_SHA: &str = "d89e3573a1f9689c22115e8a41bd332d0c7c2643";

fn add_lua_version_script(mut responses: HashMap<String, String>) -> HashMap<String, String> {
    add_lua_script(&mut responses, LUA_VERSION_SET_SCRIPT, FAKE_SCRIPT_SHA);
    responses
}

async fn make_fake_redis() -> u16 {
    make_fake_redis_with_responses(add_lua_version_script(fake_redis_stream())).await
}

async fn fake_redis_sentinel_master_stream_with_script() -> u16 {
    make_fake_redis_with_responses(add_lua_version_script(fake_redis_sentinel_master_stream()))
        .await
}

async fn make_mock_store_with_prefix_and_subscriber_channel(
    mut commands: Vec<MockCmd>,
    key_prefix: String,
    key_ttl: Option<Duration>,
    subscriber_channel: UnboundedReceiver<PushInfo>,
) -> RedisStore<MockRedisConnection, ClusterRedisManager<MockRedisConnection>> {
    commands.insert(
        0,
        MockCmd::new(
            redis::cmd("SCRIPT").arg("LOAD").arg(LUA_VERSION_SET_SCRIPT),
            Ok(FAKE_SCRIPT_SHA),
        ),
    );
    let mock_connection = MockRedisConnection::new(commands);
    let manager = ClusterRedisManager::new(mock_connection).await.unwrap();
    RedisStore::new_from_builder_and_parts(
        None,
        mock_uuid_generator,
        key_prefix,
        DEFAULT_READ_CHUNK_SIZE,
        DEFAULT_MAX_CHUNK_UPLOADS_PER_UPDATE,
        DEFAULT_SCAN_COUNT,
        DEFAULT_MAX_PERMITS,
        DEFAULT_MAX_COUNT_PER_CURSOR,
        Duration::from_secs(4),
        key_ttl,
        subscriber_channel,
        manager,
    )
    .await
    .unwrap()
}

async fn make_mock_store_with_ttl(
    commands: Vec<MockCmd>,
    key_ttl: Duration,
) -> RedisStore<MockRedisConnection, ClusterRedisManager<MockRedisConnection>> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    make_mock_store_with_prefix_and_subscriber_channel(commands, String::new(), Some(key_ttl), rx)
        .await
}

async fn make_mock_store_with_prefix(
    commands: Vec<MockCmd>,
    key_prefix: String,
) -> RedisStore<MockRedisConnection, ClusterRedisManager<MockRedisConnection>> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    make_mock_store_with_prefix_and_subscriber_channel(commands, key_prefix, None, rx).await
}

#[nativelink_test]
async fn upload_and_get_data() -> Result<(), Error> {
    // Construct the data we want to send. Since it's small, we expect it to be sent in a single chunk.
    let data = Bytes::from_static(b"14");

    // Construct a digest for our data and create a key based on that digest.
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");

    // Construct our Redis store with a mocked out backend.
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        // The first set of commands are for setting the data.
        // Append the real value to the temp key.
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(&temp_key)
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(&temp_key),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        // Move the data from the fake key to the real key.
        MockCmd::new(
            redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
            Ok(Value::Nil),
        ),
        // The second set of commands are for retrieving the data from the key.
        // Check that the key exists.
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(&real_key)
                .cmd("EXISTS")
                .arg(&real_key),
            Ok(vec![Value::Int(2), Value::Boolean(true)]),
        ),
        // Retrieve the data from the real key.
        MockCmd::new(
            redis::cmd("GETRANGE").arg(real_key).arg(0).arg(1),
            Ok(Value::BulkString(b"14".to_vec())),
        ),
    ];

    let store = make_mock_store(commands).await;

    store.update_oneshot(digest, data.clone()).await.unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    let result = store
        .get_part_unchunked(digest, 0, Some(data.len() as u64))
        .await
        .unwrap();

    assert_eq!(result, data, "Expected redis store to have updated value",);

    Ok(())
}

// Regression test for Redis-replica/failover handling in RedisStore::update.
// If the post-write STRLEN reads 0 (the connection points at a node that doesn't
// yet have the freshly written temp key — e.g. a failover moved the master, or
// brief replica lag), update must re-resolve the master and retry rather than
// failing the write with a "Data length mismatch" error.
#[nativelink_test]
async fn update_retries_after_transient_zero_length() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        // First verify hits a stale/replica connection that can't see the temp key.
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(0)),
        ),
        // After re-resolving the master, the retry sees the real length.
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(temp_key).arg(real_key),
            Ok(Value::Nil),
        ),
    ];

    let store = make_mock_store(commands).await;
    // Must succeed despite the transient zero-length read.
    store.update_oneshot(digest, data).await?;
    Ok(())
}

// If the value never becomes visible (genuine loss / persistent failure), update
// still errors after exhausting its retries rather than hanging.
#[nativelink_test]
async fn update_errors_when_length_never_matches() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);

    let mut commands = vec![MockCmd::new(
        redis::cmd("SETRANGE")
            .arg(temp_key.clone())
            .arg(0)
            .arg(data.to_vec()),
        Ok(Value::Int(0)),
    )];
    // MAX_REDIS_RETRY_ATTEMPTS (5) STRLEN reads that all return 0.
    for _ in 0..5 {
        commands.push(MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(0)),
        ));
    }

    let store = make_mock_store(commands).await;
    let result = store.update_oneshot(digest, data).await;
    assert!(
        result.is_err(),
        "expected a Data length mismatch error after exhausting retries",
    );
    Ok(())
}

// The read paths must ride out a transient Redis error (e.g. a connection
// dropped by a failover) by re-resolving the master and retrying, rather than
// surfacing the transient error. has() exercises the read-path retry.
#[nativelink_test]
async fn has_retries_after_transient_error() -> Result<(), Error> {
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let key = format!("{digest}");

    let commands = vec![
        // First existence pipeline fails with a retryable connection error.
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(key.clone())
                .cmd("EXISTS")
                .arg(key.clone()),
            Err::<Vec<Value>, _>(RedisError::from(std::io::Error::new(
                std::io::ErrorKind::ConnectionReset,
                "transient",
            ))),
        ),
        // The retry (after re-resolving the master) succeeds.
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(key.clone())
                .cmd("EXISTS")
                .arg(key.clone()),
            Ok(vec![Value::Int(2), Value::Boolean(true)]),
        ),
    ];

    let store = make_mock_store(commands).await;
    let result = store.has(digest).await?;
    assert_eq!(
        result,
        Some(2),
        "has should recover from the transient error"
    );
    Ok(())
}

// The write path must also ride out a transient Redis error (e.g. a connection
// dropped by a Sentinel failover) by re-resolving the master and retrying the
// chunk write, rather than hard-failing the upload. Previously the chunk write
// only retried a ReadOnly reply (a demoted replica), so a dropped connection —
// the more common failover symptom — failed the upload and dropped the data.
#[nativelink_test]
async fn update_retries_after_transient_write_error() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        // First chunk write fails with a retryable connection error.
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data.to_vec()),
            Err::<Value, _>(RedisError::from(std::io::Error::new(
                std::io::ErrorKind::ConnectionReset,
                "transient",
            ))),
        ),
        // After re-resolving the master, the retried chunk write succeeds.
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(temp_key).arg(real_key),
            Ok(Value::Nil),
        ),
    ];

    let store = make_mock_store(commands).await;
    // Must succeed despite the transient write error.
    store.update_oneshot(digest, data).await?;
    Ok(())
}

#[nativelink_test]
async fn upload_and_get_data_with_prefix() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");

    let prefix = "TEST_PREFIX-";

    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{prefix}{digest}");

    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data.clone().to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(temp_key).arg(real_key.clone()),
            Ok(Value::Nil),
        ),
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(real_key.clone())
                .cmd("EXISTS")
                .arg(real_key.clone()),
            Ok(vec![Value::Int(2), Value::Boolean(true)]),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE").arg(real_key).arg(0).arg(1),
            Ok(Value::BulkString(b"14".to_vec())),
        ),
    ];

    let store = make_mock_store_with_prefix(commands, prefix.to_string()).await;

    store.update_oneshot(digest, data.clone()).await.unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    let result = store
        .get_part_unchunked(digest, 0, Some(data.len() as u64))
        .await
        .unwrap();

    assert_eq!(result, data, "Expected redis store to have updated value",);

    Ok(())
}

#[nativelink_test]
async fn upload_empty_data() -> Result<(), Error> {
    let data = Bytes::from_static(b"");
    let digest = ZERO_BYTE_DIGESTS[0];

    let commands = vec![];
    let store = make_mock_store(commands).await;
    store.update_oneshot(digest, data).await.unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    Ok(())
}

#[nativelink_test]
async fn upload_empty_data_with_prefix() -> Result<(), Error> {
    let data = Bytes::from_static(b"");
    let digest = ZERO_BYTE_DIGESTS[0];
    let prefix = "TEST_PREFIX-";

    let commands = vec![];
    let store = make_mock_store_with_prefix(commands, prefix.to_string()).await;
    store.update_oneshot(digest, data).await.unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    Ok(())
}

#[nativelink_test]
async fn test_large_downloads_are_chunked() -> Result<(), Error> {
    const READ_CHUNK_SIZE: usize = 1024;
    let data = Bytes::from(vec![0u8; READ_CHUNK_SIZE + 128]);

    let digest = DigestInfo::try_new(VALID_HASH1, 1)?;
    let packed_hash_hex = format!("{digest}");

    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data.clone().to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(temp_key).arg(real_key.clone()),
            Ok(Value::Nil),
        ),
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(real_key.clone())
                .cmd("EXISTS")
                .arg(real_key.clone()),
            Ok(vec![
                Value::Int(data.len().try_into().unwrap()),
                Value::Int(1),
            ]),
        ),
        MockCmd::new(
            // We expect to be asked for data from `0..READ_CHUNK_SIZE`, but since GETRANGE is inclusive
            // the actual call should be from `0..=(READ_CHUNK_SIZE - 1)`.
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg(READ_CHUNK_SIZE.try_into().unwrap_or(i64::MAX) - 1),
            Ok(Value::BulkString(data.slice(..READ_CHUNK_SIZE).into())),
        ),
        MockCmd::new(
            // Similar GETRANGE index shenanigans here.
            redis::cmd("GETRANGE")
                .arg(real_key)
                .arg(READ_CHUNK_SIZE.try_into().unwrap_or(i64::MAX))
                .arg(data.len().try_into().unwrap_or(i64::MAX) - 1),
            Ok(Value::BulkString(data.slice(READ_CHUNK_SIZE..).into())),
        ),
    ];

    let store = make_mock_store(commands).await;

    store.update_oneshot(digest, data.clone()).await.unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    let get_result: Bytes = store
        .get_part_unchunked(digest, 0, Some(data.clone().len() as u64))
        .await
        .unwrap();

    assert_eq!(
        get_result, data,
        "Expected redis store to have updated value",
    );

    Ok(())
}

#[nativelink_test]
async fn yield_between_sending_packets_in_update() -> Result<(), Error> {
    let data_p1 = Bytes::from(vec![b'A'; DEFAULT_READ_CHUNK_SIZE + 512]);
    let data_p2 = Bytes::from(vec![b'B'; DEFAULT_READ_CHUNK_SIZE]);

    let mut data = BytesMut::new();
    data.extend_from_slice(&data_p1);
    data.extend_from_slice(&data_p2);
    let data = data.freeze();

    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");

    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let commands = vec![
        // We expect multiple `"SETRANGE"`s as we send data in multiple chunks
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(0)
                .arg(data_p1.clone().to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(temp_key.clone())
                .arg(data_p1.len())
                .arg(data_p2.clone().to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(temp_key.clone()),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(temp_key).arg(real_key.clone()),
            Ok(Value::Nil),
        ),
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(real_key.clone())
                .cmd("EXISTS")
                .arg(real_key.clone()),
            Ok(vec![Value::Int(2), Value::Int(1)]),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg((DEFAULT_READ_CHUNK_SIZE - 1).try_into().unwrap_or(i64::MAX)),
            Ok(Value::BulkString(data.clone().to_vec())),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(DEFAULT_READ_CHUNK_SIZE.try_into().unwrap_or(i64::MAX))
                .arg(
                    (DEFAULT_READ_CHUNK_SIZE * 2 - 1)
                        .try_into()
                        .unwrap_or(i64::MAX),
                ),
            Ok(Value::BulkString(data.clone().to_vec())),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key)
                .arg((DEFAULT_READ_CHUNK_SIZE * 2).try_into().unwrap_or(i64::MAX))
                .arg(
                    (data_p1.len() + data_p2.len() - 1)
                        .try_into()
                        .unwrap_or(i64::MAX),
                ),
            Ok(Value::BulkString(data.clone().to_vec())),
        ),
    ];

    let store = make_mock_store(commands).await;

    let (mut tx, rx) = make_buf_channel_pair();

    tokio::try_join!(
        async {
            store
                .update(digest, rx, UploadSizeInfo::ExactSize(data.len() as u64))
                .await
                .unwrap();

            Ok::<_, Error>(())
        },
        async {
            tx.send(data_p1).await.unwrap();
            tx.send(data_p2).await.unwrap();
            tx.send_eof().unwrap();
            Ok::<_, Error>(())
        },
    )
    .unwrap();

    let result = store.has(digest).await.unwrap();
    assert!(
        result.is_some(),
        "Expected redis store to have hash: {VALID_HASH1}",
    );

    let result = store
        .get_part_unchunked(digest, 0, Some(data.clone().len() as u64))
        .await
        .unwrap();

    assert_eq!(result, data, "Expected redis store to have updated value",);

    Ok(())
}

// Regression test for: https://github.com/TraceMachina/nativelink/issues/1286
#[nativelink_test]
async fn zero_len_items_exist_check() -> Result<(), Error> {
    let digest = DigestInfo::try_new(VALID_HASH1, 0)?;
    let packed_hash_hex = format!("{digest}");
    let real_key = packed_hash_hex;

    let commands = vec![
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg(DEFAULT_READ_CHUNK_SIZE.try_into().unwrap_or(i64::MAX) - 1),
            Ok(Value::BulkString(vec![])),
        ),
        MockCmd::new(redis::cmd("EXISTS").arg(real_key), Ok(Value::Int(0))),
    ];

    let store = make_mock_store(commands).await;

    let result = store.get_part_unchunked(digest, 0, None).await;
    assert_eq!(
        result.as_ref().unwrap_err().code,
        Code::NotFound,
        "{result:?}"
    );

    Ok(())
}

// An existing key holding nothing under a digest that names bytes is what a
// failed upload left: the store reports it missing on both paths so the
// client uploads it again instead of reading it as DataLoss forever.
#[nativelink_test]
async fn an_empty_value_under_a_digest_is_missing() -> Result<(), Error> {
    let digest = DigestInfo::try_new(VALID_HASH1, 1024)?;
    let real_key = format!("{digest}");

    let commands = vec![
        MockCmd::with_values(
            redis::pipe()
                .cmd("STRLEN")
                .arg(real_key.clone())
                .cmd("EXISTS")
                .arg(real_key.clone()),
            Ok(vec![Value::Int(0), Value::Boolean(true)]),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg(DEFAULT_READ_CHUNK_SIZE.try_into().unwrap_or(i64::MAX) - 1),
            Ok(Value::BulkString(vec![])),
        ),
        MockCmd::new(redis::cmd("EXISTS").arg(real_key), Ok(Value::Int(1))),
    ];
    let store = make_mock_store(commands).await;

    assert_eq!(store.has(digest).await?, None);
    let result = store.get_part_unchunked(digest, 0, None).await;
    assert_eq!(
        result.as_ref().unwrap_err().code,
        Code::NotFound,
        "{result:?}"
    );
    Ok(())
}

// The key was evicted between two GETRANGEs: the second comes back empty,
// which is also what the end of a value on a chunk boundary looks like. The
// store asks STRLEN, sees the key is gone, and fails the read instead of
// ending it early.
#[nativelink_test]
async fn get_part_key_removed_between_chunks_is_not_found() -> Result<(), Error> {
    let digest = DigestInfo::try_new(VALID_HASH1, DEFAULT_READ_CHUNK_SIZE * 2)?;
    let real_key = format!("{digest}");
    let chunk_end = i64::try_from(DEFAULT_READ_CHUNK_SIZE).unwrap() - 1;

    let commands = vec![
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg(chunk_end),
            Ok(Value::BulkString(vec![b'a'; DEFAULT_READ_CHUNK_SIZE])),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(chunk_end + 1)
                .arg(chunk_end * 2 + 1),
            Ok(Value::BulkString(vec![])),
        ),
        MockCmd::new(redis::cmd("STRLEN").arg(real_key), Ok(Value::Int(0))),
    ];
    let store = make_mock_store(commands).await;

    let result = store.get_part_unchunked(digest, 0, None).await;
    assert_eq!(
        result.as_ref().unwrap_err().code,
        Code::NotFound,
        "{result:?}"
    );
    Ok(())
}

// A value that ends exactly on a chunk boundary: the empty GETRANGE is the
// real end, STRLEN agrees, and the read completes with every byte.
#[nativelink_test]
async fn get_part_value_ending_on_a_chunk_boundary_reads_whole() -> Result<(), Error> {
    let digest = DigestInfo::try_new(VALID_HASH1, DEFAULT_READ_CHUNK_SIZE)?;
    let real_key = format!("{digest}");
    let chunk_end = i64::try_from(DEFAULT_READ_CHUNK_SIZE).unwrap() - 1;

    let commands = vec![
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(0)
                .arg(chunk_end),
            Ok(Value::BulkString(vec![b'a'; DEFAULT_READ_CHUNK_SIZE])),
        ),
        MockCmd::new(
            redis::cmd("GETRANGE")
                .arg(real_key.clone())
                .arg(chunk_end + 1)
                .arg(chunk_end * 2 + 1),
            Ok(Value::BulkString(vec![])),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(real_key),
            Ok(Value::Int(i64::try_from(DEFAULT_READ_CHUNK_SIZE).unwrap())),
        ),
    ];
    let store = make_mock_store(commands).await;

    let result = store.get_part_unchunked(digest, 0, None).await?;
    assert_eq!(result.len(), DEFAULT_READ_CHUNK_SIZE);
    Ok(())
}

#[nativelink_test]
async fn list_test() -> Result<(), Error> {
    async fn get_list(
        store: &RedisStore<MockRedisConnection, ClusterRedisManager<MockRedisConnection>>,
        range: impl RangeBounds<StoreKey<'static>> + Send + Sync + 'static,
    ) -> Vec<StoreKey<'static>> {
        let mut found_keys = vec![];
        store
            .list(range, |key| {
                found_keys.push(key.borrow().into_owned());
                true
            })
            .await
            .unwrap();
        found_keys
    }

    const KEY1: StoreKey = StoreKey::new_str("key1");
    const KEY2: StoreKey = StoreKey::new_str("key2");
    const KEY3: StoreKey = StoreKey::new_str("key3");

    #[allow(clippy::unnecessary_wraps)] // because that's what MockCmd wants
    fn result() -> Result<Value, RedisError> {
        Ok(Value::Array(vec![
            Value::BulkString(b"key1".to_vec()),
            Value::BulkString(b"key2".to_vec()),
            Value::BulkString(b"key3".to_vec()),
        ]))
    }

    fn command() -> MockCmd {
        MockCmd::new(
            redis::cmd("SCAN")
                .arg("0")
                .arg("MATCH")
                .arg("key*")
                .arg("COUNT")
                .arg(10000),
            result(),
        )
    }
    fn command_open() -> MockCmd {
        MockCmd::new(
            redis::cmd("SCAN")
                .arg("0")
                .arg("MATCH")
                .arg("*")
                .arg("COUNT")
                .arg(10000),
            result(),
        )
    }

    let commands = vec![
        command_open(),
        command_open(),
        command(),
        command(),
        command(),
        command_open(),
        command(),
        command(),
    ];

    let store = make_mock_store(commands).await;

    info!("Test listing all keys");
    let keys = get_list(&store, ..).await;
    assert_eq!(keys, vec![KEY1, KEY2, KEY3]);

    info!("Test listing from key1 to all");
    let keys = get_list(&store, KEY1..).await;
    assert_eq!(keys, vec![KEY1, KEY2, KEY3]);

    info!("Test listing from key1 to key2");
    let keys = get_list(&store, KEY1..KEY2).await;
    assert_eq!(keys, vec![KEY1]);

    info!("Test listing from key1 including key2");
    let keys = get_list(&store, KEY1..=KEY2).await;
    assert_eq!(keys, vec![KEY1, KEY2]);

    info!("Test listing from key1 to key3");
    let keys = get_list(&store, KEY1..KEY3).await;
    assert_eq!(keys, vec![KEY1, KEY2]);

    info!("Test listing from all to key2");
    let keys = get_list(&store, ..KEY2).await;
    assert_eq!(keys, vec![KEY1]);

    info!("Test listing from key2 to key3");
    let keys = get_list(&store, KEY2..KEY3).await;
    assert_eq!(keys, vec![KEY2]);

    info!("Test listing with reversed bounds");
    let keys = get_list(&store, KEY3..=KEY1).await;
    assert_eq!(keys, vec![]);

    Ok(())
}

// Prevent regressions to https://reviewable.io/reviews/TraceMachina/nativelink/1188#-O2pu9LV5ux4ILuT6MND
#[nativelink_test]
async fn dont_loop_forever_on_empty() -> Result<(), Error> {
    let commands = vec![];
    let store = make_mock_store(commands).await;
    let digest = DigestInfo::try_new(VALID_HASH1, 2).unwrap();
    let (tx, rx) = make_buf_channel_pair();

    tokio::join!(
        async {
            store
                .update(digest, rx, UploadSizeInfo::MaxSize(0))
                .await
                .unwrap_err();
        },
        async {
            drop(tx);
        },
    );

    Ok(())
}

#[nativelink_test]
async fn test_connection_errors() {
    // name is resolvable, but not connectable
    let spec = RedisSpec {
        addresses: vec!["redis://nativelink.com:6379/".to_string()],
        connection_timeout_ms: 1000,
        ..Default::default()
    };
    let err = RedisStore::new_standard(spec)
        .await
        .expect_err("Shouldn't have connected");
    assert_eq!(
        Error {
            code: Code::DeadlineExceeded,
            messages: vec![
                "Io: timed out".into(),
                "While connecting to redis with url: redis://nativelink.com:6379/".into()
            ],
            context: ErrorContext::None,
        },
        err
    );
}

#[nativelink_test]
async fn test_health() {
    let port = make_fake_redis().await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{port}/")],
        command_timeout_ms: 1000,
        ..Default::default()
    };
    let store = RedisStore::new_standard(spec).await.expect("Working spec");
    match store.check_health(std::borrow::Cow::Borrowed("foo")).await {
        HealthStatus::Ok {
            struct_name: _,
            message: _,
        } => {
            panic!("Expected failure");
        }
        HealthStatus::Failed {
            struct_name,
            message,
        } => {
            assert_eq!(
                struct_name,
                "nativelink_store::redis_store::RedisStore<redis::aio::connection_manager::ConnectionManager, nativelink_store::redis_store::StandardRedisManager<redis::aio::connection_manager::ConnectionManager>>"
            );
            // The write path treats a timeout as retryable (a failover symptom),
            // so it re-resolves the master and retries the chunk write once before
            // surfacing the error — hence the "(after reconnect)" prefix.
            assert!(
                message.starts_with("Store.update_oneshot() failed: Error { code: DeadlineExceeded, messages: [\"Io: timed out\", \"(after reconnect) while appending to temp key ("),
                "message: '{message}'"
            );
            logs_assert(|logs| {
                for log in logs {
                    if log.contains("check_health Store.update_oneshot() failed e=Error { code: DeadlineExceeded, messages: [\"Io: timed out\", \"(after reconnect) while appending to temp key (") {
                        return Ok(())
                    }
                }
                Err(format!("No check_health log! {logs:?}"))
            });
        }
        health_result => {
            panic!("Other result: {health_result:?}");
        }
    }
}

// After a Sentinel master failover the health PING hits a dead/old master and
// fails. check_health must re-resolve the master and PING again so a store with
// no other traffic self-heals — otherwise it reports unhealthy until restart and
// the readiness probe sheds traffic from an otherwise-recovered pod.
#[nativelink_test]
async fn check_health_recovers_after_failed_ping() {
    let commands = vec![
        // First PING hits the dead/old master.
        MockCmd::new(
            redis::cmd("PING"),
            Err::<Value, _>(RedisError::from(std::io::Error::new(
                std::io::ErrorKind::ConnectionReset,
                "connection reset by peer",
            ))),
        ),
        // After re-resolving the master, the PING succeeds.
        MockCmd::new(redis::cmd("PING"), Ok(Value::Okay)),
    ];
    let store = make_mock_store(commands).await;
    // The readiness probe uses the HealthStatusIndicator impl (a PING), not the
    // StoreLike default (update_oneshot) that `store.check_health` resolves to.
    let health = nativelink_util::health_utils::HealthStatusIndicator::check_health(
        &store,
        std::borrow::Cow::Borrowed("foo"),
    )
    .await;
    assert!(
        matches!(health, HealthStatus::Ok { .. }),
        "expected Ok after re-resolving the master on a failed PING, got: {health:?}",
    );
}

#[nativelink_test]
async fn test_deprecated_broadcast_channel_capacity() {
    let port = make_fake_redis().await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{port}/")],
        broadcast_channel_capacity: 1,
        ..Default::default()
    };
    RedisStore::new_standard(spec).await.expect("Working spec");

    assert!(logs_contain(
        "broadcast_channel_capacity in Redis spec is deprecated and ignored"
    ));
}

#[nativelink_test]
async fn test_sentinel_connect() {
    let redis_span = info_span!("redis");
    let redis_port = fake_redis_sentinel_master_stream_with_script()
        .instrument(redis_span)
        .await;
    let sentinel_span = info_span!("sentinel");
    let sentinel_port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("master", redis_port))
            .instrument(sentinel_span)
            .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{sentinel_port}/")],
        mode: RedisMode::Sentinel,
        ..Default::default()
    };
    RedisStore::new_standard(spec).await.expect("Working spec");
}

#[nativelink_test]
async fn test_sentinel_connect_with_bad_master() {
    // Note this is a fake redis port, which is fine because the sentinel code never connects to it
    let port = make_fake_redis_with_responses(fake_redis_sentinel_stream("other_name", 1234)).await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{port}/")],
        mode: RedisMode::Sentinel,
        connection_timeout_ms: 100,
        ..Default::default()
    };
    // Unavailable, not InvalidArgument: an unknown master name is
    // indistinguishable from a sentinel failover in progress, and the two
    // must not be told apart by guessing. A genuinely wrong name keeps
    // failing and stays visible; a failover recovers on retry. Classifying
    // this as permanent meant a routine failover killed in-flight builds.
    assert_eq!(
        Error {
            code: Code::Unavailable,
            messages: vec![
                "MasterNameNotFoundBySentinel: Master with given name not found in sentinel - MasterNameNotFoundBySentinel".into(),
                format!("While connecting to redis with url: redis+sentinel://127.0.0.1:{port}/")
            ],
            context: ErrorContext::None,
        },
        RedisStore::new_standard(spec).await.unwrap_err()
    );
}

#[nativelink_test]
async fn test_sentinel_connect_and_update_oneshot_readonly() {
    let redis_span = info_span!("redis");

    let redis_port = ReadOnlyRedis::new().run().instrument(redis_span).await;
    let sentinel_span = info_span!("sentinel");
    let sentinel_port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("master", redis_port))
            .instrument(sentinel_span)
            .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{sentinel_port}/")],
        mode: RedisMode::Sentinel,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    store
        .update_oneshot("abcd", Bytes::from_static(b"hello"))
        .await
        .expect("working update");
}

#[nativelink_test]
async fn test_sentinel_connect_and_update_data_unversioned_readonly() {
    let redis_span = info_span!("redis");

    let redis_port = ReadOnlyRedis::new().run().instrument(redis_span).await;
    let sentinel_span = info_span!("sentinel");
    let sentinel_port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("master", redis_port))
            .instrument(sentinel_span)
            .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{sentinel_port}/")],
        mode: RedisMode::Sentinel,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    let data = TestSchedulerDataUnversioned {
        key: "test:scheduler_key_1".to_string(),
        content: "Test scheduler data #1".to_string(),
        version: 0,
    };
    store
        .update_data(data, Some(Duration::from_mins(1)))
        .await
        .expect("working update");
}

#[nativelink_test]
async fn test_sentinel_connect_and_update_data_versioned_readonly() {
    let redis_span = info_span!("redis");

    let redis_port = ReadOnlyRedis::new().run().instrument(redis_span).await;
    let sentinel_span = info_span!("sentinel");
    let sentinel_port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("master", redis_port))
            .instrument(sentinel_span)
            .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{sentinel_port}/")],
        mode: RedisMode::Sentinel,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    let data = TestSchedulerDataVersioned {
        key: "test:scheduler_key_1".to_string(),
        content: "Test scheduler data #1".to_string(),
        version: 0,
    };
    store.update_data(data, None).await.expect("working update");
}

#[nativelink_test]
async fn test_sentinel_connect_with_url_specified_master() {
    let redis_port = fake_redis_sentinel_master_stream_with_script()
        .instrument(info_span!("redis"))
        .await;
    let port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("specific_master", redis_port))
            .instrument(info_span!("sentinel"))
            .await;
    let spec = RedisSpec {
        addresses: vec![format!(
            "redis+sentinel://127.0.0.1:{port}/?sentinelServiceName=specific_master"
        )],
        mode: RedisMode::Sentinel,
        // This test asserts that the sentinelServiceName URL parameter
        // resolves, not that it resolves quickly. 100ms — copied from the
        // fail-fast bad-master test above, where a tight budget is the point —
        // has to cover two TCP connects and two handshakes plus SENTINEL
        // MASTERS in between, which a loaded macOS CI runner does not manage.
        // Every other success-path test here allows 1s or more.
        connection_timeout_ms: 5_000,
        ..Default::default()
    };
    RedisStore::new_standard(spec).await.expect("Working spec");
}

#[nativelink_test]
async fn test_redis_connect_timeout() {
    let port = make_fake_redis_with_responses(HashMap::new()).await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{port}/")],
        connection_timeout_ms: 1,
        ..Default::default()
    };
    assert_eq!(
        Error {
            code: Code::DeadlineExceeded,
            messages: vec![
                "Io: timed out".into(),
                format!("While connecting to redis with url: redis://127.0.0.1:{port}/")
            ],
            context: ErrorContext::None,
        },
        RedisStore::new_standard(spec).await.unwrap_err()
    );
}

#[nativelink_test]
async fn test_connect_other_db() {
    let redis_port = make_fake_redis().await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{redis_port}/3")],
        ..Default::default()
    };
    RedisStore::new_standard(spec).await.expect("Working spec");
}

#[nativelink_test]
async fn test_sentinel_connect_other_db() {
    let redis_span = info_span!("redis");
    let redis_port = fake_redis_sentinel_master_stream_with_script()
        .instrument(redis_span)
        .await;
    let sentinel_span = info_span!("sentinel");
    let sentinel_port =
        make_fake_redis_with_responses(fake_redis_sentinel_stream("master", redis_port))
            .instrument(sentinel_span)
            .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis+sentinel://127.0.0.1:{sentinel_port}/3")],
        mode: RedisMode::Sentinel,
        connection_timeout_ms: 5_000,
        command_timeout_ms: 5_000,
        ..Default::default()
    };
    RedisStore::new_standard(spec).await.expect("Working spec");
}

struct SearchByContentPrefix {
    prefix: String,
}

// Define test structures that implement the scheduler traits
#[derive(Debug, Clone, PartialEq)]
struct TestSchedulerDataUnversioned {
    key: String,
    content: String,
    version: i64,
}

impl SchedulerStoreDecodeTo for TestSchedulerDataUnversioned {
    type DecodeOutput = Self;

    fn decode(version: i64, data: Bytes) -> Result<Self::DecodeOutput, Error> {
        let content = String::from_utf8(data.to_vec())
            .map_err(|e| make_err!(Code::InvalidArgument, "Invalid UTF-8 data: {e}"))?;
        // We don't have the key in the data, so we'll use a placeholder
        Ok(Self {
            key: "decoded".to_string(),
            content,
            version,
        })
    }
}

impl SchedulerStoreKeyProvider for TestSchedulerDataUnversioned {
    type Versioned = FalseValue; // Using unversioned storage

    fn get_key(&self) -> StoreKey<'static> {
        StoreKey::Str(std::borrow::Cow::Owned(self.key.clone()))
    }
}

impl SchedulerStoreDataProvider for TestSchedulerDataUnversioned {
    fn try_into_bytes(self) -> Result<Bytes, Error> {
        Ok(Bytes::from(self.content))
    }

    fn get_indexes(&self) -> Result<Vec<(&'static str, Bytes)>, Error> {
        // Add some test indexes - need to use 'static strings
        Ok(vec![
            ("test_index", Bytes::from("test_value")),
            (
                "content_prefix",
                Bytes::from(self.content.chars().take(10).collect::<String>()),
            ),
        ])
    }
}

// Define test structures that implement the scheduler traits
#[derive(Debug, Clone, PartialEq)]
struct TestSchedulerDataVersioned {
    key: String,
    content: String,
    version: i64,
}

impl SchedulerStoreKeyProvider for TestSchedulerDataVersioned {
    type Versioned = TrueValue; // Using versioned storage

    fn get_key(&self) -> StoreKey<'static> {
        StoreKey::Str(std::borrow::Cow::Owned(self.key.clone()))
    }
}

impl SchedulerStoreDataProvider for TestSchedulerDataVersioned {
    fn try_into_bytes(self) -> Result<Bytes, Error> {
        Ok(Bytes::from(self.content.into_bytes()))
    }

    fn get_indexes(&self) -> Result<Vec<(&'static str, Bytes)>, Error> {
        // Add some test indexes - need to use 'static strings
        Ok(vec![
            ("test_index", Bytes::from("test_value")),
            (
                "content_prefix",
                Bytes::from(self.content.chars().take(10).collect::<String>()),
            ),
        ])
    }
}

impl SchedulerCurrentVersionProvider for TestSchedulerDataVersioned {
    fn current_version(&self) -> i64 {
        0
    }
}

struct TestSchedulerKey;

impl SchedulerStoreDecodeTo for TestSchedulerKey {
    type DecodeOutput = TestSchedulerDataUnversioned;

    fn decode(version: i64, data: Bytes) -> Result<Self::DecodeOutput, Error> {
        TestSchedulerDataUnversioned::decode(version, data)
    }
}

impl SchedulerIndexProvider for SearchByContentPrefix {
    const KEY_PREFIX: &'static str = "test:";
    const INDEX_NAME: &'static str = "content_prefix";
    type Versioned = TrueValue;

    const MAYBE_SORT_KEY: Option<&'static str> = Some("sort_key");

    fn index_value(&self) -> std::borrow::Cow<'_, str> {
        std::borrow::Cow::Borrowed(&self.prefix)
    }
}

impl SchedulerStoreKeyProvider for SearchByContentPrefix {
    type Versioned = TrueValue;

    fn get_key(&self) -> StoreKey<'static> {
        StoreKey::Str(std::borrow::Cow::Owned("dummy_key".to_string()))
    }
}

impl SchedulerStoreDecodeTo for SearchByContentPrefix {
    type DecodeOutput = TestSchedulerDataUnversioned;

    fn decode(version: i64, data: Bytes) -> Result<Self::DecodeOutput, Error> {
        TestSchedulerKey::decode(version, data)
    }
}

#[nativelink_test]
fn test_search_by_index() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Ok(Value::Array(vec![
                Value::Array(vec![
                    Value::Int(1),
                    Value::Array(vec![
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(b"1234".to_vec()),
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"1".to_vec()),
                    ]),
                ]),
                Value::Int(0),
            ])),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix__3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG"),
            Ok(Value::Nil),
        ),
        make_ft_info("test:_content_prefix__3e762c15", 0),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert!(search_results.len() == 1, "Should find 1 matching entry");

    assert_eq!(
        search_results[0].content, "1234",
        "Content should match search pattern: '{}'",
        search_results[0].content
    );

    Ok(())
}

/// A provider that reads its index descending, the way the scheduler's
/// awaited-action index does.
struct SearchByContentPrefixDesc {
    prefix: String,
}

impl SchedulerIndexProvider for SearchByContentPrefixDesc {
    const KEY_PREFIX: &'static str = "test:";
    const INDEX_NAME: &'static str = "content_prefix_desc";
    type Versioned = TrueValue;

    const MAYBE_SORT_KEY: Option<&'static str> = Some("sort_key");
    const SORT_DESCENDING: bool = true;

    fn index_value(&self) -> std::borrow::Cow<'_, str> {
        std::borrow::Cow::Borrowed(&self.prefix)
    }
}

impl SchedulerStoreDecodeTo for SearchByContentPrefixDesc {
    type DecodeOutput = TestSchedulerDataUnversioned;

    fn decode(version: i64, data: Bytes) -> Result<Self::DecodeOutput, Error> {
        TestSchedulerKey::decode(version, data)
    }
}

// The direction on the wire follows the provider. The scheduler's queue index
// is the descending one; serving it ascending is the bug that made the Redis
// backend dispatch lowest priority first, newest first.
#[nativelink_test]
fn test_search_by_index_descending() -> Result<(), Error> {
    let commands = vec![MockCmd::new(
        redis::cmd("FT.AGGREGATE")
            .arg("test:_content_prefix_desc_sort_key_3e762c15")
            .arg("@content_prefix_desc:{ Searchable }")
            .arg("TIMEOUT")
            .arg(10000_u64)
            .arg("LOAD")
            .arg(2)
            .arg("data")
            .arg("version")
            .arg("WITHCURSOR")
            .arg("COUNT")
            .arg(1500)
            .arg("MAXIDLE")
            .arg(30000)
            .arg("SORTBY")
            .arg(2usize)
            .arg("@sort_key")
            .arg("DESC")
            .arg("MAX")
            .arg(1_000_000_u64),
        Ok(Value::Array(vec![
            Value::Array(vec![
                Value::Int(1),
                Value::Array(vec![
                    Value::BulkString(b"data".to_vec()),
                    Value::BulkString(b"1234".to_vec()),
                    Value::BulkString(b"version".to_vec()),
                    Value::BulkString(b"1".to_vec()),
                ]),
            ]),
            Value::Int(0),
        ])),
    )];
    let store = make_mock_store(commands).await;

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(SearchByContentPrefixDesc {
            prefix: "Searchable".to_string(),
        })
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert_eq!(search_results.len(), 1);
    assert_eq!(search_results[0].content, "1234");
    Ok(())
}

// A Sentinel master failover surfaces on the scheduler's index query as a
// dropped connection / command timeout against the old master. The matching
// loop must re-resolve the master and retry rather than spinning on the dead
// handle until the CAS is restarted.
#[nativelink_test]
fn test_search_by_index_retries_on_failover() -> Result<(), Error> {
    fn make_ft_aggregate(result: Result<Value, RedisError>) -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            result,
        )
    }

    let commands = vec![
        // First query hits the dead/old master mid-failover.
        make_ft_aggregate(Err(RedisError::from(std::io::Error::new(
            std::io::ErrorKind::ConnectionReset,
            "connection reset by peer",
        )))),
        // After re-resolving the master, the retry succeeds.
        make_ft_aggregate(Ok(Value::Array(vec![
            Value::Array(vec![
                Value::Int(1),
                Value::Array(vec![
                    Value::BulkString(b"data".to_vec()),
                    Value::BulkString(b"1234".to_vec()),
                    Value::BulkString(b"version".to_vec()),
                    Value::BulkString(b"1".to_vec()),
                ]),
            ]),
            Value::Int(0),
        ]))),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "search should re-resolve the master and retry past the failover")?
        .try_collect()
        .await?;

    assert_eq!(
        search_results.len(),
        1,
        "Should find the entry after retrying on the re-resolved master",
    );
    assert_eq!(search_results[0].content, "1234");

    Ok(())
}

/// `RediSearch` matches documents in the search phase and reads their fields
/// in the load phase. A document that expires or is deleted between the two
/// comes back as a RESP3 row whose `extra_attributes` is Nil. That is routine
/// on a busy scheduler — completed awaited-action records expire constantly —
/// so the row must drop out of the results rather than fail the whole
/// aggregate. Failing it reached clients as `INVALID_ARGUMENT`, which Bazel
/// treats as permanent, so one expiry race ended the build.
#[nativelink_test]
fn test_search_by_index_skips_docs_that_expired_mid_query() -> Result<(), Error> {
    fn loaded_row(content: &str) -> Value {
        Value::Map(vec![
            (
                Value::SimpleString("extra_attributes".into()),
                Value::Map(vec![
                    (
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(content.as_bytes().to_vec()),
                    ),
                    (
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"1".to_vec()),
                    ),
                ]),
            ),
            (Value::SimpleString("values".into()), Value::Array(vec![])),
        ])
    }

    fn expired_row() -> Value {
        Value::Map(vec![
            (Value::SimpleString("extra_attributes".into()), Value::Nil),
            (Value::SimpleString("values".into()), Value::Array(vec![])),
        ])
    }

    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            // A page whose middle document expired between match and load.
            Ok(Value::Array(vec![
                Value::Map(vec![
                    (
                        Value::SimpleString("attributes".into()),
                        Value::Array(vec![]),
                    ),
                    (
                        Value::SimpleString("format".into()),
                        Value::SimpleString("STRING".into()),
                    ),
                    (
                        Value::SimpleString("results".into()),
                        Value::Array(vec![loaded_row("1234"), expired_row(), loaded_row("5678")]),
                    ),
                ]),
                Value::Int(0),
            ])),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix__3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG"),
            Ok(Value::Nil),
        ),
        // The index is still backfilling on the first ask and ready on the
        // second; the read waits for the second.
        make_ft_info("test:_content_prefix__3e762c15", 1),
        make_ft_info("test:_content_prefix__3e762c15", 0),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "The expired row must not fail the aggregate")?
        .try_collect()
        .await?;

    // Only the two surviving documents come back; the expired one contributes
    // nothing rather than taking the other two down with it.
    assert_eq!(search_results.len(), 2, "Should skip only the expired row");
    assert_eq!(search_results[0].content, "1234");
    assert_eq!(search_results[1].content, "5678");

    Ok(())
}

#[nativelink_test]
fn test_search_by_index_failure() -> Result<(), Error> {
    let store = make_mock_store(vec![]).await;
    let search_provider = SearchByContentPrefix {
        prefix: String::new(),
    };

    // Can't use unwrap_err as that needs Debug which this error doesn't provide
    let Err(error) = store.search_by_index_prefix(search_provider).await else {
        panic!("Expected an error");
    };

    assert_eq!(error, Error::new_with_messages(Code::Unknown, [
        "Client: TEST - Client: unexpected command", "Error with ft_create in RedisStore::search_by_index_prefix(test:_content_prefix_sort_key_3e762c15)", "---", "Client: TEST - Client: unexpected command", "Error with second ft_aggregate in RedisStore::search_by_index_prefix(test:_content_prefix_sort_key_3e762c15)"].iter().map(ToString::to_string).collect()));

    assert!(logs_contain(
        "Error calling ft.aggregate e=TEST - Client: unexpected command index=\"test:_content_prefix_sort_key_3e762c15\" query=\"*\" options=FtAggregateOptions { load: [\"data\", \"version\"], cursor: FtAggregateCursor { count: 1500, max_idle: 30000 }, sort_by: [\"@sort_key\"], sort_desc: false } all_args=[\"FT.AGGREGATE\", \"test:_content_prefix_sort_key_3e762c15\", \"*\", \"TIMEOUT\", \"10000\", \"LOAD\", \"2\", \"data\", \"version\", \"WITHCURSOR\", \"COUNT\", \"1500\", \"MAXIDLE\", \"30000\", \"SORTBY\", \"2\", \"@sort_key\", \"ASC\", \"MAX\", \"1000000\"]"
    ));

    Ok(())
}

/// When `ft_create` races a parallel caller, `RediSearch` returns an
/// Extension-kind error with code="Index" and detail="already exists".
/// That outcome is benign — the index is in place, which is the only
/// postcondition we care about. The race-loser's error must not pollute
/// the merged error surfaced when the second `ft_aggregate` also fails.
#[nativelink_test]
fn test_search_by_index_swallows_already_exists_from_ft_create() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Err::<Value, _>(make_extension_error(
                "BUSY".to_string(),
                Some("Redis is busy running a script".to_string()),
            )),
        )
    }
    fn make_ft_create_already_exists() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG")
                .arg("sort_key")
                .arg("TAG")
                .arg("SORTABLE"),
            Err::<Value, _>(make_extension_error(
                "Index".to_string(),
                Some("already exists".to_string()),
            )),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        make_ft_create_already_exists(),
        make_ft_info("test:_content_prefix_sort_key_3e762c15", 0),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let Err(error) = store.search_by_index_prefix(search_provider).await else {
        panic!("Expected error from the second ft_aggregate");
    };

    let formatted = format!("{error}");
    assert!(
        !formatted.contains("already exists"),
        "merged error must not carry the swallowed ft_create noise; got: {formatted}",
    );
    assert!(
        formatted.contains("second ft_aggregate"),
        "merged error must carry the second ft_aggregate failure context; got: {formatted}",
    );

    Ok(())
}

#[nativelink_test]
fn test_search_by_index_preserves_other_ft_create_errors() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Err::<Value, _>(make_extension_error(
                "BUSY".to_string(),
                Some("Redis is busy running a script".to_string()),
            )),
        )
    }
    fn make_ft_create_other_error() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG")
                .arg("sort_key")
                .arg("TAG")
                .arg("SORTABLE"),
            // A genuinely surprising ft_create failure that must not be
            // swallowed by the new typed match.
            Err::<Value, _>(make_extension_error(
                "PERM".to_string(),
                Some("no permission".to_string()),
            )),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        make_ft_create_other_error(),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let Err(error) = store.search_by_index_prefix(search_provider).await else {
        panic!("Expected error");
    };
    let formatted = format!("{error}");
    assert!(
        formatted.contains("PERM") || formatted.contains("no permission"),
        "merged error must include the real ft_create failure context; got: {formatted}",
    );

    Ok(())
}

#[nativelink_test]
fn test_search_by_index_with_sort_key() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Ok(Value::Array(vec![
                Value::Array(vec![
                    Value::Int(1),
                    Value::Array(vec![
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(b"1234".to_vec()),
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"1".to_vec()),
                        Value::BulkString(b"sort_key".to_vec()),
                        Value::BulkString(b"1234".to_vec()),
                    ]),
                ]),
                Value::Int(0),
            ])),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix__3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG"),
            Ok(Value::Nil),
        ),
        make_ft_info("test:_content_prefix__3e762c15", 0),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert!(search_results.len() == 1, "Should find 1 matching entry");

    assert_eq!(
        search_results[0].content, "1234",
        "Content should match search pattern: '{}'",
        search_results[0].content
    );

    Ok(())
}

#[nativelink_test]
fn test_search_by_index_resp3() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Ok(Value::Array(vec![
                Value::Map(vec![
                    (
                        Value::SimpleString("attributes".into()),
                        Value::Array(vec![]),
                    ),
                    (
                        Value::SimpleString("format".into()),
                        Value::SimpleString("STRING".into()),
                    ),
                    (
                        Value::SimpleString("results".into()),
                        Value::Array(vec![Value::Map(vec![
                            (
                                Value::SimpleString("extra_attributes".into()),
                                Value::Map(vec![
                                    (
                                        Value::BulkString(b"data".to_vec()),
                                        Value::BulkString(b"1234".to_vec()),
                                    ),
                                    (
                                        Value::BulkString(b"version".to_vec()),
                                        Value::BulkString(b"1".to_vec()),
                                    ),
                                ]),
                            ),
                            (Value::SimpleString("values".into()), Value::Array(vec![])),
                        ])]),
                    ),
                    (Value::SimpleString("total_results".into()), Value::Int(1)),
                    (Value::SimpleString("warning".into()), Value::Array(vec![])),
                ]),
                Value::Int(0),
            ])),
        )
    }

    let commands = vec![
        make_ft_aggregate(),
        MockCmd::new(
            redis::cmd("FT.CREATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("ON")
                .arg("HASH")
                .arg("NOHL")
                .arg("NOFIELDS")
                .arg("NOFREQS")
                .arg("NOOFFSETS")
                .arg("PREFIX")
                .arg(1)
                .arg("test:")
                .arg("SCHEMA")
                .arg("content_prefix")
                .arg("TAG")
                .arg("sort_key")
                .arg("TAG")
                .arg("SORTABLE"),
            Ok(Value::Nil),
        ),
        make_ft_info("test:_content_prefix_sort_key_3e762c15", 0),
        make_ft_aggregate(),
    ];
    let store = make_mock_store(commands).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert!(search_results.len() == 1, "Should find 1 matching entry");

    assert_eq!(
        search_results[0].content, "1234",
        "Content should match search pattern: '{}'",
        search_results[0].content
    );

    Ok(())
}

#[nativelink_test]
fn test_search_by_index_skips_int_from_cursor_read() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            // First page: one entry, cursor=42 so the stream issues
            // FT.CURSOR READ for a second page.
            Ok(Value::Array(vec![
                Value::Array(vec![
                    Value::Int(2),
                    Value::Array(vec![
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(b"first".to_vec()),
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"1".to_vec()),
                    ]),
                ]),
                Value::Int(42),
            ])),
        )
    }

    fn make_ft_cursor_read() -> MockCmd {
        MockCmd::new(
            redis::cmd("ft.cursor")
                .arg("read")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .cursor_arg(42),
            Ok(Value::Array(vec![
                Value::Array(vec![
                    // Leading integer that the filter must drop.
                    Value::Int(1),
                    Value::Array(vec![
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(b"second".to_vec()),
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"2".to_vec()),
                    ]),
                ]),
                // cursor=0 ends the stream.
                Value::Int(0),
            ])),
        )
    }

    let store = make_mock_store(vec![make_ft_aggregate(), make_ft_cursor_read()]).await;
    let search_provider = SearchByContentPrefix {
        prefix: "Searchable".to_string(),
    };

    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(search_provider)
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert_eq!(
        search_results.len(),
        2,
        "Both entries should be returned with the leading Int from cursor read filtered out",
    );
    assert_eq!(search_results[0].content, "first");
    assert_eq!(search_results[1].content, "second");

    Ok(())
}

/// The store speaks RESP3, under which a cursor page arrives as a map in
/// the same shape as the aggregate's own first page. Before the cursor read
/// parsed that shape, every listing longer than one page failed on its
/// second page with "Non map item".
#[nativelink_test]
async fn search_by_index_prefix_reads_a_resp3_cursor_page() -> Result<(), Error> {
    fn make_ft_aggregate() -> MockCmd {
        MockCmd::new(
            redis::cmd("FT.AGGREGATE")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .arg("@content_prefix:{ Searchable }")
                .arg("TIMEOUT")
                .arg(10000_u64)
                .arg("LOAD")
                .arg(2)
                .arg("data")
                .arg("version")
                .arg("WITHCURSOR")
                .arg("COUNT")
                .arg(1500)
                .arg("MAXIDLE")
                .arg(30000)
                .arg("SORTBY")
                .arg(2usize)
                .arg("@sort_key")
                .arg("ASC")
                .arg("MAX")
                .arg(1_000_000_u64),
            Ok(Value::Array(vec![
                Value::Array(vec![
                    Value::Int(2),
                    Value::Array(vec![
                        Value::BulkString(b"data".to_vec()),
                        Value::BulkString(b"first".to_vec()),
                        Value::BulkString(b"version".to_vec()),
                        Value::BulkString(b"1".to_vec()),
                    ]),
                ]),
                Value::Int(42),
            ])),
        )
    }

    fn make_ft_cursor_read_resp3() -> MockCmd {
        MockCmd::new(
            redis::cmd("ft.cursor")
                .arg("read")
                .arg("test:_content_prefix_sort_key_3e762c15")
                .cursor_arg(42),
            Ok(Value::Array(vec![
                Value::Map(vec![
                    (
                        Value::SimpleString("attributes".to_string()),
                        Value::Array(vec![]),
                    ),
                    (
                        Value::SimpleString("format".to_string()),
                        Value::SimpleString("STRING".to_string()),
                    ),
                    (
                        Value::SimpleString("results".to_string()),
                        Value::Array(vec![Value::Map(vec![
                            (
                                Value::SimpleString("extra_attributes".to_string()),
                                Value::Map(vec![
                                    (
                                        Value::BulkString(b"data".to_vec()),
                                        Value::BulkString(b"second".to_vec()),
                                    ),
                                    (
                                        Value::BulkString(b"version".to_vec()),
                                        Value::BulkString(b"2".to_vec()),
                                    ),
                                ]),
                            ),
                            (
                                Value::SimpleString("values".to_string()),
                                Value::Array(vec![]),
                            ),
                        ])]),
                    ),
                ]),
                Value::Int(0),
            ])),
        )
    }

    let store = make_mock_store(vec![make_ft_aggregate(), make_ft_cursor_read_resp3()]).await;
    let search_results: Vec<TestSchedulerDataUnversioned> = store
        .search_by_index_prefix(SearchByContentPrefix {
            prefix: "Searchable".to_string(),
        })
        .await
        .err_tip(|| "Failed to search by index")?
        .try_collect()
        .await?;

    assert_eq!(
        search_results.len(),
        2,
        "the RESP3 page is read like the first"
    );
    assert_eq!(search_results[0].content, "first");
    assert_eq!(search_results[1].content, "second");
    Ok(())
}

#[nativelink_test]
async fn no_items_from_none_subscription_channel() -> Result<(), Error> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let subscription_manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    // To give the stream enough time to get polled
    sleep(Duration::from_secs(1)).await;

    assert!(!logs_contain(
        "Error receiving message in RedisSubscriptionManager from subscriber_channel"
    ));
    assert!(!logs_contain("ERROR"));

    // Because otherwise it gets dropped immediately, and we need it to live to do things
    drop(subscription_manager);

    Ok(())
}

#[nativelink_test]
async fn send_messages_to_subscription_channel() -> Result<(), Error> {
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let subscription_manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    tx.send(PushInfo {
        kind: redis::PushKind::PSubscribe,
        data: vec![
            // Pattern
            Value::BulkString("scheduler_key_change".into()),
            // Subscribe count
            Value::Int(1),
        ],
    })
    .unwrap();
    tx.send(PushInfo {
        kind: redis::PushKind::PMessage,
        data: vec![
            // First is the pattern
            Value::BulkString("scheduler_key_change".into()),
            // Second is the matching channel. Which in this case is the same as the pattern.
            Value::BulkString("scheduler_key_change".into()),
            // And then the actual message
            Value::BulkString("demo-key".into()),
        ],
    })
    .unwrap();

    timeout(Duration::from_secs(5), async {
        loop {
            assert!(!logs_contain("ERROR"));
            if logs_contain("New subscription manager key key=\"demo-key\"") {
                break;
            }
            sleep(Duration::from_millis(100)).await;
        }
    })
    .await
    .unwrap();

    // Because otherwise it gets dropped immediately, and we need it to live to do things
    drop(subscription_manager);

    assert!(logs_contain(
        "PSubscribe, ignore push_info=PushInfo { kind: PSubscribe, data: [bulk-string('\"scheduler_key_change\"'), int(1)] }"
    ));

    Ok(())
}

async fn core_test_update_data_unversioned_with_expiry(expire_response: i64) {
    let redis_span = info_span!("redis");
    let mut responses = add_lua_version_script(fake_redis_stream());
    add_to_response(
        &mut responses,
        redis::cmd("HMSET")
            .arg("test:scheduler_key_1")
            .arg("data")
            .arg("Test scheduler data #1")
            .arg("test_index")
            .arg("test_value")
            .arg("content_prefix")
            .arg("Test sched"),
        vec![Value::Okay],
    );
    add_to_response(
        &mut responses,
        redis::cmd("EXPIRE").arg("test:scheduler_key_1").arg(60),
        vec![Value::Int(expire_response)],
    );

    let redis_port = make_fake_redis_with_responses(responses)
        .instrument(redis_span)
        .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{redis_port}/")],
        mode: RedisMode::Standard,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    let data = TestSchedulerDataUnversioned {
        key: "test:scheduler_key_1".to_string(),
        content: "Test scheduler data #1".to_string(),
        version: 0,
    };
    store
        .update_data(data, Some(Duration::from_mins(1)))
        .await
        .expect("working update");
}

#[nativelink_test]
async fn test_update_data_unversioned_with_expiry() {
    core_test_update_data_unversioned_with_expiry(1).await;
    assert!(!logs_contain("Wasn't able to set expiry for Redis key"));
}

#[nativelink_test]
async fn test_update_data_unversioned_with_expiry_failure() {
    core_test_update_data_unversioned_with_expiry(0).await;
    assert!(logs_contain(
        "Wasn't able to set expiry for Redis key redis_key=test:scheduler_key_1 seconds=60"
    ));
}
#[nativelink_test]
async fn test_update_data_versioned_with_expiry() {
    let redis_span = info_span!("redis");
    let mut responses = add_lua_version_script(fake_redis_stream());
    add_to_response(
        &mut responses,
        redis::cmd("EVALSHA")
            .arg(FAKE_SCRIPT_SHA)
            .arg("1")
            .arg("test:scheduler_key_1")
            .arg("0")
            .arg("60")
            .arg("Test scheduler data #1")
            .arg("test_index")
            .arg("test_value")
            .arg("content_prefix")
            .arg("Test sched"),
        vec![Value::Array(vec![Value::Boolean(true), Value::Int(1)])],
    );
    let redis_port = make_fake_redis_with_responses(responses)
        .instrument(redis_span)
        .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{redis_port}/")],
        mode: RedisMode::Standard,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    let data = TestSchedulerDataVersioned {
        key: "test:scheduler_key_1".to_string(),
        content: "Test scheduler data #1".to_string(),
        version: 0,
    };
    store
        .update_data(data, Some(Duration::from_mins(1)))
        .await
        .expect("working update");
}

/// Test key provider that just wraps a string. Reused across the
/// subscription regression tests below.
#[derive(Clone)]
struct TestSubKey(String);

impl SchedulerStoreKeyProvider for TestSubKey {
    type Versioned = FalseValue;
    fn get_key(&self) -> StoreKey<'static> {
        StoreKey::Str(std::borrow::Cow::Owned(self.0.clone()))
    }
}

/// Sanity: a single subscriber that drops cleanly produces no warning
/// and no error.
#[nativelink_test]
async fn redis_subscription_single_drop_is_silent() -> Result<(), Error> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    let sub = manager.subscribe(TestSubKey("solo-key".to_string()))?;
    drop(sub);
    sleep(Duration::from_millis(10)).await;

    assert!(
        !logs_contain("key absent from subscribed_keys under write lock"),
        "single-subscriber drop unexpectedly logged the absence warning",
    );
    assert!(!logs_contain("ERROR"));

    drop(manager);
    Ok(())
}

#[nativelink_test]
async fn redis_subscription_drop_one_of_two_keeps_publisher() -> Result<(), Error> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    let key = "shared-key";
    let sub_a = manager.subscribe(TestSubKey(key.to_string()))?;
    let mut sub_b = manager.subscribe(TestSubKey(key.to_string()))?;

    // Drop the first; the second's subscription must still resolve
    // when we notify on the same key.
    drop(sub_a);

    manager.notify_for_test(key.to_string());
    timeout(Duration::from_secs(2), sub_b.changed())
        .await
        .expect("sub_b.changed() did not fire — publisher entry was dropped prematurely")?;

    assert!(
        !logs_contain("key absent from subscribed_keys under write lock"),
        "absence warning fired during single drop with another receiver alive",
    );
    drop(sub_b);
    drop(manager);
    Ok(())
}

#[nativelink_test]
async fn redis_subscription_concurrent_drops_no_absence_warn() -> Result<(), Error> {
    const ITERATIONS: usize = 200;
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    for i in 0..ITERATIONS {
        let key = format!("race-key-{i}");
        let sub_a = manager.subscribe(TestSubKey(key.clone()))?;
        let sub_b = manager.subscribe(TestSubKey(key.clone()))?;

        // `spawn_blocking` puts each Drop on its own thread; with the
        // pre-fix code's "drop receiver, then take lock" sequence,
        // both threads can race into the lock with already-decremented
        // counts. With the post-fix "take lock, then evaluate, then
        // drop receiver" sequence, the lock serialises the decision
        // and the warning never fires.
        let h_a = tokio::task::spawn_blocking(move || drop(sub_a));
        let h_b = tokio::task::spawn_blocking(move || drop(sub_b));
        h_a.await.unwrap();
        h_b.await.unwrap();
    }
    sleep(Duration::from_millis(50)).await;

    assert!(
        !logs_contain("key absent from subscribed_keys under write lock"),
        "concurrent drops produced the absence warning at least once across {ITERATIONS} \
         iterations — the Drop ordering regressed",
    );
    assert!(!logs_contain("ERROR"));

    drop(manager);
    Ok(())
}

#[nativelink_test]
async fn redis_subscription_resubscribe_after_drop_creates_fresh_publisher() -> Result<(), Error> {
    let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let manager =
        RedisSubscriptionManager::new(rx, Arc::new(async_lock::Mutex::new(vec![])), String::new());

    let key = "cycle-key";
    let sub_a = manager.subscribe(TestSubKey(key.to_string()))?;
    let sub_b = manager.subscribe(TestSubKey(key.to_string()))?;
    drop(sub_a);
    drop(sub_b);

    // Re-subscribe to the same key. If the previous drops left the
    // map in an inconsistent state (stale publisher kept, or a
    // partially-deconstructed entry), this either reuses a dead
    // publisher (changed() never fires) or panics inside the
    // patricia map.
    let mut sub_c = manager.subscribe(TestSubKey(key.to_string()))?;
    manager.notify_for_test(key.to_string());
    timeout(Duration::from_secs(2), sub_c.changed())
        .await
        .expect("re-subscribe after drops produced a dead publisher")?;

    assert!(!logs_contain(
        "key absent from subscribed_keys under write lock"
    ));
    drop(sub_c);
    drop(manager);
    Ok(())
}

#[derive(Debug)]
struct LoggingRemoveCallback {}

impl RemoveItemCallback for LoggingRemoveCallback {
    fn callback<'a>(
        &'a self,
        store_key: StoreKey<'a>,
    ) -> Pin<Box<dyn Future<Output = ()> + Send + 'a>> {
        info!(?store_key, "Callback for removed item");
        Box::pin(async {})
    }
}

async fn callback_for_eviction_core<F>(
    logs_contain: F,
    notify_keyspace_events: &[u8],
) -> Result<(), Error>
where
    F: Fn(&str) -> bool,
{
    let redis_span = info_span!("redis");

    let mut responses = add_lua_version_script(fake_redis_stream());
    add_to_response(
        &mut responses,
        redis::cmd("CONFIG")
            .arg("GET")
            .arg("notify-keyspace-events"),
        vec![Value::Map(vec![(
            Value::BulkString(b"notify-keyspace-events".into()),
            Value::BulkString(notify_keyspace_events.into()),
        )])],
    );
    add_to_response(
        &mut responses,
        redis::cmd("PSUBSCRIBE").arg("__key*__:*"),
        vec![Value::Nil],
    );
    let redis_port = make_fake_redis_with_responses(responses)
        .instrument(redis_span)
        .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{redis_port}/")],
        mode: RedisMode::Standard,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    store.register_remove_callback(Arc::new(LoggingRemoveCallback {}))?;

    timeout(Duration::from_secs(3), async move {
        loop {
            if logs_contain("new psubscribe complete pattern=\"__key*__:*\" new_subscription=true")
            {
                break;
            }
            sleep(Duration::from_millis(100)).await;
        }
    })
    .await?;
    Ok(())
}

#[nativelink_test]
async fn callback_for_eviction_not_enabled() -> Result<(), Error> {
    callback_for_eviction_core(logs_contain, b"").await?;
    assert!(logs_contain(
        "notify-keyspace-events not enabled for Redis, will fail to get remove callbacks"
    ));
    Ok(())
}

#[nativelink_test]
async fn callback_for_eviction_no_keyspace() -> Result<(), Error> {
    callback_for_eviction_core(logs_contain, b"E").await?;
    assert!(logs_contain(
        "notify-keyspace-events does not contain 'K' so won't get keyspace events we need for eviction events notify_keyspace_events=\"E\""
    ));
    Ok(())
}

#[nativelink_test]
async fn callback_for_eviction_no_all() -> Result<(), Error> {
    callback_for_eviction_core(logs_contain, b"K").await?;
    assert!(logs_contain(
        "notify-keyspace-events does not contain 'A' so we won't get eviction events notify_keyspace_events=\"K\""
    ));
    Ok(())
}

#[nativelink_test]
async fn callback_for_eviction_good() -> Result<(), Error> {
    callback_for_eviction_core(logs_contain, b"KA").await?;
    assert!(!logs_contain("ERROR"));
    Ok(())
}

// Repro for a fail-silent one-shot init bug: `register_remove_callback`
// returns Ok(()) immediately and performs the CONFIG GET + PSUBSCRIBE lazily
// inside a `background_spawn` via `OnceCell::get_or_try_init`. If that init
// hits a single transient Redis error (here: `-LOADING`), the error is only
// logged, the OnceCell stays uninitialized, and nothing ever retries — so the
// `__key*__:*` subscription is never established and evicted/expired keys
// never fire remove callbacks, silently and permanently.
#[nativelink_test]
async fn transient_init_error_permanently_disables_remove_callbacks() -> Result<(), Error> {
    let redis_span = info_span!("redis");

    let mut responses = add_lua_version_script(fake_redis_stream());
    // The one-time init query fails with a transient, retryable server error
    // (Redis restarting/failing over). The server is otherwise healthy and
    // would happily accept a PSUBSCRIBE.
    add_to_response_raw(
        &mut responses,
        redis::cmd("CONFIG")
            .arg("GET")
            .arg("notify-keyspace-events"),
        "-LOADING Redis is loading the dataset in memory\r\n".to_string(),
    );
    add_to_response(
        &mut responses,
        redis::cmd("PSUBSCRIBE").arg("__key*__:*"),
        vec![Value::Nil],
    );
    let redis_port = make_fake_redis_with_responses(responses)
        .instrument(redis_span)
        .await;
    let spec = RedisSpec {
        addresses: vec![format!("redis://127.0.0.1:{redis_port}/")],
        mode: RedisMode::Standard,
        ..Default::default()
    };
    let mut raw_store =
        Arc::into_inner(RedisStore::new_standard(spec).await.expect("Working spec")).unwrap();
    raw_store.replace_temp_name_generator(mock_uuid_generator);
    let store = Arc::new(raw_store);
    // The caller (e.g. ExistenceCacheStore at construction, its only call
    // site) is told Ok(()) and believes eviction tracking is live.
    store.register_remove_callback(Arc::new(LoggingRemoveCallback {}))?;

    // Deterministic sync point: wait until the background init task has hit
    // the transient error and logged it.
    timeout(Duration::from_secs(5), async {
        loop {
            if logs_contain("Error while trying to initialise remove_callback_subscribe") {
                break;
            }
            sleep(Duration::from_millis(20)).await;
        }
    })
    .await
    .expect("background init never ran/logged its error");

    // Since register_remove_callback reported success, the keyspace-event
    // subscription must (eventually) be established — otherwise remove
    // callbacks are silently dead forever. On current code there is no retry
    // path at all (the OnceCell is left empty and only another
    // register_remove_callback call could re-drive it), so this never happens.
    let subscribed = timeout(Duration::from_secs(2), async {
        loop {
            if logs_contain("new psubscribe complete pattern=\"__key*__:*\"") {
                break;
            }
            sleep(Duration::from_millis(50)).await;
        }
    })
    .await
    .is_ok();
    assert!(
        subscribed,
        "register_remove_callback returned Ok(()) but a single transient CONFIG GET \
         error permanently disabled the __key*__:* subscription; evicted/expired keys \
         will never invoke remove callbacks (stale ExistenceCacheStore entries)"
    );
    Ok(())
}

#[nativelink_test]
async fn send_eviction_to_subscription_channel() -> Result<(), Error> {
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let subscription_manager = RedisSubscriptionManager::new(
        rx,
        Arc::new(async_lock::Mutex::new(vec![Arc::new(
            LoggingRemoveCallback {},
        )])),
        String::new(),
    );

    tx.send(PushInfo {
        kind: redis::PushKind::PMessage,
        data: vec![
            Value::BulkString("demo_pattern".into()),
            Value::BulkString("keyprefix:test-eviction".into()),
            Value::BulkString("evicted".into()),
        ],
    })
    .unwrap();

    timeout(Duration::from_secs(5), async {
        loop {
            assert!(!logs_contain("ERROR"));
            if logs_contain("Callback for removed item store_key=Str(\"test-eviction\")") {
                break;
            }
            sleep(Duration::from_millis(100)).await;
        }
    })
    .await
    .unwrap();

    // Because otherwise it gets dropped immediately, and we need it to live to do things
    drop(subscription_manager);

    assert!(logs_contain(
        "Removed key removed_key=\"keyprefix:test-eviction\""
    ));

    Ok(())
}

async fn store_key_coding_round_trip_core(key_prefix: String) -> Result<(), Error> {
    let store = make_mock_store_with_prefix(vec![], key_prefix.clone()).await;

    for key in [
        StoreKey::new_str("foo"),
        StoreKey::Digest(DigestInfo::zero_digest()),
        StoreKey::Digest(DigestInfo::new([99u8; 32], 512)),
    ] {
        assert_eq!(key, decode_key(&key_prefix, store.encode_key(&key))?);
    }
    Ok(())
}

#[nativelink_test]
async fn store_key_coding_round_trip() -> Result<(), Error> {
    store_key_coding_round_trip_core(String::new()).await
}

#[nativelink_test]
async fn store_key_coding_round_trip_with_prefix() -> Result<(), Error> {
    store_key_coding_round_trip_core(String::from("demo")).await
}

async fn evict_keys_for_existence_cache_core<F>(
    prefix: String,
    removal_event: &str,
    logs_contain: F,
) -> Result<(), Error>
where
    F: Fn(&str) -> bool + Send + Sync,
{
    let spec = ExistenceCacheSpec {
        backend: StoreSpec::RedisStore(RedisSpec::default()), // Note: Not used.
        eviction_policy: Option::default(), // Not evicting here, we'll evict from Redis
    };
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();

    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let real_key = format!("{prefix}{digest}");
    let temp_key = make_temp_key(&real_key);

    let commands = vec![
        MockCmd::new(
            redis::cmd("CONFIG")
                .arg("GET")
                .arg("notify-keyspace-events"),
            Ok(Value::Map(vec![(
                Value::BulkString(b"notify-keyspace-events".into()),
                Value::BulkString(b"KA".into()),
            )])),
        ),
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(&temp_key)
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(&temp_key),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        // Move the data from the fake key to the real key.
        MockCmd::new(
            redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
            Ok(Value::Nil),
        ),
        // Retrieve the data from the real key.
        MockCmd::new(
            redis::cmd("GETRANGE").arg(&real_key).arg(0).arg(1),
            Ok(Value::BulkString(b"14".to_vec())),
        ),
    ];

    let redis_store = Arc::new(
        make_mock_store_with_prefix_and_subscriber_channel(commands, prefix.clone(), None, rx)
            .await,
    );
    let existence_store = ExistenceCacheStore::new(&spec, Store::new(redis_store.clone()));

    // Wait for subscription first so the mock redis commands are in the right order
    timeout(Duration::from_secs(5), async {
        loop {
            assert!(!logs_contain("ERROR"));
            if logs_contain("Attempting to subscribe to eviction events") {
                break;
            }
            sleep(Duration::from_millis(100)).await;
        }
    })
    .await
    .unwrap();

    existence_store
        .update_oneshot(digest, data.clone())
        .await
        .unwrap();

    tx.send(PushInfo {
        kind: redis::PushKind::PMessage,
        data: vec![
            Value::BulkString("demo_pattern".into()),
            Value::BulkString(format!("keyprefix:{real_key}").into()),
            Value::BulkString(removal_event.into()),
        ],
    })
    .unwrap();

    timeout(Duration::from_secs(5), async {
        loop {
            assert!(!logs_contain("ERROR"));
            if logs_contain("Evicting (direct remove) key=DigestInfo(\"3031323334353637383961626364656630303030303030303030303030303030-2\")") {
                break;
            }
            sleep(Duration::from_millis(100)).await;
        }
    })
    .await
    .unwrap();

    assert!(logs_contain(&format!(
        "Removed key removed_key=\"keyprefix:{prefix}3031323334353637383961626364656630303030303030303030303030303030-2\""
    )));

    Ok(())
}

#[nativelink_test]
async fn evict_keys_for_existence_cache_no_prefix() -> Result<(), Error> {
    evict_keys_for_existence_cache_core(String::new(), "evicted", logs_contain).await
}

#[nativelink_test]
async fn evict_keys_for_existence_cache_prefix() -> Result<(), Error> {
    evict_keys_for_existence_cache_core(String::from("demo_prefix:"), "evicted", logs_contain).await
}

/// A key that reaches its TTL has to invalidate the existence cache exactly
/// as a maxmemory eviction does. Redis reports the two differently: `evicted`
/// for maxmemory pressure, `expired` for a TTL. Handling only the former left
/// the cache claiming to hold a key Redis had already dropped, which is
/// newly reachable now that a store can be given a TTL.
#[nativelink_test]
async fn expired_keys_invalidate_the_existence_cache() -> Result<(), Error> {
    evict_keys_for_existence_cache_core(String::new(), "expired", logs_contain).await
}

#[nativelink_test]
async fn expired_keys_invalidate_the_existence_cache_with_prefix() -> Result<(), Error> {
    evict_keys_for_existence_cache_core(String::from("demo_prefix:"), "expired", logs_contain).await
}

/// A store configured with a TTL must expire what it writes. Without this a
/// BEP store keeps every key it ever wrote once its consumer stops, which is
/// how one deployment reached 1.79M keys with `expires=0`.
#[nativelink_test]
async fn update_sets_a_ttl_when_configured() -> Result<(), Error> {
    const TTL_SECONDS: u64 = 7 * 24 * 60 * 60;
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let store = make_mock_store_with_ttl(
        vec![
            MockCmd::new(
                redis::cmd("SETRANGE")
                    .arg(&temp_key)
                    .arg(0)
                    .arg(data.to_vec()),
                Ok(Value::Int(0)),
            ),
            // The temp key is guarded as soon as it exists, so an update that
            // dies before the rename cannot orphan it.
            MockCmd::new(
                redis::cmd("EXPIRE")
                    .arg(&temp_key)
                    .arg(i64::try_from(TTL_SECONDS).unwrap()),
                Ok(Value::Int(1)),
            ),
            MockCmd::new(
                redis::cmd("STRLEN").arg(&temp_key),
                Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
            ),
            MockCmd::new(
                redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
                Ok(Value::Nil),
            ),
            // Re-set after the rename so the retention window starts at
            // completion rather than at the first byte.
            MockCmd::new(
                redis::cmd("EXPIRE")
                    .arg(&real_key)
                    .arg(i64::try_from(TTL_SECONDS).unwrap()),
                Ok(Value::Int(1)),
            ),
            // A read afterwards, purely so the expectations that follow EXPIRE
            // get consumed. The mock ignores expectations nobody reaches, so
            // without something after it a skipped EXPIRE would pass silently.
            MockCmd::with_values(
                redis::pipe()
                    .cmd("STRLEN")
                    .arg(&real_key)
                    .cmd("EXISTS")
                    .arg(&real_key),
                Ok(vec![Value::Int(2), Value::Boolean(true)]),
            ),
        ],
        Duration::from_secs(TTL_SECONDS),
    )
    .await;

    store.update_oneshot(digest, data).await?;
    let size = store.has(digest).await?;
    assert_eq!(size, Some(2), "the value must survive the expiry being set");
    Ok(())
}

/// A failover between the rename and the expire must not leave the key
/// without a TTL. Every other step in `update` reconnects and retries once on
/// a transient error; this one did not, which review caught after it merged.
#[nativelink_test]
async fn update_retries_the_ttl_after_a_failover() -> Result<(), Error> {
    const TTL_SECONDS: u64 = 7 * 24 * 60 * 60;
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;
    let ttl_arg = i64::try_from(TTL_SECONDS).unwrap();

    let store = make_mock_store_with_ttl(
        vec![
            MockCmd::new(
                redis::cmd("SETRANGE")
                    .arg(&temp_key)
                    .arg(0)
                    .arg(data.to_vec()),
                Ok(Value::Int(0)),
            ),
            MockCmd::new(
                redis::cmd("EXPIRE").arg(&temp_key).arg(ttl_arg),
                Ok(Value::Int(1)),
            ),
            MockCmd::new(
                redis::cmd("STRLEN").arg(&temp_key),
                Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
            ),
            MockCmd::new(
                redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
                Ok(Value::Nil),
            ),
            // The master goes away right as we set the retention window.
            MockCmd::new(
                redis::cmd("EXPIRE").arg(&real_key).arg(ttl_arg),
                Err::<Value, _>(RedisError::from(std::io::Error::new(
                    std::io::ErrorKind::ConnectionReset,
                    "connection reset by peer",
                ))),
            ),
            // After re-resolving the master the TTL is set on the new one.
            MockCmd::new(
                redis::cmd("EXPIRE").arg(&real_key).arg(ttl_arg),
                Ok(Value::Int(1)),
            ),
        ],
        Duration::from_secs(TTL_SECONDS),
    )
    .await;

    store.update_oneshot(digest, data).await?;
    Ok(())
}

/// A failover between the chunk writes and the length check used to fail the
/// upload after the command timeout on the dead master. Seen on a bed where a
/// Redis master kill failed every CAS upload for forty seconds.
#[nativelink_test]
async fn update_retries_the_length_check_after_a_failover() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let store = make_mock_store(vec![
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(&temp_key)
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        // The master goes away right as the length is checked.
        MockCmd::new(
            redis::cmd("STRLEN").arg(&temp_key),
            Err::<Value, _>(RedisError::from(std::io::Error::new(
                std::io::ErrorKind::TimedOut,
                "timed out",
            ))),
        ),
        // After re-resolving the master the check runs against the new one.
        MockCmd::new(
            redis::cmd("STRLEN").arg(&temp_key),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
            Ok(Value::Nil),
        ),
    ])
    .await;

    store.update_oneshot(digest, data).await?;
    Ok(())
}

/// The default must stay off. The same store type backs the CAS fast tier and
/// the scheduler, and expiring scheduler state would drop in-flight actions.
///
/// The mock rejects any command it was not given, so an EXPIRE issued here
/// would fail this test.
#[nativelink_test]
async fn update_sets_no_ttl_by_default() -> Result<(), Error> {
    let data = Bytes::from_static(b"14");
    let digest = DigestInfo::try_new(VALID_HASH1, 2)?;
    let packed_hash_hex = format!("{digest}");
    let temp_key = make_temp_key(&packed_hash_hex);
    let real_key = packed_hash_hex;

    let store = make_mock_store(vec![
        MockCmd::new(
            redis::cmd("SETRANGE")
                .arg(&temp_key)
                .arg(0)
                .arg(data.to_vec()),
            Ok(Value::Int(0)),
        ),
        MockCmd::new(
            redis::cmd("STRLEN").arg(&temp_key),
            Ok(Value::Int(data.len().try_into().unwrap_or(i64::MAX))),
        ),
        MockCmd::new(
            redis::cmd("RENAME").arg(&temp_key).arg(&real_key),
            Ok(Value::Nil),
        ),
    ])
    .await;

    store.update_oneshot(digest, data).await?;
    Ok(())
}

/// Counting must not read any documents. `search_by_index_prefix` has to
/// `LOAD` the data and version of every match and page through them, so using
/// it to answer "how many" makes the cost grow with the number of matches; on
/// the scheduler's queued/completed indexes that is the whole action body of
/// every action, repeatedly. `count_by_index_prefix` asks `RediSearch` for the
/// total instead, which is why this test pins the command shape.
#[nativelink_test]
async fn test_count_by_index_prefix_asks_for_the_total_only() -> Result<(), Error> {
    let store = make_mock_store(vec![MockCmd::new(
        redis::cmd("FT.SEARCH")
            .arg("test:_content_prefix_sort_key_3e762c15")
            .arg("@content_prefix:{ Searchable }")
            .arg("LIMIT")
            .arg(0)
            .arg(0)
            .arg("TIMEOUT")
            .arg(10000),
        Ok(Value::Array(vec![Value::Int(42)])),
    )])
    .await;

    let count = store
        .count_by_index_prefix(SearchByContentPrefix {
            prefix: "Searchable".to_string(),
        })
        .await
        .err_tip(|| "Failed to count by index")?;

    assert_eq!(count, 42);
    Ok(())
}

/// The same reply under RESP3, which answers with a map rather than an array.
#[nativelink_test]
async fn test_count_by_index_prefix_reads_a_resp3_reply() -> Result<(), Error> {
    let store = make_mock_store(vec![MockCmd::new(
        redis::cmd("FT.SEARCH")
            .arg("test:_content_prefix_sort_key_3e762c15")
            .arg("@content_prefix:{ Searchable }")
            .arg("LIMIT")
            .arg(0)
            .arg(0)
            .arg("TIMEOUT")
            .arg(10000),
        Ok(Value::Map(vec![
            (
                Value::SimpleString("attributes".to_string()),
                Value::Array(vec![]),
            ),
            (
                Value::SimpleString("total_results".to_string()),
                Value::Int(7),
            ),
            (
                Value::SimpleString("results".to_string()),
                Value::Array(vec![]),
            ),
        ])),
    )])
    .await;

    let count = store
        .count_by_index_prefix(SearchByContentPrefix {
            prefix: "Searchable".to_string(),
        })
        .await
        .err_tip(|| "Failed to count by index")?;

    assert_eq!(count, 7);
    Ok(())
}

#[nativelink_test]
async fn incomplete_upload_never_renames_redis_temp_key() -> Result<(), Error> {
    for payload in [
        Bytes::new(),
        Bytes::from_static(b"short"),
        Bytes::from(vec![9; 79]),
    ] {
        let key = DigestInfo::try_new(VALID_HASH1, 78)?;
        let commands = if payload.is_empty() {
            vec![]
        } else {
            vec![MockCmd::new(
                redis::cmd("SETRANGE")
                    .arg(make_temp_key(&key.to_string()))
                    .arg(0)
                    .arg(payload.to_vec()),
                Ok(Value::Int(i64::try_from(payload.len()).unwrap())),
            )]
        };
        // Any STRLEN or RENAME beyond these temporary writes is unexpected.
        let store = make_mock_store(commands).await;
        let (mut tx, rx) = make_buf_channel_pair();
        let send = async move {
            if !payload.is_empty() {
                tx.send(payload).await?;
            }
            tx.send_eof()
        };
        let (result, _) = tokio::join!(
            StoreLike::update(&store, key, rx, UploadSizeInfo::ExactSize(78)),
            send
        );
        assert_eq!(result.unwrap_err().code, Code::InvalidArgument);
    }
    Ok(())
}
