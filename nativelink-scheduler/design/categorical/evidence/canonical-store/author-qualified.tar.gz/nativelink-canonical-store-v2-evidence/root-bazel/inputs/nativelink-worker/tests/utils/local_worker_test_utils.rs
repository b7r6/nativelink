// Copyright 2024 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::collections::HashMap;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};

use async_lock::Mutex;
use bytes::Bytes;
use hyper::body::Frame;
use nativelink_config::cas_server::{EndpointConfig, LocalWorkerConfig, WorkerProperty};
use nativelink_error::{Error, make_err};
use nativelink_proto::com::github::trace_machina::nativelink::remote_execution::{
    ConnectWorkerRequest, ExecuteAccepted, ExecuteComplete, ExecuteDeclined, ExecuteResult,
    GoingAwayRequest, KeepAliveRequest, UpdateForWorker,
};
use nativelink_util::channel_body_for_tests::ChannelBody;
use nativelink_util::shutdown_guard::ShutdownGuard;
use nativelink_util::spawn;
use nativelink_util::task::JoinHandleDropGuard;
use nativelink_worker::local_worker::{LocalWorker, WorkerRegistration};
use nativelink_worker::worker_api_client_wrapper::WorkerApiClientTrait;
use tokio::sync::{broadcast, mpsc};
use tonic::{Code, Status};
use tonic::{
    Response,
    Streaming,
    codec::Codec, // Needed for .decoder().
    codec::CompressionEncoding,
};
use tonic_prost::ProstCodec;
use tracing::debug;

use super::mock_running_actions_manager::MockRunningActionsManager;

/// Broadcast Channel Capacity
/// Note: The actual capacity may be greater than the provided capacity.
const BROADCAST_CAPACITY: usize = 1;

#[derive(Debug)]
#[allow(
    clippy::large_enum_variant,
    reason = "TODO Fix thix. Triggers on nightly"
)]
enum WorkerClientApiCalls {
    ConnectWorker(ConnectWorkerRequest),
    ExecutionResponse(ExecuteResult),
    ExecuteAccepted(ExecuteAccepted),
    ExecuteDeclined(ExecuteDeclined),
}

#[derive(Debug)]
#[allow(
    clippy::large_enum_variant,
    reason = "TODO Fix thix. Triggers on nightly"
)]
enum WorkerClientApiReturns {
    ConnectWorker(Result<Response<Streaming<UpdateForWorker>>, Status>),
    ExecutionResponse(Result<(), Error>),
    ExecuteAccepted(Result<(), Error>),
    ExecuteDeclined(Result<(), Error>),
}

#[derive(Clone)]
pub(crate) struct MockWorkerApiClient {
    rx_call: Arc<Mutex<mpsc::UnboundedReceiver<WorkerClientApiCalls>>>,
    tx_call: mpsc::UnboundedSender<WorkerClientApiCalls>,
    rx_resp: Arc<Mutex<mpsc::UnboundedReceiver<WorkerClientApiReturns>>>,
    tx_resp: mpsc::UnboundedSender<WorkerClientApiReturns>,
    keep_alives_count: u8,
    /// A keepalive that never completes: a send waiting its turn on a
    /// stalled connection. `keep_alives_hanging` counts the ones held.
    pub keep_alive_hangs: Arc<std::sync::atomic::AtomicBool>,
    pub keep_alives_hanging: Arc<AtomicU64>,
    pub going_away_count: Arc<AtomicU64>,
    pub going_away_drain: Arc<std::sync::atomic::AtomicBool>,
    pub execution_complete_count: Arc<AtomicU64>,
}

impl MockWorkerApiClient {
    pub(crate) fn new() -> Self {
        let (tx_call, rx_call) = mpsc::unbounded_channel();
        let (tx_resp, rx_resp) = mpsc::unbounded_channel();
        Self {
            rx_call: Arc::new(Mutex::new(rx_call)),
            tx_call,
            rx_resp: Arc::new(Mutex::new(rx_resp)),
            tx_resp,
            keep_alives_count: 0,
            keep_alive_hangs: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            keep_alives_hanging: Arc::new(AtomicU64::new(0)),
            going_away_count: Arc::new(AtomicU64::new(0)),
            going_away_drain: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            execution_complete_count: Arc::new(AtomicU64::new(0)),
        }
    }
}

impl Default for MockWorkerApiClient {
    fn default() -> Self {
        unreachable!("We don't test this functionality")
    }
}

impl MockWorkerApiClient {
    pub(crate) async fn expect_connect_worker(
        &self,
        result: Result<Response<Streaming<UpdateForWorker>>, Status>,
    ) -> ConnectWorkerRequest {
        let mut rx_call_lock = self.rx_call.lock().await;
        let req = match rx_call_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiCalls::ConnectWorker(req) => req,
            req => {
                panic!("expect_connect_worker expected ConnectWorker, got : {req:?}")
            }
        };
        self.tx_resp
            .send(WorkerClientApiReturns::ConnectWorker(result))
            .expect("Could not send request to mpsc");
        req
    }

    pub(crate) async fn expect_execute_accepted(
        &self,
        result: Result<(), Error>,
    ) -> ExecuteAccepted {
        let mut rx_call_lock = self.rx_call.lock().await;
        let req = match rx_call_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiCalls::ExecuteAccepted(req) => req,
            req => panic!("expect_execute_accepted expected ExecuteAccepted, got : {req:?}"),
        };
        self.tx_resp
            .send(WorkerClientApiReturns::ExecuteAccepted(result))
            .expect("Could not send request to mpsc");
        req
    }

    pub(crate) async fn expect_execute_declined(
        &self,
        result: Result<(), Error>,
    ) -> ExecuteDeclined {
        let mut rx_call_lock = self.rx_call.lock().await;
        let req = match rx_call_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiCalls::ExecuteDeclined(req) => req,
            req => panic!("expect_execute_declined expected ExecuteDeclined, got : {req:?}"),
        };
        self.tx_resp
            .send(WorkerClientApiReturns::ExecuteDeclined(result))
            .expect("Could not send request to mpsc");
        req
    }

    pub(crate) async fn expect_execution_response(
        &self,
        result: Result<(), Error>,
    ) -> ExecuteResult {
        let mut rx_call_lock = self.rx_call.lock().await;
        let req = match rx_call_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiCalls::ExecutionResponse(req) => req,
            req => {
                panic!("expect_execution_response expected ExecutionResponse, got : {req:?}")
            }
        };
        self.tx_resp
            .send(WorkerClientApiReturns::ExecutionResponse(result))
            .expect("Could not send request to mpsc");
        req
    }
}

impl WorkerApiClientTrait for MockWorkerApiClient {
    async fn connect_worker(
        &mut self,
        request: ConnectWorkerRequest,
    ) -> Result<Response<Streaming<UpdateForWorker>>, Status> {
        self.tx_call
            .send(WorkerClientApiCalls::ConnectWorker(request))
            .expect("Could not send request to mpsc");
        let mut rx_resp_lock = self.rx_resp.lock().await;
        match rx_resp_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiReturns::ConnectWorker(result) => result,
            resp => {
                panic!("connect_worker expected ConnectWorker response, received {resp:?}")
            }
        }
    }

    async fn keep_alive(&mut self, _request: KeepAliveRequest) -> Result<(), Error> {
        debug!("Got KeepAlive");
        if self.keep_alive_hangs.load(Ordering::Acquire) {
            self.keep_alives_hanging.fetch_add(1, Ordering::AcqRel);
            core::future::pending::<()>().await;
        }
        if self.keep_alives_count == 0 {
            self.keep_alives_count += 1;
            Ok(())
        } else {
            Err(make_err!(Code::Internal, "KeepAlive fail"))
        }
    }

    async fn going_away(&mut self, request: GoingAwayRequest) -> Result<(), Error> {
        self.going_away_count.fetch_add(1, Ordering::Relaxed);
        self.going_away_drain
            .store(request.drain, Ordering::Relaxed);
        Ok(())
    }

    async fn execution_response(&mut self, request: ExecuteResult) -> Result<(), Error> {
        self.tx_call
            .send(WorkerClientApiCalls::ExecutionResponse(request))
            .expect("Could not send request to mpsc");
        let mut rx_resp_lock = self.rx_resp.lock().await;
        match rx_resp_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiReturns::ExecutionResponse(result) => result,
            resp => {
                panic!("execution_response expected ExecutionResponse response, received {resp:?}")
            }
        }
    }

    async fn execution_complete(&mut self, _request: ExecuteComplete) -> Result<(), Error> {
        self.execution_complete_count
            .fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    async fn execute_accepted(&mut self, request: ExecuteAccepted) -> Result<(), Error> {
        self.tx_call
            .send(WorkerClientApiCalls::ExecuteAccepted(request))
            .expect("Could not send request to mpsc");
        let mut rx_resp_lock = self.rx_resp.lock().await;
        match rx_resp_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiReturns::ExecuteAccepted(result) => result,
            resp => panic!("execute_accepted expected ExecuteAccepted response, received {resp:?}"),
        }
    }

    async fn execute_declined(&mut self, request: ExecuteDeclined) -> Result<(), Error> {
        self.tx_call
            .send(WorkerClientApiCalls::ExecuteDeclined(request))
            .expect("Could not send request to mpsc");
        let mut rx_resp_lock = self.rx_resp.lock().await;
        match rx_resp_lock
            .recv()
            .await
            .expect("Could not receive msg in mpsc")
        {
            WorkerClientApiReturns::ExecuteDeclined(result) => result,
            resp => panic!("execute_declined expected ExecuteDeclined response, received {resp:?}"),
        }
    }
}

pub(crate) fn setup_grpc_stream() -> (
    mpsc::Sender<Frame<Bytes>>,
    Response<Streaming<UpdateForWorker>>,
) {
    let (tx, body) = ChannelBody::new();
    let mut codec = ProstCodec::<UpdateForWorker, UpdateForWorker>::default();
    let stream =
        Streaming::new_request(codec.decoder(), body, Some(CompressionEncoding::Gzip), None);
    (tx, Response::new(stream))
}

pub(crate) async fn setup_local_worker_with_config(
    local_worker_config: LocalWorkerConfig,
) -> TestContext {
    let mock_worker_api_client = MockWorkerApiClient::new();
    let mock_worker_api_client_clone = mock_worker_api_client.clone();
    let actions_manager = Arc::new(MockRunningActionsManager::new());
    let worker = LocalWorker::new_with_connection_factory_and_actions_manager(
        Arc::new(local_worker_config),
        actions_manager.clone(),
        Box::new(move || {
            let mock_worker_api_client = mock_worker_api_client_clone.clone();
            Box::pin(async move { Ok(mock_worker_api_client) })
        }),
        // Yield instead of sleeping so loops that spin on the sleep fn (e.g.
        // the actions-in-transit drain after a disconnect) still give the
        // runtime a chance to drop aborted tasks, as real sleeps do.
        Box::new(move |_| Box::pin(async move { tokio::task::yield_now().await })),
    );
    let (shutdown_tx_test, _) = broadcast::channel::<ShutdownGuard>(BROADCAST_CAPACITY);

    let registration = worker.registration();
    let drop_guard = spawn!("local_worker_spawn", async move {
        worker.run(shutdown_tx_test.subscribe()).await
    });

    let (tx_stream, streaming_response) = setup_grpc_stream();
    TestContext {
        client: mock_worker_api_client,
        actions_manager,

        maybe_streaming_response: Some(streaming_response),
        maybe_tx_stream: Some(tx_stream),
        registration,

        drop_guard,
    }
}

pub(crate) async fn setup_local_worker(
    platform_properties: HashMap<String, WorkerProperty>,
) -> TestContext {
    const ARBITRARY_LARGE_TIMEOUT: f32 = 10000.;
    let local_worker_config = LocalWorkerConfig {
        platform_properties,
        worker_api_endpoint: EndpointConfig {
            timeout: Some(ARBITRARY_LARGE_TIMEOUT),
            ..Default::default()
        },
        ..Default::default()
    };
    setup_local_worker_with_config(local_worker_config).await
}

pub(crate) struct TestContext {
    pub client: MockWorkerApiClient,
    pub actions_manager: Arc<MockRunningActionsManager>,

    pub maybe_streaming_response: Option<Response<Streaming<UpdateForWorker>>>,
    pub maybe_tx_stream: Option<mpsc::Sender<Frame<Bytes>>>,
    /// The flag the worker's readiness reads.
    pub registration: Arc<WorkerRegistration>,

    drop_guard: JoinHandleDropGuard<Result<(), Error>>,
}

impl TestContext {
    pub(crate) async fn finish(self) -> Result<(), Error> {
        self.drop_guard
            .await
            .map_err(|err| nativelink_error::make_input_err!("Worker task failed: {err}"))?
    }
}
