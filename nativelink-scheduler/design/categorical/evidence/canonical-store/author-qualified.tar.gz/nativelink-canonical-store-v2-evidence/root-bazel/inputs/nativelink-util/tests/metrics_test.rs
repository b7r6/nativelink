// Copyright 2025 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use nativelink_util::action_messages::{
    ActionResult, ActionStage, ExecutionMetadata, FileInfo, NameOrPath,
};
use nativelink_util::common::DigestInfo;
use nativelink_util::metrics::{
    AGE_BUCKET_LABELS, AgeBuckets, CACHE_METRICS, CacheMetricAttrs, EXECUTION_METRICS,
    ExecutionMetricAttrs, ExecutionStage, WORKER_METRICS, WorkerDisconnectReason,
    execution_output_bytes, make_execution_attributes, peak_memory_sample, pool_available_sample,
    record_cache_entries_delta, record_completed_execution_metrics, record_connection_acquired,
    record_connection_reconnect, record_executing_ages, record_execution_cpu_time,
    record_execution_peak_memory, record_health_check, record_matching_pass, record_queue_ages,
    record_rpc_served, record_store_tier_io, record_store_tier_read, record_worker_connected,
    record_worker_disconnected, record_worker_keepalive, record_worker_state, saturating_i64,
    split_grpc_path,
};
use opentelemetry::KeyValue;

#[test]
fn test_cache_metric_attrs() {
    let base_attrs = vec![
        KeyValue::new("cache.type", "test_cache"),
        KeyValue::new("instance", "test_instance"),
    ];

    let attrs = CacheMetricAttrs::new(&base_attrs);

    // Verify that the pre-computed attributes contain the expected values
    let read_hit_attrs = attrs.read_hit();
    assert_eq!(read_hit_attrs.len(), 4);
    assert!(
        read_hit_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "cache.type" && kv.value.to_string() == "test_cache")
    );
    assert!(
        read_hit_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "cache.operation.name" && kv.value.to_string() == "read")
    );
    assert!(
        read_hit_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "cache.operation.result" && kv.value.to_string() == "hit")
    );
}

#[test]
fn test_execution_metric_attrs() {
    let base_attrs = vec![
        KeyValue::new("execution.instance", "test_instance"),
        KeyValue::new("execution.worker_id", "worker_123"),
    ];

    let attrs = ExecutionMetricAttrs::new(&base_attrs);

    // Verify that the pre-computed attributes contain the expected values
    let queued_attrs = attrs.queued();
    assert_eq!(queued_attrs.len(), 3);
    assert!(queued_attrs.iter().any(
        |kv| kv.key.as_str() == "execution.instance" && kv.value.to_string() == "test_instance"
    ));
    assert!(
        queued_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "execution.stage" && kv.value.to_string() == "queued")
    );

    let completed_success_attrs = attrs.completed_success();
    assert_eq!(completed_success_attrs.len(), 4);
    assert!(
        completed_success_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "execution.stage" && kv.value.to_string() == "completed")
    );
    assert!(
        completed_success_attrs
            .iter()
            .any(|kv| kv.key.as_str() == "execution.result" && kv.value.to_string() == "success")
    );
}

#[test]
fn test_make_execution_attributes() {
    let attrs = make_execution_attributes("test_instance", Some("worker_456"), Some(100));

    assert_eq!(attrs.len(), 3);
    assert!(attrs.iter().any(
        |kv| kv.key.as_str() == "execution.instance" && kv.value.to_string() == "test_instance"
    ));
    assert!(
        attrs
            .iter()
            .any(|kv| kv.key.as_str() == "execution.worker_id"
                && kv.value.to_string() == "worker_456")
    );
    assert!(
        attrs
            .iter()
            .any(|kv| kv.key.as_str() == "execution.priority"
                && kv.value == opentelemetry::Value::I64(100))
    );
}

#[test]
fn test_metrics_lazy_initialization() {
    // Verify that the lazy static initialization works
    let _cache_metrics = &*CACHE_METRICS;
    let _execution_metrics = &*EXECUTION_METRICS;
    let _worker_metrics = &*WORKER_METRICS;

    // If we got here without panicking, the metrics were initialized successfully
}

#[test]
fn test_action_stage_to_execution_stage_conversion() {
    // Test conversion from owned ActionStage values
    assert_eq!(
        ExecutionStage::from(ActionStage::Unknown),
        ExecutionStage::Unknown
    );
    assert_eq!(
        ExecutionStage::from(ActionStage::CacheCheck),
        ExecutionStage::CacheCheck
    );
    assert_eq!(
        ExecutionStage::from(ActionStage::Queued),
        ExecutionStage::Queued
    );
    assert_eq!(
        ExecutionStage::from(ActionStage::Executing),
        ExecutionStage::Executing
    );

    // Test that Completed variants map to ExecutionStage::Completed
    let action_result = ActionResult::default();
    assert_eq!(
        ExecutionStage::from(ActionStage::Completed(action_result)),
        ExecutionStage::Completed
    );

    // Note: We can't easily test CompletedFromCache without creating a ProtoActionResult,
    // but the implementation handles it the same as Completed
}

#[test]
fn test_action_stage_ref_to_execution_stage_conversion() {
    // Test conversion from ActionStage references
    let unknown = ActionStage::Unknown;
    let cache_check = ActionStage::CacheCheck;
    let queued = ActionStage::Queued;
    let executing = ActionStage::Executing;
    let completed = ActionStage::Completed(ActionResult::default());

    assert_eq!(ExecutionStage::from(&unknown), ExecutionStage::Unknown);
    assert_eq!(
        ExecutionStage::from(&cache_check),
        ExecutionStage::CacheCheck
    );
    assert_eq!(ExecutionStage::from(&queued), ExecutionStage::Queued);
    assert_eq!(ExecutionStage::from(&executing), ExecutionStage::Executing);
    assert_eq!(ExecutionStage::from(&completed), ExecutionStage::Completed);
}

#[test]
fn test_action_stage_conversion_avoids_clone() {
    use nativelink_util::action_messages::{FileInfo, NameOrPath};
    use nativelink_util::common::DigestInfo;

    // This test verifies that using a reference doesn't clone the large ActionResult
    let large_file_info = FileInfo {
        name_or_path: NameOrPath::Path("test.txt".to_string()),
        digest: DigestInfo::new([0u8; 32], 100),
        is_executable: false,
    };
    let large_action_result = ActionResult {
        output_files: vec![large_file_info; 1000], // Large vector to make clone expensive
        ..Default::default()
    };
    let completed = ActionStage::Completed(large_action_result);

    // Using a reference should be fast even with large data
    let start = std::time::Instant::now();
    for _ in 0..10000 {
        let _stage = ExecutionStage::from(&completed);
    }
    let elapsed = start.elapsed();

    // This should complete very quickly since we're not cloning
    // In practice, 10000 conversions should take less than 1ms
    assert!(
        elapsed.as_millis() < 100,
        "Reference conversion took too long: {elapsed:?}"
    );
}

#[test]
fn execution_output_bytes_sums_files_and_streams() {
    let hash = "0123456789abcdef000000000000000000010000000000000123456789abcdef";
    let result = ActionResult {
        output_files: vec![
            FileInfo {
                name_or_path: NameOrPath::Path("out1".to_string()),
                digest: DigestInfo::try_new(hash, 1000).unwrap(),
                is_executable: false,
            },
            FileInfo {
                name_or_path: NameOrPath::Path("out2".to_string()),
                digest: DigestInfo::try_new(hash, 234).unwrap(),
                is_executable: false,
            },
        ],
        stdout_digest: DigestInfo::try_new(hash, 10).unwrap(),
        stderr_digest: DigestInfo::try_new(hash, 20).unwrap(),
        ..ActionResult::default()
    };
    assert_eq!(execution_output_bytes(&result), 1000 + 234 + 10 + 20);
}

#[test]
fn record_completed_execution_metrics_guards_unpopulated_metadata() {
    use core::time::Duration;
    use std::time::SystemTime;

    let queued = SystemTime::UNIX_EPOCH + Duration::from_secs(1_000_000);
    let at = |n| queued + Duration::from_secs(n);
    let populated = ActionResult {
        execution_metadata: ExecutionMetadata {
            queued_timestamp: queued,
            worker_start_timestamp: at(2),
            worker_completed_timestamp: at(12),
            input_fetch_start_timestamp: at(2),
            input_fetch_completed_timestamp: at(4),
            execution_start_timestamp: at(4),
            execution_completed_timestamp: at(11),
            output_upload_start_timestamp: at(11),
            output_upload_completed_timestamp: at(12),
            ..ExecutionMetadata::default()
        },
        ..ActionResult::default()
    };
    // Should record without panicking.
    record_completed_execution_metrics(&populated, "instance", Some("worker-1"), Some(3));

    // Default (UNIX_EPOCH) metadata must skip the duration records cleanly.
    record_completed_execution_metrics(&ActionResult::default(), "instance", None, None);
}

#[test]
fn test_worker_disconnect_reason_labels() {
    // These become metric label values, so they are part of the wire contract
    // and dashboards break if they change.
    assert_eq!(
        WorkerDisconnectReason::Disconnected.as_str(),
        "disconnected"
    );
    assert_eq!(WorkerDisconnectReason::Timeout.as_str(), "timeout");
    assert_eq!(WorkerDisconnectReason::Drained.as_str(), "drained");
}

#[test]
fn test_worker_metric_helpers_are_callable() {
    // The instruments are global, so there is nothing to read back here
    // without a test exporter. This guards the call sites: every helper stays
    // callable with the arguments the scheduler passes.
    record_worker_connected();
    record_worker_keepalive();
    record_worker_state("draining", true);
    record_worker_state("draining", false);
    record_worker_disconnected(WorkerDisconnectReason::Disconnected, false, false);

    // A worker that was draining and paused when it left unwinds both gauges.
    record_worker_connected();
    record_worker_state("draining", true);
    record_worker_state("paused", true);
    record_worker_disconnected(WorkerDisconnectReason::Timeout, true, true);
}

#[test]
fn test_split_grpc_path() {
    assert_eq!(
        split_grpc_path(
            "/build.bazel.remote.execution.v2.ContentAddressableStorage/FindMissingBlobs"
        ),
        (
            "build.bazel.remote.execution.v2.ContentAddressableStorage",
            "FindMissingBlobs"
        )
    );
    assert_eq!(
        split_grpc_path("/google.bytestream.ByteStream/Write"),
        ("google.bytestream.ByteStream", "Write")
    );
    // Not a gRPC route. Reported whole rather than dropped, so an unexpected
    // path is still visible.
    assert_eq!(split_grpc_path("/healthz"), ("healthz", "unknown"));
    assert_eq!(split_grpc_path(""), ("", "unknown"));
}

#[test]
fn test_health_status_metric_labels() {
    use std::borrow::Cow;

    use nativelink_util::health_utils::HealthStatus;

    // Label values are part of the wire contract for dashboards.
    assert_eq!(
        HealthStatus::Ok {
            struct_name: "S",
            message: Cow::Borrowed("")
        }
        .metric_label(),
        "ok"
    );
    assert_eq!(
        HealthStatus::Failed {
            struct_name: "S",
            message: Cow::Borrowed("")
        }
        .metric_label(),
        "failed"
    );
    assert_eq!(
        HealthStatus::Timeout { struct_name: "S" }.metric_label(),
        "timeout"
    );
}

#[test]
fn test_new_metric_helpers_are_callable() {
    // Global instruments, so nothing to read back without a test exporter.
    // This guards the call sites against drift.
    record_rpc_served("/pkg.Service/Method", 0, 0.01);
    record_rpc_served("/pkg.Service/Method", 5, 1.5);
    record_matching_pass(0.002, true);
    record_matching_pass(0.002, false);
    record_store_tier_read("fast", "hit");
    record_store_tier_read("slow", "hit");
    record_store_tier_io("fast", "read", 4096);
    record_health_check("store", "ok");
    record_execution_peak_memory(512 * 1024, "main", "CppCompile", "COMPLETED");
    record_execution_cpu_time(90_000, "main", "CppCompile", "COMPLETED");
    record_connection_acquired("grpc", Some(12), false);
    record_connection_acquired("redis", Some(0), true);
    record_connection_acquired("grpc", None, false);
    record_connection_reconnect("redis");
}

#[test]
fn test_cache_size_helpers_are_callable() {
    // Global instruments, so nothing to read back without a test exporter.
    // Sizes past `i64::MAX` saturate rather than wrap to a negative delta.
    let attrs = [KeyValue::new("cache.type", "test_cache")];
    record_cache_entries_delta(4096, 1, &attrs);
    record_cache_entries_delta(-4096, -1, &attrs);
    record_cache_entries_delta(0, 0, &attrs);
    record_cache_entries_delta(saturating_i64(u64::MAX), saturating_i64(u64::MAX), &attrs);
    record_cache_entries_delta(-saturating_i64(u64::MAX), -saturating_i64(u64::MAX), &attrs);
}

/// An unlimited pool is a semaphore holding `Semaphore::MAX_PERMITS`, about
/// 2.3e18. Recording that as a histogram sample overflowed the SDK's `u64`
/// sum within a handful of samples and panicked a debug build, which killed a
/// tokio worker and turned every later connection request into a `SendError`.
///
/// Callers now pass `None` for an unlimited pool. This covers the clamp that
/// backstops them, which is the part that can be asserted without installing
/// a meter provider.
#[test]
fn pool_available_sample_clamps_an_unbounded_permit_count() {
    // Semaphore::MAX_PERMITS.
    assert_eq!(pool_available_sample(usize::MAX >> 3), 1024);
    assert_eq!(pool_available_sample(usize::MAX), 1024);
    // Real counts pass through untouched.
    assert_eq!(pool_available_sample(0), 0);
    assert_eq!(pool_available_sample(12), 12);
    assert_eq!(pool_available_sample(1024), 1024);
}

/// Peak memory arrives from a worker over gRPC, so a malfunctioning one could
/// report a value that overflows the histogram's `u64` sum the same way an
/// unbounded connection pool did.
#[test]
fn peak_memory_sample_bounds_an_absurd_reading() {
    // KiB to bytes for anything plausible.
    assert_eq!(peak_memory_sample(0), 0);
    assert_eq!(peak_memory_sample(1), 1024);
    assert_eq!(peak_memory_sample(4 * 1024 * 1024), 4 * 1024 * 1024 * 1024);
    // Absurd readings are bounded rather than wrapped.
    assert_eq!(peak_memory_sample(u64::MAX), 1 << 50);
    assert_eq!(peak_memory_sample(u64::MAX / 512), 1 << 50);
}

/// Each bound belongs to the bucket above it, the last bucket is open, and
/// the oldest age is kept.
#[test]
fn test_age_buckets_boundaries() {
    use core::time::Duration;

    let mut ages = AgeBuckets::default();
    for secs in [
        0, 59, 60, 299, 300, 899, 900, 1799, 1800, 3599, 3600, 86_400,
    ] {
        ages.observe(Duration::from_secs(secs));
    }
    assert_eq!(ages.counts(), [2, 2, 2, 2, 2, 2]);
    assert_eq!(ages.oldest(), Duration::from_hours(24));
    assert_eq!(AGE_BUCKET_LABELS.len(), ages.counts().len());
}

/// A start time after now, as clock skew between replicas can give, counts
/// as no age rather than failing or wrapping.
#[test]
fn test_age_buckets_future_start_counts_as_zero() {
    use core::time::Duration;
    use std::time::SystemTime;

    let now = SystemTime::UNIX_EPOCH + Duration::from_secs(1_000);
    let mut ages = AgeBuckets::default();
    ages.observe_since(now + Duration::from_secs(5), now);
    ages.observe_since(now.checked_sub(Duration::from_mins(2)).unwrap(), now);
    assert_eq!(ages.counts(), [1, 1, 0, 0, 0, 0]);
    assert_eq!(ages.oldest(), Duration::from_mins(2));
}

/// Recording with no meter provider installed is a no-op, not a panic.
#[test]
fn test_record_ages_without_provider() {
    let mut ages = AgeBuckets::default();
    ages.observe(core::time::Duration::from_secs(10));
    record_queue_ages(&ages);
    record_executing_ages(&AgeBuckets::default());
}
