// Copyright 2024 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use core::cmp::min;
use core::convert::Into;
use core::fmt::Debug;
use core::pin::Pin;
use core::sync::atomic::{AtomicBool, Ordering};
use core::time::Duration;
use std::borrow::Cow;
use std::collections::vec_deque::VecDeque;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::env;
use std::ffi::{OsStr, OsString};
#[cfg(target_family = "unix")]
use std::fs::Permissions;
#[cfg(target_family = "unix")]
use std::os::unix::fs::{MetadataExt, PermissionsExt};
#[cfg(target_family = "unix")]
use std::os::unix::process::ExitStatusExt;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::{Arc, Weak};
use std::time::SystemTime;

use bytes::{Bytes, BytesMut};
use filetime::{FileTime, set_file_mtime};
use formatx::Template;
use futures::future::{
    BoxFuture, Fuse, Future, FutureExt, TryFutureExt, join_all, try_join, try_join_all,
};
use futures::stream::{FuturesUnordered, StreamExt, TryStreamExt};
use nativelink_config::cas_server::{
    Buck2FileCaptureConfig, DiskEnforcement, EnvironmentSource, MemoryEnforcement,
    ResourceEnforcementConfig, UploadActionResultConfig, UploadCacheResultsStrategy,
};
use nativelink_error::{Code, Error, ResultExt, make_err, make_input_err};
use nativelink_metric::MetricsComponent;
use nativelink_proto::build::bazel::remote::execution::v2::{
    Action, ActionResult as ProtoActionResult, Command as ProtoCommand,
    Directory as ProtoDirectory, Directory, DirectoryNode, ExecuteResponse, FileNode, SymlinkNode,
    Tree as ProtoTree, UpdateActionResultRequest,
};
use nativelink_proto::com::github::trace_machina::nativelink::remote_execution::{
    ActionResourceUsage, AuthorityResources, HistoricalExecuteResponse, Reservation,
    ResourceOutcome, StartExecute,
};
use nativelink_store::ac_utils::{
    ESTIMATED_DIGEST_SIZE, compute_buf_digest, get_and_decode_digest, serialize_and_upload_message,
};
use nativelink_store::cas_utils::is_zero_digest;
use nativelink_store::fast_slow_store::FastSlowStore;
use nativelink_store::filesystem_store::{FileEntry, FileEntryImpl, FilesystemStore};
use nativelink_store::grpc_store::GrpcStore;
use nativelink_util::action_messages::{
    ActionInfo, ActionResult, DirectoryInfo, ExecutionMetadata, FileInfo, NameOrPath, OperationId,
    SymlinkInfo, to_execute_response,
};
use nativelink_util::common::{DigestInfo, fs};
use nativelink_util::digest_hasher::{DigestHasher, DigestHasherFunc};
use nativelink_util::metrics::{INPUT_MOUNT_METRICS, record_input_relink, record_prepare_retry};
use nativelink_util::metrics_utils::{AsyncCounterWrapper, CounterWithTime};
use nativelink_util::store_trait::{Store, StoreLike, UploadSizeInfo};
use nativelink_util::task::JoinHandleDropGuard;
use nativelink_util::work_progress::{self, ProgressObserver, ProgressPhase, WorkKind};
use nativelink_util::{background_spawn, spawn, spawn_blocking};
use parking_lot::Mutex;
use prost::Message;
use relative_path::RelativePath;
use scopeguard::{ScopeGuard, guard};
use serde::Deserialize;
use tokio::io::{AsyncReadExt, AsyncSeekExt, AsyncWriteExt};
use tokio::process;
use tokio::sync::{Notify, Semaphore, SemaphorePermit, oneshot, watch};
use tokio::time::Instant;
use tokio_stream::wrappers::ReadDirStream;
use tonic::Request;
use tracing::{debug, error, info, trace, warn};
use uuid::Uuid;

use crate::buck2_file_capture::Buck2FileCapture;
use crate::input_mounts::InputMounts;
use crate::persistent_worker::{
    Input as PersistentWorkerInput, PersistentWorkerPool, PoolConfig, WireFormat, WorkRequest,
    WorkerKey,
};

/// For simplicity we use a fixed exit code for cases when our program is terminated
/// due to a signal.
const EXIT_CODE_FOR_SIGNAL: i32 = 9;

const SUPPORTS_WORKERS_PROPERTY: &str = "supports-workers";
const REQUIRES_WORKER_PROTOCOL_PROPERTY: &str = "requires-worker-protocol";

/// Default strategy for uploading historical results.
/// Note: If this value changes the config documentation
/// should reflect it.
const DEFAULT_HISTORICAL_RESULTS_STRATEGY: UploadCacheResultsStrategy =
    UploadCacheResultsStrategy::FailuresOnly;

#[cfg(target_os = "linux")]
const RESOURCE_USAGE_SAMPLE_INTERVAL: Duration = Duration::from_millis(250);

/// How many output files are open for upload at once, across the whole
/// output tree: one semaphore, taken around each file from open to upload,
/// so nested directories cannot multiply the bound. An unbounded set has hit
/// the descriptor limit on actions with tens of thousands of outputs. The
/// same number bounds each stream's fan-out.
const UPLOAD_CONCURRENCY: usize = 64;

/// What the sampler observed over an action's lifetime.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct SampledResourceUsage {
    peak_memory_kb: u64,
    cpu_time_ms: u64,
    /// The last reading before the group was gone, which is what a kernel
    /// kill is judged against.
    last_memory_kb: u64,
    /// The most the action's own files under its directory came to, when
    /// disk was measured; 0 otherwise.
    peak_disk_kb: u64,
}

/// Why the worker ended an action before the action ended itself.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KillReason {
    Timeout,
    Memory,
    Disk,
    External,
}

const SIGKILL_NUMBER: i32 = 9;

/// Appended to a `NotFound` raised while fetching something the client
/// referenced by digest (the action, its command, its inputs), so the
/// worker loop can tell a missing input from any other missing thing
/// without reading a store's wording.
pub const MISSING_INPUT_ERROR_TIP: &str = "action input missing from CAS";

fn tag_missing_input(err: Error) -> Error {
    if err.code == Code::NotFound {
        err.append(MISSING_INPUT_ERROR_TIP)
    } else {
        err
    }
}

/// How long a killed action's output pipes, or those of one that left
/// stragglers behind, get to drain. They close when every process holding
/// them is gone, which the SIGKILL to the group sees to; a process that
/// left the group could still hold them, so that wait is bounded, and what
/// was read by then is kept. An action that exited cleanly with nothing
/// left behind is read to the end.
const OUTPUT_DRAIN_TIMEOUT: Duration = Duration::from_secs(5);

/// Classifies how an action ended. A kill the worker sent names itself; a
/// SIGKILL nobody here sent, with the last memory sample within 10% of the
/// limit, is the kernel's OOM killer; any other signal is external.
pub fn classify_outcome(
    kill_reason: Option<KillReason>,
    signal: Option<i32>,
    last_memory_kb: u64,
    memory_limit_kb: Option<u64>,
) -> (ResourceOutcome, bool) {
    match (kill_reason, signal) {
        (Some(KillReason::Memory), _) => (ResourceOutcome::KilledMemory, true),
        (Some(KillReason::Disk), _) => (ResourceOutcome::KilledDisk, true),
        (Some(KillReason::Timeout), _) => (ResourceOutcome::KilledTimeout, false),
        (None, None) => (ResourceOutcome::Completed, false),
        (None, Some(SIGKILL_NUMBER)) => {
            let near_limit = memory_limit_kb.is_some_and(|limit_kb| {
                limit_kb > 0 && last_memory_kb.saturating_mul(10) >= limit_kb.saturating_mul(9)
            });
            if near_limit {
                (ResourceOutcome::KilledMemory, false)
            } else {
                (ResourceOutcome::KilledExternal, false)
            }
        }
        (Some(KillReason::External), _) | (None, Some(_)) => {
            (ResourceOutcome::KilledExternal, false)
        }
    }
}

#[cfg(target_os = "linux")]
type SpawnedChild = crate::namespace_utils::MaybeNamespacedChild;
#[cfg(not(target_os = "linux"))]
type SpawnedChild = process::Child;

/// SIGKILL through the child wrapper, which takes the whole process group
/// with it, logged if it fails.
async fn hard_kill(child: &mut SpawnedChild, why: &str) {
    if let Err(err) = child.kill().await {
        error!(?err, why, "Could not kill process in RunningActionsManager");
    }
}

/// Starts stopping an action. With a grace period the process group gets
/// SIGTERM and the returned future fires when SIGKILL is due; without one
/// SIGKILL goes out now and the future never fires.
async fn stop_action(
    child: &mut SpawnedChild,
    grace: Duration,
    why: &str,
) -> Fuse<BoxFuture<'static, ()>> {
    debug!(grace_ms = grace.as_millis(), why, "Stopping action");
    #[cfg(target_os = "linux")]
    if !grace.is_zero()
        && let Some(pgid) = child.id()
    {
        signal_process_group(pgid, libc::SIGTERM);
        return tokio::time::sleep(grace).boxed().fuse();
    }
    hard_kill(child, why).await;
    Fuse::terminated()
}

/// The reservation the action was admitted with, read back from its
/// platform properties so the measurement travels with its yardstick.
fn reservation_of(
    properties: &HashMap<String, String>,
    memory_property: Option<&str>,
    disk_property: Option<&str>,
) -> Option<Reservation> {
    let read = |name: &str| {
        properties
            .get(name)
            .and_then(|v| v.trim().parse::<u64>().ok())
    };
    let reservation = Reservation {
        cpu_count: read("cpu_count").unwrap_or(0),
        memory_kb: read(memory_property.unwrap_or("memory_kb")).unwrap_or(0),
        disk_kb: read(disk_property.unwrap_or("disk_kb")).unwrap_or(0),
    };
    (reservation.cpu_count > 0 || reservation.memory_kb > 0 || reservation.disk_kb > 0)
        .then_some(reservation)
}

#[cfg(target_os = "linux")]
fn pod_memory_limit_kb() -> Option<u64> {
    crate::capacity::observe_cgroup().map(|observed| observed.memory_kb)
}
#[cfg(not(target_os = "linux"))]
const fn pod_memory_limit_kb() -> Option<u64> {
    None
}

#[cfg(target_os = "linux")]
struct ActionResourceUsageSampler {
    stop_tx: watch::Sender<bool>,
    handle: tokio::task::JoinHandle<SampledResourceUsage>,
}

/// What the sampler found over a ceiling, with the figure it saw. Only the
/// Linux sampler sends one; the arm that receives it is built everywhere.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
enum OverLimit {
    Memory(u64),
    Disk(u64),
}

/// The ceilings the sampler enforces. Memory: two consecutive samples over
/// `memory_limit_kb`, or one at twice it. Disk: one sample of the action's
/// own files over `disk_limit_kb`. The first breach is sent on
/// `over_limit_tx` and the caller kills the action; nothing is sent when no
/// ceiling is set, and the caller keeps the sender alive so the receiver
/// stays pending.
#[cfg(target_os = "linux")]
struct Ceilings {
    memory_limit_kb: Option<u64>,
    disk_limit_kb: Option<u64>,
    over_limit_tx: Option<oneshot::Sender<OverLimit>>,
}

/// One disk sample every this many memory samples: a walk of the action
/// directory is a stat per file, so it runs every ten seconds, not four
/// times a second.
#[cfg(target_os = "linux")]
const DISK_SAMPLE_EVERY: u32 = 40;

#[cfg(target_os = "linux")]
fn start_action_resource_usage_sampler(
    pgid: u32,
    ceilings: Ceilings,
    disk_directory: Option<(PathBuf, SystemTime)>,
) -> ActionResourceUsageSampler {
    let (stop_tx, stop_rx) = watch::channel(false);
    let handle = background_spawn!(
        "action_resource_usage_sampler",
        sample_action_resource_usage(pgid, stop_rx, ceilings, disk_directory)
    );
    ActionResourceUsageSampler { stop_tx, handle }
}

/// KiB on disk of the files under `directory` that the action wrote: regular
/// files modified at or after `since`, the directory's stamp from just
/// before its command started (see [`directory_stamp`]). Its
/// inputs were materialized before that, as hard links into the CAS store
/// or private copies, and keep their earlier times, so they are told apart
/// by time rather than by link count: a hard link drops to one link the
/// moment the store evicts the blob, and would then pass for the action's
/// own. Symlinks and the directories' own blocks are not counted. Blocking;
/// run it on the blocking pool.
#[cfg(target_family = "unix")]
pub fn directory_private_kb(directory: &Path, since: SystemTime) -> u64 {
    let mut total_blocks: u64 = 0;
    let mut pending = vec![directory.to_path_buf()];
    while let Some(dir) = pending.pop() {
        let Ok(entries) = std::fs::read_dir(&dir) else {
            continue;
        };
        for entry in entries.flatten() {
            let Ok(metadata) = entry.metadata() else {
                continue;
            };
            let file_type = metadata.file_type();
            if file_type.is_dir() {
                pending.push(entry.path());
            } else if file_type.is_file()
                && metadata.modified().is_ok_and(|modified| modified >= since)
            {
                total_blocks = total_blocks.saturating_add(metadata.blocks());
            }
        }
    }
    // st_blocks are 512-byte units whatever the filesystem's block size.
    total_blocks / 2
}

#[cfg(not(target_family = "unix"))]
pub fn directory_private_kb(_directory: &Path, _since: SystemTime) -> u64 {
    0
}

/// Touches `directory` and returns the time the filesystem recorded for it.
/// File mtimes come from the kernel's coarse clock, which on Linux can lag
/// the wall clock by a tick, so a file written right after
/// `SystemTime::now()` can look older than that moment. The walk compares
/// mtimes against this stamp, taken from the same clock, so a file the
/// action writes afterwards is never older than it.
#[cfg(target_family = "unix")]
pub fn directory_stamp(directory: &Path) -> Result<SystemTime, Error> {
    use std::os::unix::io::AsRawFd;
    let dir = std::fs::File::open(directory)
        .err_tip(|| format!("Opening {} to stamp it", directory.display()))?;
    // SAFETY: a zeroed timespec is valid; only tv_nsec is set.
    let mut now: libc::timespec = unsafe { core::mem::zeroed() };
    now.tv_nsec = libc::UTIME_NOW;
    let times = [now, now];
    // SAFETY: futimens takes an open fd and a pointer to two timespecs that
    // outlive the call.
    if unsafe { libc::futimens(dir.as_raw_fd(), times.as_ptr()) } != 0 {
        return Err(std::io::Error::last_os_error())
            .err_tip(|| format!("Stamping {}", directory.display()));
    }
    dir.metadata()
        .and_then(|metadata| metadata.modified())
        .err_tip(|| format!("Reading the stamp on {}", directory.display()))
}

#[cfg(not(target_family = "unix"))]
pub fn directory_stamp(_directory: &Path) -> Result<SystemTime, Error> {
    Ok(SystemTime::now())
}

/// Starts a disk sample: the action's own files, walked on the blocking
/// pool as a task of its own, so the memory samples carry on while a large
/// tree is being walked. `None` when there is no directory to measure.
#[cfg(target_os = "linux")]
fn start_disk_sample(
    directory: Option<&(PathBuf, SystemTime)>,
) -> Option<JoinHandleDropGuard<u64>> {
    let (directory, since) = directory?.clone();
    Some(spawn_blocking!("action_disk_sample", move || {
        directory_private_kb(&directory, since)
    }))
}

/// A signal to every process in the action's group. The action is its own
/// group leader, so this reaches the children a shell forked. The SIGKILL
/// at the end of a kill goes through the child wrapper, which takes the
/// group with it (or tells the stub, namespaced); this is for the SIGTERM
/// that gives an action its grace, and for the stragglers left once the
/// action's own process has exited. Returns whether any process got it.
#[cfg(target_family = "unix")]
fn signal_process_group(pgid: u32, signal: i32) -> bool {
    let Ok(pgid) = i32::try_from(pgid) else {
        return false;
    };
    // SAFETY: killpg only takes integers and has no memory safety
    // considerations; a stale group id is reported as ESRCH, not acted on.
    unsafe { libc::killpg(pgid, signal) == 0 }
}

#[cfg(target_os = "linux")]
async fn finish_action_resource_usage_sampler(
    sampler: ActionResourceUsageSampler,
) -> Option<SampledResourceUsage> {
    let _ = sampler.stop_tx.send(true);
    sampler.handle.await.ok()
}

#[cfg(target_os = "linux")]
async fn sample_action_resource_usage(
    pgid: u32,
    mut stop_rx: watch::Receiver<bool>,
    mut ceilings: Ceilings,
    disk_directory: Option<(PathBuf, SystemTime)>,
) -> SampledResourceUsage {
    let mut peak_memory_kb = 0;
    let mut last_memory_kb = 0;
    let mut peak_disk_kb = 0;
    let mut samples_over_limit = 0u32;
    let mut samples_since_disk = DISK_SAMPLE_EVERY;
    // The walk in flight, if one is; polled, never awaited, from the loop.
    let mut disk_sample: Option<JoinHandleDropGuard<u64>> = None;
    // CPU time is cumulative per process and a process that exits stops
    // appearing, so summing the live group at the end would lose everything
    // short-lived. Keep the last figure seen for each pid and total them at
    // the end instead.
    let mut cpu_ticks_by_pid = HashMap::new();
    // What the group had already spent when sampling began. A one-shot
    // process starts at nothing; a pooled process carries every request it
    // served before, which is not this action's.
    let mut baseline_ticks: Option<u64> = None;

    let sample = |peak_memory_kb: &mut u64, cpu_ticks_by_pid: &mut HashMap<u32, u64>| {
        let observed = sample_process_group(pgid, cpu_ticks_by_pid);
        if let Some(memory_kb) = observed {
            *peak_memory_kb = (*peak_memory_kb).max(memory_kb);
        }
        observed
    };

    loop {
        let observed = sample(&mut peak_memory_kb, &mut cpu_ticks_by_pid);
        if baseline_ticks.is_none() {
            baseline_ticks = Some(cpu_ticks_by_pid.values().sum());
        }
        if let Some(memory_kb) = observed {
            last_memory_kb = memory_kb;
        }
        if observed.is_none() && !Path::new(&format!("/proc/{pgid}")).exists() {
            // The group leader has been reaped and no member process remains,
            // so the action is finished.
            break;
        }
        // Two consecutive samples over the ceiling, so one spike between
        // reads is not a kill; one sample at twice the ceiling is, because
        // an allocation that fast reaches the pod's limit before the next
        // read (observed: twelve 20 GiB allocators filled a 52 GiB pod in
        // under a second).
        if let (Some(observed_kb), Some(limit_kb)) = (observed, ceilings.memory_limit_kb) {
            if observed_kb > limit_kb {
                samples_over_limit += 1;
            } else {
                samples_over_limit = 0;
            }
            let gross = observed_kb >= limit_kb.saturating_mul(2);
            if (samples_over_limit >= 2 || gross)
                && let Some(over_limit_tx) = ceilings.over_limit_tx.take()
                && over_limit_tx.send(OverLimit::Memory(observed_kb)).is_err()
            {
                // The receiver is gone only when the action already ended.
                debug!(observed_kb, "Memory ceiling breached, action already ended");
            }
        }

        // A walk that finished since the last sample; the memory samples
        // above never waited for it.
        if let Some(handle) = disk_sample.as_mut()
            && let core::task::Poll::Ready(finished) = futures::poll!(handle)
        {
            disk_sample = None;
            if let Ok(disk_kb) = finished {
                peak_disk_kb = peak_disk_kb.max(disk_kb);
                if let Some(limit_kb) = ceilings.disk_limit_kb
                    && disk_kb > limit_kb
                    && let Some(over_limit_tx) = ceilings.over_limit_tx.take()
                    && over_limit_tx.send(OverLimit::Disk(disk_kb)).is_err()
                {
                    debug!(disk_kb, "Disk ceiling breached, action already ended");
                }
            }
        }
        // The periodic walk belongs to the soft limit; the guard alone
        // measures once, at the end, and pays no walk while running.
        samples_since_disk += 1;
        if ceilings.disk_limit_kb.is_some()
            && samples_since_disk >= DISK_SAMPLE_EVERY
            && disk_sample.is_none()
        {
            samples_since_disk = 0;
            disk_sample = start_disk_sample(disk_directory.as_ref());
        }

        if *stop_rx.borrow() {
            break;
        }

        tokio::select! {
            changed = stop_rx.changed() => {
                if changed.is_ok() && *stop_rx.borrow() {
                    if let Some(memory_kb) = sample(&mut peak_memory_kb, &mut cpu_ticks_by_pid) {
                        last_memory_kb = memory_kb;
                    }
                    break;
                }
            }
            () = tokio::time::sleep(RESOURCE_USAGE_SAMPLE_INTERVAL) => {}
        }
    }
    // What the action left on disk at the end is the figure that matters
    // for sizing; this walk, one stat per entry under the action directory,
    // is the only one the guard mode pays.
    drop(disk_sample.take());
    if let Some(handle) = start_disk_sample(disk_directory.as_ref())
        && let Ok(disk_kb) = handle.await
    {
        peak_disk_kb = peak_disk_kb.max(disk_kb);
    }

    SampledResourceUsage {
        peak_memory_kb,
        cpu_time_ms: ticks_to_millis(
            cpu_ticks_by_pid
                .values()
                .sum::<u64>()
                .saturating_sub(baseline_ticks.unwrap_or(0)),
        ),
        last_memory_kb,
        peak_disk_kb,
    }
}

/// Converts clock ticks from `/proc` into milliseconds.
///
/// `_SC_CLK_TCK` is 100 on every Linux we run on, but it is queryable so ask
/// rather than assume, and fall back to 100 if the query fails.
#[cfg(target_os = "linux")]
fn ticks_to_millis(ticks: u64) -> u64 {
    // SAFETY: `sysconf` takes an int and returns a long, with no memory
    // safety considerations.
    let hz = unsafe { libc::sysconf(libc::_SC_CLK_TCK) };
    let hz = if hz > 0 { hz as u64 } else { 100 };
    ticks.saturating_mul(1_000) / hz
}

/// Sums the resident memory of every process in the action's process group.
///
/// The action is spawned as its own process-group leader (see
/// `command_builder.process_group(0)` in `inner_execute`), so `pgid` equals
/// the spawned child's pid and every descendant inherits it. Sampling by
/// process group — rather than walking the parent/child tree from the spawned
/// pid — is required because an intermediate shell frequently exits and
/// reparents the real workload to the worker (PID 1); the tree walk then sees
/// only a childless zombie and reports zero. Process-group membership is
/// inherited and survives reparenting, and excludes the worker's own group.
/// Returns `None` when no member process can be read (the group is empty).
#[cfg(target_os = "linux")]
fn sample_process_group(pgid: u32, cpu_ticks_by_pid: &mut HashMap<u32, u64>) -> Option<u64> {
    let Ok(entries) = std::fs::read_dir("/proc") else {
        return None;
    };

    let mut total_kb = 0;
    let mut found_any_process = false;
    for entry in entries.flatten() {
        let Ok(member_pid) = entry.file_name().to_string_lossy().parse::<u32>() else {
            continue;
        };
        let Ok(stat) = std::fs::read_to_string(format!("/proc/{member_pid}/stat")) else {
            continue;
        };
        if parse_pgid_from_stat(&stat) != Some(pgid) {
            continue;
        }
        if let Some(ticks) = parse_cpu_ticks_from_stat(&stat) {
            // Monotonic per process, but a pid could in principle be reused
            // within one action, so never let the figure go backwards.
            let entry = cpu_ticks_by_pid.entry(member_pid).or_insert(0);
            *entry = (*entry).max(ticks);
        }
        if let Some(memory_kb) = read_process_memory_kb(member_pid) {
            total_kb += memory_kb;
            found_any_process = true;
        }
    }

    found_any_process.then_some(total_kb)
}

/// The process's share of its resident pages: `Pss` from `smaps_rollup`
/// divides a page shared by N processes N ways, so summed over the group it
/// counts a forked parent's pages, shared libraries and mapped inputs once.
/// `VmRSS` counts them once per process, and a test runner that forks eight
/// children would sample at several times what the cgroup charges. Falls
/// back to `VmRSS` where `smaps_rollup` cannot be read (kernels before 4.14).
#[cfg(target_os = "linux")]
fn read_process_memory_kb(pid: u32) -> Option<u64> {
    if let Ok(rollup) = std::fs::read_to_string(format!("/proc/{pid}/smaps_rollup"))
        && let Some(pss_kb) = parse_kb_field(&rollup, "Pss:")
    {
        return Some(pss_kb);
    }
    let status = std::fs::read_to_string(format!("/proc/{pid}/status")).ok()?;
    parse_kb_field(&status, "VmRSS:")
}

/// The value of a `Field:    1234 kB` line in `/proc` text, in KiB.
pub fn parse_kb_field(text: &str, field: &str) -> Option<u64> {
    text.lines().find_map(|line| {
        let rest = line.strip_prefix(field)?;
        rest.split_whitespace().next()?.parse().ok()
    })
}

/// Parses the process group id (`pgrp`, field 5) from the contents of a
/// `/proc/<pid>/stat` line.
///
/// `comm` (field 2) can contain spaces and parentheses, so fields are parsed
/// relative to the final `)` to avoid miscounting. Returns `None` when the
/// line is malformed.
#[cfg(target_os = "linux")]
pub fn parse_pgid_from_stat(stat: &str) -> Option<u32> {
    let after_comm = stat.rsplit_once(')')?.1;
    // Fields after the final ')': state(0) ppid(1) pgrp(2) ...
    after_comm.split_whitespace().nth(2)?.parse().ok()
}

/// Sums user and system CPU ticks (`utime` + `stime`, fields 14 and 15) from
/// the contents of a `/proc/<pid>/stat` line.
///
/// Parsed relative to the final `)` for the same reason as the pgid above:
/// `comm` can contain spaces and parentheses. Returns `None` when the line is
/// malformed.
///
/// `cutime`/`cstime` are deliberately not included. They only cover children
/// this process has already reaped, so adding them here would double count
/// every child that is still its own entry in the group.
#[cfg(target_os = "linux")]
pub fn parse_cpu_ticks_from_stat(stat: &str) -> Option<u64> {
    let after_comm = stat.rsplit_once(')')?.1;
    let mut fields = after_comm.split_whitespace();
    // Fields after the final ')': state(0) ppid(1) pgrp(2) session(3) tty(4)
    // tpgid(5) flags(6) minflt(7) cminflt(8) majflt(9) cmajflt(10)
    // utime(11) stime(12) ...
    let utime: u64 = fields.nth(11)?.parse().ok()?;
    let stime: u64 = fields.next()?.parse().ok()?;
    Some(utime.saturating_add(stime))
}

/// Valid string reasons for a failure.
/// Note: If these change, the documentation should be updated.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "snake_case")]
enum SideChannelFailureReason {
    /// Task should be considered timed out.
    Timeout,
}

/// This represents the json data that can be passed from the running process
/// to the parent via the `SideChannelFile`. See:
/// `config::EnvironmentSource::sidechannelfile` for more details.
/// Note: Any fields added here must be added to the documentation.
#[derive(Debug, Deserialize, Default)]
struct SideChannelInfo {
    /// If the task should be considered a failure and why.
    failure: Option<SideChannelFailureReason>,
}

fn action_supports_persistent_workers(
    action_info: &ActionInfo,
) -> Option<Result<WireFormat, Error>> {
    if action_info
        .platform_properties
        .get(SUPPORTS_WORKERS_PROPERTY)
        .is_none_or(|value| value != "1")
    {
        return None;
    }

    let protocol = action_info
        .platform_properties
        .get(REQUIRES_WORKER_PROTOCOL_PROPERTY)
        .map_or("proto", String::as_str);
    Some(WireFormat::parse(protocol))
}

fn os_args_to_strings(args: &[&OsStr]) -> Result<Vec<String>, Error> {
    args.iter()
        .map(|arg| {
            arg.to_str().map(str::to_owned).ok_or_else(|| {
                make_err!(
                    Code::InvalidArgument,
                    "Persistent worker command arguments must be valid UTF-8: {arg:?}"
                )
            })
        })
        .collect()
}

fn persistent_worker_request_arguments(argv: &[String]) -> Vec<String> {
    argv.iter()
        .skip(1)
        .skip_while(|arg| !arg.starts_with('@'))
        .cloned()
        .collect()
}
/// Maximum number of file-materialization (hardlink) or subdirectory
/// recursion futures polled concurrently per directory level. Higher values
/// drown APFS's per-volume metadata lock with `hardlink(2)` syscalls and
/// regress overall throughput vs lower-contention concurrency.
///
/// 64 is well above the inflection point on any modern Linux filesystem,
/// so this is also a no-op on Linux beyond replacing tokio scheduling
/// overhead.
const DOWNLOAD_TO_DIRECTORY_CONCURRENCY: usize = 64;

/// One permit per blob fetched into the worker's store, from the pool the
/// worker shares across every action it is staging. The pool is never
/// closed, so a refusal here is a bug, not a condition.
async fn acquire_download_permit(downloads: &Semaphore) -> Result<SemaphorePermit<'_>, Error> {
    downloads
        .acquire()
        .await
        .map_err(|e| make_err!(Code::Internal, "Input download pool closed: {e:?}"))
}

/// The pool `max_concurrent_input_downloads` asks for. At 0, the default,
/// the pool is too large to bound anything: each action then fetches its
/// inputs on its own, limited only by the per-level fan-out above.
fn input_download_pool(max_concurrent_input_downloads: usize) -> Semaphore {
    Semaphore::new(match max_concurrent_input_downloads {
        0 => Semaphore::MAX_PERMITS,
        n => n.min(Semaphore::MAX_PERMITS),
    })
}

/// How often a worker without `max_concurrent_input_downloads` may suggest
/// setting it. The signs that call for it arrive in storms; one line per
/// storm is advice, one per failed fetch would bury it.
const INPUT_POOL_HINT_INTERVAL: Duration = Duration::from_mins(10);

/// Suggests a shared input pool to a worker running without one, at most
/// once per `INPUT_POOL_HINT_INTERVAL`.
#[derive(Debug, Default)]
struct InputPoolHint {
    last: Mutex<Option<Instant>>,
}

impl InputPoolHint {
    /// Whether the hint is due at `now`. When it is, the next one is not
    /// due until a full interval has passed.
    fn due(&self, now: Instant) -> bool {
        let mut last = self.last.lock();
        if last.is_some_and(|last| now.saturating_duration_since(last) < INPUT_POOL_HINT_INTERVAL) {
            return false;
        }
        *last = Some(now);
        true
    }
}

/// Keeps every digest used by an action present in locally eviction-managed
/// CAS tiers.
///
/// A lease is registered before a digest is populated. This is important for
/// blobs that are not yet in the fast tier: reserving the key first prevents
/// the insertion that follows from immediately evicting the blob under pressure.
/// Every directly discoverable filesystem tier of the worker's
/// `FastSlowStore` is leased when present (including a `RefStore` target).
/// Transforming wrappers remain opaque by design. The reference count lets
/// concurrent actions share a digest safely.
#[derive(Debug)]
struct ActionInputLease {
    filesystem_stores: Vec<Arc<FilesystemStore>>,
    digests: Mutex<Option<HashSet<DigestInfo>>>,
}

impl ActionInputLease {
    fn new(
        cas_store: &FastSlowStore,
        command_digest: DigestInfo,
        input_root_digest: DigestInfo,
    ) -> Arc<Self> {
        let lease = Arc::new(Self {
            filesystem_stores: cas_store.get_filesystem_stores(),
            digests: Mutex::new(Some(HashSet::new())),
        });
        lease.lease_digest(&command_digest);
        lease.lease_digest(&input_root_digest);
        lease
    }

    fn lease_digest(&self, digest: &DigestInfo) {
        let mut digests = self.digests.lock();
        let Some(digests) = digests.as_mut() else {
            return;
        };
        if digests.insert(*digest) {
            for filesystem_store in &self.filesystem_stores {
                filesystem_store.lease_digest(digest);
            }
        }
    }

    fn take_release_work(&self) -> Option<(Vec<Arc<FilesystemStore>>, Vec<DigestInfo>)> {
        let digests = self.digests.lock().take()?.into_iter().collect();
        Some((self.filesystem_stores.clone(), digests))
    }

    fn spawn_release(&self) -> Option<tokio::task::JoinHandle<()>> {
        let (filesystem_stores, digests) = self.take_release_work()?;
        Some(background_spawn!(
            "action_input_lease_release",
            release_filesystem_stores(filesystem_stores, digests)
        ))
    }

    async fn release(self: Arc<Self>) {
        let Some(handle) = self.spawn_release() else {
            return;
        };
        // Detach the actual release before awaiting it so cancellation of the
        // action cleanup future cannot strand leases in a later filesystem
        // tier.
        let _result = handle.await;
    }
}

impl crate::directory_cache::DigestLease for ActionInputLease {
    fn acquire(&self, digest: &DigestInfo) {
        self.lease_digest(digest);
    }
}

impl Drop for ActionInputLease {
    fn drop(&mut self) {
        drop(self.spawn_release());
    }
}

async fn release_filesystem_stores(
    filesystem_stores: Vec<Arc<FilesystemStore>>,
    digests: Vec<DigestInfo>,
) {
    join_all(
        filesystem_stores
            .iter()
            .map(|filesystem_store| filesystem_store.release_digests(&digests)),
    )
    .await;
}

/// Aggressively download the digests of files and make a local folder from it. This function
/// gates each directory level to at most `DOWNLOAD_TO_DIRECTORY_CONCURRENCY`
/// concurrent in-flight materialization futures.
/// We require the `FilesystemStore` to be the `fast` store of `FastSlowStore`. This is for
/// efficiency reasons. We will request the `FastSlowStore` to populate the entry then we will
/// assume the `FilesystemStore` has the file available immediately after and hardlink the file
/// to a new location.
// Sadly we cannot use `async fn` here because the rust compiler cannot determine the auto traits
// of the future. So we need to force this function to return a dynamic future instead.
// see: https://github.com/rust-lang/rust/issues/78649
pub fn download_to_directory<'a>(
    cas_store: &'a FastSlowStore,
    filesystem_store: Pin<&'a FilesystemStore>,
    digest: &'a DigestInfo,
    current_directory: &'a str,
) -> BoxFuture<'a, Result<(), Error>> {
    async move {
        // No shared pool, as for a worker without
        // `max_concurrent_input_downloads`; the worker's own arrives through
        // `prepare_action_inputs`.
        let downloads = input_download_pool(0);
        download_to_directory_bounded(
            cas_store,
            filesystem_store,
            digest,
            current_directory,
            &downloads,
        )
        .await
    }
    .boxed()
}

/// `download_to_directory` drawing its fetches from `downloads`, the pool
/// the worker shares across the actions it stages.
pub fn download_to_directory_bounded<'a>(
    cas_store: &'a FastSlowStore,
    filesystem_store: Pin<&'a FilesystemStore>,
    digest: &'a DigestInfo,
    current_directory: &'a str,
    downloads: &'a Semaphore,
) -> BoxFuture<'a, Result<(), Error>> {
    download_to_directory_with_mounts(
        cas_store,
        filesystem_store,
        digest,
        current_directory,
        None,
        None,
        downloads,
    )
}

fn download_to_directory_with_mounts<'a>(
    cas_store: &'a FastSlowStore,
    filesystem_store: Pin<&'a FilesystemStore>,
    digest: &'a DigestInfo,
    current_directory: &'a str,
    input_lease: Option<Arc<ActionInputLease>>,
    input_mounts: Option<Arc<InputMounts>>,
    downloads: &'a Semaphore,
) -> BoxFuture<'a, Result<(), Error>> {
    async move {
        let (dirs, files, inline_nodes) = collect_download_links(
            cas_store,
            digest,
            current_directory,
            input_lease,
            input_mounts,
            downloads,
        )
        .await?;

        let (exec_files, plain_files): (Vec<_>, Vec<_>) =
            files.into_iter().partition(|file| file.executable);
        let mut links =
            resolve_plain_files(cas_store, filesystem_store, plain_files, downloads).await?;
        links.extend(resolve_exec_files(cas_store, filesystem_store, exec_files, downloads).await?);

        // Every directory exists before anything is written into one, so no
        // later pass has to create a parent it happens to need.
        fs::create_dir_many(dirs).await?;
        materialize_inline_nodes(cas_store, filesystem_store, inline_nodes, downloads).await?;
        materialize_links(cas_store, filesystem_store, links, downloads).await
    }
    .boxed()
}

/// A hardlink deferred to the end of the input-tree walk, so the whole tree is
/// materialized by one batched [`fs::hard_link_many`] pass instead of one
/// `spawn_blocking` dispatch per file.
struct PendingLink {
    src: PathBuf,
    dst: PathBuf,
    /// What `src` was resolved from, so a link whose source is gone by the
    /// time the batch runs can be resolved and made again.
    digest: DigestInfo,
    executable: bool,
    /// Keeps the CAS blob's `FileEntry` alive until the link is made, so the
    /// inode cannot be dropped out from under the batch. `None` for an
    /// executable variant, which is a private file outside the entry map and so
    /// has no entry to hold.
    ///
    /// A held entry pins the inode but does not stop an eviction from renaming
    /// the blob, and a variant is deleted outright by the eviction callback, so
    /// a link in the batch can still find its source gone; [`relink_evicted_input`]
    /// then fetches the blob back and links it at once. An operator who sees
    /// those repairs often is running the store at its ceiling and should enable
    /// `experimental_active_input_leases`, since a leased digest is not evicted,
    /// or raise the store's `max_bytes`.
    _keepalive: Option<Arc<FileEntryImpl>>,
}

/// A file whose CAS blob has not been resolved to a path yet.
struct PendingFile {
    digest: DigestInfo,
    dst: String,
    executable: bool,
}

/// The directories to create, the files to hardlink, and the nodes to
/// materialize one at a time, for one input subtree.
type CollectedTree = (Vec<PathBuf>, Vec<PendingFile>, Vec<InlineNode>);

/// How many evicted inputs of one tree are fetched back at once.
const INPUT_RELINK_CONCURRENCY: usize = 32;

/// How many times an input is fetched into the fast store and resolved
/// before the action fails. A store at its ceiling can take a blob away
/// again between the fetch and the lookup, or between the lookup and the
/// link.
const INPUT_FETCH_ATTEMPTS: u32 = 3;

/// The pause before a retry grows by this much per attempt, plus a jitter
/// of up to the same amount taken from the digest, so the retry does not
/// land in the eviction pass that took the blob and a tree's inputs do not
/// all come back in one burst.
const INPUT_FETCH_PAUSE_STEP_MS: u64 = 20;

fn input_fetch_pause(attempt: u32, digest: &DigestInfo) -> Duration {
    let attempt = u64::from(attempt);
    let jitter = (u64::from(digest.packed_hash()[0]) * attempt) % INPUT_FETCH_PAUSE_STEP_MS;
    Duration::from_millis(INPUT_FETCH_PAUSE_STEP_MS * attempt + jitter)
}

/// The pause before a whole input tree is fetched again doubles from here.
const PREPARE_RETRY_PAUSE_MS: u64 = 1000;

/// The pause before a whole input tree is fetched again never exceeds this.
const PREPARE_RETRY_PAUSE_CAP_MS: u64 = 30_000;

/// Whether a failed input fetch is worth trying again from this worker.
/// These are the codes the store retrier itself treats as transient; a
/// throttled object store surfaces as `Internal` once the retrier gives up,
/// and an unclassified store failure as `Unknown`. The worker's own
/// filesystem lands on those two codes as well: a full disk, a blob at
/// its link limit or a read-only mount map to `Unknown`, a broken pipe to
/// `Internal`. A worker whose disk is the problem has to hand the action
/// back so it lands on a healthy one, not fetch into the same disk until
/// the deadline, so an operating system error is never retried here. Such
/// an error carries the OS error number in its message; a store's does not.
fn is_transient_fetch_error(err: &Error) -> bool {
    match err.code {
        Code::Unavailable
        | Code::ResourceExhausted
        | Code::Aborted
        | Code::DeadlineExceeded
        | Code::DataLoss => true,
        Code::Internal | Code::Unknown => !is_os_error(err),
        _ => false,
    }
}

/// Whether the error was raised by the operating system on this worker:
/// `std::io::Error` prints those as `... (os error N)`.
fn is_os_error(err: &Error) -> bool {
    err.messages
        .iter()
        .any(|message| message.contains("(os error "))
}

/// Pause before fetching the input tree again: 1 s, 2 s, 4 s ... capped at
/// 30 s, shortened by up to a quarter with a jitter taken from the digest so
/// the workers that failed together do not all come back together.
fn prepare_retry_pause(attempt: u32, digest: &DigestInfo) -> Duration {
    let doublings = attempt.saturating_sub(1).min(5);
    let base_ms = (PREPARE_RETRY_PAUSE_MS << doublings).min(PREPARE_RETRY_PAUSE_CAP_MS);
    let jitter_byte = (u64::from(digest.packed_hash()[0]) * u64::from(attempt)) % 256;
    Duration::from_millis(base_ms - base_ms * jitter_byte / 1024)
}

/// Counts the retries of one input fetch on `worker.prepare.retries` and
/// settles it on exactly one terminal outcome once a retry was made:
/// `recovered`, `exhausted`, `failed` when a later attempt failed for good,
/// or `abandoned` when the fetch was dropped mid-retry by a kill or the
/// download timeout. A fetch that succeeded or failed first time records
/// nothing, so the terminal outcomes add up to the fetches retried.
struct PrepareRetries<R: Fn(&'static str)> {
    record: R,
    retries: u32,
    settled: bool,
}

impl<R: Fn(&'static str)> PrepareRetries<R> {
    const fn new(record: R) -> Self {
        Self {
            record,
            retries: 0,
            settled: false,
        }
    }

    fn retried(&mut self) {
        self.retries += 1;
        (self.record)("retried");
    }

    fn settle(mut self, outcome: &'static str) {
        self.settled = true;
        if self.retries > 0 {
            (self.record)(outcome);
        }
    }
}

impl<R: Fn(&'static str)> Drop for PrepareRetries<R> {
    fn drop(&mut self) {
        if !self.settled && self.retries > 0 {
            (self.record)("abandoned");
        }
    }
}

/// Records on `worker.prepare.retries`. A named function rather than the
/// helper itself, so the metrics reference generator sees the call.
fn record_prepare_outcome(outcome: &'static str) {
    record_prepare_retry(outcome);
}

/// Fetches a blob into the fast store with `populate` and resolves it there
/// with `resolve`, again when the store has taken it away in between.
async fn fetch_and_resolve<T, P, PFut, R, RFut>(
    digest: DigestInfo,
    populate: P,
    resolve: R,
) -> Result<T, Error>
where
    P: Fn() -> PFut,
    PFut: Future<Output = Result<(), Error>>,
    R: Fn() -> RFut,
    RFut: Future<Output = Result<T, Error>>,
{
    let mut attempt = 1;
    loop {
        populate()
            .await
            .err_tip(|| format!("Fetching {digest} for an input"))?;
        match resolve().await {
            Err(err) if err.code == Code::NotFound => {
                if attempt >= INPUT_FETCH_ATTEMPTS {
                    record_input_relink("exhausted");
                    return Err(err);
                }
                tokio::time::sleep(input_fetch_pause(attempt, &digest)).await;
                attempt += 1;
            }
            result => return result,
        }
    }
}

/// Executes every deferred hardlink of an input tree in one batched pass.
///
/// A link whose source has gone missing since it was resolved is made again
/// from a fresh copy of the blob; any other failure fails the tree.
async fn materialize_links(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    links: Vec<PendingLink>,
    downloads: &Semaphore,
) -> Result<(), Error> {
    let pairs = links
        .iter()
        .map(|link| (link.src.clone(), link.dst.clone()))
        .collect();
    let mut evicted = Vec::new();
    for (link, result) in links.iter().zip(fs::hard_link_many(pairs).await?) {
        let Err(err) = result else {
            continue;
        };
        // `NotFound` is the source: this walk made the destination's parent.
        // The store evicted the blob, or deleted the variant, after it was
        // resolved. Looking for the source now would prove nothing, since a
        // neighbouring action that stages the same file builds the variant
        // again within milliseconds; the link is made again from a fetch.
        if err.code != Code::NotFound {
            return Err(hardlink_error(filesystem_store, link, err));
        }
        evicted.push(link);
    }
    if evicted.is_empty() {
        return Ok(());
    }
    // The store at its ceiling is where several inputs of one tree go at
    // once, so they are fetched back together, not one round trip each.
    let repairs: Vec<BoxFuture<'_, Result<(), Error>>> = evicted
        .into_iter()
        .map(|link| relink_and_report(cas_store, filesystem_store, link, downloads).boxed())
        .collect();
    futures::stream::iter(repairs)
        .buffer_unordered(INPUT_RELINK_CONCURRENCY)
        .try_collect::<()>()
        .await
}

async fn relink_and_report(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    link: &PendingLink,
    downloads: &Semaphore,
) -> Result<(), Error> {
    let _permit = acquire_download_permit(downloads).await?;
    info!(
        digest = %link.digest,
        src_path = ?link.src,
        "Hardlink source was evicted while the input tree was staged, fetching it again"
    );
    relink_evicted_input(cas_store, filesystem_store, link)
        .await
        .map_err(|err| hardlink_error(filesystem_store, link, err))
}

/// The error a failed input hardlink surfaces as, with what an operator needs
/// to tell an evicted source from everything else.
fn hardlink_error(filesystem_store: Pin<&FilesystemStore>, link: &PendingLink, e: Error) -> Error {
    let (src_path, dest) = (&link.src, &link.dst);
    let src_metadata = std::fs::metadata(src_path);
    let dest_metadata = std::fs::metadata(dest);
    let dest_parent_metadata = dest.parent().map(Path::metadata);
    let snapshot = filesystem_store.get_eviction_snapshot();
    warn!(?e, fs_eviction_snapshot = %snapshot, ?src_path, ?src_metadata, ?dest, ?dest_metadata, ?dest_parent_metadata, "Could not make hardlink");
    if e.code == Code::NotFound {
        e.append(
            format!(
            "Could not make hardlink from {} to {}, file was likely evicted from cache.\n\
            This error often occurs when the filesystem store's max_bytes is too small for your workload.\n\
            To fix this issue:\n\
            1. Increase the 'max_bytes' value in your filesystem store configuration\n\
            2. Example: Change 'max_bytes: 10000000000' to 'max_bytes: 50000000000' (or higher)\n\
            3. The setting is typically found in your nativelink.json config under:\n\
            stores -> [your_filesystem_store] -> filesystem -> eviction_policy -> max_bytes\n\
            4. Restart NativeLink after making the change\n\n\
            If this error persists after increasing max_bytes several times, please report at:\n\
            https://github.com/TraceMachina/nativelink/issues\n\
            Include your config file and both server and client logs to help us assist you.",
            src_path.display(), dest.display()
        ))
    } else {
        e.append(format!(
            "Could not make hardlink from {} to {}",
            src_path.display(),
            dest.display()
        ))
    }
}

/// Makes one hardlink again after the batch found its source gone.
///
/// Every source of an input tree is resolved before the first link is made,
/// and a store at its ceiling can evict a blob in between: eviction renames a
/// plain blob out from under the path that was resolved, and deletes an
/// executable variant outright. The blob is still in the slow tier, so it is
/// fetched back and linked at once. A plain blob is linked inside its entry's
/// path lock, which an eviction has to take to rename it, so this link cannot
/// lose the same race again; a variant is linked straight after it is
/// resolved, which leaves a window of one call where the batch left a whole
/// tree's worth.
async fn relink_evicted_input(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    link: &PendingLink,
) -> Result<(), Error> {
    if link.executable {
        fetch_and_resolve(
            link.digest,
            || cas_store.populate_fast_store(link.digest.into()),
            || async {
                let src = filesystem_store
                    .get_executable_hardlink_source(&link.digest)
                    .await
                    .err_tip(|| {
                        format!("Resolving the executable variant for {} again", link.digest)
                    })?;
                fs::hard_link(src, &link.dst).await
            },
        )
        .await?;
        record_input_relink("executable");
        return Ok(());
    }
    fetch_and_resolve(
        link.digest,
        || cas_store.populate_fast_store(link.digest.into()),
        || async {
            let file_entry = filesystem_store
                .get_file_entry_for_digest(&link.digest)
                .await
                .err_tip(|| "Resolving an evicted hardlink source again")?;
            let dst = link.dst.clone();
            file_entry
                .get_file_path_locked(|src| async move { fs::hard_link(src, dst).await })
                .await
        },
    )
    .await?;
    record_input_relink("plain");
    Ok(())
}

/// Resolves every non-executable file of an input tree to its CAS blob path.
///
/// The blob is nearly always resident, and `populate_fast_store` would take the
/// store's eviction lock only to discover that, so resolving the entry directly
/// answers the same question and yields the path. Only a genuine miss pays the
/// populate round trip.
async fn resolve_plain_files(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    files: Vec<PendingFile>,
    downloads: &Semaphore,
) -> Result<Vec<PendingLink>, Error> {
    let mut tasks = Vec::with_capacity(files.len());
    for file in files {
        tasks.push(async move {
            let file_entry = if let Ok(entry) = filesystem_store
                .get_file_entry_for_digest(&file.digest)
                .await
            {
                entry
            } else {
                let _permit = acquire_download_permit(downloads).await?;
                fetch_and_resolve(
                    file.digest,
                    || cas_store.populate_fast_store(file.digest.into()),
                    || filesystem_store.get_file_entry_for_digest(&file.digest),
                )
                .await
                .err_tip(|| "During hard link")?
            };
            // TODO: add a test for #2051: deadlock with large number of files
            let src_path = file_entry
                .get_file_path_locked(|src| async move { Ok(src) })
                .await
                .err_tip(|| format!("for digest {}", file.digest))?;
            Ok::<_, Error>(PendingLink {
                src: PathBuf::from(src_path),
                dst: PathBuf::from(file.dst),
                digest: file.digest,
                executable: false,
                _keepalive: Some(file_entry),
            })
        });
    }
    collect_links(tasks).await
}

/// Runs the resolution tasks of one input tree, bounded, into the link batch.
async fn collect_links(
    tasks: Vec<impl Future<Output = Result<PendingLink, Error>>>,
) -> Result<Vec<PendingLink>, Error> {
    futures::stream::iter(tasks)
        .buffer_unordered(DOWNLOAD_TO_DIRECTORY_CONCURRENCY)
        .try_collect()
        .await
}

/// Resolves every executable file of an input tree to its 0o555 variant.
///
/// The shared 0o444 CAS blob cannot carry the executable bit, so each of these
/// digests hardlinks a private variant instead, and the batch checks the whole
/// tree's variants for existence in one dispatch.
///
/// A variant cannot be built from a blob that is not resident, and only this
/// caller can fetch one, so those digests are fetched and resolved here, again
/// if the store evicts the blob before the variant is built.
async fn resolve_exec_files(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    files: Vec<PendingFile>,
    downloads: &Semaphore,
) -> Result<Vec<PendingLink>, Error> {
    let digests: Vec<DigestInfo> = files.iter().map(|file| file.digest).collect();
    let sources = filesystem_store
        .get_executable_hardlink_sources(&digests)
        .await;

    let mut tasks = Vec::with_capacity(files.len());
    for (file, source) in files.into_iter().zip(sources) {
        tasks.push(async move {
            let src_path = if let Ok(src_path) = source {
                src_path
            } else {
                let _permit = acquire_download_permit(downloads).await?;
                fetch_and_resolve(
                    file.digest,
                    || cas_store.populate_fast_store(file.digest.into()),
                    || filesystem_store.get_executable_hardlink_source(&file.digest),
                )
                .await
                .err_tip(|| format!("Resolving executable variant for {}", file.digest))?
            };
            Ok::<_, Error>(PendingLink {
                src: PathBuf::from(src_path),
                dst: PathBuf::from(file.dst),
                digest: file.digest,
                executable: true,
                _keepalive: None,
            })
        });
    }
    collect_links(tasks).await
}

/// Walks the input tree, reading its `Directory` protos and sorting every node
/// into one of the passes the caller then runs: directories to create, files to
/// hardlink in a batch, and the few nodes that need individual treatment.
///
/// Nothing is written to disk here, which is what lets the caller create every
/// directory before any node is materialized into one.
fn collect_download_links<'a>(
    cas_store: &'a FastSlowStore,
    digest: &'a DigestInfo,
    current_directory: &'a str,
    input_lease: Option<Arc<ActionInputLease>>,
    input_mounts: Option<Arc<InputMounts>>,
    downloads: &'a Semaphore,
) -> BoxFuture<'a, Result<CollectedTree, Error>> {
    async move {
        if let Some(input_lease) = &input_lease {
            input_lease.lease_digest(digest);
        }
        if let Some(mounts) = &input_mounts {
            let lease = input_lease
                .as_deref()
                .map(|lease| -> &dyn crate::directory_cache::DigestLease { lease });
            if mounts
                .prepare(Path::new(current_directory), *digest, lease)
                .await?
            {
                return Ok((Vec::new(), Vec::new(), Vec::new()));
            }
        }
        // The permit covers the fetch alone, never the walk below it: a
        // parent holding one while its children wait for theirs would
        // deadlock a tree deeper than the pool.
        let directory = {
            let _permit = acquire_download_permit(downloads).await?;
            get_and_decode_digest::<ProtoDirectory>(cas_store, digest.into())
                .await
                .err_tip(|| "Converting digest to Directory")?
        };
        let mut futures = Vec::new();
        let mut pending_files = Vec::new();
        let mut inline_nodes = Vec::new();

        for file in directory.files {
            let digest: DigestInfo = file
                .digest
                .err_tip(|| "Expected Digest to exist in Directory::file::digest")?
                .try_into()
                .err_tip(|| "In Directory::file::digest")?;
            let dest = format!("{}/{}", current_directory, file.name);
            let is_executable = file.is_executable;
            let (mtime, custom_unix_mode) = match file.node_properties {
                Some(properties) => (properties.mtime, properties.unix_mode),
                None => (None, None),
            };
            if let Some(input_lease) = &input_lease {
                input_lease.lease_digest(&digest);
            }
            // Hot path: nothing to stamp, so the file needs nothing from the
            // walk beyond its digest. Hand it up unresolved and let the caller
            // resolve and link the whole tree in one batch.
            if mtime.is_none() && custom_unix_mode.is_none() && !is_zero_digest(digest) {
                pending_files.push(PendingFile {
                    digest,
                    dst: dest,
                    executable: is_executable,
                });
                continue;
            }
            inline_nodes.push(InlineNode::File {
                digest,
                dst: dest,
                is_executable,
                mtime: mtime
                    .map(|mtime| FileTime::from_unix_time(mtime.seconds, mtime.nanos as u32)),
                custom_unix_mode,
            });
        }

        for sub_directory in directory.directories {
            let digest: DigestInfo = sub_directory
                .digest
                .err_tip(|| "Expected Digest to exist in Directory::directories::digest")?
                .try_into()
                .err_tip(|| "In Directory::file::digest")?;
            let new_directory_path = format!("{}/{}", current_directory, sub_directory.name);
            if let Some(input_lease) = &input_lease {
                // Reserve queued child directories before their futures are
                // polled. Without this, a large parent can leave later
                // directory digests exposed to slow-tier eviction while the
                // first batch of children is being materialized.
                input_lease.lease_digest(&digest);
            }
            let input_lease = input_lease.clone();
            let input_mounts = input_mounts.clone();
            futures.push(
                async move {
                    let (mut sub_dirs, files, inline) = collect_download_links(
                        cas_store,
                        &digest,
                        &new_directory_path,
                        input_lease,
                        input_mounts,
                        downloads,
                    )
                    .await
                    .err_tip(|| format!("in download_to_directory : {new_directory_path}"))?;
                    sub_dirs.push(PathBuf::from(new_directory_path));
                    Ok::<_, Error>((sub_dirs, files, inline))
                }
                .boxed(),
            );
        }

        #[cfg(target_family = "unix")]
        for symlink_node in directory.symlinks {
            inline_nodes.push(InlineNode::Symlink {
                target: symlink_node.target,
                dst: format!("{}/{}", current_directory, symlink_node.name),
            });
        }

        // Gate concurrency: at most DOWNLOAD_TO_DIRECTORY_CONCURRENCY futures
        // polled at once for this directory level. Previously all futures were
        // pushed into an unbounded FuturesUnordered, which on macOS produced
        // thousands of parallel hardlink(2) calls fighting APFS's per-volume
        // metadata lock and regressing throughput vs serial.
        let collected: Vec<CollectedTree> = futures::stream::iter(futures)
            .buffer_unordered(DOWNLOAD_TO_DIRECTORY_CONCURRENCY)
            .try_collect()
            .await?;

        let mut dirs = Vec::new();
        for (sub_dirs, sub_files, sub_inline) in collected {
            dirs.extend(sub_dirs);
            pending_files.extend(sub_files);
            inline_nodes.extend(sub_inline);
        }
        Ok((dirs, pending_files, inline_nodes))
    }
    .boxed()
}

/// A node materialized one at a time rather than through a batch, because it
/// needs a private inode or is not a hardlink at all.
///
/// These are a tiny fraction of an input tree, and deferring them alongside the
/// batched files keeps one ordering rule for the whole walk: nothing is written
/// until every directory exists.
enum InlineNode {
    /// A zero-digest file, or one carrying metadata that must be stamped onto
    /// an inode private to this action.
    File {
        digest: DigestInfo,
        dst: String,
        is_executable: bool,
        mtime: Option<FileTime>,
        custom_unix_mode: Option<u32>,
    },
    #[cfg(target_family = "unix")]
    Symlink { target: String, dst: String },
}

/// Stamps the mode an input file asked for. `dest` must be an inode private to
/// this action: the same call on a hardlinked CAS blob would mutate the inode
/// every other action shares.
#[cfg(target_family = "unix")]
async fn stamp_unix_mode(
    dest: &str,
    is_executable: bool,
    custom_unix_mode: Option<u32>,
) -> Result<(), Error> {
    let mode = match (custom_unix_mode, is_executable) {
        (Some(mode), true) => mode | 0o111,
        (Some(mode), false) => mode,
        (None, true) => 0o555,
        (None, false) => return Ok(()),
    };
    fs::set_permissions(dest, Permissions::from_mode(mode))
        .await
        .err_tip(|| format!("Could not set unix mode in download_to_directory {dest}"))
}

/// Non-unix has no mode to stamp.
#[cfg(not(target_family = "unix"))]
async fn stamp_unix_mode(
    _dest: &str,
    _is_executable: bool,
    _custom_unix_mode: Option<u32>,
) -> Result<(), Error> {
    Ok(())
}

/// Materializes the nodes the batched passes cannot handle.
async fn materialize_inline_nodes(
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    nodes: Vec<InlineNode>,
    downloads: &Semaphore,
) -> Result<(), Error> {
    let mut futures = Vec::with_capacity(nodes.len());
    for node in nodes {
        futures.push(async move {
            let progress = match &node {
                #[cfg(target_family = "unix")]
                InlineNode::Symlink { dst, .. } => ProgressObserver::path_object(WorkKind::Materialize, Path::new(dst)),
                InlineNode::File { dst, .. } => ProgressObserver::path_object(WorkKind::Materialize, Path::new(dst)),
            };
            let result = match node {
                #[cfg(target_family = "unix")]
                InlineNode::Symlink { target, dst } => fs::symlink(&target, &dst)
                    .await
                    .err_tip(|| format!("Could not create symlink {target} -> {dst}")),
                InlineNode::File {
                    digest,
                    dst: dest,
                    is_executable,
                    mtime,
                    custom_unix_mode,
                } => {
                    {
                        let _permit = acquire_download_permit(downloads).await?;
                        cas_store.populate_fast_store(digest.into()).await?;
                    }
                    async {
                        if is_zero_digest(digest) {
                            // Zero-digest files are never persisted by the
                            // FilesystemStore, so materialise them directly in
                            // the worker exec dir.
                            let mut file_slot = fs::create_file(&dest)
                                .await
                                .err_tip(|| format!("Could not create zero-digest file at {dest}"))?;
                            file_slot
                                .write_all(&[])
                                .await
                                .err_tip(|| format!("Could not write zero-digest file at {dest}"))?;
                        } else {
                            // Rare path: per-file metadata (a custom unix_mode or
                            // an mtime) must land on a PRIVATE inode. A
                            // chmod/utimes on a hardlink mutates the shared CAS
                            // inode for every other action that hardlinked it
                            // (the #2347 corruption class). Copy the blob into a
                            // private inode, then stamp mode/mtime onto it below.
                            let file_entry = filesystem_store
                                .get_file_entry_for_digest(&digest)
                                .await
                                .err_tip(|| "During private copy")?;
                            let src_path = file_entry
                                .get_file_path_locked(|src| async move { Ok(src) })
                                .await?;
                            let spawned_dest = dest.clone();
                            let copy_progress = progress.clone();
                            spawn_blocking!("download_to_directory_private_copy", move || {
                                let copy = || -> std::io::Result<()> {
                                    let Some(progress) = copy_progress else {
                                        return std::fs::copy(&src_path, &spawned_dest).map(|_| ());
                                    };
                                    let mut source = std::fs::File::open(&src_path)?;
                                    let mut destination = std::fs::File::create(&spawned_dest)?;
                                    let mut buffer = vec![0_u8; fs::DEFAULT_READ_BUFF_SIZE];
                                    let mut offset = 0_u64;
                                    loop {
                                        let count = std::io::Read::read(&mut source, &mut buffer)?;
                                        if count == 0 { return Ok(()); }
                                        std::io::Write::write_all(&mut destination, &buffer[..count])?;
                                        offset = offset.checked_add(count as u64)
                                            .ok_or_else(|| std::io::Error::other("Copy offset exhausted"))?;
                                        progress.offset(offset);
                                    }
                                };
                                copy().map_err(|e| {
                                    make_err!(
                                        Code::Internal,
                                        "Failed to copy CAS blob into a private inode at {spawned_dest}: {e:?}"
                                    )
                                })
                            })
                            .await
                            .err_tip(|| {
                                "Failed to launch spawn_blocking private copy in download_to_directory"
                            })??;
                        }

                        // Private-inode tail (zero-digest or private copy only):
                        // stamp the requested mode and mtime. Safe because the
                        // inode is private to this action.
                        stamp_unix_mode(&dest, is_executable, custom_unix_mode).await?;
                        if let Some(mtime) = mtime {
                            let spawned_dest = dest.clone();
                            spawn_blocking!("download_to_directory_set_mtime", move || {
                                set_file_mtime(&spawned_dest, mtime).err_tip(|| {
                                    format!("Failed to set mtime in download_to_directory {spawned_dest}")
                                })
                            })
                            .await
                            .err_tip(
                                || "Failed to launch spawn_blocking in download_to_directory",
                            )??;
                        }
                        Ok(())
                    }
                    .await
                    .map_err(|e: Error| e.append(format!("for digest {digest}")))
                }
            };
            if result.is_ok()
                && let Some(progress) = progress { progress.complete(); }
            result
        });
    }
    futures::stream::iter(futures)
        .buffer_unordered(DOWNLOAD_TO_DIRECTORY_CONCURRENCY)
        .try_collect()
        .await
}

/// Prepares action inputs by first trying the directory cache (if available),
/// then falling back to traditional `download_to_directory`.
///
/// This provides a significant performance improvement for repeated builds
/// with the same input directories.
///
/// `work_directory` must already exist and be empty when this is called: the
/// caller pre-creates it so that, on the fallback path, `download_to_directory`
/// has a destination to write into. The directory cache, however, materializes
/// the tree with `hardlink_directory_tree` / APFS `clonefile(2)`, both of which
/// require the destination to *not* exist — so this function removes the empty
/// directory before invoking the cache and recreates it if the cache fails.
pub async fn prepare_action_inputs(
    directory_cache: &Option<Arc<crate::directory_cache::DirectoryCache>>,
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    digest: &DigestInfo,
    work_directory: &str,
    downloads: &Semaphore,
) -> Result<(), Error> {
    prepare_action_inputs_with_lease(
        directory_cache,
        cas_store,
        filesystem_store,
        digest,
        work_directory,
        None,
        downloads,
    )
    .await
}

async fn prepare_action_inputs_with_lease(
    directory_cache: &Option<Arc<crate::directory_cache::DirectoryCache>>,
    cas_store: &FastSlowStore,
    filesystem_store: Pin<&FilesystemStore>,
    digest: &DigestInfo,
    work_directory: &str,
    input_lease: Option<Arc<ActionInputLease>>,
    downloads: &Semaphore,
) -> Result<(), Error> {
    // Try cache first if available. Cache hits are safe while an action lease
    // is active because the directory cache pins its own materialized tree
    // across the hardlink operation. On a miss, pass the action lease into
    // cache construction so every CAS digest is reserved before it is
    // fetched/populated.
    if let Some(cache) = directory_cache {
        // `clonefile(2)` and `hardlink_directory_tree` both require the
        // destination to not exist. Remove the empty directory the caller
        // pre-created; without this the cache fails its precondition on every
        // action and silently falls back to the slow download path.
        fs::remove_dir(work_directory)
            .await
            .err_tip(|| format!("Failed to clear pre-created work directory {work_directory}"))?;
        let cache_result = if let Some(input_lease) = &input_lease {
            cache
                .get_or_create_with_lease(
                    *digest,
                    Path::new(work_directory),
                    Some(input_lease.as_ref()),
                )
                .await
        } else {
            cache
                .get_or_create(*digest, Path::new(work_directory))
                .await
        };
        match cache_result {
            Ok(cache_hit) => {
                // The materialized tree is already usable. The directory
                // cache locks each entry down with `set_readonly_recursive`,
                // which leaves directories writable (0o755) and only makes
                // files read-only (0o555). The macOS `clonefile(2)` path
                // copies those modes verbatim and the Linux hardlink walk
                // creates fresh writable directories, so every directory in
                // the materialized tree already accepts the nested output
                // files Bazel actions declare — no separate per-materialize
                // recursive chmod walk is needed here. Files stay read-only,
                // preserving the hermeticity contract and the CAS-hardlink
                // shared-inode invariant.
                trace!(
                    ?digest,
                    work_directory, cache_hit, "Successfully prepared inputs via directory cache"
                );
                return Ok(());
            }
            Err(e) => {
                warn!(
                    ?digest,
                    ?e,
                    "Directory cache failed, falling back to traditional download"
                );
                // The cache may have materialized a partial tree before
                // failing. `download_to_directory` needs an existing, empty
                // destination, so discard any partial state and recreate the
                // work directory.
                let _cleanup = fs::remove_dir_all(work_directory).await;
                fs::create_dir(work_directory)
                    .await
                    .err_tip(|| format!("Failed to recreate work directory {work_directory}"))?;
            }
        }
    }

    // Traditional path (cache disabled or failed)
    download_to_directory_with_mounts(
        cas_store,
        filesystem_store,
        digest,
        work_directory,
        input_lease,
        None,
        downloads,
    )
    .await
}

#[cfg(target_family = "windows")]
fn is_executable(_metadata: &std::fs::Metadata, full_path: &impl AsRef<Path>) -> bool {
    static EXECUTABLE_EXTENSIONS: &[&str] = &["exe", "bat", "com"];
    EXECUTABLE_EXTENSIONS
        .iter()
        .any(|ext| full_path.as_ref().extension().map_or(false, |v| v == *ext))
}

#[cfg(target_family = "unix")]
fn is_executable(metadata: &std::fs::Metadata, _full_path: &impl AsRef<Path>) -> bool {
    (metadata.mode() & 0o111) != 0
}

type DigestUploader = Arc<tokio::sync::OnceCell<()>>;

async fn upload_file(
    cas_store: Pin<&impl StoreLike>,
    full_path: impl AsRef<Path> + Debug + Send + Sync,
    hasher: DigestHasherFunc,
    metadata: std::fs::Metadata,
    digest_uploaders: Arc<Mutex<HashMap<DigestInfo, DigestUploader>>>,
    uploads: Arc<Semaphore>,
) -> Result<FileInfo, Error> {
    // Held from the open to the end of the upload: this is the bound on
    // files open at once for the whole output tree.
    let _permit = uploads
        .acquire()
        .await
        .err_tip(|| "Upload semaphore closed")?;
    let is_executable = is_executable(&metadata, &full_path);
    let file_size = metadata.len();
    let file = fs::open_file(&full_path, 0, u64::MAX)
        .await
        .err_tip(|| format!("Could not open file {full_path:?}"))?;

    let (digest, mut file) = hasher
        .hasher()
        .digest_for_file(&full_path, file.into_inner(), Some(file_size))
        .await
        .err_tip(|| format!("Failed to hash file in digest_for_file failed for {full_path:?}"))?;

    let progress = ProgressObserver::store_object(WorkKind::Write, &digest.into());
    let digest_uploader = match digest_uploaders.lock().entry(digest) {
        std::collections::hash_map::Entry::Occupied(occupied_entry) => occupied_entry.get().clone(),
        std::collections::hash_map::Entry::Vacant(vacant_entry) => vacant_entry
            .insert(Arc::new(tokio::sync::OnceCell::new()))
            .clone(),
    };

    // Only upload a file with a given hash once.  The file may exist multiple
    // times in the output with different names.
    digest_uploader
        .get_or_try_init(async || {
            // Only upload if the digest doesn't already exist, this should be
            // a much cheaper operation than an upload.
            let cas_store = cas_store.as_store_driver_pin();
            let store_key: nativelink_util::store_trait::StoreKey<'_> = digest.into();
            let has_start = std::time::Instant::now();
            if cas_store
                .has(store_key.borrow())
                .await
                .is_ok_and(|result| result.is_some())
            {
                trace!(
                    ?digest,
                    has_elapsed_ms = has_start.elapsed().as_millis(),
                    "upload_file: digest already exists in CAS, skipping upload",
                );
                return Ok(());
            }
            trace!(
                ?digest,
                has_elapsed_ms = has_start.elapsed().as_millis(),
                file_size = digest.size_bytes(),
                "upload_file: digest not in CAS, starting upload",
            );

            file.rewind().await.err_tip(|| "Could not rewind file")?;

            // Note: For unknown reasons we appear to be hitting:
            // https://github.com/rust-lang/rust/issues/92096
            // or a similar issue if we try to use the non-store driver function, so we
            // are using the store driver function here.
            let store_key_for_upload = store_key.clone();
            let file_upload_start = std::time::Instant::now();
            let upload_result = cas_store
                .update_with_whole_file(
                    store_key_for_upload,
                    full_path.as_ref().into(),
                    file,
                    UploadSizeInfo::ExactSize(digest.size_bytes()),
                )
                .await
                .map(|_slot| ());
            trace!(
                ?digest,
                upload_elapsed_ms = file_upload_start.elapsed().as_millis(),
                success = upload_result.is_ok(),
                "upload_file: update_with_whole_file completed",
            );

            match upload_result {
                Ok(()) => Ok(()),
                Err(err) => {
                    // Output uploads run concurrently and may overlap (e.g. a file is listed
                    // both as an output file and inside an output directory). When another
                    // upload has already moved the file into CAS, this update can fail with
                    // NotFound even though the digest is now present. Per the RE spec, missing
                    // outputs should be ignored, so treat this as success if the digest exists.
                    if err.code == Code::NotFound
                        && cas_store
                            .has(store_key.borrow())
                            .await
                            .is_ok_and(|result| result.is_some())
                    {
                        Ok(())
                    } else {
                        Err(err)
                    }
                }
            }
        })
        .await
        .err_tip(|| format!("for {full_path:?}"))?;
    if let Some(progress) = progress {
        progress.complete();
    }

    let name = full_path
        .as_ref()
        .file_name()
        .err_tip(|| format!("Expected file_name to exist on {full_path:?}"))?
        .to_str()
        .err_tip(|| {
            make_err!(
                Code::Internal,
                "Could not convert {:?} to string",
                full_path
            )
        })?
        .to_string();

    Ok(FileInfo {
        name_or_path: NameOrPath::Name(name),
        digest,
        is_executable,
    })
}

async fn upload_symlink(
    full_path: impl AsRef<Path> + Debug,
    full_work_directory_path: impl AsRef<Path>,
) -> Result<SymlinkInfo, Error> {
    let full_target_path = fs::read_link(full_path.as_ref())
        .await
        .err_tip(|| format!("Could not get read_link path of {full_path:?}"))?;

    // Detect if our symlink is inside our work directory, if it is find the
    // relative path otherwise use the absolute path.
    let target = if full_target_path.starts_with(full_work_directory_path.as_ref()) {
        let full_target_path = RelativePath::from_path(&full_target_path)
            .map_err(|v| make_err!(Code::Internal, "Could not convert {} to RelativePath", v))?;
        RelativePath::from_path(full_work_directory_path.as_ref())
            .map_err(|v| make_err!(Code::Internal, "Could not convert {} to RelativePath", v))?
            .relative(full_target_path)
            .normalize()
            .into_string()
    } else {
        full_target_path
            .to_str()
            .err_tip(|| {
                make_err!(
                    Code::Internal,
                    "Could not convert '{:?}' to string",
                    full_target_path
                )
            })?
            .to_string()
    };

    let name = full_path
        .as_ref()
        .file_name()
        .err_tip(|| format!("Expected file_name to exist on {full_path:?}"))?
        .to_str()
        .err_tip(|| {
            make_err!(
                Code::Internal,
                "Could not convert {:?} to string",
                full_path
            )
        })?
        .to_string();

    Ok(SymlinkInfo {
        name_or_path: NameOrPath::Name(name),
        target,
    })
}

fn upload_directory<'a, P: AsRef<Path> + Debug + Send + Sync + Clone + 'a>(
    cas_store: Pin<&'a impl StoreLike>,
    full_dir_path: P,
    full_work_directory: &'a str,
    hasher: DigestHasherFunc,
    digest_uploaders: Arc<Mutex<HashMap<DigestInfo, DigestUploader>>>,
    uploads: Arc<Semaphore>,
) -> BoxFuture<'a, Result<(Directory, VecDeque<ProtoDirectory>), Error>> {
    Box::pin(async move {
        let mut file_futures = Vec::new();
        let mut dir_futures = Vec::new();
        let mut symlink_futures = Vec::new();
        {
            let (_permit, dir_handle) = fs::read_dir(&full_dir_path)
                .await
                .err_tip(|| format!("Error reading dir for reading {full_dir_path:?}"))?
                .into_inner();
            let mut dir_stream = ReadDirStream::new(dir_handle);
            // Note: Try very hard to not leave file descriptors open. Try to keep them as short
            // lived as possible. This is why we iterate the directory and then build a bunch of
            // futures with all the work we are wanting to do then execute it. It allows us to
            // close the directory iterator file descriptor, then open the child files/folders.
            while let Some(entry_result) = dir_stream.next().await {
                let entry = entry_result.err_tip(|| "Error while iterating directory")?;
                let file_type = entry
                    .file_type()
                    .await
                    .err_tip(|| format!("Error running file_type() on {entry:?}"))?;
                let full_path = full_dir_path.as_ref().join(entry.path());
                if file_type.is_dir() {
                    let full_dir_path = full_dir_path.clone();
                    dir_futures.push(
                        upload_directory(
                            cas_store,
                            full_path.clone(),
                            full_work_directory,
                            hasher,
                            digest_uploaders.clone(),
                            uploads.clone(),
                        )
                        .and_then(|(dir, all_dirs)| async move {
                            let directory_name = full_path
                                .file_name()
                                .err_tip(|| {
                                    format!("Expected file_name to exist on {full_dir_path:?}")
                                })?
                                .to_str()
                                .err_tip(|| {
                                    make_err!(
                                        Code::Internal,
                                        "Could not convert {:?} to string",
                                        full_dir_path
                                    )
                                })?
                                .to_string();

                            let digest =
                                serialize_and_upload_message(&dir, cas_store, &mut hasher.hasher())
                                    .await
                                    .err_tip(|| format!("for {}", full_path.display()))?;

                            Result::<(DirectoryNode, VecDeque<Directory>), Error>::Ok((
                                DirectoryNode {
                                    name: directory_name,
                                    digest: Some(digest.into()),
                                },
                                all_dirs,
                            ))
                        })
                        .boxed(),
                    );
                } else if file_type.is_file() {
                    let digest_uploaders = digest_uploaders.clone();
                    let uploads = uploads.clone();
                    file_futures.push(async move {
                        let metadata = fs::metadata(&full_path)
                            .await
                            .err_tip(|| format!("Could not open file {}", full_path.display()))?;
                        upload_file(
                            cas_store,
                            &full_path,
                            hasher,
                            metadata,
                            digest_uploaders,
                            uploads,
                        )
                        .map_ok(TryInto::try_into)
                        .await?
                    });
                } else if file_type.is_symlink() {
                    symlink_futures.push(
                        upload_symlink(full_path, &full_work_directory)
                            .map(|symlink| symlink?.try_into()),
                    );
                }
            }
        }

        // The stream bound keeps the fan-out in check at each level; the
        // files open at once are bounded by `uploads`, which every level
        // shares, since per-level bounds would multiply.
        let dir_entries = futures::stream::iter(dir_futures)
            .buffer_unordered(UPLOAD_CONCURRENCY)
            .try_collect::<Vec<(DirectoryNode, VecDeque<Directory>)>>()
            .await?;
        let (mut file_nodes, mut symlinks) = try_join(
            futures::stream::iter(file_futures)
                .buffer_unordered(UPLOAD_CONCURRENCY)
                .try_collect::<Vec<FileNode>>(),
            futures::stream::iter(symlink_futures)
                .buffer_unordered(UPLOAD_CONCURRENCY)
                .try_collect::<Vec<SymlinkNode>>(),
        )
        .await?;

        let mut directory_nodes = Vec::with_capacity(dir_entries.len());
        // For efficiency we use a deque because it allows cheap concat of Vecs.
        // We make the assumption here that when performance is important it is because
        // our directory is quite large. This allows us to cheaply merge large amounts of
        // directories into one VecDeque. Then after we are done we need to collapse it
        // down into a single Vec.
        let mut all_child_directories = VecDeque::with_capacity(dir_entries.len());
        for (directory_node, mut recursive_child_directories) in dir_entries {
            directory_nodes.push(directory_node);
            all_child_directories.append(&mut recursive_child_directories);
        }

        file_nodes.sort_unstable_by(|a, b| a.name.cmp(&b.name));
        directory_nodes.sort_unstable_by(|a, b| a.name.cmp(&b.name));
        symlinks.sort_unstable_by(|a, b| a.name.cmp(&b.name));

        let directory = Directory {
            files: file_nodes,
            directories: directory_nodes,
            symlinks,
            node_properties: None, // We don't support file properties.
        };
        all_child_directories.push_back(directory.clone());

        Ok((directory, all_child_directories))
    })
}

async fn process_side_channel_file(
    side_channel_file: Cow<'_, OsStr>,
    args: &[&OsStr],
    timeout: Duration,
) -> Result<Option<Error>, Error> {
    let mut json_contents = String::new();
    {
        // Note: Scoping `file_slot` allows the file_slot semaphore to be released faster.
        let mut file_slot = match fs::open_file(side_channel_file, 0, u64::MAX).await {
            Ok(file_slot) => file_slot,
            Err(e) => {
                if e.code != Code::NotFound {
                    return Err(e).err_tip(|| "Error opening side channel file");
                }
                // Note: If file does not exist, it's ok. Users are not required to create this file.
                return Ok(None);
            }
        };
        file_slot
            .read_to_string(&mut json_contents)
            .await
            .err_tip(|| "Error reading side channel file")?;
    }

    let side_channel_info: SideChannelInfo = serde_json5::from_str(&json_contents)
        .map_err(Error::from)
        .err_tip(|| "Could not convert contents of side channel file (json) to SideChannelInfo")?;
    Ok(side_channel_info.failure.map(|failure| match failure {
        SideChannelFailureReason::Timeout => {
            let join_args = args.join(OsStr::new(" "));
            let command = join_args.to_string_lossy();
            warn!(%command, timeout=timeout.as_secs_f32(), "Side channel timeout for command");
            Error::new(
                Code::DeadlineExceeded,
                format!(
                    "Command '{}' timed out after {} seconds",
                    command,
                    timeout.as_secs_f32()
                ),
            )
        }
    }))
}

async fn do_cleanup(
    running_actions_manager: &Arc<RunningActionsManagerImpl>,
    operation_id: &OperationId,
    action_directory: &str,
) -> Result<(), Error> {
    // Mark this operation as being cleaned up. The other holders of the
    // mark are the orphan sweep and a retry's stale-directory removal, both
    // brief; waiting on them is what keeps this cleanup from being skipped,
    // which would leave the action's entries and reservations in place for
    // good.
    let _cleaning_guard = running_actions_manager
        .take_cleanup_mark(operation_id.clone())
        .await;

    let capture = running_actions_manager
        .buck2_captures
        .lock()
        .remove(operation_id);
    if let Some(capture) = capture
        && let Err(err) = capture.finish().await
    {
        // Capture completeness is independent of the execution result.
        warn!(%operation_id, ?err, "Buck2 archive finalization was partial");
    }

    // Debug-only hack to not cleanup workers when we need to debug something
    if !env::var("NATIVELINK_DONT_CLEANUP")
        .unwrap_or_default()
        .is_empty()
    {
        info!("Skip because env var");
        return Ok(());
    }

    debug!(%action_directory, "Worker cleaning up");
    // Note: We need to be careful to keep trying to cleanup even if one of the steps fails.
    // A fetch or an upload ended by a kill or a timeout can leave a blocking
    // copy or a stamp finishing inside the tree for a moment; the removal is
    // retried through that instead of failing on the first try.
    let remove_deadline = Instant::now() + running_actions_manager.max_cleanup_wait;
    let remove_dir_result = loop {
        match fs::remove_dir_all(action_directory).await {
            Ok(()) => break Ok(()),
            Err(err) if Instant::now() < remove_deadline => {
                debug!(%operation_id, ?err, "Removing the working directory again");
                tokio::time::sleep(Duration::from_millis(100)).await;
            }
            Err(err) => {
                break Err(err)
                    .err_tip(|| format!("Could not remove working directory {action_directory}"));
            }
        }
    };

    if let Err(err) = running_actions_manager.cleanup_action(operation_id) {
        error!(%operation_id, ?err, "Error cleaning up action");
        Result::<(), Error>::Err(err).merge(remove_dir_result)
    } else if let Err(err) = remove_dir_result {
        error!(%operation_id, ?err, "Error removing working directory");
        Err(err)
    } else {
        Ok(())
    }
}

/// Immutable authority accounting and the optional sampled memory ceiling.
/// The KiB ceiling rounds upward; it is a sampling threshold, not a hard OS cap.
/// Legacy usage telemetry cannot replace the exact charged vector retained here.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AuthorityResourceLimits {
    /// Full original dispatch vector, without unit conversion or reconstruction.
    pub charged: AuthorityResources,
    /// Configured ceiling rounded upward to the sampler's KiB resolution.
    /// Presence does not establish process coverage or an enforced OS limit.
    pub memory_limit_kb: Option<u64>,
}

impl AuthorityResourceLimits {
    fn capture(charged: AuthorityResources, memory: Option<&MemoryLimit>) -> Result<Self, Error> {
        if charged.slots == 0 {
            return Err(make_err!(
                Code::InvalidArgument,
                "authority grant requires a positive slot charge"
            ));
        }
        let memory_limit_kb = if let Some(memory) = memory.filter(|_| charged.memory_bytes != 0) {
            // Widen before multiplying so representable large byte grants do
            // not fail merely because the percentage's intermediate is large.
            let bytes = u128::from(charged.memory_bytes)
                .checked_mul(100 + u128::from(memory.headroom_percent))
                .map(|product| product.div_ceil(100))
                .and_then(|bytes| u64::try_from(bytes).ok())
                .ok_or_else(|| {
                    make_err!(
                        Code::InvalidArgument,
                        "authority memory headroom exceeds the byte range"
                    )
                })?;
            Some(bytes.div_ceil(1024))
        } else {
            None
        };
        Ok(Self {
            charged,
            memory_limit_kb,
        })
    }

    fn usage_reservation(self, legacy: Option<Reservation>) -> Reservation {
        // These coarse legacy fields are diagnostics. The Rust grant retains
        // fractional cores and individual bytes without this upward rounding.
        Reservation {
            cpu_count: self.charged.cpu_millis.div_ceil(1000),
            memory_kb: self.charged.memory_bytes.div_ceil(1024),
            // Disk remains a legacy platform diagnostic, outside the typed grant.
            disk_kb: legacy.map_or(0, |reservation| reservation.disk_kb),
        }
    }
}

pub trait RunningAction: Sync + Send + Sized + Unpin + 'static {
    /// Returns the action id of the action.
    fn get_operation_id(&self) -> &OperationId;

    /// Experimental authority adapter: observe an actual subprocess spawn.
    /// Installing an observer does not authorize execution. Implementations
    /// without this seam must refuse rather than fabricate a launch receipt.
    fn observe_launch(&self, _observer: oneshot::Sender<u32>) -> Result<(), Error> {
        Err(make_err!(
            Code::Unimplemented,
            "Process launch observation is unsupported"
        ))
    }

    /// Trusted process-domain observation, separate from directory cleanup.
    /// Unsupported domains and ambiguous termination must retain their charge.
    fn process_domain_quiescent(&self) -> bool {
        false
    }

    /// Anything that needs to execute before the actions is actually executed should happen here.
    fn prepare_action(self: Arc<Self>) -> impl Future<Output = Result<Arc<Self>, Error>> + Send;

    /// Actually perform the execution of the action.
    fn execute(self: Arc<Self>) -> impl Future<Output = Result<Arc<Self>, Error>> + Send;

    /// Any uploading, processing or analyzing of the results should happen here.
    fn upload_results(self: Arc<Self>) -> impl Future<Output = Result<Arc<Self>, Error>> + Send;

    /// Cleanup any residual files, handles or other junk resulting from running the action.
    fn cleanup(self: Arc<Self>) -> impl Future<Output = Result<Arc<Self>, Error>> + Send;

    /// Returns the final result. As a general rule this action should be thought of as
    /// a consumption of `self`, meaning once a return happens here the lifetime of `Self`
    /// is over and any action performed on it after this call is undefined behavior.
    fn get_finished_result(
        self: Arc<Self>,
    ) -> impl Future<Output = Result<ActionResult, Error>> + Send;

    /// Exact authority grant and its configured sampled ceiling, when present.
    fn authority_resource_limits(&self) -> Option<AuthorityResourceLimits> {
        None
    }

    /// Returns worker-observed resource usage captured while this action ran.
    fn resource_usage(&self) -> Option<ActionResourceUsage>;

    /// Returns the work directory of the action.
    fn get_work_directory(&self) -> &String;
}

/// What an action wrote to stdout or stderr: in memory when small, on disk
/// past `max_captured_output_bytes`, with the head kept for the log.
#[derive(Debug)]
pub enum CapturedOutput {
    Memory(Bytes),
    Spilled {
        path: PathBuf,
        len: u64,
        head: Bytes,
    },
}

impl CapturedOutput {
    const fn len(&self) -> u64 {
        match self {
            Self::Memory(bytes) => bytes.len() as u64,
            Self::Spilled { len, .. } => *len,
        }
    }

    /// The first bytes, for a log line; all of them when in memory.
    fn head(&self) -> &[u8] {
        match self {
            Self::Memory(bytes) => bytes,
            Self::Spilled { head, .. } => head,
        }
    }
}

/// The first `limit` bytes of captured output as text for a log line. The
/// cut is by bytes, so one through a multibyte character becomes U+FFFD
/// rather than a panic.
pub fn log_excerpt(bytes: &[u8], limit: usize) -> Cow<'_, str> {
    String::from_utf8_lossy(&bytes[..min(bytes.len(), limit)])
}

impl From<Bytes> for CapturedOutput {
    fn from(bytes: Bytes) -> Self {
        Self::Memory(bytes)
    }
}

/// Reads a child's stream to the end, or until `stop` says to keep what
/// has been read: an action can leave a process behind that holds the
/// pipe open after the action itself has exited, and its output must not
/// wait on that. Up to `cap` bytes stay in memory; the moment the buffer
/// passes the cap, everything so far and everything after goes to
/// `spill_path`, and the buffer is cut back to the cap as the head.
pub async fn capture_output<R: tokio::io::AsyncRead + Unpin>(
    mut reader: R,
    cap: u64,
    spill_path: PathBuf,
    what: &str,
    mut stop: watch::Receiver<bool>,
) -> Result<CapturedOutput, Error> {
    // `None` when told to stop; a closed sender counts as that too.
    async fn read_or_stop<R: tokio::io::AsyncRead + Unpin>(
        reader: &mut R,
        buf: &mut BytesMut,
        stop: &mut watch::Receiver<bool>,
        what: &str,
    ) -> Result<Option<usize>, Error> {
        if *stop.borrow() {
            return Ok(None);
        }
        tokio::select! {
            // Data already in the pipe is read before a stop is honoured.
            biased;
            read = reader.read_buf(buf) => read
                .map(Some)
                .err_tip(|| format!("Error reading {what} stream")),
            _ = stop.changed() => Ok(None),
        }
    }
    let mut buf = BytesMut::new();
    // A raw handle, outside the open-file budget on purpose: the spill
    // lives as long as the child's stream, an fd the budget never covered,
    // and a permit held for a whole noisy action would starve the store
    // paths the budget exists for.
    let mut spill: Option<(tokio::fs::File, u64)> = None;
    loop {
        if let Some((file, len)) = spill.as_mut() {
            let mut chunk = BytesMut::with_capacity(64 * 1024);
            let Some(sz) = read_or_stop(&mut reader, &mut chunk, &mut stop, what).await? else {
                break;
            };
            if sz == 0 {
                break;
            }
            file.write_all(&chunk)
                .await
                .err_tip(|| format!("Error spilling {what} to {}", spill_path.display()))?;
            *len += sz as u64;
            continue;
        }
        let Some(sz) = read_or_stop(&mut reader, &mut buf, &mut stop, what).await? else {
            break;
        };
        if sz == 0 {
            break;
        }
        if cap > 0 && buf.len() as u64 > cap {
            let mut file = tokio::fs::File::create(&spill_path)
                .await
                .err_tip(|| format!("Error creating {what} spill file {}", spill_path.display()))?;
            file.write_all(&buf)
                .await
                .err_tip(|| format!("Error spilling {what} to {}", spill_path.display()))?;
            let len = buf.len() as u64;
            buf.truncate(usize::try_from(cap).unwrap_or(usize::MAX));
            spill = Some((file, len));
        }
    }
    match spill {
        None => Ok(CapturedOutput::Memory(buf.freeze())),
        Some((mut file, len)) => {
            file.flush()
                .await
                .err_tip(|| format!("Error flushing {what} spill file"))?;
            drop(file);
            Ok(CapturedOutput::Spilled {
                path: spill_path,
                len,
                head: buf.freeze(),
            })
        }
    }
}

/// Uploads captured output to the CAS, from memory or from its spill file.
async fn upload_captured_output(
    cas_store: Pin<&FastSlowStore>,
    output: CapturedOutput,
    hasher: DigestHasherFunc,
    what: &str,
) -> Result<DigestInfo, Error> {
    match output {
        CapturedOutput::Memory(data) => {
            let digest = compute_buf_digest(&data, &mut hasher.hasher());
            cas_store
                .update_oneshot(digest, data)
                .await
                .err_tip(|| format!("Uploading {what}"))?;
            if let Some(progress) = ProgressObserver::store_object(WorkKind::Write, &digest.into())
            {
                progress.complete();
            }
            Ok(digest)
        }
        CapturedOutput::Spilled { path, len, .. } => {
            let file = fs::open_file(&path, 0, u64::MAX)
                .await
                .err_tip(|| format!("Could not open {what} spill file {}", path.display()))?;
            let (digest, file) = hasher
                .hasher()
                .digest_for_file(&path, file.into_inner(), Some(len))
                .await
                .err_tip(|| format!("Failed to hash {what} spill file {}", path.display()))?;
            cas_store
                .update_with_whole_file(
                    digest,
                    path.clone().into_os_string(),
                    file,
                    UploadSizeInfo::ExactSize(len),
                )
                .await
                .err_tip(|| format!("Uploading {what} from {}", path.display()))?;
            if let Some(progress) = ProgressObserver::store_object(WorkKind::Write, &digest.into())
            {
                progress.complete();
            }
            Ok(digest)
        }
    }
}

#[derive(Debug)]
struct RunningActionImplExecutionResult {
    stdout: CapturedOutput,
    stderr: CapturedOutput,
    exit_code: i32,
    resource_usage: Option<ActionResourceUsage>,
}

#[derive(Debug)]
struct RunningActionImplState {
    command_proto: Option<ProtoCommand>,
    launch_observer: Option<oneshot::Sender<u32>>,
    process_domain_quiescent: bool,
    // TODO(palfrey) Kill is not implemented yet, but is instrumented.
    // However, it is used if the worker disconnects to destroy current jobs.
    kill_channel_tx: Option<oneshot::Sender<()>>,
    kill_channel_rx: Option<oneshot::Receiver<()>>,
    execution_result: Option<RunningActionImplExecutionResult>,
    action_result: Option<ActionResult>,
    resource_usage: Option<ActionResourceUsage>,
    execution_metadata: ExecutionMetadata,
    // If there was an internal error, this will be set.
    // This should NOT be set if everything was fine, but the process had a
    // non-zero exit code. Instead this should be used for internal errors
    // that prevented the action from running, upload failures, timeouts, exc...
    // but we have (or could have) the action results (like stderr/stdout).
    error: Option<Error>,
    input_mounts: Option<Arc<InputMounts>>,
}

#[derive(Debug)]
pub struct RunningActionImpl {
    operation_id: OperationId,
    action_directory: String,
    work_directory: String,
    action_info: ActionInfo,
    /// `Some` only when the manager was configured with
    /// `experimental_active_input_leases`; `None` leaves eviction untouched.
    input_lease: Option<Arc<ActionInputLease>>,
    timeout: Duration,
    authority_request: bool,
    authority_resources: Option<AuthorityResourceLimits>,
    progress: Option<ProgressObserver>,
    running_actions_manager: Arc<RunningActionsManagerImpl>,
    /// Set on a kill; every phase that can wait watches it, so a kill ends
    /// a fetch or an upload as surely as it ends the command.
    kill_token: watch::Sender<bool>,
    state: Mutex<RunningActionImplState>,
    has_manager_entry: AtomicBool,
    did_cleanup: AtomicBool,
}

impl RunningActionImpl {
    pub fn new(
        execution_metadata: ExecutionMetadata,
        operation_id: OperationId,
        action_directory: String,
        action_info: ActionInfo,
        timeout: Duration,
        running_actions_manager: Arc<RunningActionsManagerImpl>,
    ) -> Self {
        let work_directory = format!("{}/{}", action_directory, "work");
        let input_lease = running_actions_manager.active_input_leases.then(|| {
            ActionInputLease::new(
                running_actions_manager.cas_store.as_ref(),
                action_info.command_digest,
                action_info.input_root_digest,
            )
        });
        let (kill_channel_tx, kill_channel_rx) = oneshot::channel();
        let (kill_token, _) = watch::channel(false);
        Self {
            kill_token,
            operation_id,
            action_directory,
            work_directory,
            action_info,
            input_lease,
            timeout,
            authority_request: false,
            authority_resources: None,
            progress: None,
            running_actions_manager,
            state: Mutex::new(RunningActionImplState {
                command_proto: None,
                launch_observer: None,
                process_domain_quiescent: true,
                kill_channel_rx: Some(kill_channel_rx),
                kill_channel_tx: Some(kill_channel_tx),
                execution_result: None,
                action_result: None,
                resource_usage: None,
                execution_metadata,
                error: None,
                input_mounts: None,
            }),
            // Set to true only after the action is inserted into the manager.
            // The constructor can fail the operation-id uniqueness check
            // immediately after this object is created.
            has_manager_entry: AtomicBool::new(false),
            // Only needs to be cleaned up after a prepare_action call, set there.
            did_cleanup: AtomicBool::new(true),
        }
    }

    #[allow(
        clippy::missing_const_for_fn,
        reason = "False positive on stable, but not on nightly"
    )]
    fn metrics(&self) -> &Arc<Metrics> {
        &self.running_actions_manager.metrics
    }

    fn usage_reservation(
        &self,
        memory_property: Option<&str>,
        disk_property: Option<&str>,
    ) -> Option<Reservation> {
        let legacy = reservation_of(
            &self.action_info.platform_properties,
            memory_property,
            disk_property,
        );
        self.authority_resources.map_or(legacy, |resources| {
            Some(resources.usage_reservation(legacy))
        })
    }

    /// Prepares any actions needed to execute this action. This action will do the following:
    ///
    /// * Download any files needed to execute the action
    /// * Build a folder with all files needed to execute the action.
    ///
    /// This function will aggressively download and spawn potentially thousands of futures. It is
    /// up to the stores to rate limit if needed.
    /// Fetches the Command and the input tree into the work directory,
    /// again after a transient store failure while `deadline` (none:
    /// unbounded) leaves room for another attempt. A worker that already
    /// holds part of the tree in its fast store finishes the job here rather
    /// than handing the action back for another worker to fetch everything
    /// against the same struggling store. The two fetches are retried
    /// together: a Command read that fails during the same storm would
    /// otherwise fail the action while the inputs were still being retried.
    /// A `prefetched_command`, read earlier to choose the read-only input
    /// mounts, is used instead of reading the Command again.
    async fn fetch_with_retry(
        &self,
        filesystem_store: Pin<&FilesystemStore>,
        deadline: Option<Instant>,
        prefetched_command: Option<ProtoCommand>,
    ) -> Result<ProtoCommand, Error> {
        let started = Instant::now();
        let mut attempt: u32 = 1;
        let mut retries = PrepareRetries::new(record_prepare_outcome);
        loop {
            let command_fut = async {
                match &prefetched_command {
                    Some(command) => Ok(command.clone()),
                    None => self.fetch_command().await,
                }
            };
            let inputs_fut = self
                .metrics()
                .download_to_directory
                .wrap(self.download_inputs(filesystem_store));
            let err = match try_join(command_fut, inputs_fut).await {
                Ok((command, ())) => {
                    if attempt > 1 {
                        info!(
                            operation_id = %self.operation_id,
                            attempt,
                            elapsed_s = started.elapsed().as_secs(),
                            "prepare_action: input fetch recovered"
                        );
                    }
                    retries.settle("recovered");
                    return Ok(command);
                }
                Err(err) if is_transient_fetch_error(&err) => err,
                Err(err) => {
                    retries.settle("failed");
                    return Err(err);
                }
            };
            self.running_actions_manager
                .suggest_input_download_pool(&self.operation_id, &err);
            let pause = prepare_retry_pause(attempt, &self.action_info.input_root_digest);
            if deadline.is_some_and(|deadline| Instant::now() + pause >= deadline) {
                retries.settle("exhausted");
                return Err(err.append(format!(
                    "Input fetch of operation {} failed {attempt} time(s) over {}s; the next retry would start after max_download_timeout",
                    self.operation_id,
                    started.elapsed().as_secs()
                )));
            }
            warn!(
                operation_id = %self.operation_id,
                attempt,
                wait_ms = pause.as_millis(),
                error = %err,
                "prepare_action: input fetch failed, retrying"
            );
            retries.retried();
            // Start the next attempt from an empty directory: the
            // directories and links of the partial tree would otherwise
            // fail it with AlreadyExists.
            if let Err(err) = self.clear_work_directory().await {
                retries.settle("failed");
                return Err(err);
            }
            tokio::time::sleep(pause).await;
            attempt += 1;
        }
    }

    /// Empties the work directory between two fetch attempts.
    async fn clear_work_directory(&self) -> Result<(), Error> {
        if let Err(remove_err) = fs::remove_dir_all(&self.work_directory).await
            && remove_err.code != Code::NotFound
        {
            return Err(remove_err.append(format!(
                "Failed to clear work directory {} before fetching the inputs again",
                self.work_directory
            )));
        }
        fs::create_dir(&self.work_directory)
            .await
            .err_tip(|| format!("Error recreating work directory {}", self.work_directory))
    }

    /// Fetches and decodes the action's Command.
    async fn fetch_command(&self) -> Result<ProtoCommand, Error> {
        self.metrics()
            .get_proto_command_from_store
            .wrap(async {
                get_and_decode_digest::<ProtoCommand>(
                    self.running_actions_manager.cas_store.as_ref(),
                    self.action_info.command_digest.into(),
                )
                .await
                .err_tip(|| "Converting command_digest to Command")
            })
            .await
    }

    /// Chooses the read-only input mounts for this action and keeps them in
    /// its state, where their cache pins are held through cleanup. Whether
    /// mounts apply depends on the Command's output paths, so with mounts
    /// configured the Command is read here and returned for the fetch to
    /// reuse; without them nothing is read, and the Command and inputs are
    /// fetched concurrently. A failure here only means ordinary input setup:
    /// the fetch that follows reads the Command and inputs with its retries.
    async fn select_input_mounts(&self) -> Option<ProtoCommand> {
        let manager = &self.running_actions_manager;
        #[cfg(target_os = "linux")]
        let mount_paths = &manager.readonly_input_mounts;
        #[cfg(not(target_os = "linux"))]
        let mount_paths: &[String] = &[];
        if mount_paths.is_empty() {
            return None;
        }
        let command = if action_supports_persistent_workers(&self.action_info).is_none() {
            match self.fetch_command().await {
                Ok(command) => Some(command),
                Err(error) => {
                    warn!(
                        ?error,
                        "Reading the Command to choose input mounts failed; using ordinary input setup"
                    );
                    None
                }
            }
        } else {
            None
        };
        let mut input_mounts = match (&command, &manager.directory_cache) {
            (Some(command), Some(cache)) => InputMounts::for_command(
                cache.clone(),
                mount_paths,
                Path::new(&self.work_directory),
                command,
            ),
            _ => None,
        };
        if input_mounts.is_some() {
            match crate::input_mounts::has_mountable_inputs(
                &manager.cas_store,
                self.action_info.input_root_digest,
                mount_paths,
                self.input_lease
                    .as_deref()
                    .map(|lease| -> &dyn crate::directory_cache::DigestLease { lease }),
            )
            .await
            {
                Ok(true) => {}
                Ok(false) => input_mounts = None,
                Err(error) => {
                    warn!(
                        ?error,
                        "Checking for mountable inputs failed; using ordinary input setup"
                    );
                    input_mounts = None;
                }
            }
        }
        if input_mounts.is_none() {
            INPUT_MOUNT_METRICS.fallbacks.add(1, &[]);
        }
        self.state.lock().input_mounts.clone_from(&input_mounts);
        command
    }

    /// Materializes the input tree into the work directory: through the
    /// read-only input mounts chosen for this action, which leave a mount
    /// point for each selected subtree, or else through the directory cache
    /// when one is configured. If preparing the mounts fails, they are
    /// dropped and the tree is downloaded without them; later attempts of
    /// the fetch then take the ordinary path.
    async fn download_inputs(&self, filesystem_store: Pin<&FilesystemStore>) -> Result<(), Error> {
        let manager = &self.running_actions_manager;
        let downloads = &manager.input_downloads;
        let input_mounts = self.state.lock().input_mounts.clone();
        if input_mounts.is_none() {
            return prepare_action_inputs_with_lease(
                &manager.directory_cache,
                &manager.cas_store,
                filesystem_store,
                &self.action_info.input_root_digest,
                &self.work_directory,
                self.input_lease.clone(),
                downloads,
            )
            .await;
        }
        let result = download_to_directory_with_mounts(
            &manager.cas_store,
            filesystem_store,
            &self.action_info.input_root_digest,
            &self.work_directory,
            self.input_lease.clone(),
            input_mounts,
            downloads,
        )
        .await;
        if let Err(error) = result {
            INPUT_MOUNT_METRICS.prepare_failures.add(1, &[]);
            INPUT_MOUNT_METRICS.fallbacks.add(1, &[]);
            warn!(
                ?error,
                "Input mount preparation failed; retrying without mounts"
            );
            // No child has started. Discard partial inputs before
            // releasing pins and retrying the ordinary download once.
            fs::remove_dir_all(&self.work_directory).await?;
            self.state.lock().input_mounts.take();
            fs::create_dir(&self.work_directory).await?;
            download_to_directory_with_mounts(
                &manager.cas_store,
                filesystem_store,
                &self.action_info.input_root_digest,
                &self.work_directory,
                self.input_lease.clone(),
                None,
                downloads,
            )
            .await?;
        }
        Ok(())
    }

    async fn inner_prepare_action(
        self: Arc<Self>,
        download_deadline: Option<Instant>,
    ) -> Result<Arc<Self>, Error> {
        // Before anything lands on disk: an action that reserved more than
        // is free is refused as backpressure, not run into ENOSPC halfway
        // through its inputs. Free means free after what the actions
        // already admitted reserved: four 4 GiB actions dispatched in one
        // second all see the same 10 GiB, so the disk alone would admit
        // them all. The reservation is held until the action's cleanup.
        if let Some(property) = self
            .running_actions_manager
            .execution_configuration
            .resource_enforcement
            .as_ref()
            .and_then(|enforcement| enforcement.disk_property_name.as_deref())
            && let Some(reserved_kb) = self
                .action_info
                .platform_properties
                .get(property)
                .and_then(|value| value.parse::<u64>().ok())
            && reserved_kb > 0
            && let Some(free_kb) = free_disk_kb(&self.running_actions_manager.root_action_directory)
        {
            // Held across the check and the insert, so two actions
            // preparing at once cannot both pass on the same free space.
            let mut reservations = self.running_actions_manager.disk_reservations_kb.lock();
            let reserved_by_others_kb: u64 = reservations
                .iter()
                .filter(|(operation_id, _)| **operation_id != self.operation_id)
                .map(|(_, kb)| *kb)
                .sum();
            if free_kb.saturating_sub(reserved_by_others_kb) < reserved_kb {
                self.metrics().disk_guard_refusals.inc();
                return Err(make_err!(
                    Code::ResourceExhausted,
                    "Not enough free disk for this action: reserved {reserved_kb} KiB ({property}), {free_kb} KiB free under {} with {reserved_by_others_kb} KiB reserved by the actions already admitted",
                    self.running_actions_manager.root_action_directory
                ));
            }
            reservations.insert(self.operation_id.clone(), reserved_kb);
        }
        {
            let mut state = self.state.lock();
            state.execution_metadata.input_fetch_start_timestamp =
                (self.running_actions_manager.callbacks.now_fn)();
        }
        let command = {
            let filesystem_store_pin =
                Pin::new(self.running_actions_manager.filesystem_store.as_ref());
            let prefetched_command = self.select_input_mounts().await;
            fs::create_dir(&self.work_directory)
                .await
                .err_tip(|| format!("Error creating work directory {}", self.work_directory))?;
            // Now the work directory has been created, we have to clean up.
            self.did_cleanup.store(false, Ordering::Release);
            // Fetch and decode the Command and download the input tree into
            // the work directory, retried together after a store failure.
            self.fetch_with_retry(filesystem_store_pin, download_deadline, prefetched_command)
                .await
                .map_err(tag_missing_input)?
        };
        {
            // Create all directories needed for our output paths. This is required by the bazel spec.
            let prepare_output_directories = |output_file| {
                let full_output_path = if command.working_directory.is_empty() {
                    format!("{}/{}", self.work_directory, output_file)
                } else {
                    format!(
                        "{}/{}/{}",
                        self.work_directory, command.working_directory, output_file
                    )
                };
                async move {
                    let full_parent_path = Path::new(&full_output_path)
                        .parent()
                        .err_tip(|| format!("Parent path for {full_output_path} has no parent"))?;
                    fs::create_dir_all(full_parent_path).await.err_tip(|| {
                        format!(
                            "Error creating output directory {} (file)",
                            full_parent_path.display()
                        )
                    })?;
                    Result::<(), Error>::Ok(())
                }
            };
            self.metrics()
                .prepare_output_files
                .wrap(try_join_all(
                    command.output_files.iter().map(prepare_output_directories),
                ))
                .await?;
            self.metrics()
                .prepare_output_paths
                .wrap(try_join_all(
                    command.output_paths.iter().map(prepare_output_directories),
                ))
                .await?;
        }
        debug!(?command, "Worker received command");
        {
            let mut state = self.state.lock();
            state.command_proto = Some(command);
            state.execution_metadata.input_fetch_completed_timestamp =
                (self.running_actions_manager.callbacks.now_fn)();
        }
        Ok(self)
    }

    pub fn canonicalise_path(
        self: &Arc<Self>,
        arg: &OsStr,
        working_directory: &String,
    ) -> Result<PathBuf, Error> {
        #[cfg(target_os = "linux")]
        if let Some(mounts) = self.state.lock().input_mounts.as_ref()
            && let Some(path) = mounts.executable_path(working_directory, arg)?
        {
            return Ok(path);
        }
        // If the program contains a slash, we treat it as a path and resolve it relative to the work directory.
        Ok(if Path::new(arg).components().count() > 1 {
            let canonical_path = PathBuf::from(&self.work_directory)
                .join(working_directory)
                .join(arg);
            if cfg!(target_os = "windows") {
                // Workaround for https://github.com/rust-lang/rust/issues/42869 using a windows-specific crate
                dunce::canonicalize(canonical_path)
            } else {
                canonical_path.canonicalize()
            }
            .err_tip(|| {
                format!(
                    "Could not canonicalize path for command root {}.",
                    arg.to_string_lossy()
                )
            })?
        } else {
            PathBuf::from(arg)
        })
    }

    /// The environment an action's process starts with: the worker's
    /// `additional_environment`, then the action's own variables on top,
    /// and on Windows the `SystemRoot` and `PATH` defaults without which
    /// nothing runs. With `per_action` the sources that belong to one
    /// action (its timeout, a side channel file, its directory) are in and
    /// the side channel file is reported through it; without it they are
    /// left out, for a pooled process that serves many actions.
    fn action_environment(
        &self,
        command_proto: &ProtoCommand,
        requested_timeout: Duration,
        mut per_action: Option<&mut Option<Cow<'_, OsStr>>>,
    ) -> BTreeMap<String, String> {
        let mut env = BTreeMap::new();
        if let Some(additional_environment) = &self
            .running_actions_manager
            .execution_configuration
            .additional_environment
        {
            for (name, source) in additional_environment {
                let value = match source {
                    EnvironmentSource::Property(property) => self
                        .action_info
                        .platform_properties
                        .get(property)
                        .cloned()
                        .unwrap_or_default(),
                    EnvironmentSource::Value(value) => value.clone(),
                    EnvironmentSource::FromEnvironment => env::var(name).unwrap_or_default(),
                    EnvironmentSource::TimeoutMillis => {
                        if per_action.is_none() {
                            continue;
                        }
                        requested_timeout.as_millis().to_string()
                    }
                    EnvironmentSource::SideChannelFile => {
                        let Some(side_channel_file) = per_action.as_mut() else {
                            continue;
                        };
                        let file = format!("{}/{}", self.action_directory, Uuid::new_v4().simple());
                        **side_channel_file = Some(Cow::Owned(file.clone().into()));
                        file
                    }
                    EnvironmentSource::ActionDirectory => {
                        if per_action.is_none() {
                            continue;
                        }
                        self.action_directory.clone()
                    }
                };
                env.insert(name.clone(), value);
            }
        }
        for variable in &command_proto.environment_variables {
            env.insert(variable.name.clone(), variable.value.clone());
        }
        // If SystemRoot is not set on windows we set it to default. Failing
        // to do this causes all commands to fail.
        #[cfg(target_family = "windows")]
        {
            if !env.keys().any(|name| name.to_uppercase() == "SYSTEMROOT") {
                env.insert("SystemRoot".to_string(), "C:\\Windows".to_string());
            }
            if !env.keys().any(|name| name.to_uppercase() == "PATH") {
                env.insert("PATH".to_string(), "C:\\Windows\\System32".to_string());
            }
        }
        env
    }

    /// What the scheduler's kill leaves behind for a pooled action, whether
    /// it came while waiting for a worker process or while one served it.
    fn record_persistent_worker_kill(&self, command_proto: ProtoCommand, command: &str) {
        let mut state = self.state.lock();
        state.error = Error::merge_option(
            state.error.take(),
            Some(Error::new(
                Code::Cancelled,
                format!("Persistent worker command '{command}' was killed by scheduler"),
            )),
        );
        state.command_proto = Some(command_proto);
        state.execution_result = Some(RunningActionImplExecutionResult {
            stdout: Bytes::new().into(),
            stderr: Bytes::new().into(),
            exit_code: EXIT_CODE_FOR_SIGNAL,
            resource_usage: None,
        });
        state.execution_metadata.execution_completed_timestamp =
            (self.running_actions_manager.callbacks.now_fn)();
    }

    async fn inner_execute(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        let (command_proto, mut kill_channel_rx) = {
            let mut state = self.state.lock();
            state.execution_metadata.execution_start_timestamp =
                (self.running_actions_manager.callbacks.now_fn)();
            (
                state
                    .command_proto
                    .take()
                    .err_tip(|| "Expected state to have command_proto in execute()")?,
                state
                    .kill_channel_rx
                    .take()
                    .err_tip(|| "Expected state to have kill_channel_rx in execute()")?
                    // This is important as we may be killed at any point.
                    .fuse(),
            )
        };
        if command_proto.arguments.is_empty() {
            return Err(make_input_err!("No arguments provided in Command proto"));
        }
        let args: Vec<&OsStr> = if let Some(entrypoint) = &self
            .running_actions_manager
            .execution_configuration
            .entrypoint
        {
            core::iter::once(entrypoint.as_ref())
                .chain(command_proto.arguments.iter().map(AsRef::as_ref))
                .collect()
        } else {
            command_proto.arguments.iter().map(AsRef::as_ref).collect()
        };
        let command_directory = if command_proto.working_directory.is_empty() {
            self.work_directory.clone()
        } else {
            format!(
                "{}/{}",
                self.work_directory, command_proto.working_directory
            )
        };
        // TODO(palfrey): This should probably be in debug, but currently
        //                    that's too busy and we often rely on this to
        //                    figure out toolchain misconfiguration issues.
        //                    De-bloat the `debug` level by using the `trace`
        //                    level more effectively and adjust this.
        info!(?args, %command_directory, "Executing command");

        let program = self
            .canonicalise_path(args[0], &command_proto.working_directory)
            .err_tip(|| format!("Canonicalisation failure. Command={args:#?}"))?;
        let requested_timeout = if self.authority_request {
            self.timeout
        } else if self.action_info.timeout.is_zero() {
            self.running_actions_manager.max_action_timeout
        } else {
            self.action_info.timeout
        };
        if self
            .running_actions_manager
            .execution_configuration
            .persistent_workers
            .enabled
            && let Some(wire_format_result) = action_supports_persistent_workers(&self.action_info)
        {
            match wire_format_result {
                Ok(wire_format) => {
                    let command_argv = os_args_to_strings(&args)?;
                    // What a one-shot action gets, but for the sources that
                    // belong to one action: a process that serves many
                    // cannot carry a timeout, a side channel file or an
                    // action directory.
                    let env = self.action_environment(&command_proto, requested_timeout, None);
                    let key = WorkerKey::from_argv(&command_argv, wire_format)?
                        .with_env(env.into_iter().collect());
                    let request = WorkRequest {
                        arguments: persistent_worker_request_arguments(&command_argv),
                        inputs: Vec::<PersistentWorkerInput>::new(),
                        request_id: 0,
                        cancel: false,
                        verbosity: 0,
                        sandbox_dir: command_directory.clone(),
                    };
                    let worker_cwd =
                        PathBuf::from(&self.running_actions_manager.root_action_directory);

                    // The wait for a process is bounded by the action's own
                    // timeout as well as the pool's, and raced against the
                    // kill: a cancelled action must not hold a slot, and a
                    // short action cannot wait longer than it may run.
                    let acquire_started = Instant::now();
                    let acquire_bound = self
                        .running_actions_manager
                        .persistent_worker_pool
                        .acquire_timeout()
                        .min(self.timeout);
                    let acquired = {
                        let acquire_fut = self
                            .running_actions_manager
                            .persistent_worker_pool
                            .acquire(key.clone(), &program, &worker_cwd);
                        tokio::pin!(acquire_fut);
                        tokio::select! {
                            result = &mut acquire_fut => Some(result),
                            _ = &mut kill_channel_rx => None,
                            () = tokio::time::sleep(acquire_bound) => Some(Err(make_err!(
                                Code::DeadlineExceeded,
                                "No persistent worker came back within the action's remaining time ({acquire_bound:?})"
                            ))),
                        }
                    };
                    let Some(acquired) = acquired else {
                        let command = args.join(OsStr::new(" ")).to_string_lossy().into_owned();
                        self.record_persistent_worker_kill(command_proto, &command);
                        return Ok(self);
                    };
                    match acquired {
                        Ok(mut lease) => {
                            self.metrics().persistent_worker_dispatches.inc();
                            let timer = self.metrics().child_process.begin_timer();
                            let execution_started = Instant::now();
                            // What the pooled process and its children use
                            // while they serve this request. The process is
                            // shared, so nothing here is enforced against
                            // the action's reservation; it is measured so
                            // the sizing loop learns what the tool needs.
                            // CPU is what the process spent from here on;
                            // peak memory is the whole process, which holds
                            // what earlier requests left in it.
                            #[cfg(target_os = "linux")]
                            let sampler = lease.worker().pid().map(|pgid| {
                                start_action_resource_usage_sampler(
                                    pgid,
                                    Ceilings {
                                        memory_limit_kb: None,
                                        disk_limit_kb: None,
                                        over_limit_tx: None,
                                    },
                                    None,
                                )
                            });
                            let dispatch_result = {
                                let remaining =
                                    self.timeout.saturating_sub(acquire_started.elapsed());
                                let dispatch_fut =
                                    lease.worker().dispatch_with_timeout(&request, remaining);
                                tokio::pin!(dispatch_fut);
                                tokio::select! {
                                    result = &mut dispatch_fut => Some(result),
                                    _ = &mut kill_channel_rx => None,
                                }
                            };
                            #[cfg(target_os = "linux")]
                            let sampled_usage = match sampler {
                                Some(sampler) => finish_action_resource_usage_sampler(sampler)
                                    .await
                                    .unwrap_or_default(),
                                None => SampledResourceUsage::default(),
                            };
                            #[cfg(not(target_os = "linux"))]
                            let sampled_usage = SampledResourceUsage::default();
                            let response = match dispatch_result {
                                Some(Ok(response)) => {
                                    lease.release(true).await;
                                    response
                                }
                                Some(Err(err)) => {
                                    lease.release(false).await;
                                    return Err(err).err_tip(|| {
                                        format!("Dispatching action to persistent worker {key:?}")
                                    });
                                }
                                None => {
                                    drop(timer);
                                    lease.release(false).await;
                                    let command =
                                        args.join(OsStr::new(" ")).to_string_lossy().into_owned();
                                    self.record_persistent_worker_kill(command_proto, &command);
                                    return Ok(self);
                                }
                            };
                            timer.measure();

                            if response.exit_code == 0 {
                                self.metrics().child_process_success_error_code.inc();
                            } else {
                                self.metrics().child_process_failure_error_code.inc();
                            }
                            info!(?args, ?key, "Persistent worker command complete");
                            let (memory_property, disk_property) = self
                                .running_actions_manager
                                .execution_configuration
                                .resource_enforcement
                                .as_ref()
                                .map_or((None, None), |e| {
                                    (
                                        e.memory.as_ref().map(|m| m.property_name.as_str()),
                                        e.disk_property_name.as_deref(),
                                    )
                                });
                            let (outcome, enforced) =
                                classify_outcome(None, None, sampled_usage.last_memory_kb, None);
                            let resource_usage = Some(ActionResourceUsage {
                                peak_memory_kb: sampled_usage.peak_memory_kb,
                                cpu_time_ms: sampled_usage.cpu_time_ms,
                                sampled: sampled_usage.peak_memory_kb > 0
                                    || sampled_usage.cpu_time_ms > 0,
                                operation_id: String::new(),
                                worker_id: String::new(),
                                wall_time_ms: u64::try_from(
                                    execution_started.elapsed().as_millis(),
                                )
                                .unwrap_or(u64::MAX),
                                peak_disk_kb: 0,
                                outcome: outcome.into(),
                                enforced,
                                reserved: self.usage_reservation(memory_property, disk_property),
                            });
                            {
                                let mut state = self.state.lock();
                                state.command_proto = Some(command_proto);
                                state.execution_result = Some(RunningActionImplExecutionResult {
                                    stdout: Bytes::new().into(),
                                    stderr: Bytes::from(response.output).into(),
                                    exit_code: response.exit_code,
                                    resource_usage,
                                });
                                state.execution_metadata.execution_completed_timestamp =
                                    (self.running_actions_manager.callbacks.now_fn)();
                            }
                            return Ok(self);
                        }
                        Err(err) => {
                            self.metrics().persistent_worker_fallbacks.inc();
                            info!(
                                ?err,
                                ?key,
                                "Falling back to one-shot execution; persistent worker unavailable"
                            );
                        }
                    }
                }
                Err(err) => {
                    self.metrics().persistent_worker_fallbacks.inc();
                    info!(
                        ?err,
                        "Falling back to one-shot execution; unsupported persistent worker protocol"
                    );
                }
            }
        }

        let mut command_builder = process::Command::new(program);
        #[cfg(target_family = "unix")]
        command_builder.arg0(args[0]);
        command_builder
            .args(&args[1..])
            .kill_on_drop(true)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .current_dir(command_directory.clone())
            .env_clear();

        if self
            .running_actions_manager
            .execution_configuration
            .set_tmpdir
        {
            // One tmp per action, removed with the action directory, so two
            // actions writing the same name under $TMPDIR no longer collide.
            // Code that hardcodes /tmp still does.
            let tmp_directory = format!("{}/tmp", self.action_directory);
            fs::create_dir_all(&tmp_directory)
                .await
                .err_tip(|| format!("Creating {tmp_directory} for TMPDIR"))?;
            command_builder.env("TMPDIR", &tmp_directory);
        }

        let mut maybe_side_channel_file: Option<Cow<'_, OsStr>> = None;
        for (name, value) in self.action_environment(
            &command_proto,
            requested_timeout,
            Some(&mut maybe_side_channel_file),
        ) {
            command_builder.env(name, value);
        }

        #[cfg(target_family = "unix")]
        let authority_observer = self.state.lock().launch_observer.is_some();
        #[cfg(target_os = "linux")]
        let mut namespace_receipt = None;
        // Sandboxing of the command if we are running on Linux, this resolves issues where
        // children can spawn children and also provides better reproducibility.
        #[cfg(target_os = "linux")]
        {
            let use_namespaces = self.running_actions_manager.use_namespaces;

            if !matches!(use_namespaces, UseNamespaces::No) {
                let (mount, isolate_tmp) = match use_namespaces {
                    UseNamespaces::YesAndMount { isolate_tmp } => (true, isolate_tmp),
                    UseNamespaces::No | UseNamespaces::Yes => (false, false),
                };
                let root_action_directory = std::ffi::CString::new(
                    self.running_actions_manager.root_action_directory.clone(),
                )
                .err_tip(|| "In RunningActionImpl::inner_execute()")?;
                let action_directory = std::ffi::CString::new(self.action_directory.clone())
                    .err_tip(|| "In RunningActionImpl::inner_execute()")?;
                // The action's private /tmp is its own tmp directory, the
                // same one TMPDIR points at, bound over /tmp in the child.
                let tmp_directory = if isolate_tmp {
                    let tmp_directory = format!("{}/tmp", self.action_directory);
                    fs::create_dir_all(&tmp_directory)
                        .await
                        .err_tip(|| format!("Creating {tmp_directory} for the private /tmp"))?;
                    Some(
                        std::ffi::CString::new(tmp_directory)
                            .err_tip(|| "In RunningActionImpl::inner_execute()")?,
                    )
                } else {
                    None
                };

                let input_mounts = self.state.lock().input_mounts.clone();
                let bind_mounts = input_mounts
                    .as_ref()
                    .map(|mounts| mounts.bind_mounts())
                    .transpose()?
                    .unwrap_or_default();
                // The authority recipient needs proof about inner PID 1 even
                // when the outer stub is hard-killed. Legacy callers retain
                // their existing namespace setup and signal behavior.
                let receipt_sender = if authority_observer {
                    let (receiver, sender) =
                        crate::namespace_utils::NamespaceQuiescenceReceipt::channel()
                            .err_tip(|| "Creating namespace quiescence receipt channel")?;
                    namespace_receipt = Some(receiver);
                    Some(sender)
                } else {
                    None
                };
                // SAFETY: This function is specifically designed to operate in a async-signal-safe
                // environment.
                unsafe {
                    command_builder.pre_exec(move || {
                        crate::namespace_utils::configure_namespace_with_quiescence_receipt(
                            mount,
                            tmp_directory.as_deref(),
                            &root_action_directory,
                            &action_directory,
                            &bind_mounts,
                            receipt_sender.as_ref(),
                        )
                    });
                }
            }
        }
        // Run the action as its own process-group leader (pgid == child
        // pid) on every unix. The resource-usage sampler attributes memory
        // by process group, and the kill at exit ends the group, so this
        // keeps the whole action together, including processes reparented
        // to the worker when an intermediate shell exits, and never
        // conflates it with the worker's own group.
        #[cfg(target_family = "unix")]
        command_builder.process_group(0);

        let mut child_process = command_builder
            .spawn()
            .err_tip(|| format!("Could not execute command {args:?}"))?;
        // Close the parent's copy of the receipt sender held by pre_exec.
        drop(command_builder);
        // Ours until the wait below collects it; the reaper leaves it alone.
        let _owned_child = crate::reaper::OwnedChild::new(child_process.id());
        self.state.lock().process_domain_quiescent = false;
        if let Some(progress) = &self.progress {
            progress.set_phase(ProgressPhase::Running);
        }
        // A lost receipt leaves the authority adapter uncertain; it neither
        // retries this launch nor assumes the child failed to start. Legacy
        // execution installs no observer and follows the same process path.
        if let Some(observer) = self.state.lock().launch_observer.take()
            && let Some(pid) = child_process.id()
        {
            let _receipt = observer.send(pid);
        }
        let stdout_reader = child_process
            .stdout
            .take()
            .err_tip(|| "Expected stdout to exist on command this should never happen")?;
        let stderr_reader = child_process
            .stderr
            .take()
            .err_tip(|| "Expected stderr to exist on command this should never happen")?;

        #[cfg(target_os = "linux")]
        // Wrap the child process to send SIGTERM rather than SIGKILL if namespaced to
        // prevent zombie processes.
        let child_process = crate::namespace_utils::MaybeNamespacedChild::new(
            !matches!(
                self.running_actions_manager.use_namespaces,
                UseNamespaces::No,
            ),
            child_process,
        );

        // The reservation the scheduler placed this action by, if the
        // worker is asked to hold it to that number.
        let memory_reservation = if let Some(resources) = self.authority_resources {
            resources
                .memory_limit_kb
                .map(|limit_kb| (resources.charged.memory_bytes.div_ceil(1024), limit_kb))
        } else {
            self.running_actions_manager
                .execution_configuration
                .resource_enforcement
                .as_ref()
                .and_then(|enforcement| {
                    let memory = enforcement.memory.as_ref()?;
                    let reserved_kb = self
                        .action_info
                        .platform_properties
                        .get(&memory.property_name)?
                        .parse::<u64>()
                        .ok()?;
                    (reserved_kb > 0).then(|| {
                        let limit_kb =
                            reserved_kb.saturating_mul(100 + memory.headroom_percent) / 100;
                        (reserved_kb, limit_kb)
                    })
                })
        };
        // The disk reservation, held to only with `disk: soft`; disk is
        // measured whenever the enforcement names a disk property.
        let disk_enforcement = self
            .running_actions_manager
            .execution_configuration
            .resource_enforcement
            .as_ref()
            .and_then(|enforcement| {
                let property = enforcement.disk_property_name.as_deref()?;
                let reserved_kb = self
                    .action_info
                    .platform_properties
                    .get(property)
                    .and_then(|value| value.parse::<u64>().ok())
                    .unwrap_or(0);
                let limit_kb = (enforcement.disk_soft && reserved_kb > 0).then(|| {
                    reserved_kb.saturating_mul(100 + enforcement.disk_headroom_percent) / 100
                });
                Some((reserved_kb, limit_kb))
            });
        let (over_limit_tx, over_limit_rx) = oneshot::channel::<OverLimit>();
        // Holds the sender when no ceiling is enforced, so the receiver
        // below stays pending instead of resolving closed.
        let mut over_limit_keepalive = Some(over_limit_tx);
        #[cfg(target_os = "linux")]
        let mut maybe_resource_usage_sampler = child_process.id().map(|pgid| {
            let memory_limit_kb = memory_reservation.map(|(_, limit_kb)| limit_kb);
            let disk_limit_kb = disk_enforcement.and_then(|(_, limit_kb)| limit_kb);
            let over_limit_tx = (memory_limit_kb.is_some() || disk_limit_kb.is_some())
                .then(|| over_limit_keepalive.take())
                .flatten();
            let disk_directory = disk_enforcement.map(|_| {
                let directory = PathBuf::from(&self.action_directory);
                let since = directory_stamp(&directory).unwrap_or_else(|err| {
                    warn!(?err, "Timing the disk walk by the wall clock instead");
                    SystemTime::now()
                });
                (directory, since)
            });
            start_action_resource_usage_sampler(
                pgid,
                Ceilings {
                    memory_limit_kb,
                    disk_limit_kb,
                    over_limit_tx,
                },
                disk_directory,
            )
        });
        #[cfg(not(target_os = "linux"))]
        let _ = &disk_enforcement;
        let mut over_limit_fut = over_limit_rx.fuse();

        // The group to end when the action's own process has exited; taken
        // before the guard owns the child.
        #[cfg(target_family = "unix")]
        let action_pgid = child_process.id();
        let mut child_process_guard = guard(child_process, |mut child_process| {
            let result: Result<Option<std::process::ExitStatus>, std::io::Error> =
                child_process.try_wait();
            match result {
                Ok(res) if res.is_some() => {
                    // The child already exited, probably a timeout or kill operation
                }
                result => {
                    error!(
                        ?result,
                        "Child process was not cleaned up before dropping the call to execute(), killing in background spawn."
                    );
                    background_spawn!("running_actions_manager_kill_child_process", async move {
                        drop(child_process.kill().await);
                    });
                }
            }
        });

        let output_cap = self
            .running_actions_manager
            .execution_configuration
            .max_captured_output_bytes;
        let stdout_spill = PathBuf::from(&self.action_directory).join("nativelink.stdout");
        let stderr_spill = PathBuf::from(&self.action_directory).join("nativelink.stderr");
        // Flipped when the pipes have had their drain after the action
        // ended; the readers then keep what they have.
        let (drain_stop_tx, drain_stop_rx) = watch::channel(false);
        let stdout_stop = drain_stop_rx.clone();
        let all_stdout_fut = spawn!("stdout_reader", async move {
            capture_output(
                stdout_reader,
                output_cap,
                stdout_spill,
                "stdout",
                stdout_stop,
            )
            .await
        });
        let all_stderr_fut = spawn!("stderr_reader", async move {
            capture_output(
                stderr_reader,
                output_cap,
                stderr_spill,
                "stderr",
                drain_stop_rx,
            )
            .await
        });
        let mut kill_reason: Option<KillReason> = None;
        let kill_grace = self
            .running_actions_manager
            .execution_configuration
            .kill_grace;
        // Armed by a soft kill; fires SIGKILL if the action is still there
        // when the grace period ends.
        let mut grace_fut: Fuse<BoxFuture<'static, ()>> = Fuse::terminated();
        let execution_started = std::time::Instant::now();

        let timer = self.metrics().child_process.begin_timer();
        let mut sleep_fut = (self.running_actions_manager.callbacks.sleep_fn)(self.timeout).fuse();
        let process_progress = self
            .progress
            .as_ref()
            .map(|progress| progress.object(WorkKind::Process, b"owned-child"));
        let mut progress_tick = tokio::time::interval(Duration::from_secs(5));
        progress_tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        let mut progress_probe = 0_u64;
        let mut progress_enabled = process_progress.is_some();
        loop {
            tokio::select! {
                _ = progress_tick.tick(), if progress_enabled && kill_reason.is_none() && !*self.kill_token.borrow() => {
                    match child_process_guard.try_wait() {
                        Ok(None) => {
                            if let Some(next) = progress_probe.checked_add(1) {
                                progress_probe = next;
                                if let Some(progress) = &process_progress { progress.offset(next); }
                            } else {
                                progress_enabled = false;
                                warn!("Owned-child progress counter exhausted; renewal disabled");
                            }
                        }
                        Ok(Some(_)) => progress_enabled = false,
                        Err(error) => {
                            progress_enabled = false;
                            warn!(?error, "Owned-child progress probe failed; renewal disabled");
                        }
                    }
                }
                () = &mut sleep_fut => {
                    self.running_actions_manager.metrics.task_timeouts.inc();
                    kill_reason = Some(KillReason::Timeout);
                    grace_fut = stop_action(&mut child_process_guard, kill_grace, "action timeout").await;
                    {
                        let joined_command = args.join(OsStr::new(" "));
                        let command = joined_command.to_string_lossy();
                        info!(
                            seconds = self.action_info.timeout.as_secs_f32(),
                            %command,
                            %command_directory,
                            "Command timed out"
                        );
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), Some(Error::new(
                            Code::DeadlineExceeded,
                            format!(
                                "Command '{}' timed out after {} seconds",
                                command,
                                self.action_info.timeout.as_secs_f32()
                            )
                        )));
                    }
                },
                () = &mut grace_fut => {
                    warn!(
                        operation_id = ?self.operation_id,
                        grace_ms = kill_grace.as_millis(),
                        "Action did not leave on SIGTERM within its grace period, sending SIGKILL"
                    );
                    hard_kill(&mut child_process_guard, "grace period expired").await;
                },
                Ok(over_limit) = &mut over_limit_fut => match over_limit {
                    OverLimit::Disk(observed_kb) => {
                        self.running_actions_manager.metrics.disk_reservation_kills.inc();
                        kill_reason = Some(KillReason::Disk);
                        // The files are still being written; no grace here.
                        hard_kill(&mut child_process_guard, "disk reservation").await;
                        let (reserved_kb, limit_kb) = disk_enforcement
                            .map_or((0, 0), |(reserved_kb, limit_kb)| {
                                (reserved_kb, limit_kb.unwrap_or(0))
                            });
                        let (property, headroom) = self
                            .running_actions_manager
                            .execution_configuration
                            .resource_enforcement
                            .as_ref()
                            .map_or(("", 0), |e| (e.disk_property_name.as_deref().unwrap_or(""), e.disk_headroom_percent));
                        warn!(
                            operation_id = ?self.operation_id,
                            reserved_kb,
                            limit_kb,
                            observed_kb,
                            "Action exceeded its disk reservation, killed"
                        );
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), Some(Error::new(
                            Code::FailedPrecondition,
                            format!(
                                "Action exceeded its disk reservation: reserved {reserved_kb} KiB ({property}), \
                                 limit {limit_kb} KiB with {headroom}% headroom, its own files came to {observed_kb} KiB. \
                                 Raise the reservation or write less."
                            ),
                        )));

                    }
                    OverLimit::Memory(observed_kb) => {
                        self.running_actions_manager.metrics.memory_reservation_kills.inc();
                        kill_reason = Some(KillReason::Memory);
                        // Memory is still growing; no grace here.
                        hard_kill(&mut child_process_guard, "memory reservation").await;
                        let (reserved_kb, limit_kb) = memory_reservation.unwrap_or((0, 0));
                        let (property, headroom) = self
                            .running_actions_manager
                            .execution_configuration
                            .resource_enforcement
                            .as_ref()
                            .and_then(|e| e.memory.as_ref())
                            .map_or(("", 0), |m| (if self.authority_resources.is_some() { "typed authority grant" } else { m.property_name.as_str() }, m.headroom_percent));
                        warn!(
                            operation_id = ?self.operation_id,
                            reserved_kb,
                            limit_kb,
                            observed_kb,
                            "Action exceeded its memory reservation, killed"
                        );
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), Some(Error::new(
                            Code::FailedPrecondition,
                            format!(
                                "Action exceeded its memory reservation: reserved {reserved_kb} KiB ({property}), \
                                 limit {limit_kb} KiB with {headroom}% headroom, observed {observed_kb} KiB. \
                                 Raise the reservation or shrink the action."
                            ),
                        )));

                    }
                },
                maybe_exit_status = child_process_guard.wait() => {
                    // Defuse our guard so it does not try to cleanup and make senseless logs.
                    drop(ScopeGuard::<_, _>::into_inner(child_process_guard));
                    drop(over_limit_keepalive.take());
                    let exit_status = maybe_exit_status.err_tip(|| "Failed to collect exit code of process")?;
                    #[cfg(target_os = "linux")]
                    if let Some(receipt) = namespace_receipt.take() {
                        // Waiting for outer SIGKILL alone is insufficient.
                        // Bound receipt delivery and actual inner-domain exit;
                        // any failure keeps the reservation charged.
                        match tokio::time::timeout(
                            self.running_actions_manager.max_cleanup_wait,
                            receipt.close_and_wait(),
                        ).await {
                            Ok(Ok(())) => self.state.lock().process_domain_quiescent = true,
                            result => warn!(?result, "Namespace quiescence remains unconfirmed"),
                        }
                    } else if !matches!(self.running_actions_manager.use_namespaces, UseNamespaces::No)
                        && exit_status.code().is_some_and(|code| code != 255)
                    {
                        // Legacy outer-stub ordinary exit follows waitpid(PID1).
                        // A signalled stub and its wait-error sentinel (255)
                        // cannot prove that the inner namespace has exited.
                        self.state.lock().process_domain_quiescent = true;
                    }
                    // TODO(palfrey) We should implement stderr/stdout streaming to client here.
                    // If we get killed before the stream is started, then these will lock up.
                    let killed_action = kill_reason.is_some();
                    if killed_action {
                        drop(timer);
                    } else {
                        timer.measure();
                    }
                    // The action is over; anything still running in its
                    // group is a straggler (a background job, a helper that
                    // daemonized) holding the pipes open, and without this
                    // the action would sit here until its timeout. The
                    // sandboxes Bazel runs locally end them the same way.
                    #[cfg(target_family = "unix")]
                    let had_stragglers = if authority_observer {
                        // The authority path closes a namespace by exact pidfd.
                        // A reaped child's numeric PGID may have been reused,
                        // so it must never receive a late signal. Unisolated
                        // or unconfirmed domains still bound the output drain
                        // and retain their original reservation.
                        !self.state.lock().process_domain_quiescent
                    } else {
                        action_pgid.is_some_and(|pgid| signal_process_group(pgid, libc::SIGKILL))
                    };
                    #[cfg(not(target_family = "unix"))]
                    let had_stragglers = false;
                    // An action that exited on its own with nothing left in
                    // its group closes its pipes itself, and its output is
                    // the result, so that read runs to the end: a reader
                    // slowed by a busy spill must not lose bytes to a clock.
                    // The wait is bounded only when there was something to
                    // hold the pipes: a killed action, whose output is a
                    // bonus, or stragglers, one of which may have left the
                    // group. What was read by then is kept.
                    let mut drain = core::pin::pin!(async { tokio::join!(all_stdout_fut, all_stderr_fut) });
                    let (maybe_all_stdout, maybe_all_stderr) = if killed_action || had_stragglers {
                        tokio::select! {
                            outputs = &mut drain => outputs,
                            () = tokio::time::sleep(OUTPUT_DRAIN_TIMEOUT) => {
                                warn!(
                                    operation_id = ?self.operation_id,
                                    drain_s = OUTPUT_DRAIN_TIMEOUT.as_secs(),
                                    killed_action,
                                    had_stragglers,
                                    "A process held the action's output pipes open past the drain; keeping what was read"
                                );
                                drain_stop_tx.send_replace(true);
                                drain.await
                            }
                        }
                    } else {
                        drain.await
                    };
                    let (stdout, stderr) = (
                        maybe_all_stdout.err_tip(|| "Internal error reading from stdout of worker task")??,
                        maybe_all_stderr.err_tip(|| "Internal error reading from stderr of worker task")??,
                    );

                    #[cfg(target_os = "linux")]
                    let sampled_usage = match maybe_resource_usage_sampler.take() {
                        Some(sampler) => finish_action_resource_usage_sampler(sampler)
                            .await
                            .unwrap_or_default(),
                        None => SampledResourceUsage::default(),
                    };
                    #[cfg(not(target_os = "linux"))]
                    let sampled_usage = SampledResourceUsage::default();

                    let memory_limit_kb = memory_reservation
                        .map(|(_, limit_kb)| limit_kb)
                        .or(self.running_actions_manager.pod_memory_limit_kb);
                    // The signal that ended the process, where the platform reports one.
                    #[cfg(target_family = "unix")]
                    let signal = exit_status.signal();
                    #[cfg(not(target_family = "unix"))]
                    let signal = None;
                    let (outcome, enforced) = classify_outcome(
                        kill_reason,
                        signal,
                        sampled_usage.last_memory_kb,
                        memory_limit_kb,
                    );

                    let exit_code = exit_status.code().map_or_else(|| {
                        self.metrics().child_process_failure_error_code.inc();
                        if kill_reason.is_none() {
                            // No exit code and no kill of ours: a signal from
                            // outside. SIGKILL near the memory limit is the
                            // kernel's OOM killer.
                            warn!(
                                ?args,
                                outcome = outcome.as_str_name(),
                                last_memory_kb = sampled_usage.last_memory_kb,
                                ?memory_limit_kb,
                                "Runner subprocess terminated by a signal nobody here sent"
                            );
                        }
                        EXIT_CODE_FOR_SIGNAL
                    }, |exit_code| {
                        if exit_code == 0 {
                            self.metrics().child_process_success_error_code.inc();
                        } else {
                            self.metrics().child_process_failure_error_code.inc();
                        }
                        exit_code
                    });
                    if kill_reason.is_none() && outcome == ResourceOutcome::KilledMemory {
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), Some(Error::new(
                            Code::FailedPrecondition,
                            format!(
                                "Action was killed by the kernel at {} KiB, within 10% of the {} KiB memory limit: \
                                 out of memory. Raise the reservation or shrink the action.",
                                sampled_usage.last_memory_kb,
                                memory_limit_kb.unwrap_or(0),
                            ),
                        )));
                    }

                    let (memory_property, disk_property) = self
                        .running_actions_manager
                        .execution_configuration
                        .resource_enforcement
                        .as_ref()
                        .map_or((None, None), |e| {
                            (
                                e.memory.as_ref().map(|m| m.property_name.as_str()),
                                e.disk_property_name.as_deref(),
                            )
                        });
                    let resource_usage = Some(ActionResourceUsage {
                        peak_memory_kb: sampled_usage.peak_memory_kb,
                        cpu_time_ms: sampled_usage.cpu_time_ms,
                        // An action too short to catch a sample leaves both at
                        // zero; say so rather than report a misleading zero.
                        sampled: sampled_usage.peak_memory_kb > 0
                            || sampled_usage.cpu_time_ms > 0
                            || sampled_usage.peak_disk_kb > 0,
                        operation_id: String::new(),
                        worker_id: String::new(),
                        wall_time_ms: u64::try_from(execution_started.elapsed().as_millis()).unwrap_or(u64::MAX),
                        peak_disk_kb: sampled_usage.peak_disk_kb,
                        outcome: outcome.into(),
                        enforced,
                        reserved: self.usage_reservation(memory_property, disk_property),
                    });

                    // log something useful instead of repeating same ?arg
                    info!(?exit_code, outcome = outcome.as_str_name(), "Command complete");

                    let maybe_error_override = if let Some(side_channel_file) = maybe_side_channel_file {
                        process_side_channel_file(side_channel_file.clone(), &args, requested_timeout).await
                        .err_tip(|| format!("Error processing side channel file: {}", side_channel_file.display()))?
                    } else {
                        None
                    };
                    {
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), maybe_error_override);

                        state.command_proto = Some(command_proto);
                        state.execution_result = Some(RunningActionImplExecutionResult{
                            stdout,
                            stderr,
                            exit_code,
                            resource_usage,
                        });
                        state.execution_metadata.execution_completed_timestamp = (self.running_actions_manager.callbacks.now_fn)();
                    }
                    return Ok(self);
                },
                _ = &mut kill_channel_rx => {
                    kill_reason = Some(KillReason::External);
                    grace_fut = stop_action(&mut child_process_guard, kill_grace, "scheduler kill").await;
                    {
                        let mut state = self.state.lock();
                        state.error = Error::merge_option(state.error.take(), Some(Error::new(
                            Code::Aborted,
                            format!(
                                "Command '{}' was killed by scheduler",
                                args.join(OsStr::new(" ")).to_string_lossy()
                            )
                        )));
                    }
                },
            }
        }
        // Unreachable.
    }

    async fn inner_upload_results(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        enum OutputType {
            None,
            File(FileInfo),
            Directory(DirectoryInfo),
            FileSymlink(SymlinkInfo),
            DirectorySymlink(SymlinkInfo),
        }

        let upload_start = std::time::Instant::now();
        debug!(
            operation_id = ?self.operation_id,
            "Worker uploading results - starting",
        );
        let (mut command_proto, execution_result, mut execution_metadata) = {
            let mut state = self.state.lock();
            state.execution_metadata.output_upload_start_timestamp =
                (self.running_actions_manager.callbacks.now_fn)();
            (
                state
                    .command_proto
                    .take()
                    .err_tip(|| "Expected state to have command_proto in execute()")?,
                state
                    .execution_result
                    .take()
                    .err_tip(|| "Execution result does not exist at upload_results stage")?,
                state.execution_metadata.clone(),
            )
        };
        let cas_store = self.running_actions_manager.cas_store.as_ref();
        let hasher = self.action_info.unique_qualifier.digest_function();

        let mut output_path_futures: Vec<BoxFuture<'_, Result<OutputType, Error>>> = Vec::new();
        let mut output_paths = command_proto.output_paths;
        if output_paths.is_empty() {
            output_paths
                .reserve(command_proto.output_files.len() + command_proto.output_directories.len());
            output_paths.append(&mut command_proto.output_files);
            output_paths.append(&mut command_proto.output_directories);
        }
        let digest_uploaders = Arc::new(Mutex::new(HashMap::new()));
        let uploads = Arc::new(Semaphore::new(UPLOAD_CONCURRENCY));
        for entry in output_paths {
            let full_path = OsString::from(if command_proto.working_directory.is_empty() {
                format!("{}/{}", self.work_directory, entry)
            } else {
                format!(
                    "{}/{}/{}",
                    self.work_directory, command_proto.working_directory, entry
                )
            });
            let work_directory = &self.work_directory;
            let digest_uploaders = digest_uploaders.clone();
            let uploads = uploads.clone();
            output_path_futures.push(
                async move {
                    let metadata = {
                        let metadata = match fs::symlink_metadata(&full_path).await {
                            Ok(file) => file,
                            Err(e) => {
                                if e.code == Code::NotFound {
                                    // In the event our output does not exist, according to the bazel remote
                                    // execution spec, we simply ignore it continue.
                                    return Result::<OutputType, Error>::Ok(OutputType::None);
                                }
                                return Err(e).err_tip(|| {
                                    format!("Could not open file {}", full_path.display())
                                });
                            }
                        };

                        if metadata.is_file() {
                            return Ok(OutputType::File(
                                upload_file(
                                    cas_store.as_pin(),
                                    &full_path,
                                    hasher,
                                    metadata,
                                    digest_uploaders,
                                    uploads,
                                )
                                .await
                                .map(|mut file_info| {
                                    file_info.name_or_path = NameOrPath::Path(entry);
                                    file_info
                                })
                                .err_tip(|| format!("Uploading file {}", full_path.display()))?,
                            ));
                        }
                        metadata
                    };
                    if metadata.is_dir() {
                        Ok(OutputType::Directory(
                            upload_directory(
                                cas_store.as_pin(),
                                &full_path,
                                work_directory,
                                hasher,
                                digest_uploaders,
                                uploads,
                            )
                            .and_then(|(root_dir, children)| async move {
                                let tree = ProtoTree {
                                    root: Some(root_dir),
                                    children: children.into(),
                                };
                                let tree_digest = serialize_and_upload_message(
                                    &tree,
                                    cas_store.as_pin(),
                                    &mut hasher.hasher(),
                                )
                                .await
                                .err_tip(|| format!("While processing {entry}"))?;
                                Ok(DirectoryInfo {
                                    path: entry,
                                    tree_digest,
                                })
                            })
                            .await
                            .err_tip(|| format!("Uploading directory {}", full_path.display()))?,
                        ))
                    } else if metadata.is_symlink() {
                        // Resolve the symlink to determine what it points to.
                        // Symlinks created by DirectoryCache (absolute paths into
                        // the cache directory) must NOT be uploaded as symlinks —
                        // the target path is worker-local and meaningless to the
                        // client. Instead, follow the symlink and upload the
                        // resolved content (file or directory).
                        let target = fs::read_link(&full_path).await.err_tip(|| {
                            format!("Reading symlink target for {}", full_path.display())
                        })?;
                        let is_absolute_symlink = Path::new(&target).is_absolute();

                        if is_absolute_symlink {
                            // Absolute symlink — resolve and upload contents.
                            match fs::metadata(&full_path).await {
                                Ok(resolved_meta) => {
                                    if resolved_meta.is_dir() {
                                        // Upload as directory (Tree proto).
                                        Ok(OutputType::Directory(
                                            upload_directory(
                                                cas_store.as_pin(),
                                                &full_path,
                                                work_directory,
                                                hasher,
                                                digest_uploaders,
                                                uploads,
                                            )
                                            .and_then(|(root_dir, children)| async move {
                                                let tree = ProtoTree {
                                                    root: Some(root_dir),
                                                    children: children.into(),
                                                };
                                                let tree_digest = serialize_and_upload_message(
                                                    &tree,
                                                    cas_store.as_pin(),
                                                    &mut hasher.hasher(),
                                                )
                                                .await
                                                .err_tip(|| format!("While processing {entry}"))?;
                                                Ok(DirectoryInfo {
                                                    path: entry,
                                                    tree_digest,
                                                })
                                            })
                                            .await
                                            .err_tip(
                                                || {
                                                    format!(
                                                        "Uploading symlinked directory {}",
                                                        full_path.display()
                                                    )
                                                },
                                            )?,
                                        ))
                                    } else {
                                        // Upload as file (follow symlink).
                                        Ok(OutputType::File(
                                            upload_file(
                                                cas_store.as_pin(),
                                                &full_path,
                                                hasher,
                                                resolved_meta,
                                                digest_uploaders,
                                                uploads,
                                            )
                                            .await
                                            .map(|mut file_info| {
                                                file_info.name_or_path = NameOrPath::Path(entry);
                                                file_info
                                            })
                                            .err_tip(
                                                || {
                                                    format!(
                                                        "Uploading symlinked file {}",
                                                        full_path.display()
                                                    )
                                                },
                                            )?,
                                        ))
                                    }
                                }
                                Err(e) => {
                                    if e.code != Code::NotFound {
                                        return Err(e).err_tip(|| {
                                            format!(
                                                "While resolving absolute symlink {}",
                                                full_path.display()
                                            )
                                        });
                                    }
                                    Ok(OutputType::None)
                                }
                            }
                        } else {
                            // Relative symlink — action intentionally created it.
                            // Upload as a proper symlink.
                            let output_symlink = upload_symlink(&full_path, work_directory)
                                .await
                                .map(|mut symlink_info| {
                                    symlink_info.name_or_path = NameOrPath::Path(entry);
                                    symlink_info
                                })
                                .err_tip(|| format!("Uploading symlink {}", full_path.display()))?;
                            match fs::metadata(&full_path).await {
                                Ok(metadata) => {
                                    if metadata.is_dir() {
                                        Ok(OutputType::DirectorySymlink(output_symlink))
                                    } else {
                                        // Note: If it's anything but directory we put it as a file symlink.
                                        Ok(OutputType::FileSymlink(output_symlink))
                                    }
                                }
                                Err(e) => {
                                    if e.code != Code::NotFound {
                                        return Err(e).err_tip(|| {
                                            format!(
                                                "While querying target symlink metadata for {}",
                                                full_path.display()
                                            )
                                        });
                                    }
                                    // If the file doesn't exist, we consider it a file. Even though the
                                    // file doesn't exist we still need to populate an entry.
                                    Ok(OutputType::FileSymlink(output_symlink))
                                }
                            }
                        }
                    } else {
                        Err(make_err!(
                            Code::Internal,
                            "{full_path:?} was not a file, folder or symlink. Must be one.",
                        ))
                    }
                }
                .boxed(),
            );
        }
        let mut output_files = vec![];
        let mut output_folders = vec![];
        let mut output_directory_symlinks = vec![];
        let mut output_file_symlinks = vec![];

        if execution_result.exit_code != 0 {
            error!(
                exit_code = ?execution_result.exit_code,
                stdout = ?log_excerpt(execution_result.stdout.head(), 1000),
                stderr = ?log_excerpt(execution_result.stderr.head(), 1000),
                command = ?command_proto.arguments,
                "Command returned non-zero exit code",
            );
        }

        let stdout_digest_fut = self.metrics().upload_stdout.wrap(async {
            let start = std::time::Instant::now();
            let data = execution_result.stdout;
            let data_len = data.len();
            // Boxed: the upload future is large, and two of them inline
            // pushed the debug test binary past its thread stack.
            let digest = Box::pin(upload_captured_output(
                cas_store.as_pin(),
                data,
                hasher,
                "stdout",
            ))
            .await?;
            debug!(
                ?digest,
                data_len,
                elapsed_ms = start.elapsed().as_millis(),
                "upload_results: stdout upload completed",
            );
            Result::<DigestInfo, Error>::Ok(digest)
        });
        let stderr_digest_fut = self.metrics().upload_stderr.wrap(async {
            let start = std::time::Instant::now();
            let data = execution_result.stderr;
            let data_len = data.len();
            // Boxed: the upload future is large, and two of them inline
            // pushed the debug test binary past its thread stack.
            let digest = Box::pin(upload_captured_output(
                cas_store.as_pin(),
                data,
                hasher,
                "stderr",
            ))
            .await?;
            debug!(
                ?digest,
                data_len,
                elapsed_ms = start.elapsed().as_millis(),
                "upload_results: stderr upload completed",
            );
            Result::<DigestInfo, Error>::Ok(digest)
        });

        debug!(
            operation_id = ?self.operation_id,
            num_output_paths = output_path_futures.len(),
            "upload_results: starting stdout/stderr/output_paths uploads",
        );
        let mut output_path_futures =
            futures::stream::iter(output_path_futures).buffer_unordered(UPLOAD_CONCURRENCY);
        let join_start = std::time::Instant::now();
        let upload_result = futures::try_join!(stdout_digest_fut, stderr_digest_fut, async {
            while let Some(output_type) = output_path_futures.try_next().await? {
                match output_type {
                    OutputType::File(output_file) => output_files.push(output_file),
                    OutputType::Directory(output_folder) => output_folders.push(output_folder),
                    OutputType::FileSymlink(output_symlink) => {
                        output_file_symlinks.push(output_symlink);
                    }
                    OutputType::DirectorySymlink(output_symlink) => {
                        output_directory_symlinks.push(output_symlink);
                    }
                    OutputType::None => { /* Safe to ignore */ }
                }
            }
            Ok(())
        });
        drop(output_path_futures);
        debug!(
            operation_id = ?self.operation_id,
            elapsed_ms = join_start.elapsed().as_millis(),
            success = upload_result.is_ok(),
            "upload_results: all uploads completed",
        );
        let resource_usage = execution_result.resource_usage.clone();
        let (stdout_digest, stderr_digest) = match upload_result {
            Ok((stdout_digest, stderr_digest, ())) => (stdout_digest, stderr_digest),
            Err(e) => return Err(e).err_tip(|| "Error while uploading results"),
        };

        execution_metadata.output_upload_completed_timestamp =
            (self.running_actions_manager.callbacks.now_fn)();
        output_files.sort_unstable_by(|a, b| a.name_or_path.cmp(&b.name_or_path));
        output_folders.sort_unstable_by(|a, b| a.path.cmp(&b.path));
        output_file_symlinks.sort_unstable_by(|a, b| a.name_or_path.cmp(&b.name_or_path));
        output_directory_symlinks.sort_unstable_by(|a, b| a.name_or_path.cmp(&b.name_or_path));
        let num_output_files = output_files.len();
        let num_output_folders = output_folders.len();
        {
            let mut state = self.state.lock();
            execution_metadata.worker_completed_timestamp =
                (self.running_actions_manager.callbacks.now_fn)();
            state.action_result = Some(ActionResult {
                output_files,
                output_folders,
                output_directory_symlinks,
                output_file_symlinks,
                exit_code: execution_result.exit_code,
                stdout_digest,
                stderr_digest,
                execution_metadata,
                server_logs: HashMap::default(), // TODO(palfrey) Not implemented.
                error: state.error.clone(),
                message: String::new(), // Will be filled in on cache_action_result if needed.
            });
            state.resource_usage = resource_usage;
        }
        debug!(
            operation_id = ?self.operation_id,
            total_elapsed_ms = upload_start.elapsed().as_millis(),
            num_output_files,
            num_output_folders,
            "upload_results: inner_upload_results completed successfully",
        );
        Ok(self)
    }

    async fn inner_get_finished_result(self: Arc<Self>) -> Result<ActionResult, Error> {
        let mut state = self.state.lock();
        state
            .action_result
            .take()
            .err_tip(|| "Expected action_result to exist in get_finished_result")
    }
}

impl Drop for RunningActionImpl {
    fn drop(&mut self) {
        if self.did_cleanup.load(Ordering::Acquire) {
            if self.has_manager_entry.load(Ordering::Acquire) {
                drop(
                    self.running_actions_manager
                        .cleanup_action(&self.operation_id),
                );
            }
            if let Some(input_lease) = self.input_lease.clone() {
                background_spawn!(
                    "running_action_impl_release_input_lease",
                    input_lease.release()
                );
            }
            return;
        }
        let operation_id = self.operation_id.clone();
        error!(
            %operation_id,
            "RunningActionImpl did not cleanup. This is a violation of the requirements, will attempt to do it in the background."
        );
        let running_actions_manager = self.running_actions_manager.clone();
        let action_directory = self.action_directory.clone();
        let input_lease = self.input_lease.clone();
        let input_mounts = self.state.get_mut().input_mounts.take();
        background_spawn!("running_action_impl_drop", async move {
            let cleanup_result =
                do_cleanup(&running_actions_manager, &operation_id, &action_directory).await;
            drop(input_mounts);
            if let Some(input_lease) = input_lease {
                input_lease.release().await;
            }
            if let Err(err) = cleanup_result {
                error!(
                    %operation_id,
                    ?action_directory,
                    ?err,
                    "Error cleaning up action"
                );
            }
        });
    }
}

impl RunningAction for RunningActionImpl {
    fn get_operation_id(&self) -> &OperationId {
        &self.operation_id
    }

    fn observe_launch(&self, observer: oneshot::Sender<u32>) -> Result<(), Error> {
        if self
            .running_actions_manager
            .execution_configuration
            .persistent_workers
            .enabled
        {
            return Err(make_err!(
                Code::Unimplemented,
                "Authority launch observation does not qualify persistent workers"
            ));
        }
        let mut state = self.state.lock();
        if state.launch_observer.is_some() || state.kill_channel_rx.is_none() {
            return Err(make_err!(
                Code::FailedPrecondition,
                "Launch observation must be installed once before execution"
            ));
        }
        state.launch_observer = Some(observer);
        Ok(())
    }

    fn process_domain_quiescent(&self) -> bool {
        self.state.lock().process_domain_quiescent
    }

    async fn prepare_action(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        let download_timeout = self.running_actions_manager.max_download_timeout;
        let operation_id = self.operation_id.clone();
        let manager = self.running_actions_manager.clone();
        let metrics = self.metrics().clone();
        let mut kill_rx = self.kill_token.subscribe();
        // The retry loop inside stops short of this; the timeout below is
        // the backstop for an attempt that never answers. The retries are
        // also bounded by the action's own timeout: the scheduler ends the
        // action soon after that passes, whatever the worker is still
        // fetching. A window too far out to represent leaves the retries
        // unbounded, as the timeout is.
        let action_timeout = self.action_info.timeout;
        let retry_window = if self.authority_request || action_timeout.is_zero() {
            download_timeout
        } else {
            download_timeout.min(action_timeout)
        };
        let download_deadline = Instant::now().checked_add(retry_window);
        // Boxed: the prepare state machine is large, and pinning it on the
        // stack next to the select below overflowed a test thread.
        let mut prepare_fut = Box::pin(work_progress::scope(
            self.progress.clone(),
            Box::pin(
                metrics
                    .prepare_action
                    .wrap(Self::inner_prepare_action(self, download_deadline)),
            ),
        ));
        // A fetch that never answers would otherwise hold the slot for good
        // while the worker's keepalives say it is fine: name it every minute
        // and give up at the timeout, so the scheduler can retry elsewhere.
        let stall_warn_fut = async {
            let mut elapsed_secs = 0u64;
            loop {
                tokio::time::sleep(Duration::from_mins(1)).await;
                elapsed_secs += 60;
                warn!(
                    ?operation_id,
                    elapsed_s = elapsed_secs,
                    timeout_s = download_timeout.as_secs(),
                    "prepare_action: still fetching inputs, possible stall",
                );
            }
        };
        let res = tokio::time::timeout(download_timeout, async {
            tokio::pin!(stall_warn_fut);
            tokio::select! {
                result = &mut prepare_fut => result,
                _ = kill_rx.wait_for(|killed| *killed) => {
                    warn!(%operation_id, "prepare_action: killed while fetching inputs");
                    Err(make_err!(
                        Code::Aborted,
                        "Operation {operation_id} was killed while fetching its inputs"
                    ))
                }
                () = &mut stall_warn_fut => unreachable!(),
            }
        })
        .await
        .map_err(|_| {
            warn!(
                %operation_id,
                timeout_s = download_timeout.as_secs(),
                "prepare_action: input fetch timed out"
            );
            let err = make_err!(
                Code::DeadlineExceeded,
                "Fetching the inputs of operation {operation_id} took longer than max_download_timeout ({}s)",
                download_timeout.as_secs(),
            );
            manager.suggest_input_download_pool(&operation_id, &err);
            err
        })
        .and_then(|res| res);
        if let Err(ref e) = res {
            warn!(?e, "Error during prepare_action");
        }
        res
    }

    async fn execute(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        let res = work_progress::scope(
            self.progress.clone(),
            Box::pin(
                self.metrics()
                    .clone()
                    .execute
                    .wrap(Self::inner_execute(self)),
            ),
        )
        .await;
        if let Err(ref e) = res {
            warn!(?e, "Error during prepare_action");
        }
        res
    }

    async fn upload_results(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        let upload_timeout = self.running_actions_manager.max_upload_timeout;
        let operation_id = self.operation_id.clone();
        info!(
            ?operation_id,
            upload_timeout_s = upload_timeout.as_secs(),
            "upload_results: starting with timeout",
        );
        let metrics = self.metrics().clone();
        let kill_token = self.kill_token.clone();
        if let Some(progress) = &self.progress {
            progress.set_phase(ProgressPhase::Uploading);
        }
        let upload_fut = work_progress::scope(
            self.progress.clone(),
            Box::pin(
                metrics
                    .upload_results
                    .wrap(Self::inner_upload_results(self)),
            ),
        );

        let stall_warn_fut = async {
            let mut elapsed_secs = 0u64;
            loop {
                tokio::time::sleep(Duration::from_mins(1)).await;
                elapsed_secs += 60;
                warn!(
                    ?operation_id,
                    elapsed_s = elapsed_secs,
                    timeout_s = upload_timeout.as_secs(),
                    "upload_results: still in progress — possible stall",
                );
            }
        };

        // Only a kill that arrives during the upload ends it: a kill that
        // already ended the command leaves a killed result that still has to
        // reach the scheduler, so the token's current state is taken as seen
        // and only a change from here on aborts.
        let mut kill_rx = kill_token.subscribe();
        kill_rx.borrow_and_update();
        let res = tokio::time::timeout(upload_timeout, async {
            tokio::pin!(upload_fut);
            tokio::pin!(stall_warn_fut);
            tokio::select! {
                result = &mut upload_fut => result,
                Ok(()) = kill_rx.changed() => {
                    warn!(%operation_id, "upload_results: killed while uploading");
                    Err(make_err!(
                        Code::Aborted,
                        "Operation {operation_id} was killed while uploading its results"
                    ))
                }
                () = &mut stall_warn_fut => unreachable!(),
            }
        })
        .await
        .map_err(|err| {
            warn!(%operation_id, timeout=upload_timeout.as_secs(), "Upload results timeout");
            Error::from_std_err(Code::DeadlineExceeded, &err).append(format!(
                "Upload results timed out after {}s for operation {:?}",
                upload_timeout.as_secs(),
                operation_id,
            ))
        })?;
        if let Err(ref e) = res {
            warn!(?operation_id, ?e, "Error during upload_results");
        }
        res
    }

    async fn cleanup(self: Arc<Self>) -> Result<Arc<Self>, Error> {
        let res = self
            .metrics()
            .clone()
            .cleanup
            .wrap(async move {
                let result = do_cleanup(
                    &self.running_actions_manager,
                    &self.operation_id,
                    &self.action_directory,
                )
                .await;
                self.has_manager_entry.store(false, Ordering::Release);
                self.did_cleanup.store(true, Ordering::Release);
                self.state.lock().input_mounts.take();
                // The work directory and manager entry are gone before the
                // lease is released. If this future is cancelled while the
                // release task is finishing, Drop still observes a completed
                // cleanup and cannot strand the action in the manager.
                if let Some(input_lease) = self.input_lease.clone() {
                    input_lease.release().await;
                }
                result.map(move |()| self)
            })
            .await;
        if let Err(ref e) = res {
            warn!(?e, "Error during cleanup");
        }
        res
    }

    async fn get_finished_result(self: Arc<Self>) -> Result<ActionResult, Error> {
        self.metrics()
            .clone()
            .get_finished_result
            .wrap(Self::inner_get_finished_result(self))
            .await
    }

    fn authority_resource_limits(&self) -> Option<AuthorityResourceLimits> {
        self.authority_resources
    }

    fn resource_usage(&self) -> Option<ActionResourceUsage> {
        self.state.lock().resource_usage.clone()
    }

    fn get_work_directory(&self) -> &String {
        &self.work_directory
    }
}

pub trait RunningActionsManager: Sync + Send + Sized + Unpin + 'static {
    type RunningAction: RunningAction;

    fn create_and_add_action(
        self: &Arc<Self>,
        worker_id: String,
        start_execute: StartExecute,
    ) -> impl Future<Output = Result<Arc<Self::RunningAction>, Error>> + Send;

    /// Authority dispatch requires complete accepted platform facts, finite
    /// execution deadlines and the exact immutable accounting grant.
    /// Implementations must opt in explicitly; platform strings are not grants.
    fn create_and_add_authority_action(
        self: &Arc<Self>,
        _worker_id: String,
        _start_execute: StartExecute,
        _reserved_resources: AuthorityResources,
    ) -> impl Future<Output = Result<Arc<Self::RunningAction>, Error>> + Send {
        async {
            Err(make_err!(
                Code::Unimplemented,
                "authority action creation is unsupported"
            ))
        }
    }

    /// Install a bounded observer before the initial Action CAS fetch.
    fn create_and_add_authority_action_observed(
        self: &Arc<Self>,
        _worker_id: String,
        _start_execute: StartExecute,
        _reserved_resources: AuthorityResources,
        _progress: ProgressObserver,
    ) -> impl Future<Output = Result<Arc<Self::RunningAction>, Error>> + Send {
        async {
            Err(make_err!(
                Code::Unimplemented,
                "authority progress observation is unsupported"
            ))
        }
    }

    fn cache_action_result(
        &self,
        action_digest: DigestInfo,
        action_result: &mut ActionResult,
        hasher: DigestHasherFunc,
    ) -> impl Future<Output = Result<(), Error>> + Send;

    fn kill_all(&self) -> impl Future<Output = ()> + Send;

    fn kill_operation(
        &self,
        operation_id: &OperationId,
    ) -> impl Future<Output = Result<(), Error>> + Send;

    fn metrics(&self) -> &Arc<Metrics>;
}

/// A function to get the current system time, used to allow mocking for tests
type NowFn = fn() -> SystemTime;
type SleepFn = fn(Duration) -> BoxFuture<'static, ()>;

/// Functions that may be injected for testing purposes, during standard control
/// flows these are specified by the new function.
#[derive(Clone, Copy)]
pub struct Callbacks {
    /// A function that gets the current time.
    pub now_fn: NowFn,
    /// A function that sleeps for a given Duration.
    pub sleep_fn: SleepFn,
}

impl Debug for Callbacks {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("Callbacks").finish_non_exhaustive()
    }
}

/// The set of additional information for executing an action over and above
/// those given in the `ActionInfo` passed to the worker.  This allows
/// modification of the action for execution on this particular worker.  This
/// may be used to run the action with a particular set of additional
/// environment variables, or perhaps configure it to execute within a
/// container.
/// What the worker holds an action to beyond the scheduler's ledger. Each
/// axis is on or off on its own; the value exists when at least one is on.
#[derive(Debug, Clone)]
pub struct ResourceEnforcement {
    /// Soft memory enforcement: the worker kills an action whose process
    /// group grows past its reservation plus headroom. Linux only; the
    /// sampler that measures it does not exist elsewhere. An action run
    /// through a persistent worker is not covered: that process outlives
    /// the action and serves others, so its memory is no one action's
    /// reservation, and only the pod's limit bounds it.
    pub memory: Option<MemoryLimit>,
    /// Refuse an action whose disk reservation, under this property, is
    /// more than the free space under the work directory less what the
    /// actions already admitted reserved, and measure what the action
    /// writes.
    pub disk_property_name: Option<String>,
    /// Kill an action whose own files pass the disk reservation plus
    /// `disk_headroom_percent`.
    pub disk_soft: bool,
    pub disk_headroom_percent: u64,
}

/// The reservation a memory ceiling is built from.
#[derive(Debug, Clone)]
pub struct MemoryLimit {
    /// Legacy platform property carrying the reservation in KiB. Authority
    /// actions use their separate typed byte grant and never read this property.
    pub property_name: String,
    /// Percent above the reservation the action may reach.
    pub headroom_percent: u64,
}

impl ResourceEnforcement {
    /// From the worker's configuration. `None` when neither axis is on;
    /// `disk: guard` alone is honoured as much as `memory: soft` alone.
    pub fn from_config(config: &ResourceEnforcementConfig) -> Option<Self> {
        let memory = match config.memory {
            MemoryEnforcement::None => None,
            MemoryEnforcement::Soft => Some(MemoryLimit {
                property_name: config.memory_property_name.clone(),
                headroom_percent: config.memory_headroom_percent,
            }),
        };
        let disk_property_name =
            (config.disk != DiskEnforcement::None).then(|| config.disk_property_name.clone());
        (memory.is_some() || disk_property_name.is_some()).then_some(Self {
            memory,
            disk_property_name,
            disk_soft: config.disk == DiskEnforcement::Soft,
            disk_headroom_percent: config.disk_headroom_percent,
        })
    }
}

/// Free space in KiB on the filesystem holding `path`, as an unprivileged
/// process may use it.
#[cfg(target_family = "unix")]
pub fn free_disk_kb(path: &str) -> Option<u64> {
    let c_path = std::ffi::CString::new(path).ok()?;
    let mut stat: libc::statvfs = unsafe { core::mem::zeroed() };
    // SAFETY: `c_path` is a valid C string and `stat` is a zeroed out
    // parameter the call fills in.
    let rc = unsafe { libc::statvfs(c_path.as_ptr(), &raw mut stat) };
    if rc != 0 {
        return None;
    }
    Some(widen(stat.f_bavail).saturating_mul(widen(stat.f_frsize)) / 1024)
}

/// `statvfs` fields are u32 or u64 depending on the platform.
#[cfg(target_family = "unix")]
fn widen(value: impl Into<u64>) -> u64 {
    value.into()
}

#[cfg(not(target_family = "unix"))]
pub fn free_disk_kb(_path: &str) -> Option<u64> {
    None
}

#[derive(Debug, Default)]
pub struct ExecutionConfiguration {
    /// Bytes of stdout or stderr kept in memory before the rest spills to a
    /// file under the action directory; 0 keeps everything in memory.
    pub max_captured_output_bytes: u64,
    /// Kill an action that exceeds its memory reservation, before the
    /// pod's cgroup limit takes the whole worker with it.
    pub resource_enforcement: Option<ResourceEnforcement>,
    /// Time a timed-out or cancelled action gets between SIGTERM and
    /// SIGKILL to write its own cleanup; zero sends SIGKILL at once.
    pub kill_grace: Duration,
    /// Point `TMPDIR` at a directory of the action's own, removed with it.
    pub set_tmpdir: bool,
    /// How many input blobs the worker fetches into its store at once,
    /// across every action it is staging; 0 shares no pool, and each action
    /// fetches on its own.
    pub max_concurrent_input_downloads: usize,
    /// Buck2-only helper, configured for a dedicated execution container.
    pub buck2_file_capture: Option<Buck2FileCaptureConfig>,
    /// If set, will be executed instead of the first argument passed in the
    /// `ActionInfo` with all of the arguments in the `ActionInfo` passed as
    /// arguments to this command.
    pub entrypoint: Option<String>,
    /// The only environment variables that will be specified when the command
    /// executes other than those in the `ActionInfo`.  On Windows, `SystemRoot`
    /// and PATH are also assigned (see `inner_execute`).
    pub additional_environment: Option<HashMap<String, EnvironmentSource>>,
    /// Bazel persistent workers: whether an action that supports them runs
    /// in a pooled process, and how the pool is sized.
    pub persistent_workers: PersistentWorkersSettings,
}

/// See `ExecutionConfiguration::persistent_workers`.
#[derive(Debug, Clone, Copy)]
pub struct PersistentWorkersSettings {
    pub enabled: bool,
    pub pool: PoolConfig,
}

impl Default for PersistentWorkersSettings {
    fn default() -> Self {
        Self {
            enabled: true,
            pool: PoolConfig::default(),
        }
    }
}

#[derive(Debug)]
struct UploadActionResults {
    upload_ac_results_strategy: UploadCacheResultsStrategy,
    upload_historical_results_strategy: UploadCacheResultsStrategy,
    ac_store: Option<Store>,
    historical_store: Store,
    success_message_template: Template,
    failure_message_template: Template,
}

impl UploadActionResults {
    fn new(
        config: &UploadActionResultConfig,
        ac_store: Option<Store>,
        historical_store: Store,
    ) -> Result<Self, Error> {
        let upload_historical_results_strategy = config
            .upload_historical_results_strategy
            .unwrap_or(DEFAULT_HISTORICAL_RESULTS_STRATEGY);
        if !matches!(
            config.upload_ac_results_strategy,
            UploadCacheResultsStrategy::Never
        ) && ac_store.is_none()
        {
            return Err(make_input_err!(
                "upload_ac_results_strategy is set, but no ac_store is configured"
            ));
        }
        Ok(Self {
            upload_ac_results_strategy: config.upload_ac_results_strategy,
            upload_historical_results_strategy,
            ac_store,
            historical_store,
            success_message_template: Template::new(&config.success_message_template).map_err(
                |e| {
                    Error::from_std_err(Code::InvalidArgument, &e).append(format!(
                        "Could not convert success_message_template to rust template: {}",
                        config.success_message_template
                    ))
                },
            )?,
            failure_message_template: Template::new(&config.failure_message_template).map_err(
                |e| {
                    Error::from_std_err(Code::InvalidArgument, &e).append(format!(
                        "Could not convert failure_message_template to rust template: {}",
                        config.success_message_template
                    ))
                },
            )?,
        })
    }

    const fn should_cache_result(
        strategy: UploadCacheResultsStrategy,
        action_result: &ActionResult,
        treat_infra_error_as_failure: bool,
    ) -> bool {
        let did_fail = action_result.exit_code != 0
            || (treat_infra_error_as_failure && action_result.error.is_some());
        match strategy {
            UploadCacheResultsStrategy::SuccessOnly => !did_fail,
            UploadCacheResultsStrategy::Never => false,
            // Never cache internal errors or timeouts.
            UploadCacheResultsStrategy::Everything => {
                treat_infra_error_as_failure || action_result.error.is_none()
            }
            UploadCacheResultsStrategy::FailuresOnly => did_fail,
        }
    }

    /// Formats the message field in `ExecuteResponse` from the `success_message_template`
    /// or `failure_message_template` config templates.
    fn format_execute_response_message(
        mut template_str: Template,
        action_digest_info: DigestInfo,
        maybe_historical_digest_info: Option<DigestInfo>,
        hasher: DigestHasherFunc,
    ) -> Result<String, Error> {
        template_str.replace(
            "digest_function",
            hasher.proto_digest_func().as_str_name().to_lowercase(),
        );
        template_str.replace(
            "action_digest_hash",
            action_digest_info.packed_hash().to_string(),
        );
        template_str.replace("action_digest_size", action_digest_info.size_bytes());
        if let Some(historical_digest_info) = maybe_historical_digest_info {
            template_str.replace(
                "historical_results_hash",
                format!("{}", historical_digest_info.packed_hash()),
            );
            template_str.replace(
                "historical_results_size",
                historical_digest_info.size_bytes(),
            );
        } else {
            template_str.replace("historical_results_hash", "");
            template_str.replace("historical_results_size", "");
        }
        template_str.text().map_err(|e| {
            Error::from_std_err(Code::InvalidArgument, &e)
                .append("Could not convert template to text")
        })
    }

    async fn upload_ac_results(
        &self,
        action_digest: DigestInfo,
        action_result: ProtoActionResult,
        hasher: DigestHasherFunc,
    ) -> Result<(), Error> {
        let Some(ac_store) = self.ac_store.as_ref() else {
            return Ok(());
        };
        // If we are a GrpcStore we shortcut here, as this is a special store.
        if let Some(grpc_store) = ac_store.downcast_ref::<GrpcStore>(Some(action_digest.into())) {
            let update_action_request = UpdateActionResultRequest {
                // This is populated by `update_action_result`.
                instance_name: String::new(),
                action_digest: Some(action_digest.into()),
                action_result: Some(action_result),
                results_cache_policy: None,
                digest_function: hasher.proto_digest_func().into(),
            };
            return grpc_store
                .update_action_result(Request::new(update_action_request))
                .await
                .map(|_| ())
                .err_tip(|| "Caching ActionResult");
        }

        let mut store_data = BytesMut::with_capacity(ESTIMATED_DIGEST_SIZE);
        action_result
            .encode(&mut store_data)
            .err_tip(|| "Encoding ActionResult for caching")?;

        ac_store
            .update_oneshot(action_digest, store_data.split().freeze())
            .await
            .err_tip(|| "Caching ActionResult")
    }

    async fn upload_historical_results_with_message(
        &self,
        action_digest: DigestInfo,
        execute_response: ExecuteResponse,
        message_template: Template,
        hasher: DigestHasherFunc,
    ) -> Result<String, Error> {
        let historical_digest_info = serialize_and_upload_message(
            &HistoricalExecuteResponse {
                action_digest: Some(action_digest.into()),
                execute_response: Some(execute_response.clone()),
            },
            self.historical_store.as_pin(),
            &mut hasher.hasher(),
        )
        .await
        .err_tip(|| format!("Caching HistoricalExecuteResponse for digest: {action_digest}"))?;

        Self::format_execute_response_message(
            message_template,
            action_digest,
            Some(historical_digest_info),
            hasher,
        )
        .err_tip(|| "Could not format message in upload_historical_results_with_message")
    }

    async fn cache_action_result(
        &self,
        action_info: DigestInfo,
        action_result: &mut ActionResult,
        hasher: DigestHasherFunc,
    ) -> Result<(), Error> {
        let should_upload_historical_results =
            Self::should_cache_result(self.upload_historical_results_strategy, action_result, true);
        let should_upload_ac_results =
            Self::should_cache_result(self.upload_ac_results_strategy, action_result, false);
        // Shortcut so we don't need to convert to proto if not needed.
        if !should_upload_ac_results && !should_upload_historical_results {
            return Ok(());
        }

        let mut execute_response = to_execute_response(action_result.clone());

        // In theory exit code should always be != 0 if there's an error, but for safety we
        // catch both.
        let message_template = if action_result.exit_code == 0 && action_result.error.is_none() {
            self.success_message_template.clone()
        } else {
            self.failure_message_template.clone()
        };

        let upload_historical_results_with_message_result = if should_upload_historical_results {
            let maybe_message = self
                .upload_historical_results_with_message(
                    action_info,
                    execute_response.clone(),
                    message_template,
                    hasher,
                )
                .await;
            match maybe_message {
                Ok(message) => {
                    action_result.message.clone_from(&message);
                    execute_response.message = message;
                    Ok(())
                }
                Err(e) => Result::<(), Error>::Err(e),
            }
        } else {
            match Self::format_execute_response_message(message_template, action_info, None, hasher)
            {
                Ok(message) => {
                    action_result.message.clone_from(&message);
                    execute_response.message = message;
                    Ok(())
                }
                Err(e) => Err(e).err_tip(|| "Could not format message in cache_action_result"),
            }
        };

        // Note: Done in this order because we assume most results will succeed and most configs will
        // either always upload upload historical results or only upload on failure. In which case
        // we can avoid an extra clone of the protos by doing this last with the above assumption.
        let ac_upload_results = if should_upload_ac_results {
            self.upload_ac_results(
                action_info,
                execute_response
                    .result
                    .err_tip(|| "No result set in cache_action_result")?,
                hasher,
            )
            .await
        } else {
            Ok(())
        };
        upload_historical_results_with_message_result.merge(ac_upload_results)
    }
}

#[cfg(target_os = "linux")]
#[derive(Copy, Clone, Debug)]
pub enum UseNamespaces {
    No,
    Yes,
    /// Also unshare the mount namespace. With `isolate_tmp` each action gets
    /// a private `/tmp`, its own tmp directory bound over `/tmp`, on top of
    /// the masked root action directory.
    YesAndMount {
        isolate_tmp: bool,
    },
}

/// Execution inputs for an authority-owned worker. This constructor vocabulary
/// deliberately has no AC/history destinations, publication policies or response
/// templates. Canonical runtime construction remains reachable through test wiring.
#[derive(Debug)]
pub struct AuthorityRunningActionsManagerArgs {
    pub root_action_directory: String,
    pub execution_configuration: ExecutionConfiguration,
    pub cas_store: Arc<FastSlowStore>,
    pub max_action_timeout: Duration,
    pub max_upload_timeout: Duration,
    pub max_download_timeout: Duration,
    pub max_cleanup_wait: Duration,
    pub max_cleanup_backoff: Duration,
    pub timeout_handled_externally: bool,
    pub directory_cache: Option<Arc<crate::directory_cache::DirectoryCache>>,
    pub active_input_leases: bool,
    #[cfg(target_os = "linux")]
    pub readonly_input_mounts: Vec<String>,
    #[cfg(target_os = "linux")]
    pub use_namespaces: UseNamespaces,
}

#[derive(Debug)]
pub struct RunningActionsManagerArgs<'a> {
    pub root_action_directory: String,
    pub execution_configuration: ExecutionConfiguration,
    pub cas_store: Arc<FastSlowStore>,
    pub ac_store: Option<Store>,
    pub historical_store: Store,
    pub upload_action_result_config: &'a UploadActionResultConfig,
    pub max_action_timeout: Duration,
    pub max_upload_timeout: Duration,
    pub max_download_timeout: Duration,
    pub max_cleanup_wait: Duration,
    pub max_cleanup_backoff: Duration,
    pub timeout_handled_externally: bool,
    pub directory_cache: Option<Arc<crate::directory_cache::DirectoryCache>>,
    /// When true, every digest in an active action's input Merkle closure is
    /// leased in the locally eviction-managed CAS tiers until the action's
    /// cleanup completes. While leases are held, those tiers may temporarily
    /// exceed their configured `max_bytes` / `max_count` eviction limits.
    pub active_input_leases: bool,
    #[cfg(target_os = "linux")]
    pub readonly_input_mounts: Vec<String>,
    #[cfg(target_os = "linux")]
    pub use_namespaces: UseNamespaces,
}

impl RunningActionsManagerArgs<'_> {
    fn into_execution(self) -> AuthorityRunningActionsManagerArgs {
        let args = self;
        AuthorityRunningActionsManagerArgs {
            root_action_directory: args.root_action_directory,
            execution_configuration: args.execution_configuration,
            cas_store: args.cas_store,
            max_action_timeout: args.max_action_timeout,
            max_upload_timeout: args.max_upload_timeout,
            max_download_timeout: args.max_download_timeout,
            max_cleanup_wait: args.max_cleanup_wait,
            max_cleanup_backoff: args.max_cleanup_backoff,
            timeout_handled_externally: args.timeout_handled_externally,
            directory_cache: args.directory_cache,
            active_input_leases: args.active_input_leases,
            #[cfg(target_os = "linux")]
            readonly_input_mounts: args.readonly_input_mounts,
            #[cfg(target_os = "linux")]
            use_namespaces: args.use_namespaces,
        }
    }
}

/// The mark that an operation's directory is being cleaned; dropping it
/// clears the mark and wakes whoever waits for it.
#[derive(Debug)]
pub struct CleanupGuard {
    manager: Weak<RunningActionsManagerImpl>,
    operation_id: OperationId,
}

impl Drop for CleanupGuard {
    fn drop(&mut self) {
        let Some(manager) = self.manager.upgrade() else {
            return;
        };
        let mut cleaning = manager.cleaning_up_operations.lock();
        cleaning.remove(&self.operation_id);
        manager.cleanup_complete_notify.notify_waiters();
    }
}

/// Holds state info about what is being executed and the interface for interacting
/// with actions while they are running.
#[derive(Debug)]
pub struct RunningActionsManagerImpl {
    root_action_directory: String,
    execution_configuration: ExecutionConfiguration,
    cas_store: Arc<FastSlowStore>,
    filesystem_store: Arc<FilesystemStore>,
    // Authority construction retains no legacy publisher or destination handle.
    upload_action_results: Option<UploadActionResults>,
    max_action_timeout: Duration,
    max_upload_timeout: Duration,
    max_download_timeout: Duration,
    timeout_handled_externally: bool,
    /// The container's memory limit, the yardstick for calling a SIGKILL
    /// nobody here sent an OOM kill.
    pod_memory_limit_kb: Option<u64>,
    #[cfg(target_os = "linux")]
    use_namespaces: UseNamespaces,
    running_actions: Mutex<HashMap<OperationId, Weak<RunningActionImpl>>>,
    // Note: We don't use Notify because we need to support a .wait_for()-like function, which
    // Notify does not support.
    action_done_tx: watch::Sender<()>,
    callbacks: Callbacks,
    metrics: Arc<Metrics>,
    /// Disk each admitted action reserved, by operation, so the disk guard
    /// checks against what is left after them. An entry lives from the
    /// guard passing to `cleanup_action`.
    disk_reservations_kb: Mutex<HashMap<OperationId, u64>>,
    /// Track operations being cleaned up to avoid directory collisions during action retries.
    /// When an action fails and is retried on the same worker, we need to ensure the previous
    /// attempt's directory is fully cleaned up before creating a new one.
    /// See: <https://github.com/TraceMachina/nativelink/issues/1859>
    cleaning_up_operations: Mutex<HashSet<OperationId>>,
    max_cleanup_wait: Duration,
    max_cleanup_backoff: Duration,
    /// Notify waiters when a cleanup operation completes. This is used in conjunction with
    /// `cleaning_up_operations` to coordinate directory cleanup and creation.
    cleanup_complete_notify: Arc<Notify>,
    /// Optional directory cache for improving performance by caching reconstructed
    /// input directories and using hardlinks.
    directory_cache: Option<Arc<crate::directory_cache::DirectoryCache>>,
    /// Whether active action inputs are leased against eviction in the local
    /// CAS tiers (opt-in via `experimental_active_input_leases`).
    active_input_leases: bool,
    /// The pool every input fetch draws a permit from, shared by all the
    /// actions this worker stages; see
    /// `ExecutionConfiguration::max_concurrent_input_downloads`. Without
    /// one configured it is too large to bound anything.
    input_downloads: Semaphore,
    /// Set while no pool is configured, to suggest one when fetches show
    /// the store behind them struggling.
    input_pool_hint: Option<InputPoolHint>,
    #[cfg(target_os = "linux")]
    readonly_input_mounts: Vec<String>,
    persistent_worker_pool: PersistentWorkerPool,
    /// Retires idle persistent workers; ends with the manager.
    _persistent_worker_sweeper: JoinHandleDropGuard<()>,
    buck2_captures: Mutex<HashMap<OperationId, Buck2FileCapture>>,
}

impl RunningActionsManagerImpl {
    /// Permits free in the input fetch pool right now; with nothing staging,
    /// the pool's size, which is `Semaphore::MAX_PERMITS` without one.
    pub fn free_input_downloads(&self) -> usize {
        self.input_downloads.available_permits()
    }

    /// Suggests `max_concurrent_input_downloads` when this worker fetches
    /// without a shared pool and a fetch just failed or stalled the way an
    /// overloaded store makes it. `DataLoss` is retried as transient but
    /// means a truncated or corrupt stored copy, not a struggling store, so
    /// it suggests nothing.
    fn suggest_input_download_pool(&self, operation_id: &OperationId, error: &Error) {
        let Some(hint) = &self.input_pool_hint else {
            return;
        };
        if error.code != Code::DataLoss && hint.due(Instant::now()) {
            warn!(
                %operation_id,
                %error,
                "Input fetches are failing or stalling while max_concurrent_input_downloads is unset: every action this worker stages fetches its inputs on its own, and several cold actions at once can overload the CAS and the object store behind it. Consider setting max_concurrent_input_downloads to 64 so they share one pool of fetches (logged at most every 10 minutes)"
            );
        }
    }

    pub fn new_with_callbacks(
        args: RunningActionsManagerArgs<'_>,
        callbacks: Callbacks,
    ) -> Result<Self, Error> {
        let config = args.upload_action_result_config;
        let ac_store = args.ac_store.clone();
        let historical_store = args.historical_store.clone();
        Self::new_execution(args.into_execution(), callbacks, || {
            UploadActionResults::new(config, ac_store, historical_store)
                .err_tip(|| "During RunningActionsManagerImpl construction")
                .map(Some)
        })
    }

    /// Build the experimental authority worker without legacy publication
    /// capabilities. No store placeholders or disabled upload policies are used.
    pub fn new_authority(args: AuthorityRunningActionsManagerArgs) -> Result<Self, Error> {
        Self::new_execution(
            args,
            Callbacks {
                now_fn: SystemTime::now,
                sleep_fn: |duration| Box::pin(tokio::time::sleep(duration)),
            },
            || Ok(None),
        )
    }

    fn new_execution(
        args: AuthorityRunningActionsManagerArgs,
        callbacks: Callbacks,
        create_publisher: impl FnOnce() -> Result<Option<UploadActionResults>, Error>,
    ) -> Result<Self, Error> {
        #[cfg(target_os = "linux")]
        {
            crate::input_mounts::validate_paths(&args.readonly_input_mounts)?;
            if !args.readonly_input_mounts.is_empty()
                && (!matches!(args.use_namespaces, UseNamespaces::YesAndMount { .. })
                    || args.directory_cache.is_none())
            {
                return Err(make_err!(
                    Code::InvalidArgument,
                    "Read-only input mounts require Linux mount namespaces and a directory cache"
                ));
            }
        }
        // Sadly because of some limitations of how Any works we need to clone more times than optimal.
        let filesystem_store = args
            .cas_store
            .fast_store()
            .downcast_ref::<FilesystemStore>(None)
            .err_tip(
                || "Expected FilesystemStore store for .fast_store() in RunningActionsManagerImpl",
            )?
            .get_arc()
            .err_tip(|| "FilesystemStore's internal Arc was lost")?;
        let (action_done_tx, _) = watch::channel(());
        let persistent_worker_pool =
            PersistentWorkerPool::new(args.execution_configuration.persistent_workers.pool);
        let persistent_worker_sweeper = persistent_worker_pool.spawn_sweeper();
        let max_downloads = args.execution_configuration.max_concurrent_input_downloads;
        let input_downloads = input_download_pool(max_downloads);
        let input_pool_hint = (max_downloads == 0).then(InputPoolHint::default);
        Ok(Self {
            root_action_directory: args.root_action_directory,
            execution_configuration: args.execution_configuration,
            input_downloads,
            input_pool_hint,
            cas_store: args.cas_store,
            filesystem_store,
            upload_action_results: create_publisher()?,
            max_action_timeout: args.max_action_timeout,
            pod_memory_limit_kb: pod_memory_limit_kb(),
            max_upload_timeout: args.max_upload_timeout,
            max_download_timeout: args.max_download_timeout,
            timeout_handled_externally: args.timeout_handled_externally,
            running_actions: Mutex::new(HashMap::new()),
            action_done_tx,
            callbacks,
            metrics: Arc::new(Metrics {
                directory_cache: args.directory_cache.as_ref().map(Arc::downgrade),
                ..Default::default()
            }),
            disk_reservations_kb: Mutex::new(HashMap::new()),
            cleaning_up_operations: Mutex::new(HashSet::new()),
            max_cleanup_wait: args.max_cleanup_wait,
            max_cleanup_backoff: args.max_cleanup_backoff,
            cleanup_complete_notify: Arc::new(Notify::new()),
            directory_cache: args.directory_cache,
            active_input_leases: args.active_input_leases,
            #[cfg(target_os = "linux")]
            readonly_input_mounts: args.readonly_input_mounts,
            persistent_worker_pool,
            _persistent_worker_sweeper: persistent_worker_sweeper,
            buck2_captures: Mutex::new(HashMap::new()),
            #[cfg(target_os = "linux")]
            use_namespaces: args.use_namespaces,
        })
    }

    pub fn new(args: RunningActionsManagerArgs<'_>) -> Result<Self, Error> {
        Self::new_with_callbacks(
            args,
            Callbacks {
                now_fn: SystemTime::now,
                sleep_fn: |duration| Box::pin(tokio::time::sleep(duration)),
            },
        )
    }

    /// Fixes a race condition that occurs when an action fails to execute on a worker, and the same worker
    /// attempts to re-execute the same action before the physical cleanup (file is removed) completes.
    /// See this issue for additional details: <https://github.com/TraceMachina/nativelink/issues/1859>
    async fn wait_for_cleanup_if_needed(
        self: &Arc<Self>,
        operation_id: &OperationId,
    ) -> Result<(), Error> {
        let start = Instant::now();
        let mut backoff = Duration::from_millis(10);
        let mut has_waited = false;

        loop {
            // The mark is held for the removal below, so it cannot race the
            // orphan sweep's removal of the same tree; while someone else
            // holds it, this waits.
            let mark = self.perform_cleanup(operation_id.clone());
            if let Some(_cleaning_guard) = mark {
                let action_is_running = self
                    .running_actions
                    .lock()
                    .get(operation_id)
                    .and_then(Weak::upgrade)
                    .is_some();
                if action_is_running {
                    return Err(make_err!(
                        Code::AlreadyExists,
                        "Action with operation_id {} is already running",
                        operation_id
                    ));
                }

                let dir_path =
                    PathBuf::from(&self.root_action_directory).join(operation_id.to_string());

                if !dir_path.exists() {
                    return Ok(());
                }

                // Safety check: ensure we're only removing directories under root_action_directory
                let root_path = Path::new(&self.root_action_directory);
                let canonical_root = root_path.canonicalize().err_tip(|| {
                    format!(
                        "Failed to canonicalize root directory: {}",
                        self.root_action_directory
                    )
                })?;
                let canonical_dir = dir_path.canonicalize().err_tip(|| {
                    format!("Failed to canonicalize directory: {}", dir_path.display())
                })?;

                if !canonical_dir.starts_with(&canonical_root) {
                    return Err(make_err!(
                        Code::Internal,
                        "Attempted to remove directory outside of root_action_directory: {}",
                        dir_path.display()
                    ));
                }

                // Directory exists but not being cleaned - remove it
                warn!(
                    "Removing stale directory for {}: {}",
                    operation_id,
                    dir_path.display()
                );
                self.metrics.stale_removals.inc();

                // Try to remove the directory, with one retry on failure
                let remove_result = fs::remove_dir_all(&dir_path).await;
                if let Err(e) = remove_result {
                    // Retry once after a short delay in case the directory is temporarily locked
                    tokio::time::sleep(Duration::from_millis(100)).await;
                    fs::remove_dir_all(&dir_path).await.err_tip(|| {
                        format!(
                            "Failed to remove stale directory {} for retry of {} after retry (original error: {})",
                            dir_path.display(),
                            operation_id,
                            e
                        )
                    })?;
                }
                return Ok(());
            }

            if start.elapsed() > self.max_cleanup_wait {
                self.metrics.cleanup_wait_timeouts.inc();
                warn!(%operation_id, waited=?start.elapsed(), "Timeout waiting for previous operation cleanup");
                return Err(make_err!(
                    Code::DeadlineExceeded,
                    "Timeout waiting for previous operation cleanup: {} (waited {:?})",
                    operation_id,
                    start.elapsed()
                ));
            }

            if !has_waited {
                self.metrics.cleanup_waits.inc();
                has_waited = true;
            }

            trace!(
                "Waiting for cleanup of {} (elapsed: {:?}, backoff: {:?})",
                operation_id,
                start.elapsed(),
                backoff
            );

            tokio::select! {
                () = self.cleanup_complete_notify.notified() => {},
                () = tokio::time::sleep(backoff) => {
                    // Exponential backoff
                    backoff = (backoff * 2).min(self.max_cleanup_backoff);
                },
            }
        }
    }

    fn make_action_directory<'a>(
        &'a self,
        operation_id: &'a OperationId,
    ) -> impl Future<Output = Result<String, Error>> + 'a {
        self.metrics.make_action_directory.wrap(async move {
            let action_directory = format!("{}/{}", self.root_action_directory, operation_id);
            fs::create_dir(&action_directory)
                .await
                .err_tip(|| format!("Error creating action directory {action_directory}"))?;
            Ok(action_directory)
        })
    }

    fn create_action_info(
        &self,
        start_execute: StartExecute,
        queued_timestamp: SystemTime,
        authority_request: bool,
    ) -> impl Future<Output = Result<(ActionInfo, bool), Error>> + '_ {
        self.metrics.create_action_info.wrap(async move {
            let mut execute_request = start_execute
                .execute_request
                .err_tip(|| "Expected execute_request to exist in StartExecute")?;
            // v1 authority fixes an omitted digest function to SHA256. It must
            // not inherit the mutable legacy process default on this seam.
            if authority_request && execute_request.digest_function == 0 {
                execute_request.digest_function =
                    DigestHasherFunc::Sha256.proto_digest_func().into();
            }
            let action_digest: DigestInfo = execute_request
                .action_digest
                .clone()
                .err_tip(|| "Expected action_digest to exist on StartExecute")?
                .try_into()?;
            let load_start_timestamp = (self.callbacks.now_fn)();
            let action =
                get_and_decode_digest::<Action>(self.cas_store.as_ref(), action_digest.into())
                    .await
                    .err_tip(|| "During start_action")
                    .map_err(tag_missing_input)?;
            let explicit_timeout = action.timeout.is_some();
            if authority_request
                && let Some(timeout) = action.timeout
                && (!(0..=315_576_000_000).contains(&timeout.seconds)
                    || !(0..1_000_000_000).contains(&timeout.nanos))
            {
                return Err(make_err!(
                    Code::InvalidArgument,
                    "invalid authority Action timeout"
                ));
            }
            let mut action_info = ActionInfo::try_from_action_and_execute_request(
                execute_request,
                action,
                load_start_timestamp,
                queued_timestamp,
            )
            .err_tip(|| "Could not create ActionInfo in create_and_add_action()")?;
            // With enforcement on, the scheduler's view of the properties
            // replaces the client's: a hint or cold-start reservation the
            // scheduler placed this action by only exists there, and what
            // is enforced (and exported to the environment) has to be the
            // number the ledger charged. Off, the worker keeps reading the
            // client's copy as it always did, so an upgrade changes no
            // action's environment on its own.
            if authority_request {
                let platform = start_execute.platform.ok_or_else(|| {
                    make_err!(
                        Code::InvalidArgument,
                        "authority dispatch requires complete platform"
                    )
                })?;
                let mut properties = HashMap::new();
                for property in platform.properties {
                    if properties.insert(property.name, property.value).is_some() {
                        return Err(make_err!(
                            Code::InvalidArgument,
                            "duplicate authority platform property"
                        ));
                    }
                }
                action_info.platform_properties = properties;
            } else if self.execution_configuration.resource_enforcement.is_some()
                && let Some(platform) = start_execute.platform
            {
                for property in platform.properties {
                    action_info
                        .platform_properties
                        .insert(property.name, property.value);
                }
            }
            Ok((action_info, explicit_timeout))
        })
    }

    /// Removes action directories under the root that no running action
    /// owns and that have not been touched for `max_cleanup_wait`. A
    /// cleanup that failed (the store was down, the process restarted
    /// mid-removal) leaves its directory behind, and it counts against the
    /// pod's disk until something removes it. A directory that will not go
    /// is logged and counted and the sweep carries on, or one stubborn
    /// entry would stop every sweep at the same place. Returns how many
    /// were removed; the error is for the listing itself failing.
    ///
    /// A directory is named for its operation, and a retry of that
    /// operation may be starting at any moment. The retry's
    /// `wait_for_cleanup_if_needed` waits while the operation is marked as
    /// cleaning, so the sweep takes that mark for the removal and reads
    /// ownership and age under it; a mark already held is the action's own
    /// cleanup, which finishes the job.
    pub async fn sweep_orphaned_directories(self: &Arc<Self>) -> Result<usize, Error> {
        let (_permit, dir_handle) = fs::read_dir(&self.root_action_directory)
            .await
            .err_tip(|| format!("Reading {} for orphans", self.root_action_directory))?
            .into_inner();
        let mut dir_stream = ReadDirStream::new(dir_handle);
        let now = SystemTime::now();
        let mut removed = 0;
        while let Some(entry) = dir_stream.next().await {
            let entry = entry.err_tip(|| "Iterating action root for orphans")?;
            let Some(name) = entry.file_name().to_str().map(str::to_owned) else {
                continue;
            };
            // A running action's directory is not the sweep's to touch, and
            // its cleanup waits on the mark, so the mark is taken only for
            // an unowned directory and given back at once if the directory
            // became owned in between: an action that starts and ends
            // inside that window then cleans up as usual, not later.
            let is_owned = || {
                self.running_actions
                    .lock()
                    .keys()
                    .any(|operation_id| operation_id.to_string() == name)
            };
            if is_owned() {
                continue;
            }
            let Some(_cleaning_guard) = self.perform_cleanup(OperationId::from(name.as_str()))
            else {
                continue;
            };
            if is_owned() {
                continue;
            }
            let path = entry.path();
            // Not followed: a symlink under the root is not an action
            // directory, whatever it points at.
            let Ok(metadata) = fs::symlink_metadata(&path).await else {
                continue;
            };
            if !metadata.is_dir() {
                continue;
            }
            // Young directories may belong to an action between creation and
            // registration; only settled ones are orphans.
            let age = metadata
                .modified()
                .ok()
                .and_then(|modified| now.duration_since(modified).ok())
                .unwrap_or(Duration::MAX);
            if age < self.max_cleanup_wait {
                continue;
            }
            warn!(path = %path.display(), age_secs = age.as_secs(), "Removing orphaned action directory");
            match fs::remove_dir_all(&path).await {
                Ok(()) => {
                    self.metrics.orphan_removals.inc();
                    removed += 1;
                }
                Err(err) => {
                    self.metrics.orphan_removal_failures.inc();
                    warn!(path = %path.display(), ?err, "Could not remove orphaned action directory");
                }
            }
        }
        Ok(removed)
    }

    fn cleanup_action(&self, operation_id: &OperationId) -> Result<(), Error> {
        // The guard must be dropped before notifying: `send_modify` takes
        // the watch channel's internal lock, and a `wait_for` closure that
        // takes `running_actions` runs while holding that same lock, so
        // notifying while holding `running_actions` is an ABBA deadlock
        // (issue #2672). There is no lost wakeup in the gap: the removal
        // happens-before the notify.
        let result = {
            let mut running_actions = self.running_actions.lock();
            running_actions.remove(operation_id).err_tip(|| {
                format!(
                    "Expected operation id '{operation_id}' to exist in RunningActionsManagerImpl"
                )
            })
        };
        self.disk_reservations_kb.lock().remove(operation_id);
        // No need to copy anything, we just are telling the receivers an event happened.
        self.action_done_tx.send_modify(|()| {});
        result.map(|_| ())
    }

    // Note: We do not capture metrics on this call, only `.kill_all()`.
    // Important: When the future returns the process may still be running.
    async fn kill_operation(action: Arc<RunningActionImpl>) {
        warn!(
            operation_id = ?action.operation_id,
            "Sending kill to running operation",
        );
        // The token first: a phase waiting on it (a fetch, an upload) ends
        // now, whether or not the command ever started.
        action.kill_token.send_replace(true);
        let kill_channel_tx = {
            let mut action_state = action.state.lock();
            action_state.kill_channel_tx.take()
        };
        if let Some(kill_channel_tx) = kill_channel_tx
            && kill_channel_tx.send(()).is_err()
        {
            error!(
                operation_id = ?action.operation_id,
                "Error sending kill to running operation",
            );
        }
    }

    /// Marks the operation as being cleaned and returns the guard that
    /// clears the mark, or `None` when another cleanup already holds it.
    ///
    /// The guard is built only after the lock is released: its `Drop` takes
    /// the same lock, so a guard made under it and thrown away (as
    /// `then_some` did, whatever the insert said) deadlocked the thread on
    /// its own mutex and, one by one, every runtime thread that then came to
    /// clean up or start an action, while the worker's keepalives kept it
    /// looking alive. The orphan sweep made the double mark routine: it marks
    /// every directory it visits, and a directory whose action is mid-cleanup
    /// is already marked.
    pub fn perform_cleanup(self: &Arc<Self>, operation_id: OperationId) -> Option<CleanupGuard> {
        let inserted = self
            .cleaning_up_operations
            .lock()
            .insert(operation_id.clone());
        inserted.then(|| CleanupGuard {
            manager: Arc::downgrade(self),
            operation_id,
        })
    }

    /// Takes the cleanup mark, waiting for whoever holds it to let go. The
    /// wait is armed before the mark is tried, so a release in between is
    /// not missed.
    pub async fn take_cleanup_mark(self: &Arc<Self>, operation_id: OperationId) -> CleanupGuard {
        loop {
            let notified = self.cleanup_complete_notify.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            if let Some(guard) = self.perform_cleanup(operation_id.clone()) {
                return guard;
            }
            notified.await;
        }
    }
}

impl RunningActionsManagerImpl {
    async fn create_and_add_action_impl(
        self: &Arc<Self>,
        worker_id: String,
        start_execute: StartExecute,
        reserved_resources: Option<AuthorityResources>,
    ) -> Result<Arc<RunningActionImpl>, Error> {
        let authority_request = reserved_resources.is_some();
        let authority_resources = reserved_resources
            .map(|charged| {
                AuthorityResourceLimits::capture(
                    charged,
                    self.execution_configuration
                        .resource_enforcement
                        .as_ref()
                        .and_then(|enforcement| enforcement.memory.as_ref()),
                )
            })
            .transpose()?;
        self.metrics
            .create_and_add_action
            .wrap(async move {
                let capture_metadata = start_execute.request_metadata.clone();
                let capture_worker = worker_id.clone();
                let capture_digest = start_execute.execute_request.as_ref()
                    .and_then(|request| request.action_digest.as_ref())
                    .map(|digest| digest.hash.clone()).unwrap_or_default();
                let queued_timestamp = if authority_request {
                    let queued = start_execute.queued_timestamp.ok_or_else(|| make_err!(Code::InvalidArgument, "authority dispatch requires queued timestamp"))?;
                    if !(-62_135_596_800..=253_402_300_799).contains(&queued.seconds) || !(0..1_000_000_000).contains(&queued.nanos) {
                        return Err(make_err!(Code::InvalidArgument, "invalid authority queued timestamp"));
                    }
                    SystemTime::try_from(queued).map_err(|error| make_err!(Code::InvalidArgument, "invalid queued timestamp: {error}"))?
                } else {
                    start_execute.queued_timestamp.and_then(|time| time.try_into().ok()).unwrap_or(SystemTime::UNIX_EPOCH)
                };
                let operation_id = start_execute
                    .operation_id.as_str().into();
                let action_info_future = self.create_action_info(start_execute, queued_timestamp, authority_request);
                let (action_info, explicit_timeout) = if authority_request {
                    tokio::time::timeout(self.max_download_timeout, action_info_future)
                        .await.map_err(|_| make_err!(Code::DeadlineExceeded, "authority Action fetch exceeded download timeout"))??
                } else {
                    action_info_future.await?
                };
                let exceeds_worker_limit = action_info.timeout > self.max_action_timeout;
                if authority_request && explicit_timeout && exceeds_worker_limit {
                    return Err(make_err!(Code::InvalidArgument, "authority Action timeout exceeds worker maximum"));
                }
                debug!(
                    ?action_info,
                    "Worker received action",
                );
                // Wait for any previous cleanup to complete before creating directory
                self.wait_for_cleanup_if_needed(&operation_id).await?;
                let action_directory = self.make_action_directory(&operation_id).await?;
                let execution_metadata = ExecutionMetadata {
                    worker: worker_id,
                    queued_timestamp: action_info.insert_timestamp,
                    worker_start_timestamp: action_info.load_timestamp,
                    worker_completed_timestamp: SystemTime::UNIX_EPOCH,
                    input_fetch_start_timestamp: SystemTime::UNIX_EPOCH,
                    input_fetch_completed_timestamp: SystemTime::UNIX_EPOCH,
                    execution_start_timestamp: SystemTime::UNIX_EPOCH,
                    execution_completed_timestamp: SystemTime::UNIX_EPOCH,
                    output_upload_start_timestamp: SystemTime::UNIX_EPOCH,
                    output_upload_completed_timestamp: SystemTime::UNIX_EPOCH,
                };
                let timeout = if authority_request && explicit_timeout {
                    action_info.timeout
                } else if action_info.timeout.is_zero() || self.timeout_handled_externally {
                    self.max_action_timeout
                } else {
                    action_info.timeout
                };
                // REAPI lets a server clamp a timeout over its maximum; the
                // client asked for more time, not for a rejection.
                let timeout = if timeout > self.max_action_timeout {
                    info!(
                        ?operation_id,
                        requested_s = timeout.as_secs_f32(),
                        max_s = self.max_action_timeout.as_secs_f32(),
                        "Action timeout clamped to the worker maximum"
                    );
                    self.max_action_timeout
                } else {
                    timeout
                };
                let mut running_action = RunningActionImpl::new(
                    execution_metadata,
                    operation_id.clone(),
                    action_directory,
                    action_info,
                    timeout,
                    self.clone(),
                );
                running_action.authority_request = authority_request;
                running_action.authority_resources = authority_resources;
                running_action.progress = if authority_request { ProgressObserver::current() } else { None };
                let running_action = Arc::new(running_action);
                {
                    let mut running_actions = self.running_actions.lock();
                    // Check if action already exists and is still alive
                    if let Some(existing_weak) = running_actions.get(&operation_id)
                        && let Some(_existing_action) = existing_weak.upgrade() {
                            return Err(make_err!(
                                Code::AlreadyExists,
                                "Action with operation_id {} is already running",
                                operation_id
                            ));
                    }
                    running_actions.insert(operation_id.clone(), Arc::downgrade(&running_action));
                    running_action
                        .has_manager_entry
                        .store(true, Ordering::Release);
                }
                if let Some(config) = &self.execution_configuration.buck2_file_capture
                    && Buck2FileCapture::eligible(capture_metadata.as_ref()) {
                    // The directory exists already. A cancelled registration must
                    // take the same Drop cleanup path as a prepared action.
                    running_action.did_cleanup.store(false, Ordering::Release);
                    match Buck2FileCapture::start(
                        config,
                        capture_metadata.as_ref(),
                        &capture_worker,
                        &operation_id.to_string(),
                        &capture_digest,
                    ).await {
                        Ok(Some(capture)) => {
                            self.buck2_captures.lock().insert(operation_id, capture);
                        }
                        Ok(None) => {}
                        Err(err) => {
                            warn!(%operation_id, ?err, "Buck2 container file capture could not start");
                        }
                    }
                }
                Ok(running_action)
            })
            .await
    }
}

impl RunningActionsManager for RunningActionsManagerImpl {
    type RunningAction = RunningActionImpl;

    async fn create_and_add_action(
        self: &Arc<Self>,
        worker_id: String,
        start_execute: StartExecute,
    ) -> Result<Arc<RunningActionImpl>, Error> {
        self.create_and_add_action_impl(worker_id, start_execute, None)
            .await
    }

    async fn create_and_add_authority_action(
        self: &Arc<Self>,
        worker_id: String,
        start_execute: StartExecute,
        reserved_resources: AuthorityResources,
    ) -> Result<Arc<RunningActionImpl>, Error> {
        self.create_and_add_action_impl(worker_id, start_execute, Some(reserved_resources))
            .await
    }

    async fn create_and_add_authority_action_observed(
        self: &Arc<Self>,
        worker_id: String,
        start_execute: StartExecute,
        reserved_resources: AuthorityResources,
        progress: ProgressObserver,
    ) -> Result<Arc<RunningActionImpl>, Error> {
        work_progress::scope(
            Some(progress),
            self.create_and_add_action_impl(worker_id, start_execute, Some(reserved_resources)),
        )
        .await
    }

    async fn cache_action_result(
        &self,
        action_info: DigestInfo,
        action_result: &mut ActionResult,
        hasher: DigestHasherFunc,
    ) -> Result<(), Error> {
        let publisher = self.upload_action_results.as_ref().ok_or_else(|| {
            make_err!(
                Code::FailedPrecondition,
                "Authority workers cannot publish action cache or accepted history results"
            )
        })?;
        self.metrics
            .cache_action_result
            .wrap(publisher.cache_action_result(action_info, action_result, hasher))
            .await
    }

    async fn kill_operation(&self, operation_id: &OperationId) -> Result<(), Error> {
        let running_action = {
            let running_actions = self.running_actions.lock();
            running_actions
                .get(operation_id)
                .and_then(Weak::upgrade)
                .ok_or_else(|| make_input_err!("Failed to get running action {operation_id}"))?
        };
        Self::kill_operation(running_action).await;
        Ok(())
    }

    // Note: When the future returns the process should be fully killed and cleaned up.
    async fn kill_all(&self) {
        self.metrics
            .kill_all
            .wrap_no_capture_result(async move {
                let kill_operations: Vec<Arc<RunningActionImpl>> = {
                    let running_actions = self.running_actions.lock();
                    running_actions.values().filter_map(Weak::upgrade).collect()
                };
                let mut kill_futures: FuturesUnordered<_> = kill_operations
                    .into_iter()
                    .map(Self::kill_operation)
                    .collect();
                while kill_futures.next().await.is_some() {}
            })
            .await;
        // Wait for the running actions to drain. Deliberately NOT
        // `wait_for(|()| ...)`: that closure runs while the watch channel's
        // internal lock is held, so taking `running_actions` inside it
        // deadlocks with anyone notifying the channel while holding
        // `running_actions` (issue #2672). Checking outside the channel's
        // lock loses no wakeup: `changed()` reports any version bump since
        // the last check, and `cleanup_action` removes before it notifies.
        let mut action_done_rx = self.action_done_tx.subscribe();
        loop {
            if self.running_actions.lock().is_empty() {
                break;
            }
            // The only sender lives on `self`, so this cannot error; if it
            // ever did, giving up the wait is still the safe answer.
            if action_done_rx.changed().await.is_err() {
                break;
            }
        }
    }

    #[inline]
    fn metrics(&self) -> &Arc<Metrics> {
        &self.metrics
    }
}

#[derive(Debug, Default, MetricsComponent)]
pub struct Metrics {
    #[metric(help = "Stats about the create_and_add_action command.")]
    create_and_add_action: AsyncCounterWrapper,
    #[metric(help = "Stats about the cache_action_result command.")]
    cache_action_result: AsyncCounterWrapper,
    #[metric(help = "Stats about the kill_all command.")]
    kill_all: AsyncCounterWrapper,
    #[metric(help = "Stats about the create_action_info command.")]
    create_action_info: AsyncCounterWrapper,
    #[metric(help = "Stats about the make_work_directory command.")]
    make_action_directory: AsyncCounterWrapper,
    #[metric(help = "Stats about the prepare_action command.")]
    prepare_action: AsyncCounterWrapper,
    #[metric(help = "Stats about the execute command.")]
    execute: AsyncCounterWrapper,
    #[metric(help = "Stats about the upload_results command.")]
    upload_results: AsyncCounterWrapper,
    #[metric(help = "Stats about the cleanup command.")]
    cleanup: AsyncCounterWrapper,
    #[metric(help = "Stats about the get_finished_result command.")]
    get_finished_result: AsyncCounterWrapper,
    #[metric(help = "Number of times an action waited for cleanup to complete.")]
    cleanup_waits: CounterWithTime,
    #[metric(help = "Number of stale directories removed during action retries.")]
    stale_removals: CounterWithTime,
    #[metric(help = "Orphaned action directories removed by the periodic sweep.")]
    orphan_removals: CounterWithTime,
    #[metric(help = "Orphaned action directories the sweep could not remove.")]
    orphan_removal_failures: CounterWithTime,
    #[metric(help = "Number of timeouts while waiting for cleanup to complete.")]
    cleanup_wait_timeouts: CounterWithTime,
    #[metric(help = "Stats about the get_proto_command_from_store command.")]
    get_proto_command_from_store: AsyncCounterWrapper,
    #[metric(help = "Stats about the download_to_directory command.")]
    download_to_directory: AsyncCounterWrapper,
    #[metric(help = "Stats about the prepare_output_files command.")]
    prepare_output_files: AsyncCounterWrapper,
    #[metric(help = "Stats about the prepare_output_paths command.")]
    prepare_output_paths: AsyncCounterWrapper,
    #[metric(help = "Stats about the child_process command.")]
    child_process: AsyncCounterWrapper,
    #[metric(help = "Stats about the child_process_success_error_code command.")]
    child_process_success_error_code: CounterWithTime,
    #[metric(help = "Stats about the child_process_failure_error_code command.")]
    child_process_failure_error_code: CounterWithTime,
    #[metric(help = "Total time spent uploading stdout.")]
    upload_stdout: AsyncCounterWrapper,
    #[metric(help = "Total time spent uploading stderr.")]
    upload_stderr: AsyncCounterWrapper,
    #[metric(help = "Total number of task timeouts.")]
    task_timeouts: CounterWithTime,
    #[metric(help = "Actions killed for exceeding their memory reservation.")]
    memory_reservation_kills: CounterWithTime,
    #[metric(help = "Actions refused because their disk reservation exceeded the free space.")]
    disk_guard_refusals: CounterWithTime,
    #[metric(help = "Actions killed for writing past their disk reservation.")]
    disk_reservation_kills: CounterWithTime,
    #[metric(help = "Actions served by a pooled persistent worker process.")]
    persistent_worker_dispatches: CounterWithTime,
    #[metric(
        help = "Actions that asked for a persistent worker and ran one-shot instead: pool at capacity, spawn failure or an unsupported protocol."
    )]
    persistent_worker_fallbacks: CounterWithTime,
    #[metric(
        help = "Stats about the input-directory cache (hits, misses, subtree reuse, evictions, size)."
    )]
    directory_cache: Option<Weak<crate::directory_cache::DirectoryCache>>,
}

#[cfg(test)]
mod tests {
    use core::sync::atomic::AtomicU32;

    use nativelink_macro::nativelink_test;
    use pretty_assertions::assert_eq;

    use super::*;

    fn test_digest(first_byte: u8) -> DigestInfo {
        let mut hash = [0u8; 32];
        hash[0] = first_byte;
        DigestInfo::new(hash, 1)
    }

    /// Runs `fetch_and_resolve` against a resolve step that fails with
    /// `fail_with` for the first `failures` calls and succeeds after, and
    /// returns the result with how often each step ran.
    async fn drive(failures: u32, fail_with: Code) -> (Result<u32, Error>, u32, u32) {
        let populates = AtomicU32::new(0);
        let resolves = AtomicU32::new(0);
        let result = fetch_and_resolve(
            test_digest(0),
            || async {
                populates.fetch_add(1, Ordering::Relaxed);
                Ok(())
            },
            || async {
                let call = resolves.fetch_add(1, Ordering::Relaxed) + 1;
                if call <= failures {
                    return Err(make_err!(fail_with, "resolve attempt {call} failed"));
                }
                Ok(call)
            },
        )
        .await;
        (
            result,
            populates.load(Ordering::Relaxed),
            resolves.load(Ordering::Relaxed),
        )
    }

    #[nativelink_test]
    async fn fetch_and_resolve_retries_a_missing_blob() {
        let (result, populates, resolves) = drive(2, Code::NotFound).await;
        assert_eq!(result.unwrap(), 3);
        assert_eq!(populates, 3);
        assert_eq!(resolves, 3);
    }

    #[nativelink_test]
    async fn fetch_and_resolve_gives_up_after_the_last_attempt() {
        let (result, populates, resolves) = drive(3, Code::NotFound).await;
        assert_eq!(result.unwrap_err().code, Code::NotFound);
        assert_eq!(populates, INPUT_FETCH_ATTEMPTS);
        assert_eq!(resolves, INPUT_FETCH_ATTEMPTS);
    }

    #[nativelink_test]
    async fn fetch_and_resolve_returns_other_errors_at_once() {
        let (result, populates, resolves) = drive(1, Code::Internal).await;
        assert_eq!(result.unwrap_err().code, Code::Internal);
        assert_eq!(populates, 1);
        assert_eq!(resolves, 1);
    }

    #[nativelink_test]
    async fn fetch_and_resolve_stops_when_the_fetch_fails() {
        let resolves = AtomicU32::new(0);
        let result: Result<(), Error> = fetch_and_resolve(
            test_digest(0),
            || async { Err(make_err!(Code::Unavailable, "slow store is down")) },
            || async {
                resolves.fetch_add(1, Ordering::Relaxed);
                Ok(())
            },
        )
        .await;
        assert_eq!(result.unwrap_err().code, Code::Unavailable);
        assert_eq!(resolves.load(Ordering::Relaxed), 0);
    }

    /// The hint is reported for the first sign of trouble and then not
    /// again until a full interval has passed, however many signs follow.
    #[test]
    fn input_pool_hint_is_due_once_per_interval() {
        let hint = InputPoolHint::default();
        let start = Instant::now();
        assert!(hint.due(start), "the first sign is reported");
        assert!(!hint.due(start), "a second sign at once is not");
        let almost = start + INPUT_POOL_HINT_INTERVAL - Duration::from_secs(1);
        assert!(!hint.due(almost), "nor one before the interval has passed");
        let next = start + INPUT_POOL_HINT_INTERVAL;
        assert!(hint.due(next), "one a full interval later is reported");
        assert!(
            !hint.due(next + Duration::from_secs(1)),
            "and starts the next interval"
        );
    }

    #[test]
    fn input_download_pool_is_unbounded_only_when_unset() {
        assert_eq!(
            input_download_pool(0).available_permits(),
            Semaphore::MAX_PERMITS
        );
        assert_eq!(input_download_pool(64).available_permits(), 64);
        assert_eq!(
            input_download_pool(usize::MAX).available_permits(),
            Semaphore::MAX_PERMITS,
            "a value past what a semaphore holds is clamped, not a panic"
        );
    }

    #[test]
    fn input_fetch_pause_grows_with_the_attempt_and_stays_bounded() {
        let step = Duration::from_millis(INPUT_FETCH_PAUSE_STEP_MS);
        for first_byte in [0u8, 1, 19, 20, 127, 255] {
            let digest = test_digest(first_byte);
            for attempt in 1..INPUT_FETCH_ATTEMPTS {
                let pause = input_fetch_pause(attempt, &digest);
                assert!(pause >= step * attempt, "{pause:?} for attempt {attempt}");
                assert!(
                    pause < step * (attempt + 1),
                    "{pause:?} for attempt {attempt}"
                );
            }
        }
        assert_ne!(
            input_fetch_pause(1, &test_digest(3)),
            input_fetch_pause(1, &test_digest(7))
        );
    }

    #[test]
    fn prepare_retry_pause_doubles_and_stays_under_the_cap() {
        let cap = Duration::from_millis(PREPARE_RETRY_PAUSE_CAP_MS);
        for first_byte in [0u8, 1, 19, 127, 255] {
            let digest = test_digest(first_byte);
            for attempt in 1..=10u32 {
                let base = Duration::from_millis(
                    (PREPARE_RETRY_PAUSE_MS << attempt.saturating_sub(1).min(5))
                        .min(PREPARE_RETRY_PAUSE_CAP_MS),
                );
                let pause = prepare_retry_pause(attempt, &digest);
                assert!(pause <= base, "{pause:?} for attempt {attempt}");
                assert!(pause > base * 3 / 4, "{pause:?} for attempt {attempt}");
                assert!(pause <= cap, "{pause:?} for attempt {attempt}");
            }
        }
        assert_eq!(
            prepare_retry_pause(1, &test_digest(0)),
            Duration::from_secs(1)
        );
        assert_eq!(
            prepare_retry_pause(2, &test_digest(0)),
            Duration::from_secs(2)
        );
        assert_eq!(
            prepare_retry_pause(3, &test_digest(0)),
            Duration::from_secs(4)
        );
        assert_eq!(prepare_retry_pause(9, &test_digest(0)), cap);
        assert_ne!(
            prepare_retry_pause(1, &test_digest(3)),
            prepare_retry_pause(1, &test_digest(7))
        );
    }

    #[test]
    fn transient_fetch_errors_are_the_retrier_codes() {
        for code in [
            Code::Unavailable,
            Code::ResourceExhausted,
            Code::Aborted,
            Code::Internal,
            Code::Unknown,
            Code::DeadlineExceeded,
            Code::DataLoss,
        ] {
            let err = make_err!(code, "store answered 503 ServerBusy");
            assert!(is_transient_fetch_error(&err), "{code:?}");
        }
        for code in [
            Code::NotFound,
            Code::InvalidArgument,
            Code::FailedPrecondition,
            Code::PermissionDenied,
            Code::Unauthenticated,
            Code::Unimplemented,
            Code::OutOfRange,
            Code::AlreadyExists,
            Code::Cancelled,
        ] {
            let err = make_err!(code, "store answered");
            assert!(!is_transient_fetch_error(&err), "{code:?}");
        }
    }

    /// The worker's own disk failing maps to the same codes a store
    /// failure does, but is never retried on this worker. The error
    /// numbers are Linux's (ENOSPC, EPIPE), so that part runs on unix.
    #[test]
    fn an_operating_system_error_is_not_a_transient_fetch_error() {
        #[cfg(target_family = "unix")]
        {
            let disk_full = Error::from(std::io::Error::from_raw_os_error(28));
            assert_eq!(disk_full.code, Code::Unknown);
            assert!(!is_transient_fetch_error(&disk_full), "{disk_full:?}");
            let broken_pipe =
                Error::from(std::io::Error::from_raw_os_error(32)).append("Writing an input");
            assert_eq!(broken_pipe.code, Code::Internal);
            assert!(!is_transient_fetch_error(&broken_pipe), "{broken_pipe:?}");
        }
        // What the standard library prints for any OS error, whatever the
        // platform's number for it.
        let os_error = Error::from(std::io::Error::other(
            "No space left on device (os error 28)",
        ));
        assert_eq!(os_error.code, Code::Internal);
        assert!(!is_transient_fetch_error(&os_error), "{os_error:?}");
        // A store that reset the connection is not this worker's disk.
        let reset = Error::from(std::io::Error::from(std::io::ErrorKind::ConnectionReset));
        assert_eq!(reset.code, Code::Unavailable);
        assert!(is_transient_fetch_error(&reset), "{reset:?}");
    }

    /// Every retried fetch settles on one terminal outcome, dropped ones
    /// included; a fetch never retried records nothing.
    #[test]
    fn prepare_retries_settle_once() {
        let recorded = std::cell::RefCell::new(Vec::new());
        let record = |outcome: &'static str| recorded.borrow_mut().push(outcome);

        let mut retries = PrepareRetries::new(record);
        retries.retried();
        retries.retried();
        retries.settle("recovered");
        assert_eq!(*recorded.borrow(), vec!["retried", "retried", "recovered"]);

        recorded.borrow_mut().clear();
        PrepareRetries::new(record).settle("failed");
        assert!(recorded.borrow().is_empty(), "no retry, nothing to settle");

        recorded.borrow_mut().clear();
        {
            let mut retries = PrepareRetries::new(record);
            retries.retried();
        }
        assert_eq!(*recorded.borrow(), vec!["retried", "abandoned"]);
    }
}
