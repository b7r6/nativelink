# Canonical filesystem capability qualification

Frozen commit: `049c04f94d0905d17ee35d4f6da20f8c0d943948` on `codex/canonical-filesystem-capabilities`; base `fd963152b9` in `/tmp/nativelink-canonical-filesystem-capabilities`. Worktree clean at freeze. The six-file additive change introduces descriptor-relative fixed layout operations in the standalone Linux package. No runtime, StoreDriver implementation, scheduler engine, canonical parser, ownership record schema, or existing Ownership algorithm changed.

Final source is under `qualified/source/`, with per-file SHA-256 in `qualified/source-manifest.json`; `qualified/change.patch` is the exact commit. Frozen final test binary SHA-256: `484631993c984432fbece7deade8b6103ceb84d18bc6386c388dcbbc0fe9b356`. Kernel: `7.2.9`. Cargo uses the separate `/tmp/nativelink-authority-namespace-target`, not the root workspace target.

## Scope

FixedLayout pins content/temp/content.exec under CAS and sink. Opaque handles retain Arc ownership of every role lock. Leaf parsing is canonical and length-bounded; staging creation is exclusive; CAS publication uses NOREPLACE; sink replacement is atomic; publication consumes the only writable wrapper; reads remain tied to opened files. Returned handles provide no File, descriptor or ambient path conversion. No cleanup runs on drop/error. Explicit sync_layout syncs all six children, then the two role parents.

The API exposes filename structure, not verified digest bytes, persistent non-reused physical generations, collector authorization, hostile same-UID writer defense, mount-alias qualification or power-loss durability. Remove requires caller slot serialization and is not compare-and-unlink. Existing inode-reuse and failed-final-sync counterexamples remain. Child/root renames preserve original descriptors, even when original directories move outside the declared ambient path. Existing path-based FilesystemStore construction remains incompatible; README records the dedicated capability FileEntry/enumeration/eviction/I/O bridge still needed.

## Verification

Final `test-qualified.log`: 25 unit cases pass (13 existing ownership cases plus 12 capability cases), zero failures, and zero doc tests. Exact command: `CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/tmp/nativelink-authority-namespace-target timeout 120s cargo test --manifest-path tools/canonical-filesystem/Cargo.toml --locked --offline --profile smol`.

Final `clippy-qualified.log`: strict all-target/all-feature Clippy passes. Exact command: `CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/tmp/nativelink-authority-namespace-target cargo clippy --manifest-path tools/canonical-filesystem/Cargo.toml --locked --offline --profile smol --all-targets --all-features -- -D warnings`.

`pre-commit-initial.log`: all applicable hooks passed on all six changed files using explicit configuration `/nix/store/llxhiivz6jahnfx7wsyyghq318lggww1-pre-commit-config.json`. This includes rustfmt, buildifier format/lint, license, typos and Vale. `vale-final.log` separately reports zero errors. Both staged and unstaged diff checks passed. Bazel source lists were updated and linted; the actual Bazel ownership target was not run in this isolated worktree and remains for root integration qualification.

The capability cases demonstrate ancestor, role-root and all six child-directory rename/symlink substitution; immutable CAS versus mutable sink and retained old reader; all fixed-child symlink refusals at reopen; preflight of both roots before layout writes; strict leaves; symlink/directory/FIFO/socket/observed-hardlink refusal; exclusive temp refusal; different-role and replaced-temp refusal with artifacts preserved; every returned handle retaining all four role locks; and delayed blocking I/O after caller drop. Special-file cases also passed isolated five-second process deadlines on the frozen binary.

## Syscall evidence

`run-syscall-checks.py` replays the final frozen binary; exact commands, exit codes, output hashes and traces are under `qualified-syscalls/`. Baseline succeeds with 16 fsync calls: eight existing ownership initialization calls, six child-directory calls, then CAS-parent and sink-parent calls. Trace descriptor annotations establish the two final calls target the pinned role parents.

Separate EIO injections at fsync 15 and 16 both return `sync_layout_parent`. Each test checks that all six children and all four unchanged records remain, all role locks are held at the error return, and reopen succeeds, before its final success assertion intentionally fails. Exit 101 in those two logs is the expected injected-failure observation, not a passing baseline. This explicitly preserves the readable-state-versus-historical-sync distinction; syscall error injection is not power-loss testing.

Earlier pre-final traces and binary remain at evidence root. Their baseline predates the added bounded leaf-parser length check; final exact-source syscall runs are the qualified-syscalls copies.

## Development failures preserved

The initial 24-case run had 20 passes and four failures: the new socket fixture exceeded sockaddr_un pathname length, then three other fixtures encountered the poisoned test lock. Initial exact sources, source hashes and binary are retained under `initial/`. The socket is now bound under a short temporary name and renamed into the digest slot. The subsequent 24-case run passed.

Initial strict lint runs reported an overlong doc paragraph, needless Arc-by-value parameters, repository-wide thread-construction lint, then an underscore-prefixed field used by the new parent sync method. These were fixed; the standalone delayed-thread test has a local justified lint allowance because it deliberately has no NativeLink runtime dependency. Typos found one spelling and Vale found four prose issues; their exact logs are retained. The `pre-lint-correction/` snapshot preserves the 25-case source immediately before the field-name/spelling corrections. Intermediate iterations not separately captured are represented only by their logs, not claimed as complete source freezes.

No injected source mutants, broad root Cargo runs, deployment, listener startup or runtime wiring occurred in this subtask.
