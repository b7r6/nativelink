#!/usr/bin/env python3
"""Replay the bounded capability sync and special-file checks on the frozen binary."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
binary = root / "qualified/capability-tests"
output = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "qualified-syscalls"
output.mkdir(parents=True, exist_ok=False)
results = []
for fail in [None, 15, 16]:
    name = "layout-sync-baseline" if fail is None else f"layout-sync-fsync-{fail}-error"
    command = ["strace", "-f", "-yy", "-e", "trace=fsync"]
    if fail is not None:
        command += ["-e", f"inject=fsync:error=EIO:when={fail}"]
    command += [
        "-o", str(output / f"{name}.strace"), str(binary), "--exact",
        "tests::capabilities::explicit_layout_sync_preserves_children_records_and_locks",
        "--test-threads=1", "--nocapture",
    ]
    run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=20, check=False)
    (output / f"{name}.log").write_text(run.stdout)
    trace = (output / f"{name}.strace").read_text()
    assert run.returncode == (0 if fail is None else 101), (name, run.returncode, run.stdout)
    if fail is not None:
        assert "sync_layout_parent" in run.stdout and "INJECTED" in trace
    else:
        assert trace.count("fsync(") == 16, trace
        lines = [line for line in trace.splitlines() if "fsync(" in line]
        assert "/cas>" in lines[-2] and "/sink>" in lines[-1], lines[-2:]
    results.append({
        "case": name, "command": command, "exit_code": run.returncode,
        "trace_sha256": hashlib.sha256(trace.encode()).hexdigest(),
        "log_sha256": hashlib.sha256(run.stdout.encode()).hexdigest(),
    })

for case in [
    "regular_type_prechecks_refuse_special_files_and_symlinks_without_opening_them",
    "exclusive_temporary_names_refuse_existing_symlinks_and_special_files",
]:
    command = [str(binary), "--exact", "tests::capabilities::" + case, "--test-threads=1"]
    run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5, check=False)
    (output / f"{case}.log").write_text(run.stdout)
    assert run.returncode == 0, run.stdout
    results.append({"case": case, "command": command, "timeout_seconds": 5, "exit_code": run.returncode})

(output / "results.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
