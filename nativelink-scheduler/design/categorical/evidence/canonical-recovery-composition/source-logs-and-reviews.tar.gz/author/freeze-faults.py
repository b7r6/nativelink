from pathlib import Path
import json,hashlib,datetime
E=Path('/tmp/nativelink-canonical-recovery-composition-evidence')
Q=E/'qualified-source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
clock='nativelink-scheduler/src/authority/canonical_clock.rs';recovery='nativelink-scheduler/src/authority/canonical_recovery.rs';owner='nativelink-scheduler/src/authority/canonical_owner.rs'
def replace_once(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
cases=[]
s=(Q/clock).read_text();s=replace_once(s,'.ensure_linearizable()\n        .await\n        .map_err(|_| ClockError::Read)?;','.get_read_log_id()\n        .await\n        .map(|(barrier, _)| barrier)\n        .map_err(|_| ClockError::Read)?;')
cases.append(('leader-only',clock,s,'composed_owner_waits_for_real_base_apply_with_read_queue_available','Remove application wait but retain exact applied-position guard. At composedlevel, guard may refuse and supervisedcleanup keepscaller pending behindheldBase. Record actual postrelease error/proposal outcome; do not claim an earlyoffer/pending-oracle kill or a missing prerequisite as detection.'))
s=(Q/clock).read_text();s=replace_once(s,') -> Result<Clock, ClockError> {\n    let barrier = raft',') -> Result<Clock, ClockError> {\n    let origin = Instant::now();\n    #[cfg(test)]\n    if let Some(hook) = after_origin {\n        hook(origin);\n    }\n    let barrier = raft')
s=replace_once(s,'    #[cfg(not(test))]\n    {\n        Clock::capture(facts)\n    }\n    #[cfg(test)]\n    {\n        Clock::capture_inner(facts, after_origin)\n    }','    Clock::finish_capture(facts, origin, Instant::now())')
cases.append(('early-origin',clock,s,'composed_origin_follows_completed_validated_read','Actualorigin is observed beforeactualvalidatedreadcompletion; direct no-origin assertion fails whileactualauditgateheld.'))
s=replace_once((Q/clock).read_text(),'clock.first_tick = clock.observe_at(first)?;','clock.first_tick = clock.observe_at(first).unwrap_or(clock.facts.tick);')
cases.append(('sample-fallback',clock,s,'composed_real_first_sample_range_failure_cannot_offer_or_skip_final_drop','AtactualbaseC andactualelapsed>=1s, fallback incorrectlyoffersowner; direct constructor-result versusheldfinalDrop oracle mustobserve result, not a missingdrop timeout.'))
s=replace_once((Q/owner).read_text(),'base_tick: clock.base_tick,','base_tick: clock.base_tick.saturating_sub(1),')
cases.append(('wrong-base',owner,s,'composed_recovery_captures_actually_replayed_committed_and_uncommitted_time','Realretainedsuffix actuallyreplayed; publiccopiedbase differs from independentlyexpectedBASE+9.'))
s=replace_once((Q/owner).read_text(),'        self.lifecycle.shutdown().await','        drop(self.lifecycle);\n        Ok(())')
cases.append(('early-shutdown-ack',owner,s,'composed_cancelled_shutdown_waiter_cannot_abort_final_destruction','ActualfinalDropgate reached; explicitshutdown mustnotreturnwhileheld. EarlyOkdirectlyfails pendingassertion. Laterabortbranchisnotclaimedifnotreached.'))
s=replace_once((Q/recovery).read_text(),'        drop(self.stop.take());\n    }\n}\n\nimpl Control','        self.supervisor.abort();\n        drop(self.stop.take());\n    }\n}\n\nimpl Control')
cases.append(('abort-supervisor',recovery,s,'composed_cancel_during_validated_read_keeps_storage_until_actual_completion','Actualblockingread reached andcalleraborted, thenauditreleased. IndependentphysicalflockmuststayhelduntilheldfinalDropgate. Onlyobservedprematurereleasecountsdetection; missinggate/closedchannel/timeout alone notdetection.'))
D=E/'planned-fault-sources';D.mkdir();rows=[]
for name,path,s,test,oracle in cases:
 p=D/(name+'.rs');p.write_text(s)
 rows.append({'name':name,'path':path,'variant_copy':str(p.relative_to(E)),'source_sha256':sha(p),'bytes':p.stat().st_size,'original_sha256':sha(Q/path),'test':'authority::journal::canonical_owner::tests::recovery::composition::'+test,'oracle':oracle})
manifest={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified_source_manifest_sha256':sha(E/'qualified-source.json'),'qualified_commit':'d80937eb1815cf00c23e331e790f47077f516320','cases':rows,'status':'Six exactoperatorvariants frozen before anymutantcompile; selectedtestoracles fixed. No runtime detections yet.','classification':'Require compiler0, actualexecutedselectedtest, witnessedstage, directmeaningfulassertion. Missingstage/timeouts/compilerfailuresareprerequisites. Recordsurvivorsandwrong-oraclefailures honestly.','scope_note':'Leader-only removal retainsguard+supervisedcleanup; composedtarget mayrefuseafterrelease instead of earlyreturn. Privateclock layeralreadyhasseparatelyqualifiedpendingoracle. No six-kills promise.'}
p=E/'planned-faults.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n');print(sha(p))
