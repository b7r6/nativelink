from pathlib import Path
import json,hashlib,datetime
E=Path('/tmp/nativelink-canonical-recovery-composition-evidence')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=(E/'run-api-probes.py').read_text()
old="passed=run.returncode==0 if expected is None else run.returncode!=0 and bool(matched) and all((d.get('code') or {}).get('code')==expected for d in errors)"
new='''def in_probe(span):
  while span:
   if pathlib.Path(span['file_name']).resolve()==destination.resolve() and span.get('line_start')==22:return True
   span=(span.get('expansion') or {}).get('span')
  return False
 def related_private_type(diagnostic):
  return case['file']=='constructor.rs' and diagnostic.get('code') is None and diagnostic.get('message')=='type `journal::canonical_owner::canonical_recovery::LifecycleOwner` is private' and any(in_probe(span) for span in diagnostic.get('spans',[]))
 passed=run.returncode==0 if expected is None else run.returncode!=0 and bool(matched) and all((d.get('code') or {}).get('code')==expected or related_private_type(d) for d in errors)'''
assert original.count(old)==1
p=E/'run-api-probes-v2.py';assert not p.exists();p.write_text(original.replace(old,new))
first=json.loads((E/'api-first/summary.json').read_text());constructor=next(r for r in first['rows'] if r['source']=='constructor.rs')
assert constructor['intended_rejection_observed'] is False
assert len(constructor['primary_errors'])==2
required=[d for d in constructor['primary_errors'] if (d.get('code') or {}).get('code')=='E0451'];assert len(required)==1
assert any(s.get('is_primary') and Path(s['file_name']).name=='constructor.rs' and s['line_start']==22 for s in required[0]['spans'])
secondary=[d for d in constructor['primary_errors'] if d.get('code') is None];assert len(secondary)==1
assert secondary[0]['message']=='type `journal::canonical_owner::canonical_recovery::LifecycleOwner` is private'
def in_probe(span):
 while span:
  if Path(span['file_name']).name=='constructor.rs' and span.get('line_start')==22:return True
  span=(span.get('expansion') or {}).get('span')
 return False
assert any(in_probe(span) for span in secondary[0]['spans'])
record={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'first_summary_sha256':sha(E/'api-first/summary.json'),'original_runner_sha256':sha(E/'run-api-probes.py'),'amended_runner_sha256':sha(p),'primary_requirement_unchanged':'Nonzero compiler exit and exactE0451 primaryspan at constructor privatefield remain mandatory. All other16probe sourcebytes andrequiredcodes unchanged.','reason':'Initial harness overly required every primary diagnostic to repeat the samecode. Compiler also reports the private LifecycleOwner type through panic! macro expansion for the sameexpression. This supplemental privacy rejection is expected and is not a dependency/compiler prerequisite.','narrow_additional_rule':'Only constructor.rs may also carry exact code-less privateLifecycleOwner message, with source/macroexpansion chain to constructor.rs line22. Any unrelated primarydiagnostic stillrefuses classification.','first_actual_observations':{'positive_compiled':True,'negative_compiler_rejections':16,'required_primary_boundary_diagnostics':16,'initial_harness_classified':15,'constructor_required_E0451_observed':True,'reviewed_classification':16},'original_summary_preserved':True,'runtime_or_probe_source_changed':False,'execution':'This addendum reviews alreadyretained actualdiagnostics; it is not a new compiler run. Finalrestored APIprobes will rerunwithv2.'}
p=E/'api-classifier-addendum.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n');print(sha(p))
