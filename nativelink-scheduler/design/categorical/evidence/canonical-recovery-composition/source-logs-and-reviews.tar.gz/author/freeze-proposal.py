from pathlib import Path
import hashlib,json,shutil,subprocess,datetime,re
W=Path('/tmp/nativelink-canonical-recovery-composition')
E=Path('/tmp/nativelink-canonical-recovery-composition-evidence')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 p=E/name;p.write_text(json.dumps(value,indent=2)+'\n');return sha(p)
life=Path('/tmp/nativelink-canonical-recovery-lifecycle-evidence/qualified-source.json')
clock=Path('/tmp/nativelink-canonical-recovery-clock-evidence/runtime-qualified-candidate')
original=Path('/tmp/nativelink-canonical-recovery-independent-owner-review')
paths=[x['path'] for x in json.loads(life.read_text())['source_inputs']]
paths+=['nativelink-scheduler/src/authority/canonical_recovered_owner_tests.rs','nativelink-scheduler/tests/canonical_recovered_owner_api_test.rs']
paths += [str(p.relative_to(W)) for p in sorted((W/'nativelink-scheduler/tests/canonical_recovered_owner_api').glob('*.rs'))]
rows=[]
for name in paths:
 src=W/name;dst=E/'tests-first-source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 rows.append({'path':name,'bytes':src.stat().st_size,'sha256':sha(src)})
clockrows=[]
for row in json.loads((clock/'manifest.json').read_text())['files']:
 src=clock/'source'/row['path'];assert sha(src)==row['sha256'];dst=E/'clock-dependency-source'/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);clockrows.append(row)
shutil.copy2(clock/'manifest.json',E/'clock-dependency-manifest.json')
for name in ['construction-plan.json','tests-first.json']:
 shutil.copy2(original/name,E/('approved-B-'+name))
subprocess.run(['git','diff','--binary'],cwd=W,stdout=(E/'tests-first-tracked.patch').open('w'),check=True)
names=re.findall(r'async fn (composed_\w+)\(', (W/'nativelink-scheduler/src/authority/canonical_recovered_owner_tests.rs').read_text())
assert len(names)==15
first={
 'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Concrete tests-first draft for closed recovered-owner composition. No public runtime implementation or compiler invocation. Missing public APIs and unintegrated clock dependency are anticipated; they are not semantic failures.',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),
 'qualified_lifecycle_source':'327d41eb37285192e0b249ac78fe5f6cacad9fdf',
 'qualified_lifecycle_manifest_sha256':sha(life),
 'lifecycle_packet_commit':'7ea36ea27840d276f07dfa62ebaca2fe48a893dc',
 'clock_dependency_status':'Read-only copied root qualified-candidate source. Root owns remaining qualification and integration. This draft does not claim the clock is qualified.',
 'clock_dependency_manifest_sha256':sha(E/'clock-dependency-manifest.json'),
 'clock_dependency_inputs':clockrows,
 'approved_construction_plan_sha256':sha(E/'approved-B-construction-plan.json'),
 'approved_24_case_plan_sha256':sha(E/'approved-B-tests-first.json'),
 'source_inputs':rows,
 'test_names':names,
 'new_runtime_test_cases':{'library':15,'external':1,'scope':'planned, not executed'},
 'external_api_probes':{'positive':1,'negative':15,'plan_sha256':sha(E/'api-probes-plan.json'),'scope':'compile-time closure checks, not runtime mutant detections'},
 'test_support_delta':['Add three lifecycle stages BeforeClock/ClockReadStarted/ClockStored; cfg(test) actual-origin observer and one-shot blocking/panic callback, validated-read hook.','Keep original 21 lifecycle tests and all their assertions. Extend only test support; temporal fixture helpers gain visibility solely within owner tests.','New composition tests invoke private hook entry of exactly the public wrapper implementation. No public test-only hook or caller-provided production clock.','Explicitly drop cfg(test) Raft/Journal aliases before cleanup acknowledgement assertions; actual SM/snapshot tests await proposal drop or drop observer aliases before drain assertion.'],
 'formatters':'Rustfmt nightly2026-08-26 and buildifier8.5.1 ran successfully; no Cargo/Bazel/Clippy invocation.',
 'runtime_diff':'No production Rust file changed. Only tests, test-helper visibility, and BUILD source/target entries are changed.',
 'baseline':'No compiler baseline run. The public recovered type/methods are intentionally absent and clock source is not integrated. Such compiler absence would not count as 16 failing semantic tests.'
}
firstsha=write('tests-first.json',first)
coverage={
'B01':['new composed_public_preparing_refusal_preserves_storage','new external public_recovery_refuses_preparing_and_finishes_custody_before_error','existing lifecycle created provenance and Sealed positive'],
'B02':['new composed_recovery_captures_actually_replayed_committed_and_uncommitted_time (committed=true)'],
'B03':['same new replay test (committed=false); actual Raft restart/election determines applied base'],
'B04':['new composed_owner_waits_for_real_base_apply_with_read_queue_available; observed leader watermark > applied index, actual Base gate outside Journal.io; planned leader-only mutant'],
'B05':['new composed_origin_follows_completed_validated_read; actual blocking audit callback, no origin/offer while held and actual origin >= release'],
'B06':['existing private clock exact-cutoff/floor tests','new composed_real_first_sample_range_failure_cannot_offer_or_skip_final_drop with real Instant elapsed >=1s and C base'],
'B07':['existing private clock backward-before-origin and backward-after-last same-tick tests'],
'B08':['existing private clock overflow and invalid-base tests'],
'B09':['new composed_restart_preserves_application_deadlines_and_ignores_downtime; exact scheduler bytes and persisted base across real elapsed lifetime/downtime','existing private clock fractional/downtime numeric tests'],
'B10':['existing lifecycle unpolled start and all reached startup cancellations; new public Preparing refusal'],
'B11':['existing lifecycle actual Raft::new initial storage read cancellation + immediate handle storage stages','new composed cancellation at actual Base barrier and actual validated blocking read'],
'B12':['existing lifecycle queued offer, pre-ACK armed cancellation, rejected ACK, synchronous post-ACK panic; no second handoff added by public wrapper'],
'B13':['new composed Drop/unpolledshutdown and cancelled actual shutdown waiter'],
'B14':['new actual postleader metadata ClockRead, firstsample ClockRange and postorigin Panic each require actual final destruction before error; direct early-result oracle avoids counting missingdrop timeouts as detection'],
'B15':['new composed_shutdown_waits_for_real_base_state_machine_after_core_join; actual worker holds Base gate, proposal-owned observers dropped before pending assertion'],
'B16':['new composed_shutdown_waits_for_actual_spawned_snapshot_after_core_join; actual BuildSnapshot calls1/completed0 while queue held, completed1 after release'],
'B17':['new composed_late_storage_clone_cannot_be_bypassed_by_shutdown'],
'B18':['existing lifecycle cancelled actual Journal.io blocking closure and qualified helper actual cancelled I/O tests'],
'B19':['new composed finalDrop gates on errors/Drop/shutdown; existing lifecycle/helper actual destruction tests'],
'B20':['existing helper retained cleanup Journal and lifecycle private database alias; new late clone; source review checks no self-retaining cleanup reference'],
'B21':['new actual-origin capture panic; existing lifecycle startup/session panics and real core panic classification'],
'B22':['new public error and shutdown lock assertions plus existing lifecycle independent Ownership alias test'],
'B23':['new one positive and15 independent negative external compile probes; existing canonical_binding generic-path runtime refusals, owner API test retained'],
'B24':['new restart exact scheduler bytes preserve deadlines/effects/reservations and Sealed; source/API closure no sample/propose/query/service constructor or driver'],
}
proposal={
 'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'tests_first_sha256':firstsha,
 'status':'PROPOSED ONLY. Await root source review and qualified clock integration before changing production runtime. Parent has accepted bounded public shape in conversation, not this entire implementation/test packet.',
 'public_surface':{
  'methods':['PreparedCanonicalOwner::recover_sealed(self) -> Result<RecoveredCanonicalOwner,RecoveryError> async','RecoveredCanonicalOwner::diagnostic(&self) -> RecoveryDiagnostic','RecoveredCanonicalOwner::shutdown(self) -> Result<(),RecoveryError> async'],
  'RecoveredCanonicalOwner':'One private lifecycle: LifecycleOwner field. No Clone, Deserialize, Deref, AsRef, constructor, field extraction, arbitrary closure, sender, raw runtime or sample method.',
  'RecoveryDiagnostic':'Copied owner:OwnerDiagnostic, applied_term:u64, applied_node_id:u64, applied_index:u64, base_tick:u64, first_tick:u64. All historical validated capture facts, no live health guarantee or Instant/OpenRaft runtime type.',
  'RecoveryError':'Public bounded Phase,Storage,Runtime,Panic,Task,Handoff,ClockRead,ClockRange,ClockBackward with Display/Error. Keep private LifecycleOwner imports compatible; no raw underlying error/resource payload.',
  'semantics':'Success owns supervised sealed recovery after real application barrier, validated read, fresh actual monotonic origin and fallible first sample. No cold initialization/seal writer, periodic clock driver, application proposals, serving integration, or new postreplay parent-fsync promise.'},
 'runtime_delta':[
  'Integrate qualified root clock first, resolve only owner module/BUILD/test module additions while preserving all existing lifecycle/helper/clock tests.',
  'Move or reexport bounded RecoveryError from canonical_owner, keep private recovery import compatible; add three explicit clock error mappings.',
  'Resources gains Option<canonical_clock::Clock>; initialize None in first poll before supervisor spawn. The supervised caught run borrows resources; all errors/panics retain designated cleanupArc and any returnedRaft outside caught future.',
  'After actual initialized+leader and existing stop check, publish cfgtest borrowed Raft observer before BeforeClock hook. Await canonical_clock::recover on the matching borrowed resources.raft and resources.journal. Do not select/drop this recovery future on caller cancellation: retain supervisor/resources, finish bounded barrier/audit or its error, store successful Clock immediately before another await, then inspect stop before offering.',
  'Add ClockReadStarted observation before entering actual recovery, ClockStored after immediate resource storage; both cfgtest. Test hooks during actual audit and after actual origin are cfgtest-only. Production cannot replace instants/facts or callback into clock.',
  'Offer private {owner:OwnerDiagnostic,clock:canonical_clock::Diagnostic} copied facts. LifecycleOwner gains copied clockdiagnostic and preserves its existing diagnostic() -> OwnerDiagnostic unchanged. Obtain clock facts only from stored Clock; no fallback.',
  'Existing permanent supervisor, raw JoinHandle detach-on-Drop, offered/ACK separation, owner armed before ACK, samepoll successful ACK->return, and cleanup ordering remain exactly intact. Wrapper awaits private start then constructs public wrapper and returns without another suspension.',
  'Public wrapper diagnostic copies full applied identity primitives and original owner facts. Public consuming shutdown awaits inner shutdown. Dropping wrapper or unpolled shutdown drops private Control and requests independent cleanup.',
  'Cleanup drops stored Clock along with private handles before final database drain; clock has no storage capability. Existing real Raft terminal classification and blocking final database destruction remain authoritative.',
  'Update private module docstrings and public contract comments to historical capture scope. No production sites/config/service/clock-driver changes.'
 ],
 'test_only_clock_hook':{
  'shape':'Private cfg(test) recover_with_hooks takes optional one-shot during_audit callback and one-shot after_origin callback FnOnce(Instant)+Send. Existing recover_with_audit_hook and unit Clock::capture call route with no hook, preserving original16 assertions.',
  'ordering':'actual ensure_linearizable -> complete temporal::audit -> ReadFacts::after_barrier -> actual Instant::now origin -> cfgtest observer/gate -> actual Instant::now first -> existing finish_capture checked sample. Hook never supplies a replacement instant, base, facts, or result.',
  'bounded_wait':'Firstsample test uses Tokio multi_thread2; hook stdmpsc recv_timeout10s, test observes actual origin and waits actual elapsed>=1s before releasing. At persisted C this must return ClockRange. Actual finalDrop is held and error-return is directly selected against that gate.',
  'prerequisite_integrity':'Missing actual stage/gate is a prerequisite failure, never a mutant detection. Faults that wrongly return a constructor result are caught directly before expected failure cleanup, not by waiting until a missingdrop timeout.'
 },
 'original_24_case_coverage_map':coverage,
 'existing_counts_not_additive':'21 lifecycle,16 privateclock,12 helper/custody existing tests are retained and mapped. Clock count remains pending root qualification. New planned15lib+1external runtime tests and1positive/15negative compile probes are separate categories; no tests or controls executed here.',
 'planned_compiled_controls':[
  {'name':'leader-only-read','change':'Replace actual ensure_linearizable with actual get_read_log_id watermark only, retaining validation','oracle':'composed actual Base pending assertion sees early error/owner while real apply held and Journal reads available'},
  {'name':'origin-before-read','change':'Capture actual origin before awaited audit, preserving cfgtest observation of that actual origin and actual second sample','oracle':'composed_origin_follows_completed_validated_read direct no-origin assertion while actual read held'},
  {'name':'first-sample-fallback','change':'Replace checked first observation propagation with persisted-base fallback','oracle':'composed real1s cutoff test directly observes forbidden constructor return before required finalDrop'},
  {'name':'misreported-base','change':'Offer/public diagnostic copies a wrong base rather than stored recovered Clock diagnostic','oracle':'actual replay test exact base BASE+9 comparison'},
  {'name':'public-early-shutdown-ack','change':'Public wrapper drops lifecycle and returns Ok without awaiting its shutdown','oracle':'actual finalDrop reached then constructor shutdown pending assertion fails on earlyOk'},
  {'name':'abort-supervisor-with-public-consumer','change':'Abort raw supervisor in Control Drop','oracle':'composed actual validated-read cancellation, after testobserver aliases absent, requires supervised finalDrop rather than silently lost guardian'}
 ],
 'control_freeze_rule':'These are planned operator descriptions, not executed immutable variants. Freeze exact independently compiled variants only after reviewed runtime implementation and baseline; record source/ELF/log/observedassertion per attempt. A missing prerequisite, compiler error, timeout, or survivor is never promoted to a detection.',
 'validation_plan':['Freeze root-qualified clock integration and tests-first merge before runtime changes.','Review actual runtime source and source manifest independently before compiling.','Under explicit Cargo lane handoff use root new dedicated cache outside repository target; no concurrent cleanup.','Run focused15 composition cases and1 new external bridge; broad authority/owner/clock/helper tests plus both external bridge tests; strict all-targets Clippy -Dwarnings and full hooks.','Run positive external compile probe first, then15 negatives with exact primary-span+errorcode checks using actual production library identity; retain all logs.','Freeze+compile selected runtime controls; restore exact qualified source and rerun broad/strict with actual copiedELFs.','Package exact source/log/review/executable evidence, independent relocation verification, then parent root integration+Bazel validation.'],
 'limits':['No serving/applicationdriver/timeprogress claim.','No hostile-code filesystem exclusivity or release of independent lower-level Ownership aliases.','No process/runtime destruction cleanup acknowledgement, earlyRaftnew explicit tickjoin, global task-join or newDropdurability claim.','No success if required cleanup fails; error alone does not promise storage rollback.','No compiler or runtime result claimed by this proposal; no fabricated baseline failures.']
}
print('tests-first',firstsha)
print('proposal',write('proposed-runtime-delta.json',proposal))
print('source_inputs',len(rows),'clock_dependency_inputs',len(clockrows))
