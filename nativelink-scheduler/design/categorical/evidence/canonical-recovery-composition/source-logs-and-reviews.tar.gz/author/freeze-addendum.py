from pathlib import Path
import hashlib,json,shutil,subprocess,datetime,re
W=Path('/tmp/nativelink-canonical-recovery-composition');E=Path('/tmp/nativelink-canonical-recovery-composition-evidence')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):
 p=E/n;assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');return sha(p)
original=json.loads((E/'tests-first.json').read_text())
paths=[row['path'] for row in original['source_inputs']]
paths+=['nativelink-scheduler/src/authority/canonical_temporal_tests.rs','nativelink-scheduler/tests/canonical_recovered_owner_api/singleton_adapter.rs']
rows=[]
for name in paths:
 src=W/name;dst=E/'tests-first-amended-source'/name;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copy2(src,dst);rows.append({'path':name,'bytes':src.stat().st_size,'sha256':sha(src)})
api=json.loads((E/'api-probes-plan.json').read_text())
api['previous_plan_sha256']=sha(E/'api-probes-plan.json')
api['negative'].append({'file':'singleton_adapter.rs','required_code':'E0308','required_primary_span':'the external owner argument passed to a function requiring Singleton','oracle':'type mismatch at actual closed owner->raw Singleton service boundary; not a runtime fault'})
apisha=write('api-probes-amended-plan.json',api)
names=re.findall(r'async fn (composed_\w+)\(', (W/'nativelink-scheduler/src/authority/canonical_recovered_owner_tests.rs').read_text());assert len(names)==16
add={
'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'previous_tests_first_sha256':sha(E/'tests-first.json'),
'previous_proposal_sha256':sha(E/'proposed-runtime-delta.json'),
'originals_preserved':True,
'status':'Amended tests-first source only; no production Rust edits, runtime implementation or compiler invocation.',
'base_commit':original['base_commit'],
'source_inputs':rows,
'changes':[
'Add exact modified canonical_temporal_tests.rs fullcopy/hash, previously omitted from39sourceinputs; original trackedpatch recorded the7testhelper visibility changes.',
'Add real nestedtask-held Journal test. Outerholder survives into BeforeDrain, creates actual inner holder afterward, drops original, observes pending+locks, releases and joins inner/outer before successful shutdown.',
'Add external E0308 probe rejecting recovered owner passed to a function requiring raw Singleton.',
'Cancel-during-validated-read test now repeatedly performs actual independent flock checks while awaiting finalDrop reached; early physicalrelease directlyfails even if aborted supervisor never enters finalDrop. Missinggate/timeouts alone remain prerequisites.',
'Bound initial ensure_linearizable prerequisite, actual snapshot trigger and initial queue acquisition with WAIT and stage-specific messages. No production read/audit timebound is claimed.',
'Public recovered owner requires bounded Debug printing only copieddiagnostic, not resources; supports explicit unwrap_err/result-debug assertions.',
],
'new_test_names':names,
'new_runtime_test_cases':{'library':16,'external':1,'status':'planned, unexecuted'},
'external_api_probes':{'positive':1,'negative':16,'plan_sha256':apisha,'status':'planned, uncompiled; separate from runtime controls'},
'clock_dependency_manifest_sha256':original['clock_dependency_manifest_sha256'],
'clock_dependency_status':original['clock_dependency_status'],
'formatters':'Rustfmt success after amendments, git diff --check success; no Cargo/Bazel/Clippy invocation.',
'prior_independent_storage_review':{'path':'/tmp/nativelink-canonical-recovery-composition-independent-storage-review/initial-review.json','sha256':'97e2fc1592021cd09f2edac20a09fe251ba42d81c494d6e296f2582b3bfc9c62'},
'production_source_unchanged':['nativelink-scheduler/src/authority/canonical_recovery.rs','nativelink-scheduler/src/authority/canonical_owner.rs','nativelink-scheduler/src/authority/canonical_temporal.rs','nativelink-scheduler/src/authority/journal.rs'],
}
for name in add['production_source_unchanged']:
 assert (W/name).read_bytes()==subprocess.check_output(['git','show',original['base_commit']+':'+name],cwd=W)
addsha=write('tests-first-addendum.json',add)
proposal=json.loads((E/'proposed-runtime-delta.json').read_text())
proposal['previous_proposal_sha256']=sha(E/'proposed-runtime-delta.json')
proposal['tests_first_addendum_sha256']=addsha
proposal['status']='AMENDED PROPOSAL ONLY. Await independent/root source review and qualified clock integration before production runtime edits. Originals remain immutable.'
proposal['public_surface']['RecoveredCanonicalOwner']+=' Bounded Debug prints only copied diagnostic.'
proposal['runtime_delta']=[x.replace('finish bounded barrier/audit or its error','await the required barrier/audit or its error while retaining resources (no total history-work or elapsed-time bound)') for x in proposal['runtime_delta']]
proposal['original_24_case_coverage_map']['B20'].append('new composed_nested_cleanup_holder_is_released_before_acknowledgement actual outer/inner task holder, release and joined completion')
proposal['original_24_case_coverage_map']['B23']=['new one positive and16 independent negative external compile probes, including raw Singleton service-argument mismatch','existing canonical_binding generic-path runtime refusals, owner API test retained']
proposal['existing_counts_not_additive']='21 lifecycle,16 privateclock,12 helper/custody existing tests are retained and mapped, clock qualification owned by root. New planned16lib+1external runtime tests and1positive/16negative compile probes are separate categories. No tests/controls executed here.'
proposal['planned_compiled_controls'][-1]['oracle']='After actual held audit completion, composed cancelled-read test repeatedly checks real independent flock while awaiting required heldfinalDrop. Any physicalrelease before that gate directlyfails. Missinggate, closedchannel, timeout or unreleasedleak alone is prerequisite/inconclusive, never detection.'
proposal['validation_plan']=[s.replace('focused15 composition','focused16 composition').replace('then15 negatives','then16 negatives') for s in proposal['validation_plan']]
print('addendum',addsha)
print('amended proposal',write('proposed-runtime-amended.json',proposal))
print('amended APIplan',apisha,'inputs',len(rows))
subprocess.run(['git','diff','--binary'],cwd=W,stdout=(E/'tests-first-amended-tracked.patch').open('w'),check=True)
