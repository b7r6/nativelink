import pathlib,json,hashlib,tarfile,gzip,io,shutil,datetime
E=pathlib.Path('/tmp/nativelink-canonical-recovery-composition-evidence');W=pathlib.Path('/tmp/nativelink-canonical-recovery-composition');D=W/'nativelink-scheduler/design/categorical/evidence/canonical-recovery-composition'
D.mkdir(parents=True,exist_ok=False)
roots={'author':E,'root-review':pathlib.Path('/tmp/nativelink-canonical-recovery-composition-independent-root-review'),'storage-review':pathlib.Path('/tmp/nativelink-canonical-recovery-composition-independent-storage-review')}
def sha(b):return hashlib.sha256(b).hexdigest()
files=[];groups={};aliases=[]
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  name=prefix+'/'+str(p.relative_to(root));b=p.read_bytes();entry={'path':name,'bytes':len(b),'sha256':sha(b)}
  kind='executable' if b.startswith(b'\x7fELF') else 'rust-library' if b.startswith(b'!<arch>\n') else None
  if kind:
   entry['kind']=kind;groups.setdefault(entry['sha256'],(p,len(b),kind));aliases.append(entry)
  else:files.append((p,entry))
archives=[]
def archive(name,kind,items):
 path=D/name;members=[]
 with path.open('wb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed:
   with tarfile.open(fileobj=compressed,mode='w') as output:
    for p,entry in items:
     b=p.read_bytes();assert sha(b)==entry['sha256'];assert len(b)==entry['bytes'];info=tarfile.TarInfo(entry['path']);info.size=len(b);info.mode=0o755 if entry.get('kind')=='executable' else 0o644;info.mtime=0;output.addfile(info,io.BytesIO(b));members.append(entry)
 assert path.stat().st_size<25_000_000,path
 archives.append({'path':name,'kind':kind,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':members})
archive('source-logs-and-reviews.tar.gz','source-logs-and-reviews',files)
unique=[(p,{'path':'binaries/'+digest,'bytes':size,'sha256':digest,'kind':kind}) for digest,(p,size,kind) in sorted(groups.items())]
for number,start in enumerate(range(0,len(unique),2)):archive(f'binaries-{number:03}.tar.gz','binaries',unique[start:start+2])
shutil.copyfile(E/'verify-bundle.py',D/'verify-bundle.py')
labels=[('focused-first','initial-runtime'),('broad-first','initial-runtime'),('strict-first','initial-runtime'),('strict-corrected','qualified'),('qualified-broad','qualified')]
labels += [('fault-'+c['name'],c['name']) for c in json.loads((E/'planned-faults.json').read_text())['cases']]
labels += [('restored-broad','qualified'),('restored-strict','qualified')]
attempts=[{'receipt':'author/'+label+'.json','sha256':sha((E/(label+'.json')).read_bytes()),'log':'author/'+label+'.log','source_boundary':boundary} for label,boundary in labels]
faults=json.loads((E/'fault-results.json').read_text())
M={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tests_first_commit':'a39b277e5b7a85ee0fb2773236a05fadfe1a9162','clock_dependency_source_commit':'4841fae0ed7b6901e976742daf7040c799634f93','source_commit':'d80937eb1815cf00c23e331e790f47077f516320','scope':'Closed public recovered owner composes qualified private supervisor, actual linearizable read and validated audit, recovered fixed clock, and final backend destruction. No serving, sampling, proposals, query, rawhandle conversions, cold initialization or seal writer.','verifier_sha256':sha((D/'verify-bundle.py').read_bytes()),'qualified_source_manifest_sha256':sha((E/'qualified-source.json').read_bytes()),'source_restoration_receipt_sha256':sha((E/'source-restoration.json').read_bytes()),'fault_results_sha256':sha((E/'fault-results.json').read_bytes()),'archives':archives,'distinct_binary_count':len(unique),'distinct_executable_count':sum(row[1]['kind']=='executable' for row in unique),'distinct_rust_library_count':sum(row[1]['kind']=='rust-library' for row in unique),'binary_alias_count':len(aliases),'binary_aliases':sorted(aliases,key=lambda r:r['path']),'attempts':attempts,'positive_results':'16 new focused composition tests; qualified/restored combined216library+2externalAPItests pass,1existingignored; corrected/restored strictalltargets-Dwarnings0. Existing21lifecycle+16privateclock+12helper/custody tests retained.','original_attempts':'Firstfocused16 and firstbroad216+2 pass. Firststrict5diagnostics/3distinctlints corrected narrowly: constclockmapping, clockOptionNone, testonlycallbacktypealias. No testbody or oracle weakening. OriginalAPI pass+16requiredrejections; originalclassifier counted15 becauseconstructor E0451 hadrelatedprivate-type secondaryerror. Exactnarrowclassifier addendum frozen before restoredrerun; raworiginalsummary preserved.','source_provenance':'Cargo receipt source_manifest_sha25670798 identifies original input-path selection. Actual44 bytehashes are source_before/source_after and exact copiedattempt inputs, checked against the stated initial, qualified, or individual frozenvariant boundary.','compiled_controls':faults,'external_api_probes':'Two actual runs, each positive compilation and16intendedprimarynegative diagnostics. Firstclassifier summary15retained; amended restoredsummary16. No runtime fault/testexecutable count assigned to rustcmetadata probes.','limits':['Copied diagnostic describes capture, not continuing core health or readiness.','Existing Singleton and AuthorityService routes remain independently callable; no repository-wide canonical serving or rawhandle elimination claim.','Cold bootstrap and seal writing remain absent; public Preparing recovery is refused.','Early Raft::new storage failure proves final backend quiescence, not explicit tick join.','Process/runtime destruction, unavailableexecutor and doublepanic do not acknowledge asynchronous cleanup.','Blocked I/O or independently held backend references can keep cleanup pending.','Successful release concerns canonical backend custody; external Ownership aliases can retain namespace locks.','Database Drop completion is not a new durability acknowledgement.','Retained productionrlibs and selected source inputs are not a hermetic transitive toolchain/dependency closure.']}
(D/'manifest.json').write_text(json.dumps(M,indent=2)+'\n')
(D/'README.md').write_text('''# Closed recovered canonical owner evidence

Source commit `d80937eb1815cf00c23e331e790f47077f516320` composes the private recovery supervisor, actual linearizable read, complete validated temporal audit, and fixed recovered clock into `PreparedCanonicalOwner::recover_sealed`. The returned owner exposes a copied diagnostic and consuming shutdown. It exposes no live sample, proposal, query, raw storage handle, cold initialization, seal writer, or serving path. The diagnostic describes the capture and is not a current health report.

All 16 new focused composition tests pass. Qualified and restored combined runs pass 216 library tests and two external owner API tests, with one existing ignored test. Strict checks pass after three narrow lint corrections and on restored source. Existing lifecycle, private clock, cleanup, and custody tests remain included. The source, original attempts, lint correction, independent reviews, exact compiled controls, all retained test executables, and selected production Rust libraries are archived.

Six separately frozen runtime controls compiled and were executed against their declared tests. The per-case results retain the exact first observation and distinguish direct assertion failures from later cleanup effects. The leader-only control is detected when premature core shutdown refuses the required successful proposal after Base release; it is not evidence of a premature owner offer. Later unexecuted branches are not claimed.

The external compiler probes each compile the positive API and reject all 16 invalid uses with their intended primary diagnostic. The original classifier counted 15 because the constructor probe produced E0451 plus a related private-type error. Its raw summary remains unchanged. A frozen, narrow classifier amendment accepts only that exact secondary error with the same constructor expansion span; the restored run reports all 16. Compiler probes are separate from runtime controls.

Run `python3 verify-bundle.py` from this directory to verify archive contents, binary aliases, exact source boundaries and Cargo attempt bindings, and both external probe runs. Add `--extract /path/to/output` to reconstruct the relative files. The verifier reads only this bundle and the selected destination. Recorded absolute command paths are provenance, not dependencies of verification.

The Cargo receipt field `source_manifest_sha256` identifies the original input-path selection manifest. The 44 actual file hashes in each `source_before` and `source_after` map identify executed source content; verification binds them to the initial runtime, qualified runtime, or individual frozen control. This packet retains selected source and production libraries, not a hermetic toolchain or dependency closure.

Actual final database destruction precedes acknowledged completion. Blocked storage or independent backend references can keep cleanup pending. External ownership aliases can retain namespace locks. Database destruction is not a new durability acknowledgement, and process or runtime destruction cannot acknowledge asynchronous cleanup. Existing Singleton and AuthorityService routes remain; this slice does not claim canonical serving or repository-wide elimination of raw handles.
''')
print(json.dumps({'directory':str(D),'manifest_sha256':sha((D/'manifest.json').read_bytes()),'archives':[{k:v for k,v in a.items() if k!='members'} for a in archives],'distinct_binaries':len(unique),'retained_binary_aliases':len(aliases),'source_log_review_files':len(files)},indent=2))
