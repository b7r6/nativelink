from pathlib import Path
import hashlib,json,shutil,subprocess,datetime
W=Path('/tmp/nativelink-canonical-recovery-composition');E=Path('/tmp/nativelink-canonical-recovery-composition-evidence')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((E/'tests-first-addendum.json').read_text())
clock=json.loads((E/'clock-dependency-manifest.json').read_text())
paths=list(dict.fromkeys([r['path'] for r in previous['source_inputs']]+[r['path'] for r in clock['files']]))
rows=[]
for p in paths:
 src=W/p;dst=E/'integrated-tests-source'/p;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copy2(src,dst);rows.append({'path':p,'bytes':src.stat().st_size,'sha256':sha(src)})
changed=[r['path'] for r in previous['source_inputs'] if sha(W/r['path'])!=r['sha256']]
assert set(changed)=={'nativelink-scheduler/BUILD.bazel','nativelink-scheduler/src/authority/canonical_owner.rs','nativelink-scheduler/src/authority/canonical_temporal.rs','nativelink-scheduler/src/authority/canonical_temporal_tests.rs','nativelink-scheduler/src/authority/journal.rs'},changed
name='nativelink-scheduler/src/authority/canonical_temporal_tests.rs'
new=(W/name).read_text();old=(E/'tests-first-amended-source'/name).read_text()
assert new.replace('#[path = "canonical_recovery_clock_tests.rs"]\nmod recovery_clock;\n\n','')==old
for name in ['canonical_clock.rs','canonical_clock_tests.rs','canonical_recovery_clock_tests.rs','canonical_temporal.rs','journal.rs']:
 p='nativelink-scheduler/src/authority/'+name
 assert (W/p).read_bytes()==subprocess.check_output(['git','show','4841fae0ed7b6901e976742daf7040c799634f93:'+p],cwd=W)
d={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'tests_first_commit':'a39b277e5b7a85ee0fb2773236a05fadfe1a9162','qualified_clock_source_commit':'4841fae0ed7b6901e976742daf7040c799634f93','tests_first_addendum_sha256':sha(E/'tests-first-addendum.json'),'proposal_sha256':sha(E/'proposed-runtime-amended.json'),'root_review_sha256':'a1cffbefa912c6151ed04c0b077e8ffef606fee74424192dabd4523a4e511351','storage_review_sha256':'a8af2e1e8ce01b990a87ca0ebd389335926545831b8ab13a859cfc80b664a1f9','source_inputs':rows,'changed_since_addendum':changed,'mechanical_test_change':'Only canonical_temporal_tests adds qualified clock test module declaration. All other preexisting/new test/probe source bytes unchanged. All7fixturevisibility changes retained.','merge_resolution':'Two expected conflicts BUILD source list union sorted and owner module list concatenation. Fullhooks passed both tests-first commit and clock cherry-pick.','runtime_status':'Closed public composition not implemented; no Cargo invoked. Qualified clock5corefiles match exact4841 source; dependencies retained.','git_status':subprocess.check_output(['git','status','--short'],cwd=W,text=True)}
p=E/'integrated-tests-source.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print(sha(p),len(rows))
