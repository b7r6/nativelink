import pathlib,subprocess,shutil,os,json,hashlib
root=pathlib.Path('/tmp/nativelink-publication-capacity')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/publication-capacity')
final=evidence/'final-source'
baseline=pathlib.Path('/tmp/nativelink-categorical-evidence/publication-candidate/final-source')
relative='nativelink-scheduler/tests/publication_candidate/'
changed=[relative+'engine.rs',relative+'validation.rs']
for p in final.rglob('*'):
 if p.is_file():
  dest=evidence/'baseline-repro-source'/p.relative_to(final)
  dest.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(p,dest)
for p in changed:
 shutil.copy2(baseline/p,evidence/'baseline-repro-source'/p)
try:
 for p in changed:
  shutil.copyfile(baseline/p,root/p)
 with (evidence/'baseline-five-gap-repro.log').open('wb') as log:
  result=subprocess.run(['cargo','test','--locked','--offline','--profile=smol','-p','nativelink-scheduler','--test','publication_candidate_test','capacity','--','--skip','full_fixed_caps_complete_and_snapshot_with_escaping_and_large_child_rows'],cwd=root,env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-history-candidate-target',CARGO_BUILD_JOBS='8'),stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps({'exit':result.returncode,'source':'baseline-repro-source'}),flush=True)
finally:
 for p in changed:
  shutil.copyfile(final/p,root/p)
