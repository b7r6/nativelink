import pathlib,subprocess,os,json,hashlib,difflib,time
root=pathlib.Path('/tmp/nativelink-publication-capacity')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/publication-capacity')
base='nativelink-scheduler/tests/publication_candidate/'
sources={name:(evidence/'final-source'/base/name).read_text() for name in ['engine.rs','validation.rs']}
mutants=[
('omit_cached_projection_limit','engine.rs','''        if !self.metadata.actions[&candidate.action]
            && candidate.response.exit_code == 0
            && candidate.response.error.is_none()
            && serde_json::to_vec(&Self::cached_payload(candidate)?)
                .map_err(|_| Error::Invalid)?
                .len()
                > self.scheduler.payload_limit_bytes()
        {
            return Err(Error::Bounds);
        }
''','', 'stage_rejects_cache_projection_above_the_real_payload_limit'),
('permit_child_payload_limit_drift','validation.rs','            || self.scheduler.payload_limit_bytes() != MAX_PAYLOAD\n','', 'restore_rejects_a_different_real_scheduler_payload_ceiling'),
('omit_worker_stage_action_binding','engine.rs','''            if request.action.instance != candidate.action {
                return Err(Error::Unauthorized);
            }
''','', 'stage_cannot_spend_execution_credit_on_another_qualified_action'),
('omit_current_attempt_preview','engine.rs','            next.validate_worker_stage(&candidate)?;\n','', 'late_predecessor_cannot_consume_replacement_attempt_stage_credit'),
]
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-history-candidate-target',CARGO_BUILD_JOBS='8')
results=[]
try:
 for name,filename,old,new,test in mutants:
  source=sources[filename]
  assert source.count(old)==1,(name,source.count(old))
  changed=source.replace(old,new)
  directory=evidence/'mutants'/name
  directory.mkdir(parents=True,exist_ok=True)
  (directory/filename).write_text(changed)
  (directory/'mutation.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen/'+filename,tofile='mutant/'+filename)))
  path=root/base/filename
  path.write_text(changed)
  command=['cargo','test','--locked','--offline','--profile=smol','-p','nativelink-scheduler','--test','publication_candidate_test',test]
  started=time.time()
  with (directory/'test.log').open('wb') as log:
   result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(directory/'test.log').read_text()
  compiled='Running tests/publication_candidate_test.rs' in output
  row={'name':name,'test':test,'exit':result.returncode,'compiled':compiled,'outcome':'SURVIVED' if result.returncode==0 else ('KILLED' if compiled else 'BUILD_FAILED'),'seconds':round(time.time()-started,3),'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'log_sha256':hashlib.sha256((directory/'test.log').read_bytes()).hexdigest()}
  results.append(row)
  (evidence/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(row),flush=True)
  path.write_text(source)
finally:
 for filename,source in sources.items():
  (root/base/filename).write_text(source)
