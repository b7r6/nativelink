from pathlib import Path
import subprocess,json,hashlib,shutil,time
root=Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03'); out=Path(__file__).parent
clock=root/'nativelink-service/src/authority_clock.rs'; server=root/'nativelink-service/src/authority_server.rs'
original={p:p.read_text() for p in (clock,server)}
clock_old='''        self.base
            .checked_add(elapsed.as_secs())
            .ok_or_else(|| "Monotonic authority seconds exhausted".to_owned())'''
clock_new='''        Ok(self.base.saturating_add(elapsed.as_secs()))'''
server_old='''        let now = (self.config.now)()
            .map_err(|error| format!("Authority clock observation failed: {error}"))?
            .max(self.state.now);'''
server_new='''        let now = (self.config.now)().unwrap_or(self.state.now).max(self.state.now);'''
start=original[server].index('        // Once polled, preparation owns authority')
end=original[server].index('\n    }\n\n    async fn start_owned',start)
wrapper=original[server][start:end]
mutants=[('saturate-clock',clock,clock_old,clock_new,'exhaustion_and_a_source_before_origin_are_errors'),('ignore-clock-error',server,server_old,server_new,'clock_failure_'),('skip-startup-sweep',server,'        if let Err(error) = driver.time().await {','        if driver.config.instance.is_empty() && let Err(error) = driver.time().await {','clock_failure_refuses_start_before_due_recovery_mutations'),('drop-owned-preparation',server,wrapper,'        Self::start_owned(authority, config).await','cancelled_clock_preparation_retains_custody_until_shutdown')]
results=[json.loads((out/'mutants-first-attempt.json').read_text())[0]]
try:
 for name,path,old,new,filter in mutants[1:]:
  assert original[path].count(old)==1,(name,original[path].count(old))
  path.write_text(original[path].replace(old,new))
  subprocess.run(['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(path)],check=True)
  mutated_sha=hashlib.sha256(path.read_bytes()).hexdigest()
  log=out/(name+'.log'); cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','//nativelink-service:unit_test','--test_output=errors','--test_arg='+filter]
  started=time.monotonic()
  with log.open('w') as f:
   try: code=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=90).returncode
   except subprocess.TimeoutExpired: code=124
  testlog=root/'bazel-testlogs/nativelink-service/unit_test/test.log'
  text=testlog.read_text() if testlog.exists() else ''
  shutil.copyfile(testlog,out/(name+'-test.log')) if testlog.exists() else None
  detected=code!=0 and code!=124 and 'test result: FAILED' in text and filter.removesuffix('_') in text and 'Build did NOT complete successfully' not in log.read_text()
  results.append({'name':name,'command':cmd,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'mutated_path':str(path.relative_to(root)),'mutated_sha256':mutated_sha,'detected_compiled_semantic_failure':detected})
  print(name,code,detected,flush=True)
  path.write_text(original[path])
  (out/'mutants.json').write_text(json.dumps(results,indent=2)+'\n')
  if not detected: raise RuntimeError('Mutation not qualified: '+name)
finally:
 for path,text in original.items(): path.write_text(text)
 for path,text in original.items(): assert path.read_text()==text
 (out/'mutants.json').write_text(json.dumps(results,indent=2)+'\n')
