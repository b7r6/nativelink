from pathlib import Path
import subprocess,json,hashlib,shutil,time
root=Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03'); out=Path(__file__).parent
server=root/'nativelink-service/src/authority_server.rs'; original=server.read_text()
(out/'fixed-authority_server.rs').write_text(original)
shutil.copyfile(root/'bazel-testlogs/nativelink-service/unit_test/test.log',out/'fixed-unit-test.log')
old='            } else if attempt.deadline.at <= now {'
mutants=[('execution-equality-via-progress','            } else if attempt.deadline.at.min(attempt.running_deadline.unwrap_or(u64::MAX)) <= now {'),('delay-independent-progress','            } else if attempt.deadline.at < now {')]
results=[]
try:
 for name,new in mutants:
  assert original.count(old)==1
  server.write_text(original.replace(old,new))
  subprocess.run(['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(server)],check=True)
  mutated=server.read_bytes(); (out/(name+'.rs')).write_bytes(mutated)
  cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','//nativelink-service:unit_test','--test_output=errors','--test_arg=quantized_']
  with (out/(name+'.log')).open('w') as f: code=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=90).returncode
  testlog=root/'bazel-testlogs/nativelink-service/unit_test/test.log'; shutil.copyfile(testlog,out/(name+'-test.log')); body=testlog.read_text()
  compiled='Build completed,' in (out/(name+'.log')).read_text() and 'test result: FAILED.' in body
  results.append({'name':name,'command':cmd,'exit_code':code,'compiled':compiled,'detected':compiled and code!=0,'sha256':hashlib.sha256(mutated).hexdigest()})
  (out/'mutants.json').write_text(json.dumps(results,indent=2)+'\n'); print(name,code,compiled,flush=True)
  if not compiled or code==0: raise RuntimeError(name)
  server.write_text(original)
finally:
 server.write_text(original)
 assert server.read_text()==original
