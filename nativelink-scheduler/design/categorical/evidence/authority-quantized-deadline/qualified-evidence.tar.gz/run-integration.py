from pathlib import Path
import subprocess,hashlib,json,shutil
root=Path.cwd(); out=Path(__file__).parent
names=set(json.loads(Path('/tmp/nativelink-categorical-evidence/singleton-capability-integration/sources-before.json').read_text()))
def sources(): return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
before=sources();(out/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','//nativelink-service:unit_test','//nativelink-service:integration_tests/authority_listener_test_test','//nativelink-worker:integration_tests/authority_rpc_test_test','//nativelink-worker:authority_history_rpc_test','//nativelink-worker:authority_receipt_rpc_test','//nativelink-worker:authority_publication_ordering_test','//nativelink-worker:authority_replicated_rpc_test','//:nativelink']
(out/'integration-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'integration.log').open('w') as f: code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=sources();(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n'); assert before==after
for target in cmd:
 if target.startswith('//') and target!='//:nativelink':
  path=target[2:].replace(':','/'); log=root/'bazel-testlogs'/path/'test.log'; dst=out/'integration-testlogs'/path/'test.log';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(log,dst)
print('integration exit',code,'unchanged inputs',len(before));raise SystemExit(code)
