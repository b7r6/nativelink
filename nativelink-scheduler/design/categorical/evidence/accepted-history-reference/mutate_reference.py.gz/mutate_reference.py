import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-accepted-history-reference')
evidence = Path('/tmp/nativelink-accepted-history-reference-evidence')
path = root / 'nativelink-scheduler/tests/accepted_history/reference.rs'
original = path.read_text()
mutations = [
    ('allow-zero-attempt-id', 'binding.attempt != 0', 'binding.attempt != u64::MAX'),
    ('skip-acceptance-authorization', '\n                    || fact.authorized != Some(*original)', ''),
    ('omit-history-id-headroom', 'end.checked_add(self.reserved.len() as u64)', 'end.checked_add(0)'),
    ('accept-wrong-publication-object', 'if row.recipe.object != *object', 'if false && row.recipe.object != *object'),
    ('backfill-preactivation-terminal', 'if fact.phase == Phase::Open {', 'if fact.phase != Phase::OtherTerminal {'),
    ('materialize-failed-publication', '*outcome != PublicationOutcome::Stored', '*outcome == PublicationOutcome::Unknown'),
    ('revoke-already-accepted-history', '|| row.original != *original', '|| fact.authorized != Some(*original)\n                || row.original != *original'),
    ('skip-noncacheable-history', '                let Phase::WorkerTerminal {\n                    original, response, ..\n                } = &fact.phase', '                if matches!(fact.phase, Phase::WorkerTerminal { cacheable: false, .. }) { return Ok(Outcome::Ignored); }\n                let Phase::WorkerTerminal {\n                    original, response, ..\n                } = &fact.phase'),
]
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p', 'nativelink-scheduler', '--test', 'accepted_history_reference_test']
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-publication-ordering-target')
results = []
def run(name):
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    text = result.stdout.decode(errors='replace')
    (evidence / f'{name}.log').write_text(text)
    return result.returncode, text
try:
    code, output = run('mutation-baseline')
    assert code == 0, output
    for name, before, after in mutations:
        assert original.count(before) == 1, (name, original.count(before))
        source = original.replace(before, after, 1)
        path.write_text(source)
        code, output = run('mutation-' + name)
        compiled = 'Running tests/accepted_history_reference_test.rs' in output
        killed = compiled and code != 0 and 'test result: FAILED' in output
        result = {'name': name, 'returncode': code, 'compiled': compiled, 'killed': killed,
                  'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                  'before': before, 'after': after}
        results.append(result)
        print(json.dumps(result), flush=True)
finally:
    path.write_text(original)
    code, output = run('mutation-restored')
    report = {'boundary': 'Mutations are of the independent oracle, not the production candidate; these establish contract-test sensitivity only.',
              'baseline_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
              'command': command, 'results': results, 'restored_returncode': code}
    (evidence / 'mutations.json').write_text(json.dumps(report, indent=2) + '\n')
assert code == 0, output
assert len(results) == len(mutations) and all(item['killed'] for item in results), results
