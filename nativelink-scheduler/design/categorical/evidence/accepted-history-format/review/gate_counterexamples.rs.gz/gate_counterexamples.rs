// Independent review fixture of the exact immutable format preview.
// No history implementation or frozen reference is included.
#![allow(dead_code)]
use nativelink_scheduler::authority::ClusterEpoch;
#[path = "/tmp/nativelink-history-format-review/nativelink-scheduler/src/authority/format.rs"]
mod reviewed_format;

use std::collections::{BTreeMap, BTreeSet};
use openraft::{BasicNode, CommittedLeaderId, LogId, Membership, StoredMembership};
use reviewed_format::{ACCEPTED_HISTORY, RECEIPT_RETIREMENT, ActiveFormat, AdmissionRegistry, AuthorityDomain, FormatControl, ReaderCapabilities};

fn position(index: u64) -> LogId<u64> { LogId::new(CommittedLeaderId::new(1, 1), index) }
fn setup() -> (std::sync::Arc<AdmissionRegistry>, ActiveFormat, StoredMembership<u64, BasicNode>, std::sync::Arc<reviewed_format::MemberLease>) {
    let domain = AuthorityDomain { epoch: ClusterEpoch(7), namespace: 8 };
    let registry = AdmissionRegistry::new(domain);
    let active = ActiveFormat::base(domain);
    let member = registry.register(domain, 1, 1, ReaderCapabilities::AcceptedHistory, &active).unwrap();
    let membership = StoredMembership::new(Some(position(0)), Membership::new(vec![BTreeSet::from([1])], BTreeMap::from([(1, BasicNode::default())])));
    (registry, active, membership, member)
}

#[test]
fn duplicate_abort_enqueue_can_create_unappendable_second_position() {
    let (registry, mut active, membership, _member) = setup();
    let preparation = registry.prepare(&active, &membership, BTreeSet::from([ACCEPTED_HISTORY])).unwrap();
    let abort = FormatControl::Abort { domain: active.domain, permit: preparation.permit };
    registry.enqueue_control(&abort).unwrap();
    // The second helper observes no committed decision yet.
    assert!(registry.decision(preparation.permit).unwrap().is_none());
    let duplicate = registry.enqueue_control(&abort);
    registry.authorize(&abort, position(1)).unwrap();
    active.apply(&abort, &membership, ReaderCapabilities::AcceptedHistory, position(1)).unwrap();
    registry.observe_committed(&active);
    assert!(registry.authorize(&abort, position(2)).is_err());
    assert!(duplicate.is_err(), "duplicate Abort was admitted even though its later log position cannot be appended after the first commits");
}

#[test]
fn new_prepare_must_reject_stale_applied_epoch_after_commit() {
    let (registry, mut committed, membership, _member) = setup();
    let first = registry.prepare(&committed, &membership, BTreeSet::from([ACCEPTED_HISTORY])).unwrap();
    committed.apply(&FormatControl::Prepare(first.clone()), &membership, ReaderCapabilities::AcceptedHistory, position(1)).unwrap();
    let old_applied = committed.clone();
    committed.apply(&FormatControl::Activate(first), &membership, ReaderCapabilities::AcceptedHistory, position(2)).unwrap();
    registry.observe_committed(&committed);
    // A prepare helper completed its earlier read barrier, then resumed in
    // SaveCommitted-to-Apply gap. The old snapshot still has feature_epoch 0.
    let second = registry.prepare(&old_applied, &membership, BTreeSet::from([ACCEPTED_HISTORY, RECEIPT_RETIREMENT]));
    if let Ok(second) = &second {
        assert!(committed.apply(&FormatControl::Prepare(second.clone()), &membership, ReaderCapabilities::AcceptedHistory, position(3)).is_err());
    }
    assert!(second.is_err(), "registry minted a stale epoch permit after its committed feature set advanced");
}
