import pathlib,subprocess,os,json,hashlib,difflib,time
root=pathlib.Path('/tmp/nativelink-publication-candidate')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/publication-candidate')
path=root/'nativelink-scheduler/tests/publication_candidate/engine.rs'
frozen=evidence/'final-source/nativelink-scheduler/tests/publication_candidate/engine.rs'
source=frozen.read_text()
mutants=[
 ('skip_real_complete','next.scheduler_apply(a::Event::Complete { attempt, worker, incarnation, result: stage.candidate.response.clone() })?;','let _ = (attempt, worker, incarnation);'),
 ('wrong_operation_root_kind','let root = self.acquire(r::RootKind::Operation, &candidate.closure, until)?;','let root = self.acquire(r::RootKind::Publication, &candidate.closure, until)?;'),
 ('retain_old_head_root','next.retain(r::Event::Release { root: r::RootId(next.metadata.accepted[&old].root), lease: 1 })?;','let _ = old;'),
 ('ignore_do_not_cache','let eligible = !request.do_not_cache && stage.candidate.response.exit_code == 0 && stage.candidate.response.error.is_none();','let eligible = stage.candidate.response.exit_code == 0 && stage.candidate.response.error.is_none();'),
 ('truncate_incarnation_mapping','.find(|row| row.namespace == key.namespace && row.incarnation == key.incarnation)','.find(|row| row.namespace == key.namespace)'),
 ('read_accepts_wrong_object','.is_ok_and(|candidate| candidate.closure.contains(member))','.is_ok_and(|candidate| candidate.closure.iter().any(|row| row.key == member.key))'),
 ('ignore_catalogue_revision','            || evidence.catalogue_revision != self.metadata.revision\n',''),
 ('ignore_read_barrier','if barrier != next.metadata.commit - 1\n                || next.metadata.heads.get(action) != Some(&expected)','if next.metadata.heads.get(action) != Some(&expected)'),
 ('cache_hit_loses_wire_bit','result: Some(result), cached_result: true, ..ExecuteResponse::default()','result: Some(result), cached_result: false, ..ExecuteResponse::default()'),
 ('no_outer_rollback','''        let mut next = self.clone();
        next.metadata.commit = next.metadata.commit.checked_add(1).ok_or(Error::Bounds)?;
        let reply = apply(&mut next)?;
        next.validate()?;
        *self = next;
        Ok(reply)''','''        self.metadata.commit = self.metadata.commit.checked_add(1).ok_or(Error::Bounds)?;
        let reply = apply(self)?;
        self.validate()?;
        Ok(reply)'''),
]
mutants=[row for row in mutants if row[0] in ('ignore_catalogue_revision','ignore_read_barrier')]
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-history-candidate-target',CARGO_BUILD_JOBS='8')
command=['cargo','test','--locked','--offline','--profile=smol','-p','nativelink-scheduler','--test','publication_candidate_test']
results=[]
try:
 for name,old,new in mutants:
  assert source.count(old)==1,(name,source.count(old))
  changed=source.replace(old,new)
  directory=evidence/'mutants-strengthened'/name
  directory.mkdir(parents=True,exist_ok=True)
  (directory/'engine.rs').write_text(changed)
  (directory/'mutation.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen/engine.rs',tofile='mutant/engine.rs')))
  path.write_text(changed)
  started=time.time()
  with (directory/'test.log').open('wb') as log:
   result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(directory/'test.log').read_text()
  compiled='Running tests/publication_candidate_test.rs' in output
  row={'name':name,'exit':result.returncode,'compiled':compiled,'outcome':'SURVIVED' if result.returncode==0 else ('KILLED' if compiled else 'BUILD_FAILED'),'seconds':round(time.time()-started,3),'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'log_sha256':hashlib.sha256((directory/'test.log').read_bytes()).hexdigest()}
  results.append(row)
  (evidence/'mutation-strengthened-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(row),flush=True)
  path.write_text(source)
finally:
 path.write_text(source)
