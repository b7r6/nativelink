import pathlib,subprocess,os,json,hashlib,difflib,time
root=pathlib.Path('/tmp/nativelink-publication-candidate')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/publication-candidate')
relative='nativelink-scheduler/tests/publication_candidate/validation.rs'
path=root/relative
source=(evidence/'final-source'/relative).read_text()
mutants=[
 ('ignore_preparation_fence_relations',"""                    || preparation.fences.keys().ne(current_fences.keys())
                    || preparation.fences.iter().any(|(cohort, fence)| {
                        current_fences
                            .get(cohort)
                            .is_none_or(|current| fence > current)
                    })
""",''),
 ('allow_predecessor_provenance',"""                        || scheduler
                            .attempts
                            .iter()
                            .any(|later| later.execution == execution && later.id > attempt)
""",''),
]
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/nativelink-history-candidate-target',CARGO_BUILD_JOBS='8')
command=['cargo','test','--locked','--offline','--profile=smol','-p','nativelink-scheduler','--test','publication_candidate_test']
results=[]
try:
 for name,old,new in mutants:
  assert source.count(old)==1,(name,source.count(old))
  changed=source.replace(old,new)
  directory=evidence/'mutants-postfreeze'/name
  directory.mkdir(parents=True,exist_ok=True)
  (directory/'validation.rs').write_text(changed)
  (directory/'mutation.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='final/validation.rs',tofile='mutant/validation.rs')))
  path.write_text(changed)
  started=time.time()
  with (directory/'test.log').open('wb') as log:
   result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(directory/'test.log').read_text()
  compiled='Running tests/publication_candidate_test.rs' in output
  row={'name':name,'exit':result.returncode,'compiled':compiled,'outcome':'SURVIVED' if result.returncode==0 else ('KILLED' if compiled else 'BUILD_FAILED'),'seconds':round(time.time()-started,3),'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'log_sha256':hashlib.sha256((directory/'test.log').read_bytes()).hexdigest()}
  results.append(row)
  (evidence/'mutation-postfreeze-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(row),flush=True)
  path.write_text(source)
finally:
 path.write_text(source)
