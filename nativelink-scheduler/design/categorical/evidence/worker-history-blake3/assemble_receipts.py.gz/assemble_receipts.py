from pathlib import Path
import gzip, hashlib, json, subprocess

root=Path('/tmp/nativelink-worker-history-blake3')
e=Path('/tmp/nativelink-categorical-evidence/worker-history-blake3')
sha=lambda data:hashlib.sha256(data).hexdigest()
passing=['four-histories-serial','four-histories-parallel','default-and-feature2-regressions','authority-worker-regressions','strict-clippy','rustfmt-check','buildifier-check','typos-check','vale-check','git-diff-check']
receipts={name:json.loads((e/(name+'.json')).read_text()) for name in passing}
assert all(r['exit_code']==0 for r in receipts.values())
for r in receipts.values():
 for f,h in r.get('source_sha256',{}).items():assert sha((root/f).read_bytes())==h,(f,h)
for name in ['four-histories-serial','four-histories-parallel']:
 log=(e/(name+'.log')).read_text()
 markers=[line for line in log.splitlines() if line.startswith('AUTHORITY_REAL_PROCESS_HISTORY:')]
 assert len(markers)==4 and 'SKIP' not in log
 assert sum('algorithm=BLAKE3;' in line for line in markers)==2
 assert sum('algorithm=SHA256;' in line for line in markers)==2
 assert '4 passed; 0 failed; 0 ignored' in log
for name in ['default-and-feature2-regressions','authority-worker-regressions']:
 assert 'SKIP' not in (e/(name+'.log')).read_text()
regression=(e/'authority-worker-regressions.log').read_text()
assert '4 passed; 0 failed; 0 ignored' in regression
assert '18 passed; 0 failed; 0 ignored' in regression
before=json.loads((e/'worker-context-gap.json').read_text())
assert before['exit_code']==101
for f,h in before['source_sha256'].items():assert sha((e/'worker-context-gap-source'/f).read_bytes())==h
failure=(e/'worker-context-gap.log').read_text()
assert 'Command complete exit_code=0' in failure
assert 'Real process failed before candidate creation' in failure
assert 'Hash verification using SHA256 failed' in failure
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert base=='db0d34de596dd552d71807cabc423c5f4d5b1e8a'
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
(e/'worker-history-blake3.patch').write_bytes(patch)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert len(changed)==5
for name in changed:
 p=e/'fixed-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
qualification={
 'base_commit':base,'patch_sha256':sha(patch),'changed_source_sha256':{f:sha((root/f).read_bytes()) for f in changed},
 'finding':'With valid BLAKE3 Action, Command and input root through VerifyStore, a real namespace process completed with exit zero but AuthorityWorker result upload inherited SHA256 and failed digest verification before candidate creation.',
 'fix':'AuthorityWorker::run_action scopes its entire lifecycle future to the dispatch digest algorithm with opentelemetry FutureExt. Omitted algorithm zero selects SHA256 explicitly; no process-global default mutation. Child tasks inherit the current context. Test input uploads have their own explicit context.',
 'coverage':{'real_namespace_histories':{'algorithms':['SHA256','BLAKE3'],'outcomes':[{'do_not_cache':True,'exit_code':0},{'do_not_cache':False,'exit_code':7}],'serial_passes':4,'concurrent_passes':4,'skips':0,'checks':['request digest_function','independently hashed Action, Command and input root in verified CAS','independently hashed output file, stdout and stderr in verified CAS','worker executes once while coordinator is offline','retained candidate accepted through RPC reconnect','exact captured ExecuteResponse bytes in independent history wire recipe','history namespace, algorithm, digest and length','Pending survives another durable restart','Materialized exact bytes without terminal change','legacy AC/history Everything policies remain bypassed']},'parent_helper_default_and_feature2':2,'authority_scheduler':4,'authority_worker':18,'strict_clippy':True,'pinned_rustfmt':True,'buildifier':True,'typos':True,'vale':True,'git_diff_check':True},
 'failed_runs':[{'name':'input-context-gap','meaning':'Fixture prerequisite failure during direct Command upload, before execution. Input helper now carries explicit per-future digest context.','source_note':'Snapshot was captured before launch. An expected-algorithm lowercase assertion was corrected while that compilation was running, so this fixture-only failed run is not used as an exact compiled-source attestation.'},{'name':'worker-context-gap','meaning':'Actual namespace process with valid inputs; unchanged AuthorityWorker fails output upload under inherited SHA256. Exact pre-run source hashes and snapshot retained.'}],
 'limits':['Experimental authority qualification wiring only; no production constructor or operator activation.','Both algorithms run concurrently in separate fixture workers in one test process; this is not a general concurrency or load proof.','Omitted algorithm zero remains explicitly SHA256 by the source branch; the four history cases send explicit algorithms and do not alter the process global default.','Focused Cargo verification only in this worktree; warm-root Bazel integration is delegated to the parent.','No publication reference or candidate implementation source was inspected for this task.'],
 'bazel_targets_for_parent':['//nativelink-worker:authority_history_rpc_test','//nativelink-worker:authority_receipt_rpc_test','//nativelink-worker:integration_tests/authority_rpc_test_test','//nativelink-worker:integration_tests/authority_worker_test_test','//nativelink-worker:integration_tests/authority_scheduler_test_test'],
 'runs':receipts,
}
(e/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
bundle=e/'receipt-bundle';bundle.mkdir(exist_ok=False)
files={}
for p in sorted(e.rglob('*')):
 if not p.is_file() or bundle in p.parents:continue
 rel=p.relative_to(e)
 if p.name.endswith('.log') or '-source' in str(rel):
  dest=bundle/(str(rel)+'.gz');data=gzip.compress(p.read_bytes(),mtime=0)
 else:
  dest=bundle/rel;data=p.read_bytes()
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 files[str(dest.relative_to(bundle))]={'sha256':sha(data),'bytes':len(data),'raw_sha256':sha(p.read_bytes()),'raw_bytes':p.stat().st_size}
manifest={'base_commit':base,'qualification_sha256':sha((e/'qualification.json').read_bytes()),'patch_sha256':sha(patch),'artifacts':files}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,meta in files.items():assert sha((bundle/name).read_bytes())==meta['sha256']
print(json.dumps({'patch_sha256':sha(patch),'qualification_sha256':manifest['qualification_sha256'],'manifest_sha256':sha((bundle/'manifest.json').read_bytes()),'bundle_bytes':sum(p.stat().st_size for p in bundle.rglob('*') if p.is_file()),'artifacts':len(files)},indent=2))
