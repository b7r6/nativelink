from pathlib import Path
import subprocess, os, json, hashlib, difflib
root=Path('/tmp/nativelink-terminal-outcome-robustness')
evidence=Path('/tmp/nativelink-terminal-outcome-robustness-evidence')
source=root/'nativelink-scheduler/tests/terminal_outcome/reference.rs'
baseline=source.read_text()
(evidence/'baseline').mkdir(exist_ok=True)
(evidence/'baseline/reference.rs').write_text(baseline)
test=root/'nativelink-scheduler/tests/terminal_outcome/cases.rs'
test_hash=hashlib.sha256(test.read_bytes()).hexdigest()
audit=root/'nativelink-scheduler/tests/terminal_outcome/restore_audit.rs'
audit_hash=hashlib.sha256(audit.read_bytes()).hexdigest()

def replace(old,new):
    assert baseline.count(old)==1, (old[:100],baseline.count(old))
    return baseline.replace(old,new,1)

mutants=[]
def add(name, code, case): mutants.append((name,code,'cases::'+case))
add('01-classification-coerced-complete', replace('''            Classification::MemoryFailure {
                original_charged,
                peak_memory_bytes,
                quiescent,
            } => a::Event::MemoryFailure {
                attempt: identity.attempt,
                worker: identity.worker,
                incarnation: identity.incarnation,
                charged: original_charged,
                peak_memory_bytes,
                quiescent,
                result: report.payload.clone(),
            },''','''            Classification::MemoryFailure { .. } => a::Event::Complete {
                attempt: identity.attempt,
                worker: identity.worker,
                incarnation: identity.incarnation,
                result: report.payload.clone(),
            },'''), 'memory_classification_preserves_all_three_actual_final_reasons')
add('02-forced-final-through-invented-ceiling',replace('''        let execution = trial.execution;
        let identity = report.identity;''','''        let execution = trial.execution;
        let identity = report.identity;
        if let Classification::MemoryFailure { original_charged, .. } = report.classification {
            let node = before.workers.iter().find(|node| node.id == identity.worker).unwrap();
            let capacity = a::Resources { memory_bytes: original_charged.memory_bytes, ..node.capacity };
            self.schedule(a::Event::Capacity { worker: node.id, incarnation: node.incarnation,
                session: node.session, capacity, available: capacity, draining: false })?;
        }'''),'retry_growth_is_decided_by_m1_and_preserves_original_requests_and_stages')
add('03-missing-no-graph-gate',replace('''        if response.result.is_some() {
            return Err(Refusal::GraphBearing);
        }''','''        // Mutant: silently allow an ActionResult without protection.'''),'graph_bearing_complete_and_memory_reports_are_refused_without_empty_graph_fallback')
add('04-overwrite-cancelled-operation-link',replace('''            self.operations.insert(operation.id, link);''','''            let link = self.accepted.get(&operation.execution).map_or(link, |accepted| OperationLink::NoGraph(accepted.report));
            self.operations.insert(operation.id, link);'''),'each_joined_handle_keeps_its_terminal_in_both_cancel_report_orders')
add('05-refund-on-cancel-without-quiescence',replace('''        if let a::Event::AdvanceTime { now } = event {
            self.retain(r::Event::AdvanceTime { now: *now })?;
        }''','''        if matches!(event, a::Event::Cancel { .. } | a::Event::ExpireInterest { .. }) {
            for trial in self.scheduler.view().attempts.into_iter().filter(|trial| !trial.authorized) {
                self.schedule(a::Event::Cleanup { attempt: trial.id, worker: trial.worker, incarnation: trial.incarnation })?;
            }
        }
        if let a::Event::AdvanceTime { now } = event {
            self.retain(r::Event::AdvanceTime { now: *now })?;
        }'''),'last_cancel_closes_logical_credit_but_retains_physical_charge_until_cleanup')
add('06-forget-old-write-intents-on-report',replace('''        let after = self.scheduler.view();''','''        let mut storage = serde_json::to_value(&self.storage).unwrap();
        storage["writes"] = serde_json::json!([]);
        self.storage = serde_json::from_value(storage).unwrap();
        let after = self.scheduler.view();'''),'unknown_stage_writes_survive_cancel_retry_final_and_expiry_then_late_success')
add('07-ignore-interest-generation-fence',replace('''        let reply = self.schedule(event.clone())?;''','''        let event = match event {
            a::Event::ExpireInterest { operation, .. } => a::Event::ExpireInterest {
                operation: *operation,
                generation: self.scheduler.view().operations.iter().find(|row| row.id == *operation).unwrap().interest_deadline.generation,
            },
            other => other.clone(),
        };
        let reply = self.schedule(event.clone())?;
        let event = &event;'''),'interest_expiry_requires_current_generation_and_advance_only_moves_clocks')
add('08-reauthorize-recorded-origin',replace('''                || origin.now > view.scheduler.now''','''                || origin.now > view.scheduler.now
                || !view.scheduler.workers.iter().any(|worker| worker.id == origin.identity.worker && worker.incarnation == origin.identity.incarnation)'''),'recorded_origin_survives_later_worker_replacement_and_duplicate_report_is_stable')
add('09-omit-original-operation-binding',replace('''            if self.actions.get(&operation.execution) != Some(&self.binding(original)?) {
                return Err(Refusal::Unauthorized);
            }''','''            let _ = original; // Mutant: use representative binding only.'''),'per_operation_principal_binding_is_checked_on_admission_and_snapshot_restore')
add('10-omit-outer-byte-admission',replace('''        next.snapshot()?;''','''        // Mutant: byte limit checked only when later asking for a snapshot.'''),'complete_outer_snapshot_byte_gate_refuses_a_valid_terminal_atomically')
old='''            || self.stages.len()
                + self
                    .credits
                    .values()
                    .filter(|credit| credit.pending_stage)
                    .count()
                > MAX_STAGES
            || self.physical.len()
                + self
                    .credits
                    .values()
                    .map(|credit| credit.unused_members)
                    .sum::<usize>()
                > MAX_GENERATIONS'''
add('11-borrow-other-executions-credits',replace(old,'''            || self.stages.len() > MAX_STAGES
            || self.physical.len() > MAX_GENERATIONS'''),'finite_stage_and_execution_credits_refuse_without_dispatch_or_borrowing')
add('12-ignore-conflicting-report-reuse',replace('''            return if previous.report == *report {''','''            return if previous.report.id == report.id {'''),'recorded_origin_survives_later_worker_replacement_and_duplicate_report_is_stable')

add('13-omit-local-history-checks', replace('        self.check_report_history(&view)?;', '        // Mutant omits retained evidence consistency checks.'), 'audit::grown_target_cannot_survive_removal_of_its_retry_record')
add('14-permit-evidenceless-zero-grant-retry', replace('if ordinal >= MAX_REPORTS || base == 0 {', 'if ordinal >= MAX_REPORTS {').replace('|| successor.memory_bytes > base.saturating_mul(2)', '|| (base != 0 && successor.memory_bytes > base.saturating_mul(2))'), 'audit::retry_with_zero_original_grant_cannot_lose_its_only_growth_evidence')
add('15-early-budget-exhaustion', replace('ordinal == MAX_REPORTS', 'ordinal <= MAX_REPORTS'), 'audit::coherent_attempt_budget_reason_still_requires_three_actual_attempts')
add('16-invent-missing-evidence-reason', replace('ordinal < MAX_REPORTS && base == 0', 'ordinal < MAX_REPORTS'), 'audit::missing_growth_final_cannot_acquire_positive_peak_evidence')
add('17-omit-immutable-grant-chain', replace('if reservation.charged != target {', 'if false {').replace('if target != execution.reservation_target {', 'if false {'), 'audit::successor_reservation_cannot_survive_removal_of_its_retry_record')
add('18-omit-growth-upper-bound', replace('                            || successor.memory_bytes > base.saturating_mul(2)', ''), 'audit::retained_growth_cannot_exceed_the_original_evidence_bound')
add('19-omit-per-attempt-report-order', replace('                    || preceding_report.is_some_and(|previous| {\n                        previous.position >= record.position || previous.now > record.now\n                    })', ''), 'audit::retry_positions_must_follow_actual_attempt_order_even_at_one_clock_tick')
a=baseline.index('        if reports.iter().any(|record| {')
b=baseline.index('        for execution in &view.scheduler.executions {',a)
add('20-omit-global-position-clock-check', baseline[:a]+baseline[b:], 'audit::report_order_rejects_zero_future_and_reversed_clock_witnesses')
add('21-disconnect-terminal-clock', replace('                        || execution.terminal_at != Some(record.now))', ')'), 'audit::coherent_terminal_time_witness_cannot_rewrite_retained_scheduler_time')
add('22-reauthorize-historical-worker-ceiling', replace('                            a::ResourceFailureReason::NoLargerEligibleWorker => {\n                                ordinal < MAX_REPORTS && base > 0\n                            }', '                            a::ResourceFailureReason::NoLargerEligibleWorker => {\n                                ordinal < MAX_REPORTS && base > 0 && !view.scheduler.workers.iter().any(|worker| worker.capacity.memory_bytes > original_charged.memory_bytes)\n                            }'), 'audit::historical_no_larger_reason_survives_later_capacity_growth')

results=[]
env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/nativelink-history-differential-target'
try:
    for name,code,case in mutants:
        directory=evidence/'mutants'/name;directory.mkdir(parents=True,exist_ok=True)
        source.write_text(code)
        (directory/'reference.rs').write_text(code)
        (directory/'mutation.diff').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),code.splitlines(True),fromfile='baseline/reference.rs',tofile=name+'/reference.rs')))
        cmd=['cargo','test','--locked','--profile','smol','-j','8','-p','nativelink-scheduler','--test','terminal_outcome_restore_audit_test',case,'--','--exact']
        run=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (directory/'cargo.log').write_text(run.stdout)
        compiled='Running tests/terminal_outcome_restore_audit_test.rs' in run.stdout
        killed=compiled and run.returncode!=0 and 'test result: FAILED' in run.stdout and '1 failed' in run.stdout
        result=dict(name=name,case=case,compiled=compiled,killed=killed,exit=run.returncode,source_sha256=hashlib.sha256(code.encode()).hexdigest(),test_sha256=test_hash,audit_sha256=audit_hash)
        results.append(result)
        (directory/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)
        assert hashlib.sha256(test.read_bytes()).hexdigest()==test_hash
        assert hashlib.sha256(audit.read_bytes()).hexdigest()==audit_hash
finally:
    source.write_text(baseline)
    (evidence/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print('baseline restored '+hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
