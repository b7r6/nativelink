from pathlib import Path
import subprocess,hashlib,json,shutil
root=Path.cwd();out=Path(__file__).parent
assert (root/'nativelink-scheduler/src/authority/journal.rs').read_bytes()==(out/'fixed-source/nativelink-scheduler/src/authority/journal.rs').read_bytes()
names=set(json.loads(Path('/tmp/nativelink-categorical-evidence/authority-memory-wire-integration/sources-before.json').read_text()))
names.add('nativelink-scheduler/src/authority/singleton_recovery_tests.rs')
def sources():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
before=sources();(out/'restored-sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['bazel','test','--jobs=8','--local_test_jobs=3','--test_env=RUST_TEST_THREADS=4','--test_output=errors','//nativelink-scheduler:unit_test','//tools/canonical-filesystem:journal_bridge_test','//nativelink-scheduler:integration_tests/authority_raft_test_test','//nativelink-scheduler:integration_tests/authority_format_test_test','//nativelink-scheduler:integration_tests/authority_cluster_test_test','//nativelink-scheduler:integration_tests/authority_volatile_test_test','//nativelink-service:unit_test','//nativelink-worker:integration_tests/authority_rpc_test_test','//tools/canonical-store:canonical_store_test','//nativelink-worker:authority_history_rpc_test','//nativelink-worker:authority_replicated_rpc_test','//:nativelink'];(out/'restored-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'restored.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=sources();(out/'restored-sources-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
for label in cmd:
 if label.startswith('//') and label!='//:nativelink':
  path=label[2:].replace(':','/');dest=out/'restored-testlogs'/path/'test.log';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'bazel-testlogs'/path/'test.log',dest)
print('restored exit',code,'unchanged inputs',len(before));raise SystemExit(code)
