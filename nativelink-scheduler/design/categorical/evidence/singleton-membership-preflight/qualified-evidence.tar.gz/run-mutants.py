from pathlib import Path
import subprocess,json,hashlib,shutil
root=Path.cwd();out=Path(__file__).parent;path=root/'nativelink-scheduler/src/authority/journal.rs';original=path.read_text();results=[]
mutations=[
 ('ignore-uncommitted-membership','                        if let Some(membership) = &mut singleton_membership\n                            && let EntryPayload::Membership(value) = &entry.payload\n                        {\n                            if recovered_frontier.is_none_or(|position| entry.log_id.index > position.index) {\n                                return Err(failure(\n                                    ErrorVerb::Read,\n                                    "singleton recovery has pending membership beyond committed frontier",\n                                ));\n                            }\n                            if applied.last_applied.is_none_or(|position| entry.log_id.index > position.index) {\n                                *membership = StoredMembership::new(Some(entry.log_id), value.clone());\n                            }\n                        }\n','                        if let Some(membership) = &mut singleton_membership\n                            && let EntryPayload::Membership(value) = &entry.payload\n                            && recovered_frontier.is_some_and(|position| entry.log_id.index <= position.index)\n                            && applied.last_applied.is_none_or(|position| entry.log_id.index > position.index)\n                        {\n                            *membership = StoredMembership::new(Some(entry.log_id), value.clone());\n                        }\n','singleton_refuses_pending_membership_even_when_it_still_names_only_self'),
 ('project-by-logid-not-index','if applied.last_applied.is_none_or(|position| entry.log_id.index > position.index) {','if applied.last_applied.is_none_or(|position| entry.log_id > position) {','singleton_committed_projection_uses_raft_index_interval'),
 ('allow-retained-learners','        || !membership.nodes().map(|(id, _)| *id).eq([node_id])\n','','singleton_refuses_foreign_joint_learner_and_unsupported_applied_membership'),
 ('ignore-membership-index','member_position > frontier || member_position.index > frontier.index','member_position > frontier','singleton_rejects_membership_position_beyond_recovered_index'),
 ('reject-historical-snapshot','position.index >= member_position.index','position.index <= frontier.index','singleton_recovers_committed_three_to_one_with_historical_snapshot'),
]
try:
 for name,old,new,test in mutations:
  assert original.count(old)==1,(name,original.count(old));changed=original.replace(old,new);path.write_text(changed);subprocess.run(['/nix/store/8vn3l8abbbqakb5jv9g2845p9g0wbqav-rustfmt-preview-1.100.0-nightly-2026-08-26-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true',str(path)],check=True);changed=path.read_text();(out/(name+'.rs')).write_text(changed)
  cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','--test_arg='+test,'//nativelink-scheduler:unit_test']
  with (out/(name+'.log')).open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
  log=root/'bazel-testlogs/nativelink-scheduler/unit_test/test.log';b=log.read_bytes() if log.exists() else b'';shutil.copyfile(log,out/(name+'-test.log'))
  compiled=b'running 1 test' in b and ('Compiling Rust bin' in (out/(name+'.log')).read_text());detected=compiled and b'test result: FAILED. 0 passed; 1 failed;' in b and code==3
  results.append({'name':name,'command':cmd,'exit_code':code,'compiled':compiled,'detected':detected,'sha256':hashlib.sha256(changed.encode()).hexdigest()});(out/'mutants.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,compiled,detected,flush=True)
  if not detected:raise RuntimeError('selected mutation not detected: '+name)
finally:
 path.write_text(original)
 assert path.read_text()==original
