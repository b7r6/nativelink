from pathlib import Path
import subprocess,json,shutil
out=Path(__file__).parent;root=Path.cwd();results=[]
for name,label,arg in [('unit','//nativelink-scheduler:unit_test','recovery_tests::'),('bridge','//tools/canonical-filesystem:journal_bridge_test','singleton_existing_uninitialized_membership_is_not_adopted')]:
 cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','--test_arg='+arg,label]
 with (out/('baseline-'+name+'.log')).open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 src=root/'bazel-testlogs'/label[2:].replace(':','/')/'test.log'
 if src.exists():shutil.copyfile(src,out/('baseline-'+name+'-test.log'))
 results.append({'name':name,'command':cmd,'exit_code':code});(out/'baseline-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True)
