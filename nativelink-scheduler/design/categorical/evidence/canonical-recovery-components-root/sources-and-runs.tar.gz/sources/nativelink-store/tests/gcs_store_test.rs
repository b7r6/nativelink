// Copyright 2024 The NativeLink Authors. All rights reserved.
//
// Licensed under the Functional Source License, Version 1.1, Apache 2.0 Future License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    See LICENSE file for details
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use core::sync::atomic::Ordering;
use core::time::Duration;
use std::sync::Arc;

use bytes::{BufMut, Bytes, BytesMut};
use mock_instant::thread_local::MockClock;
use nativelink_config::stores::{CommonObjectSpec, ErrorCode, ExperimentalGcsSpec, Retry};
use nativelink_error::{Code, Error, make_err};
use nativelink_macro::nativelink_test;
use nativelink_store::cas_utils::ZERO_BYTE_DIGESTS;
use nativelink_store::gcs_client::client::GcsOperations;
use nativelink_store::gcs_client::mocks::{FailureMode, MockGcsOperations, MockRequest};
use nativelink_store::gcs_client::types::{DEFAULT_CONTENT_TYPE, ObjectPath};
use nativelink_store::gcs_store::GcsStore;
use nativelink_util::buf_channel::make_buf_channel_pair;
use nativelink_util::common::DigestInfo;
use nativelink_util::health_utils::{HealthStatus, HealthStatusIndicator};
use nativelink_util::instant_wrapper::MockInstantWrapped;
use nativelink_util::store_trait::{StoreKey, StoreLike, UploadSizeInfo};
use pretty_assertions::assert_eq;
use sha2::{Digest, Sha256};

const BUCKET_NAME: &str = "test-bucket";
const KEY_PREFIX: &str = "test-prefix/";
const VALID_HASH1: &str = "0123456789abcdef000000000000000000010000000000000123456789abcdef";

fn to_store_key(digest: DigestInfo) -> StoreKey<'static> {
    digest.into()
}

#[nativelink_test]
async fn simple_has_object_found() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Add a test object to the mock
    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    mock_ops.add_object(&object_path, vec![1, 2, 3, 4, 5]).await;

    // Test has method
    let result = store.has(store_key).await?;

    assert_eq!(result, Some(5), "Expected to find object with size 5");

    // Verify the correct method was called
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.metadata_calls.load(Ordering::Relaxed),
        1,
        "read_object_metadata should have been called once"
    );

    Ok(())
}

#[nativelink_test]
async fn simple_has_object_not_found() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Test has method with a digest that doesn't exist
    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let result = store.has(store_key).await?;

    assert_eq!(result, None, "Expected not to find the object");

    // Verify the correct method was called
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.metadata_calls.load(Ordering::Relaxed),
        1,
        "read_object_metadata should have been called once"
    );

    Ok(())
}

#[nativelink_test]
async fn simple_has_object_error() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    // Mark it to fail
    mock_ops.set_should_fail(true);
    let store = create_test_store(mock_ops.clone()).await?;

    // Test has method with a digest that doesn't exist
    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let result = store.has(store_key).await;

    assert_eq!(
        result,
        Err(Error::new_with_messages(
            Code::Internal,
            [
                "Simulated generic failure",
                "Error while trying to read - bucket: test-bucket path: test-prefix/0123456789abcdef000000000000000000010000000000000123456789abcdef-100",
                "On attempt 1"
            ]
                .iter()
                .map(ToString::to_string)
                .collect()
        )),
        "Expected to get an error"
    );
    Ok(())
}

#[nativelink_test]
async fn has_handles_not_found_error() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());

    // Set the mock to return a simulated NotFound error
    mock_ops.set_should_fail(true);
    mock_ops.set_failure_mode(FailureMode::NotFound).await;

    let store = create_test_store(mock_ops.clone()).await?;

    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);

    // Test that a NotFound error from the client is caught and translated into Ok(None)
    // without indefinitely retrying.
    let result = store.has(store_key).await?;

    assert_eq!(
        result, None,
        "Expected NotFound error to be handled and return None"
    );

    Ok(())
}

#[nativelink_test]
async fn get_part_handles_not_found_error() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());

    // Set the mock to return a simulated NotFound error
    mock_ops.set_should_fail(true);
    mock_ops.set_failure_mode(FailureMode::NotFound).await;

    let store = create_test_store(mock_ops.clone()).await?;

    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, _rx) = make_buf_channel_pair();

    let store_clone = store.clone();
    let get_part_fut = nativelink_util::spawn!("get_part_task", async move {
        store_clone.get_part(store_key, &mut tx, 0, None).await
    });

    let err = get_part_fut.await?.unwrap_err();
    assert_eq!(
        err.code,
        Code::NotFound,
        "Expected NotFound error to be propagated immediately"
    );

    Ok(())
}

#[nativelink_test]
async fn get_part_not_found_not_retried_by_default() -> Result<(), Error> {
    // Create mock GCS operations without adding any object, so reads
    // yield NotFound.
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store_with_retry(
        mock_ops.clone(),
        Retry {
            max_retries: 2,
            delay: 0.001,
            jitter: 0.0,
            ..Default::default()
        },
    )
    .await?;

    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, _rx) = make_buf_channel_pair();

    let store_clone = store.clone();
    let get_part_fut = nativelink_util::spawn!("get_part_task", async move {
        store_clone.get_part(store_key, &mut tx, 0, None).await
    });

    let err = get_part_fut.await?.unwrap_err();
    assert_eq!(err.code, Code::NotFound, "Expected NotFound error");

    // Even with a retry budget configured, NotFound must not consume it
    // unless explicitly opted in via `retry_on_errors`.
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.read_calls.load(Ordering::Relaxed),
        1,
        "read_object_content should not be retried on NotFound by default"
    );

    Ok(())
}

#[nativelink_test]
async fn get_part_retries_not_found_when_opted_in() -> Result<(), Error> {
    // Create mock GCS operations without adding any object, so reads
    // yield NotFound.
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store_with_retry(
        mock_ops.clone(),
        Retry {
            max_retries: 2,
            delay: 0.001,
            jitter: 0.0,
            retry_on_errors: Some(vec![ErrorCode::NotFound]),
        },
    )
    .await?;

    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, _rx) = make_buf_channel_pair();

    let store_clone = store.clone();
    let get_part_fut = nativelink_util::spawn!("get_part_task", async move {
        store_clone.get_part(store_key, &mut tx, 0, None).await
    });

    let err = get_part_fut.await?.unwrap_err();
    assert_eq!(
        err.code,
        Code::NotFound,
        "Expected NotFound error after retries are exhausted"
    );

    // With NotFound in `retry_on_errors`, the read should be attempted
    // once plus `max_retries` more times before giving up.
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.read_calls.load(Ordering::Relaxed),
        3,
        "read_object_content should be retried on NotFound when opted in"
    );

    Ok(())
}

#[nativelink_test]
async fn has_with_results_test() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Add a test object to the mock
    let digest1 = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key1: StoreKey = to_store_key(digest1);
    let object_path1 = create_object_path(&store_key1);
    mock_ops
        .add_object(&object_path1, vec![1, 2, 3, 4, 5])
        .await;

    // Create another digest that won't exist in the store
    let digest2 = DigestInfo::try_new(
        "baaa6789abcdef000000000000000000010000000000000123456789abcdef00",
        200,
    )?;
    let store_key2: StoreKey = to_store_key(digest2);

    // Create a zero digest for testing special handling
    let zero_digest = DigestInfo::new(Sha256::new().finalize().into(), 0);
    let zero_key: StoreKey = to_store_key(zero_digest);

    // Test has_with_results method
    let keys = vec![store_key1, store_key2, zero_key];
    let mut results = vec![None, None, None];

    store.has_with_results(&keys, &mut results).await?;

    assert_eq!(
        results,
        vec![Some(5), None, Some(0)],
        "Expected results to match [Some(5), None, Some(0)]"
    );

    // Verify correct methods were called
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.metadata_calls.load(Ordering::Relaxed),
        2,
        "read_object_metadata should have been called twice"
    );

    Ok(())
}

#[nativelink_test]
async fn simple_update() -> Result<(), Error> {
    const DATA_SIZE: usize = 50;

    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Create test data
    let mut send_data = BytesMut::new();
    for i in 0..DATA_SIZE {
        send_data.put_u8(u8::try_from((i % 93) + 33).expect("printable ASCII range"));
    }
    let send_data = send_data.freeze();

    let digest = DigestInfo::try_new(VALID_HASH1, DATA_SIZE as u64)?;
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, rx) = make_buf_channel_pair();

    // Start update operation
    let store_clone = store.clone();
    let update_fut = nativelink_util::spawn!("update_task", async move {
        store_clone
            .update(store_key, rx, UploadSizeInfo::ExactSize(DATA_SIZE as u64))
            .await
    });

    for i in 0..DATA_SIZE {
        tx.send(send_data.slice(i..=i)).await?;
    }
    tx.send_eof()?;
    update_fut.await??;

    // Verify the mock operations were called correctly
    let requests = mock_ops.get_requests().await;
    let write_requests: Vec<_> = requests
        .iter()
        .filter_map(|req| {
            if let MockRequest::Write {
                object_path,
                content_len,
            } = req
            {
                Some((object_path, content_len))
            } else {
                None
            }
        })
        .collect();

    assert_eq!(write_requests.len(), 1, "Expected one write request");
    assert_eq!(
        *write_requests[0].1, DATA_SIZE,
        "Expected content length to match DATA_SIZE"
    );

    Ok(())
}

#[nativelink_test]
async fn update_zero_length() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    let digest = ZERO_BYTE_DIGESTS[0];
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, rx) = make_buf_channel_pair();

    // Start update operation
    let store_clone = store.clone();
    let update_fut = nativelink_util::spawn!("update_task", async move {
        store_clone
            .update(store_key, rx, UploadSizeInfo::ExactSize(0))
            .await
    });

    tx.send_eof()?;
    update_fut.await??;

    // Verify the mock operations were called correctly
    let requests = mock_ops.get_requests().await;
    let write_requests = requests.iter().filter_map(|req| {
        if let MockRequest::Write {
            object_path,
            content_len,
        } = req
        {
            Some((object_path, content_len))
        } else {
            None
        }
    });

    assert_eq!(write_requests.count(), 0, "Expected no write request");

    Ok(())
}

#[nativelink_test]
async fn update_zero_digest_with_data() -> Result<(), Error> {
    const DATA_SIZE: usize = 50;

    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Create test data
    let mut send_data = BytesMut::new();
    for i in 0..DATA_SIZE {
        send_data.put_u8(u8::try_from((i % 93) + 33).unwrap());
    }
    let send_data = send_data.freeze();

    let digest = ZERO_BYTE_DIGESTS[0];
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, rx) = make_buf_channel_pair();

    // Start update operation
    let store_clone = store.clone();
    let update_fut = nativelink_util::spawn!("update_task", async move {
        store_clone
            .update(store_key, rx, UploadSizeInfo::ExactSize(DATA_SIZE as u64))
            .await
    });

    tx.send(send_data).await?;
    tx.send_eof()?;
    assert!(
        update_fut.await?.is_err(),
        "No error for zero byte digest with data"
    );

    Ok(())
}

#[nativelink_test]
async fn get_part_test() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Add test data to the mock
    let digest = DigestInfo::try_new(VALID_HASH1, 11)?; // "hello world" length
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    mock_ops
        .add_object(&object_path, b"hello world".to_vec())
        .await;

    let (mut tx, mut rx) = make_buf_channel_pair();
    let store_clone = store.clone();
    let store_key_clone = store_key.clone();

    let handle = nativelink_util::spawn!("get_part_task", async move {
        store_clone
            .get_part(store_key_clone, &mut tx, 0, None)
            .await
    });

    // Receive the data
    let received_data =
        match tokio::time::timeout(Duration::from_secs(5), rx.consume(Some(100))).await {
            Ok(result) => result?,
            Err(_) => {
                return Err(make_err!(
                    Code::DeadlineExceeded,
                    "Timeout waiting for data"
                ));
            }
        };

    assert_eq!(
        received_data.as_ref(),
        b"hello world",
        "Received data should match original"
    );

    // Ensure get_part completes successfully
    handle.await??;

    Ok(())
}

#[nativelink_test]
async fn get_part_with_range() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Add test data to the mock
    let digest = DigestInfo::try_new(VALID_HASH1, 11)?; // "hello world" length
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    mock_ops
        .add_object(&object_path, b"hello world".to_vec())
        .await;
    let (mut tx, mut rx) = make_buf_channel_pair();

    // Start get_part operation to retrieve a range (bytes 6-10, i.e., "world")
    let store_clone = store.clone();
    let get_fut = nativelink_util::spawn!("get_part_partial_task", async move {
        store_clone.get_part(store_key, &mut tx, 6, Some(5)).await
    });

    // Receive the data
    let received_data = rx.consume(Some(100)).await?;
    assert_eq!(
        received_data.as_ref(),
        b"world",
        "Received data should match the requested range"
    );
    get_fut.await??;

    // Verify the mock operations were called correctly
    let requests = mock_ops.get_requests().await;
    let read_requests: Vec<_> = requests
        .iter()
        .filter_map(|req| {
            if let MockRequest::ReadContent {
                object_path: _,
                start,
                end,
            } = req
            {
                Some((start, end))
            } else {
                None
            }
        })
        .collect();

    assert_eq!(read_requests.len(), 1, "Expected one read content request");
    assert_eq!(*read_requests[0].0, 6, "Expected start offset to be 6");
    assert_eq!(
        *read_requests[0].1,
        Some(11),
        "Expected end offset to be Some(11)"
    );

    Ok(())
}

#[nativelink_test]
async fn get_part_zero_digest() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Create a zero digest
    let digest = DigestInfo::new(Sha256::new().finalize().into(), 0);
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, mut rx) = make_buf_channel_pair();

    // Start get_part operation
    let store_clone = store.clone();
    let get_fut = nativelink_util::spawn!("get_part_full_task", async move {
        store_clone.get_part(store_key, &mut tx, 0, None).await
    });

    // Receive the data - should be empty
    let received_data = rx.consume(Some(100)).await?;
    assert_eq!(
        received_data.as_ref(),
        b"",
        "Received data should be empty for zero digest"
    );
    get_fut.await??;

    // Verify no mock operations were called (zero digest is special-cased)
    let call_counts = mock_ops.get_call_counts();
    assert_eq!(
        call_counts.read_calls.load(Ordering::Relaxed),
        0,
        "No read operations should have been called for zero digest"
    );

    Ok(())
}

#[nativelink_test]
async fn test_expired_object() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());

    // Create a GCS store with the mock operations and expiration set to 2 days
    let expiration_seconds = 2 * 24 * 60 * 60;
    let store = create_test_store_with_expiration(mock_ops.clone(), expiration_seconds).await?;

    // Create a digest and object
    let digest = DigestInfo::try_new(VALID_HASH1, 5)?;
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    let base_timestamp = 1000;
    mock_ops
        .add_object_with_timestamp(&object_path, vec![1, 2, 3, 4, 5], base_timestamp)
        .await;

    // Mock the now function to return a time before expiration
    MockClock::set_time(Duration::from_secs(base_timestamp + expiration_seconds - 1));

    // Check that the object exists (it's not expired yet)
    let result = store.has(store_key.clone()).await?;
    assert_eq!(
        result,
        Some(5),
        "Expected to find the object before expiration"
    );

    // Mock the now function to return a time after expiration
    MockClock::set_time(Duration::from_secs(base_timestamp + expiration_seconds + 1));

    // Object should now be considered expired
    let result = store.has(store_key).await?;
    assert_eq!(result, None, "Expected the object to be considered expired");

    Ok(())
}

#[nativelink_test]
async fn large_file_update_test() -> Result<(), Error> {
    const DATA_SIZE: usize = 11 * 1024 * 1024; // 11MB to exceed SIMPLE_UPLOAD_THRESHOLD

    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Create test data
    let pattern: Vec<u8> = (0..100)
        .map(|i| u8::try_from(i % 256).expect("modulo 256 fits in u8"))
        .collect();

    // Create a digest and channel pair
    let digest = DigestInfo::try_new(VALID_HASH1, DATA_SIZE as u64)?;
    let store_key: StoreKey = to_store_key(digest);
    let (mut tx, rx) = make_buf_channel_pair();

    // Start update operation
    let store_clone = store.clone();
    let update_fut = nativelink_util::spawn!("update_task", async move {
        store_clone
            .update(store_key, rx, UploadSizeInfo::ExactSize(DATA_SIZE as u64))
            .await
    });

    // Send data in chunks using the pattern
    let mut bytes_sent = 0;
    while bytes_sent < DATA_SIZE {
        let chunk_size = core::cmp::min(pattern.len(), DATA_SIZE - bytes_sent);
        tx.send(Bytes::copy_from_slice(&pattern[0..chunk_size]))
            .await?;
        bytes_sent += chunk_size;
    }
    tx.send_eof()?;
    update_fut.await??;

    // Verify the mock operations were called correctly
    let requests = mock_ops.get_requests().await;

    // For large files, should see resumable upload operations
    let start_resumable_requests = requests
        .iter()
        .filter(|req| matches!(req, MockRequest::StartResumable { .. }))
        .count();

    assert!(
        start_resumable_requests > 0,
        "Expected at least one StartResumable request for large file"
    );

    Ok(())
}

#[nativelink_test]
async fn test_content_type() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let _store = create_test_store(mock_ops.clone()).await?;

    // Add a test object to the mock
    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    mock_ops.add_object(&object_path, vec![1, 2, 3, 4, 5]).await;

    // Get the object metadata to check content type
    let result = mock_ops.read_object_metadata(&object_path).await?;

    assert!(result.is_some(), "Expected to find metadata");
    let metadata = result.unwrap();
    assert_eq!(
        metadata.content_type, DEFAULT_CONTENT_TYPE,
        "Content type should match the default content type"
    );

    Ok(())
}

#[nativelink_test]
async fn test_null_object_metadata() -> Result<(), Error> {
    // Create mock GCS operations
    let mock_ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(mock_ops.clone()).await?;

    // Add a test object to the mock
    let digest = DigestInfo::try_new(VALID_HASH1, 100)?;
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);

    // Add a "bad" metadata object with negative size
    // This is done by manually constructing a "broken" object in the mock
    let content = vec![1, 2, 3, 4, 5];
    let timestamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();

    let metadata = nativelink_store::gcs_client::types::GcsObject {
        name: object_path.path.clone(),
        bucket: object_path.bucket.clone(),
        size: -1, // Invalid size to test error handling
        content_type: DEFAULT_CONTENT_TYPE.to_string(),
        update_time: Some(nativelink_store::gcs_client::types::Timestamp {
            seconds: timestamp,
            nanos: 0,
        }),
    };

    let _mock_object = Arc::new((metadata, content));

    // Now try to access it through the store
    let result = store.has(store_key).await;

    // Should either return None (if the mock skips invalid objects)
    // or return an error (if it propagates the invalid size)
    match result {
        Ok(None) => {
            // This is fine - the store might consider invalid sizes as "not found"
        }
        Ok(Some(_)) => {
            panic!("Expected not to find object with invalid size");
        }
        Err(e) => {
            // This is also fine - the store might error on invalid sizes
            assert!(
                e.code == Code::InvalidArgument || e.code == Code::Internal,
                "Expected InvalidArgument or Internal error for invalid size"
            );
        }
    }

    Ok(())
}

// Helper function to create a test GCS store
async fn create_test_store(
    ops: Arc<MockGcsOperations>,
) -> Result<Arc<GcsStore<MockGcsOperations, fn() -> MockInstantWrapped>>, Error> {
    GcsStore::new_with_ops(
        &ExperimentalGcsSpec {
            bucket: BUCKET_NAME.to_string(),
            common: CommonObjectSpec {
                key_prefix: Some(KEY_PREFIX.to_string()),
                ..Default::default()
            },
            ..Default::default()
        },
        ops,
        MockInstantWrapped::default,
    )
}

// Helper function to create a test GCS store with a custom retry config
async fn create_test_store_with_retry(
    ops: Arc<MockGcsOperations>,
    retry: Retry,
) -> Result<Arc<GcsStore<MockGcsOperations, fn() -> MockInstantWrapped>>, Error> {
    GcsStore::new_with_ops(
        &ExperimentalGcsSpec {
            bucket: BUCKET_NAME.to_string(),
            common: CommonObjectSpec {
                key_prefix: Some(KEY_PREFIX.to_string()),
                retry,
                ..Default::default()
            },
            ..Default::default()
        },
        ops,
        MockInstantWrapped::default,
    )
}

// Helper function to create a test GCS store with expiration
async fn create_test_store_with_expiration(
    ops: Arc<MockGcsOperations>,
    expiration_seconds: u64,
) -> Result<Arc<GcsStore<MockGcsOperations, fn() -> MockInstantWrapped>>, Error> {
    GcsStore::new_with_ops(
        &ExperimentalGcsSpec {
            bucket: BUCKET_NAME.to_string(),
            common: CommonObjectSpec {
                key_prefix: Some(KEY_PREFIX.to_string()),
                consider_expired_after_s: u32::try_from(expiration_seconds)
                    .expect("expiration_seconds exceeds u32::MAX"),
                ..Default::default()
            },
            ..Default::default()
        },
        ops,
        MockInstantWrapped::default,
    )
}

// Helper to create an object path from a store key
fn create_object_path(key: &StoreKey) -> ObjectPath {
    ObjectPath::new(
        BUCKET_NAME.to_string(),
        &format!("{}{}", KEY_PREFIX, key.as_str()),
    )
}

#[nativelink_test]
async fn check_health_ok_when_bucket_reachable() -> Result<(), Error> {
    let ops = Arc::new(MockGcsOperations::new());
    let store = create_test_store(ops.clone()).await?;

    match HealthStatusIndicator::check_health(&*store, std::borrow::Cow::Borrowed("test")).await {
        HealthStatus::Ok { .. } => {}
        other => panic!("expected HealthStatus::Ok, got {other:?}"),
    }
    // Sanity: the probe issues exactly one object_exists call.
    assert_eq!(
        ops.get_call_counts()
            .object_exists_calls
            .load(Ordering::Relaxed),
        1
    );
    Ok(())
}

#[nativelink_test]
async fn check_health_failed_on_object_exists_error() -> Result<(), Error> {
    let ops = Arc::new(MockGcsOperations::new());
    ops.set_should_fail(true);
    ops.set_failure_mode(FailureMode::NetworkError).await;
    let store = create_test_store(ops.clone()).await?;

    match HealthStatusIndicator::check_health(&*store, std::borrow::Cow::Borrowed("test")).await {
        HealthStatus::Failed { message, .. } => {
            assert!(
                message.contains("object_exists errored"),
                "unexpected failure message: {message}",
            );
            Ok(())
        }
        other => panic!("expected HealthStatus::Failed, got {other:?}"),
    }
}

#[nativelink_test]
async fn get_part_ignores_empty_stream_chunks() -> Result<(), Error> {
    use futures::stream::{self, Stream, StreamExt};
    use nativelink_store::gcs_client::types::GcsObject;
    use nativelink_util::buf_channel::DropCloserReadHalf;

    /// Wraps `MockGcsOperations`, re-chunking every content read so the
    /// stream interleaves zero-length chunks the way an HTTP/2 peer that
    /// emits empty DATA frames does.
    #[derive(Debug)]
    struct EmptyChunkOps(Arc<MockGcsOperations>);

    impl GcsOperations for EmptyChunkOps {
        async fn read_object_metadata(
            &self,
            object: &ObjectPath,
        ) -> Result<Option<GcsObject>, Error> {
            self.0.read_object_metadata(object).await
        }

        async fn read_object_content(
            &self,
            object_path: &ObjectPath,
            start: u64,
            end: Option<u64>,
        ) -> Result<Box<dyn Stream<Item = Result<Bytes, Error>> + Send + Unpin>, Error> {
            let mut inner = self.0.read_object_content(object_path, start, end).await?;
            let mut content = BytesMut::new();
            while let Some(chunk) = inner.next().await {
                content.put(chunk?);
            }
            let content = content.freeze();
            let mid = content.len() / 2;
            Ok(Box::new(stream::iter(vec![
                Ok(Bytes::new()),
                Ok(content.slice(..mid)),
                Ok(Bytes::new()),
                Ok(content.slice(mid..)),
                Ok(Bytes::new()),
            ])))
        }

        async fn write_object(
            &self,
            object_path: &ObjectPath,
            content: Vec<u8>,
        ) -> Result<(), Error> {
            self.0.write_object(object_path, content).await
        }

        async fn start_resumable_write(&self, object_path: &ObjectPath) -> Result<String, Error> {
            self.0.start_resumable_write(object_path).await
        }

        async fn upload_chunk(
            &self,
            upload_url: &str,
            object_path: &ObjectPath,
            data: Bytes,
            offset: u64,
            end_offset: u64,
            total_size: Option<u64>,
        ) -> Result<(), Error> {
            self.0
                .upload_chunk(
                    upload_url,
                    object_path,
                    data,
                    offset,
                    end_offset,
                    total_size,
                )
                .await
        }

        async fn upload_from_reader(
            &self,
            object_path: &ObjectPath,
            reader: &mut DropCloserReadHalf,
            upload_id: &str,
            max_size: u64,
        ) -> Result<(), Error> {
            self.0
                .upload_from_reader(object_path, reader, upload_id, max_size)
                .await
        }

        async fn object_exists(&self, object_path: &ObjectPath) -> Result<bool, Error> {
            self.0.object_exists(object_path).await
        }
    }

    let mock_ops = Arc::new(MockGcsOperations::new());
    let digest = DigestInfo::try_new(VALID_HASH1, 11)?; // "hello world" length
    let store_key: StoreKey = to_store_key(digest);
    let object_path = create_object_path(&store_key);
    mock_ops
        .add_object(&object_path, b"hello world".to_vec())
        .await;

    let store = GcsStore::new_with_ops(
        &ExperimentalGcsSpec {
            bucket: BUCKET_NAME.to_string(),
            common: CommonObjectSpec {
                key_prefix: Some(KEY_PREFIX.to_string()),
                ..Default::default()
            },
            ..Default::default()
        },
        Arc::new(EmptyChunkOps(mock_ops)),
        MockInstantWrapped::default,
    )?;

    let (mut tx, mut rx) = make_buf_channel_pair();
    let store_clone = store.clone();
    let store_key_clone = store_key.clone();

    let handle = nativelink_util::spawn!("get_part_task", async move {
        store_clone
            .get_part(store_key_clone, &mut tx, 0, None)
            .await
    });

    let received_data =
        match tokio::time::timeout(Duration::from_secs(5), rx.consume(Some(100))).await {
            Ok(result) => result?,
            Err(_) => {
                return Err(make_err!(
                    Code::DeadlineExceeded,
                    "Timeout waiting for data"
                ));
            }
        };

    assert_eq!(
        received_data.as_ref(),
        b"hello world",
        "Received data should match original despite empty stream chunks"
    );

    handle.await??;

    Ok(())
}

#[nativelink_test]
async fn incomplete_upload_never_publishes_gcs_object() -> Result<(), Error> {
    for expected in [78, 8 * 1024 * 1024] {
        for payload in [Bytes::new(), Bytes::from_static(b"short")] {
            let ops = Arc::new(MockGcsOperations::new());
            let store = create_test_store(ops.clone()).await?;
            let key = DigestInfo::try_new(VALID_HASH1, expected)?;
            let (mut tx, rx) = make_buf_channel_pair();
            let send = async move {
                if !payload.is_empty() {
                    tx.send(payload).await?;
                }
                tx.send_eof()
            };
            let (result, _) = tokio::join!(
                store.update(key, rx, UploadSizeInfo::ExactSize(expected)),
                send
            );
            assert_eq!(result.unwrap_err().code, Code::InvalidArgument);
            let calls = ops.get_call_counts();
            assert_eq!(calls.write_calls.load(Ordering::Relaxed), 0);
            assert_eq!(calls.upload_chunk_calls.load(Ordering::Relaxed), 0);
        }
    }
    Ok(())
}
