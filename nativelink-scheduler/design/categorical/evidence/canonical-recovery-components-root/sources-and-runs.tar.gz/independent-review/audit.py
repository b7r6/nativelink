from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
from urllib.parse import urlparse, unquote

E = Path('/tmp/nativelink-categorical-evidence/canonical-recovery-components-root-integration')
R = Path('/tmp/nativelink-canonical-recovery-components-root-independent-review')
D = R / 'evidence'
D.mkdir(exist_ok=True)
ROOT = Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
HEAD = '61a12ad332edc657126ff369609286739fd15444'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def file_sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def js(p):
    return json.loads(p.read_bytes())

copied = []
for p in sorted(E.rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(E)
    dest = D / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert file_sha(p) == file_sha(dest)
    elif rel.parts[0] == 'binaries':
        os.link(p, dest)  # Only immutable retained copies, never Bazel outputs.
    else:
        shutil.copyfile(p, dest)
    assert file_sha(p) == file_sha(dest)
    copied.append({'path': str(rel), 'bytes': dest.stat().st_size, 'sha256': file_sha(dest)})

before = js(D / 'sources-before.json')
assert before == js(D / 'sources-after.json') and len(before) == 1365
context = js(D / 'context.json')
assert context['head'] == HEAD
paths = list(before)
request = ''.join(HEAD + ':' + p + '\n' for p in paths).encode()
raw = subprocess.check_output(['git', 'cat-file', '--batch'], input=request, cwd=ROOT)
offset = 0
for p in paths:
    end = raw.index(b'\n', offset)
    header = raw[offset:end].split()
    assert len(header) == 3 and header[1] == b'blob', (p, header)
    size = int(header[2])
    start = end + 1
    blob = raw[start:start + size]
    assert raw[start + size:start + size + 1] == b'\n'
    offset = start + size + 1
    b = (D / 'sources' / p).read_bytes()
    assert b == blob and size == before[p]['bytes'] and sha(b) == before[p]['sha256'], p
assert offset == len(raw)
tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', HEAD], cwd=ROOT).decode().splitlines()
expected = [p for p in tracked if not p.startswith('nativelink-scheduler/design/categorical/evidence/')]
assert set(expected) == set(paths)
generated = js(D / 'generated-configs.json')
for p, x in generated.items():
    b = (D / 'generated-configs' / p).read_bytes()
    assert len(b) == x['bytes'] and sha(b) == x['sha256']
    if p in before:
        assert (D / 'sources' / p).read_text() == x['target'] and before[p]['symlink']
    else:
        assert p not in tracked

command = js(D / 'command.json')
execution = js(D / 'execution.json')
assert '--nocache_test_results' in command and execution['exit_code'] == 0
assert js(D / 'capture-errors.json') == []
events = [json.loads(line) for line in (D / 'events.jsonl').read_text().splitlines()]
finished = [e['finished'] for e in events if 'finished' in e]
assert len(finished) == 1 and finished[0]['overallSuccess'] and finished[0]['exitCode'].get('code', 0) == 0
plain = [e for e in events if 'completed' in e and not e['id']['targetCompleted'].get('aspect')]
assert len(plain) == 6 and all(e['completed'].get('success') for e in plain)
sets = {e['id']['namedSet']['id']: e['namedSetOfFiles'] for e in events if 'namedSetOfFiles' in e}
recorded_bins = js(D / 'binaries.json')
bin_results = []
for e in plain:
    label = e['id']['targetCompleted']['label']
    groups = [g for g in e['completed']['outputGroup'] if g['name'] == 'default']
    assert len(groups) == 1 and len(groups[0]['fileSets']) == 1
    files = sets[groups[0]['fileSets'][0]['id']]['files']
    assert len(files) == 1
    f = files[0]
    x = recorded_bins[f['name']]
    p = D / 'binaries' / f['name']
    with p.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
    digest = file_sha(p)
    assert digest == f['digest'] == x['sha256']
    assert p.stat().st_size == int(f['length']) == x['bytes']
    assert f == x['bep']
    expected_name = 'nativelink' if label == '//:nativelink' else label[2:].replace(':', '/')
    assert f['name'] == expected_name
    bin_results.append({'target': label, 'sha256': digest, 'bytes': p.stat().st_size, 'retained_copy': str(p.relative_to(R)), 'bep_uri': f['uri']})

results = [e for e in events if 'testResult' in e]
summaries = [e for e in events if 'testSummary' in e]
assert len(results) == 5 and len(summaries) == 5
expected_counts = {'//nativelink-scheduler:unit_test': (200, 0, 1), '//nativelink-scheduler:canonical_owner_api_test': (1, 0, 0), '//tools/canonical-filesystem:ownership_test': (35, 0, 0), '//tools/canonical-filesystem:journal_test': (47, 0, 0), '//tools/canonical-filesystem:journal_bridge_test': (12, 0, 0)}
log_metadata = js(D / 'logs.json')
test_results = []
all_names = {}
for e in results:
    label = e['id']['testResult']['label']
    t = e['testResult']
    assert t['status'] == 'PASSED' and not t.get('cachedLocally', False)
    assert t['executionInfo']['strategy'] == 'linux-sandbox'
    rel = label[2:].replace(':', '/')
    for f in t['testActionOutput']:
        copied_path = 'testlogs/' + rel + '/' + f['name']
        meta = log_metadata[copied_path]
        assert f == meta['bep']
        b = (D / copied_path).read_bytes()
        assert sha(b) == meta['sha256']
        actual = Path(unquote(urlparse(f['uri']).path))
        assert actual.read_bytes() == b
    log = (D / 'testlogs' / rel / 'test.log').read_text()
    counts = [tuple(map(int, x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
    assert counts == [expected_counts[label]]
    names = re.findall(r'^test ([^ ]+) \.\.\. ok$', log, re.M)
    ignored = re.findall(r'^test ([^ ]+) \.\.\. ignored[^\n]*$', log, re.M)
    assert len(names) == counts[0][0] and len(set(names)) == len(names)
    assert len(ignored) == counts[0][2]
    all_names[label] = names
    summary = next(s['testSummary'] for s in summaries if s['id']['testSummary']['label'] == label)
    assert summary['overallStatus'] == 'PASSED' and summary['totalRunCount'] == 1 and summary['attemptCount'] == 1
    test_results.append({'target': label, 'passed': counts[0][0], 'failed': 0, 'ignored': ignored, 'fresh_linux_sandbox_execution': True, 'test_log_sha256': sha(log.encode())})
unit_names = all_names['//nativelink-scheduler:unit_test']
clock = [n for n in unit_names if 'canonical_clock::tests::' in n or 'temporal::recovery_clock::' in n]
lifecycle = [n for n in unit_names if 'tests::recovery::lifecycle_' in n]
assert len(clock) == 16 and len(lifecycle) == 21
assert not any('composed_' in n for n in unit_names)
assert 'tools/canonical-filesystem/src/worker.rs' not in before
owner_source = (D / 'sources/nativelink-scheduler/src/authority/canonical_owner.rs').read_text()
assert 'pub struct RecoveredCanonicalOwner' not in owner_source

receipt = {'scope': 'Independent read-only source/Git/BEP/log/actual ELF qualification audit. No builds, compiler/test executions or root edits by reviewer.', 'commit': HEAD, 'context_scope': context['scope'], 'selected_tracked_source_inputs_exact_before_after_copies_git': 1365, 'excluded_tracked_prefix': 'nativelink-scheduler/design/categorical/evidence/', 'generated_config_copies_exact': generated, 'source_manifest_sha256': file_sha(D / 'sources-before.json'), 'execution': execution, 'successful_targets': 6, 'uncached_test_targets': 5, 'test_results': test_results, 'passed_test_executions': 295, 'ignored_test_executions': 1, 'clock_tests_included_not_additive': 16, 'lifecycle_tests_included_not_additive': 21, 'actual_bep_bound_elfs': bin_results, 'capture_errors': [], 'limitations': ['The server ELF was built and copied; it was not started by this gate.', '295 passes count executions across five targets. Shared filesystem tests repeat across variants; this is not295 independent behavioral cases.', 'This boundary has private lifecycle and private clock components, without the new public recovered-owner composition or worker materialization source.', 'No mutation/control execution is established by this integration gate.'], 'verdict': 'Recorded root integration success is supported by exact Git sources, fresh raw test results, complete log copies and all six actual BEP-bound executable artifacts.'}
(R / 'copied-evidence-manifest.json').write_text(json.dumps(copied, indent=2) + '\n')
b = (json.dumps(receipt, indent=2) + '\n').encode()
(R / 'review.json').write_bytes(b)
print(json.dumps({'review_sha256': sha(b), 'source_manifest_sha256': receipt['source_manifest_sha256'], 'sources': len(before), 'passed': 295, 'ignored': 1, 'actual_ELFs': len(bin_results), 'copied_files': len(copied)}, indent=2))
