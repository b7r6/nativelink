# Independent terminal candidate source review

Reviewer: `storage_review`. Final read-only pass: 2026-10-23T06:38:21Z.
Worktree: `/tmp/nativelink-publication-terminal`.
Base commit: `65951b7db3c135ae5f7c1d68a4ffbbfb72a209b8`.
The worktree contains uncommitted additions; the file hashes below identify the
reviewed implementation, rather than the base commit alone.

Result: no remaining concrete finding in the bounded source-review scope after
the final fixes listed below. This receipt is a static review result, not a test
execution receipt or a proof of all histories.

## Scope and independence

Reviewed the candidate against the frozen terminal-outcome contract, focusing on
corruption-safe restore, exact original requests and accepted origin, unchanged
ignored/rejected events, logical credit closure versus retained physical charges,
retry classification, and separation from graph publication. Used the actual
scheduler and Coarse implementation to check the candidate's composition.

No independent publication-head or terminal reference implementation or tests
were read. No publication/terminal candidate test bodies were read. The candidate
test crate's module-wiring file was inspected to locate the actual Coarse source.
No candidate implementation or tests were edited. This receipt is the only file
written for this final task.

The reviewer did not execute compilation, tests, restore witnesses, or mutants.
The coordinator reported that a separate tester reproduced restore, duplicate
observation, and timestamp-order witnesses before the fixes; those executions
are attributable to that tester's receipts, not this review.

## Findings and final disposition

| Original finding | Final source-review status |
| --- | --- |
| Retained memory evidence could contradict Retry or the terminal reason: absent growth evidence could retain a retry; a first attempt could claim attempt-budget exhaustion. | Closed by growth-base, attempt-ordinal and reason checks, plus the saturating doubled-base upper bound for retry targets. Historical worker ceilings are deliberately not recomputed from current workers. |
| Removing a retry report could preserve the scheduler's grown target while losing exact report evidence and duplicate identity. | Closed by checking the complete chain from original request resources through each original charged reservation and recorded retry target to the current target. |
| Stripping v4 terminal metadata could admit ResourceFailed, target growth, or last-interest Cancelled as an older private format. The coordinator independently identified the final ResourceFailed case; this review identified the retry and cancellation variants. | Closed for these distinguishable impossible legacy states by the legacy-format invariant. This does not authenticate a fully rewritten snapshot or distinguish histories whose retained states coincide. |
| Retry report positions/times could contradict retained attempt order, execution admission/terminal time, or a later worker graph publication. | Closed by per-execution ordering and time bounds, graph acceptance position checks, and terminal time equality. |
| Reports and graph acceptances from different executions could have decreasing logical time in increasing commit order. | Closed: `dated_positions` collects both kinds of retained dated event, sorts by commit position, and rejects decreasing time. Equal times remain valid. Separate invariants reject relevant duplicate positions. Undated direct grants cannot supply a historical timestamp. |
| An identical settled `observe` repeated a Coarse `WriteDone` that returned Ignored, but still incremented catalogue revision and invalidated preparation. | Closed in private v4: the shortcut follows stage/write/key/object identity checks; conflicting outcomes still reach Coarse and fail. The outer no-op comparison preserves commit and canonical snapshot when the child states and metadata are unchanged. Older private formats retain their existing behavior. |

Also checked the already-corrected safe lookup of a graph acceptance's stage and
the exclusion of the disposable lookup index from canonical no-op comparison.
These fixes were supplied by the coordinator before the relevant review pass.

## Bounded positive observations

- The no-graph gate validates the exact captured response and refuses every
  present ActionResult. Actual protocol facts require a nonzero status for a
  no-result response, preventing the Complete path from emitting an M4 publish
  intent for these accepted reports.
- Report application uses the genuine scheduler transition inside the outer
  clone. Exact report duplicates retain their original classification without
  reacquiring current worker authority; conflicting identities are refused.
- Accepted terminal links derive from each actual operation terminal. Canceled
  joined handles are not overwritten, original operation requests are checked,
  and graph/no-graph links are mutually exclusive.
- Terminal reconciliation closes unused logical credit while retaining existing
  and prior stage associations. It does not release scheduler reservations,
  consume cancellation intents, remove write records, or add CAS roots.
- The proposed changed state passes invariants and the full canonical snapshot
  byte bound before it replaces the current outer state.

These observations do not prove completeness, production readiness, all future
byte or retry-slot headroom, physical quiescence, collector correctness, or
historical authenticity. In particular, the retained state cannot reconstruct
historical worker eligibility/capacity or authenticate a coherently rewritten
history. The scope remains the bounded private candidate and frozen contract.

## Reviewed source identities

All repository paths below are relative to the review worktree. Hashes are
SHA-256 of the final reviewed file bytes.

| Path | SHA-256 |
| --- | --- |
| `nativelink-scheduler/tests/publication_candidate/terminal.rs` | `01794a74e045a6f5125e8df83ee868ca6505636a7845208cf651c8da5cb1a7df` |
| `nativelink-scheduler/tests/publication_candidate/terminal_types.rs` | `3e6227a5ef1c744950e7eab23383d7d87fa8453890a95ad66352b19df3a795dd` |
| `nativelink-scheduler/tests/publication_candidate/engine.rs` | `aae00b9a1a413881df97b76026f9d0eed1aa681e88c1b72e4c93051db5f0d6c2` |
| `nativelink-scheduler/tests/publication_candidate/validation.rs` | `e0a85535114cce243ead22a6581f6af93738086e0133d75bdfe31d8091bae89e` |
| `nativelink-scheduler/tests/publication_candidate/direct_client.rs` | `32c17d97419b8134bf64bfd727a6758be542e404b3e46a7d06c3302cb3028aa8` |
| `nativelink-scheduler/tests/publication_candidate/binding.rs` | `8b24530501054fa820fb3db38e900dc0dd547f14ef0405f50888ac4aa4c32b1f` |
| `nativelink-scheduler/src/authority/mod.rs` | `8cf6e43594b03c7e425e5947b3bfadd1046649ff209e7dee7c46fda26f924f0d` |
| `nativelink-scheduler/src/authority/reapi.rs` | `2904be6f9022eb2af8e9a304fd0da1005677e8f5c0634b7b007c60912cc224c9` |
| `nativelink-scheduler/src/authority/types.rs` | `e7b70fa6e50dbf4ac0ca64da8019dd75a812b0a695d8fe8576a9c63c71ed1d4d` |
| `nativelink-scheduler/tests/retention/coarse.rs` | `dfbe4d3701a510421be2425cef4e24b67aadd9a77e5be0e260ac2550f80042ad` |
| `/tmp/nativelink-terminal-outcome-contract-v1.md` | `c1d21e6acefe0d32129753263ba4edbbd552a74115c5899535b221df49acbe3d` |
