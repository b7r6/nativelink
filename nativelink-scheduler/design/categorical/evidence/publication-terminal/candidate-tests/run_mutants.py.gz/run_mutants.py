#!/usr/bin/env python3
"""Run serial compiled faults against an immutable terminal-candidate freeze."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/tmp/nativelink-publication-terminal')
EVIDENCE = Path('/tmp/nativelink-categorical-evidence/publication-terminal-tests')
FREEZE = EVIDENCE / 'final-freeze'
OUT = EVIDENCE / 'mutants'
OUT.mkdir(exist_ok=True)
TERMINAL = 'nativelink-scheduler/tests/publication_candidate/terminal.rs'
ENGINE = 'nativelink-scheduler/tests/publication_candidate/engine.rs'
STATE = 'nativelink-scheduler/src/authority/mod.rs'
manifest = json.loads((FREEZE / 'freeze.json').read_text())

def digest(data):
    return hashlib.sha256(data).hexdigest()

def exact_replace(source, before, after):
    assert source.count(before) == 1, (source.count(before), before)
    return source.replace(before, after)

def insert_report(source, insertion):
    needle = '        self.transaction(|next| {\n            let origin = &report.origin;'
    return exact_replace(source, needle, insertion + needle)

def cleanup(source):
    start = source.index('    pub(super) fn reconcile_terminal_credits')
    end = source.index('    pub(super) fn operation_has_no_graph', start)
    chunk = source[start:end]
    replacement = '''        let view = self.scheduler.view();
        for execution in &view.executions {
            if execution.terminal.is_some() {
                for attempt in view.attempts.iter().filter(|a| a.execution == execution.id) {
                    let _ = self.scheduler.apply(a::RecordedEvent {
                        epoch: EPOCH,
                        event: a::Event::Cleanup {
                            attempt: attempt.id,
                            worker: attempt.worker,
                            incarnation: attempt.incarnation,
                        },
                    });
                }
            }
        }
'''
    chunk = exact_replace(chunk, '        let view = self.scheduler.view();\n', replacement)
    return source[:start] + chunk + source[end:]

def overwrite_cancel(source):
    start = source.index('    fn terminal(&mut self, execution: ExecutionId, result: TerminalResult)')
    end = source.index('    fn emit(', start)
    chunk = exact_replace(source[start:end],
        '.filter(|operation| operation.view.execution == execution && operation.view.interested)',
        '.filter(|operation| operation.view.execution == execution)')
    return source[:start] + chunk + source[end:]

def byte_guard(source):
    start = source.index('    pub(crate) fn snapshot(&self)')
    end = source.index('    pub(crate) fn restore(', start)
    chunk = exact_replace(source[start:end],
        '        if bytes.len() > MAX_SNAPSHOT {\n            return Err(Error::Bounds);\n        }\n', '')
    return source[:start] + chunk + source[end:]

mutants = [
    ('01-memory-to-complete', TERMINAL, 'Rewrite incoming memory-failure classification to Complete.',
     lambda s: insert_report(s, '''        let mut report = report;
        if matches!(report.kind, TerminalReportKind::MemoryFailure { .. }) {
            report.kind = TerminalReportKind::Complete;
        }
'''), False),
    ('02-drop-memory-peak', TERMINAL, 'Discard reported positive peak memory evidence before actual State decision.',
     lambda s: insert_report(s, '''        let mut report = report;
        if let TerminalReportKind::MemoryFailure { peak_memory_bytes, .. } = &mut report.kind {
            *peak_memory_bytes = None;
        }
'''), False),
    ('03-allow-result-graph', TERMINAL, 'Remove response.result=None gate while preserving payload/captured-response checks.',
     lambda s: exact_replace(s, '''        if response
            .decode()
            .map_err(|_| Error::Invalid)?
            .result
            .is_some()
        {
            return Err(Error::Invalid);
        }
''', '        let _ = response.decode().map_err(|_| Error::Invalid)?;\n'), False),
    ('04-early-cleanup', TERMINAL, 'Automatically refund terminal-execution reservations via Cleanup during credit reconciliation.',
     cleanup, False),
    ('05-current-worker-reauthorization', TERMINAL, 'Reauthorize retained report origin against current draining-worker status.',
     lambda s: exact_replace(s, '''        let origin = &report.origin;
        if origin.epoch != view.epoch {
''', '''        let origin = &report.origin;
        if view.workers.iter().any(|worker| worker.id == origin.worker && worker.draining) {
            return Err(Error::Unauthorized);
        }
        if origin.epoch != view.epoch {
'''), False),
    ('06-no-global-time-order', TERMINAL, 'Remove report/graph global event-time order validation; preserve position uniqueness.',
     lambda s: exact_replace(s, '''        if dated_positions.windows(2).any(|pair| pair[0].1 > pair[1].1) {
            return Err(Error::Corrupt);
        }
''', ''), False),
    ('07-duplicate-observe-mutates', ENGINE, 'Remove private-v4 duplicate write-observation no-op shortcut.',
     lambda s: exact_replace(s, '''            if next.metadata.terminal.is_some() && row.outcomes.get(&write) == Some(&success) {
                return Ok(());
            }
''', ''), False),
    ('08-no-snapshot-byte-guard', ENGINE, 'Remove only snapshot serialization byte-length admission guard; preserve validate, transaction snapshot gate and restore byte limit.',
     byte_guard, True),
    ('09-state-overwrites-cancelled', STATE, 'Actual State terminal transition updates uninterested/cancelled joined operations.',
     overwrite_cancel, False),
    ('10-state-no-interest-generation', STATE, 'Actual State interest expiry ignores generation; preserves terminal/deadline checks.',
     lambda s: exact_replace(exact_replace(s, '''            Event::ExpireInterest {
                operation,
                generation,
            } => {
''', '''            Event::ExpireInterest {
                operation,
                generation: _,
            } => {
'''), '''                if entry.view.terminal.is_some()
                    || entry.view.interest_deadline.generation != generation
                {
''', '''                if entry.view.terminal.is_some() {
'''), False),
]

originals = {path: (FREEZE / 'source' / path).read_bytes() for path in (TERMINAL, ENGINE, STATE)}

def verify_frozen():
    wrong = []
    for path, expected in manifest['frozen_source_sha256'].items():
        actual = digest((ROOT / path).read_bytes())
        if actual != expected:
            wrong.append((path, expected, actual))
    assert not wrong, wrong

def restore():
    for path, data in originals.items():
        (ROOT / path).write_bytes(data)
    verify_frozen()

verify_frozen()
results = []
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-mutations-target', CARGO_BUILD_JOBS='8')
base = ['cargo', 'test', '--locked', '--offline', '--profile=smol', '-p', 'nativelink-scheduler', '--test', 'publication_candidate_test']
try:
    for name, path, description, mutation, full in mutants:
        verify_frozen()
        folder = OUT / name
        folder.mkdir(exist_ok=False)
        changed = mutation(originals[path].decode()).encode()
        assert changed != originals[path]
        artifact = folder / path
        artifact.parent.mkdir(parents=True, exist_ok=True)
        artifact.write_bytes(changed)
        (ROOT / path).write_bytes(changed)
        command = base + ([] if full else ['terminal_tests'])
        record = {
            'name': name, 'description': description, 'mutated_path': path,
            'original_sha256': digest(originals[path]), 'mutant_sha256': digest(changed),
            'frozen_manifest_sha256': digest((FREEZE / 'freeze.json').read_bytes()),
            'command': command, 'cwd': str(ROOT),
            'environment_overrides': {k: env[k] for k in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS')},
            'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        (folder / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {name}', flush=True)
        begin = time.monotonic()
        with (folder / 'test.log').open('w') as log:
            proc = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        output = (folder / 'test.log').read_text()
        compiled = 'Finished `smol` profile' in output and 'Running tests/publication_candidate_test.rs' in output
        detected = compiled and proc.returncode != 0 and 'test result: FAILED.' in output
        survived = compiled and proc.returncode == 0 and 'test result: ok.' in output
        record.update({
            'returncode': proc.returncode, 'seconds': round(time.monotonic()-begin, 2),
            'compiled': compiled, 'detected': detected, 'survived': survived,
            'outcome': 'detected' if detected else ('survived' if survived else 'invalid-run'),
            'result_lines': [line for line in output.splitlines() if line.startswith('test result:')],
            'failed_tests': [line for line in output.splitlines() if line.startswith('test ') and line.endswith(' ... FAILED')],
            'log_sha256': digest((folder / 'test.log').read_bytes()),
        })
        (folder / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
        restore()
        record['source_restored_to_frozen_hashes'] = True
        (folder / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
        results.append(record)
        (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(f"DONE {name} {record['outcome']} {record['seconds']}s {record['result_lines']}", flush=True)
        if not compiled:
            print(output[-6000:], flush=True)
            break
finally:
    restore()
    (OUT / 'restoration.json').write_text(json.dumps({
        'verified': True, 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'frozen_manifest_sha256': digest((FREEZE / 'freeze.json').read_bytes()),
        'all_frozen_sources_match': True,
    }, indent=2) + '\n')
    print('RESTORED all frozen sources', flush=True)
