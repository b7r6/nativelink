import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-categorical-azure-retention')
evidence = Path('/tmp/nativelink-categorical-evidence/azure-typed-retention')
bridge = 'nativelink-scheduler/tests/retention/typed_bridge.rs'
closure = 'nativelink-store/src/physical_closure.rs'
adapter = 'nativelink-store/tests/physical_azure/adapter.rs'
sources = {name: (root / name).read_text() for name in [bridge, closure, adapter]}
env = dict(os.environ, CARGO_BUILD_JOBS='8',
           CARGO_TARGET_DIR='/tmp/nativelink-categorical-physical/target',
           CARGO_MANIFEST_DIR=str(root / 'nativelink-store'),
           NATIVELINK_AZURITE_TEST_RUNNER_DIR='/tmp/nativelink-categorical-azurite/nativelink-store/tests/azurite_runner')
test_name = 'local_azurite_typed_retention_contract'
records = []
if os.environ.get('MUTATIONS_RESUME') == '1':
    for row in json.loads((evidence / 'mutation-results.json').read_text()):
        output = (evidence / f"{row['name']}-live.log").read_text()
        marker = row['expected_failure_marker']
        if row['compile_exit'] == 0 and ((marker is None and row['test_exit'] == 0)
                or (marker is not None and row['test_exit'] != 0 and marker in output)):
            records.append(row)
    assert records and records[0]['name'] == 'mutation-baseline'
    assert records[0]['source_sha256'] == {path: hashlib.sha256(text.encode()).hexdigest()
                                          for path, text in sources.items()}


def qualify(name, changed=None, text=None, failure_marker=None):
    for path, original in sources.items():
        (root / path).write_text(text if path == changed else original)
    compiled = subprocess.run(
        ['cargo', 'test', '-p', 'nativelink-store', '--test', 'physical_azure_test',
         '--no-run', '--message-format=json'],
        cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=300)
    (evidence / f'{name}-compile.log').write_text(compiled.stdout)
    record = {'name': name, 'changed': changed,
              'source_sha256': {path: hashlib.sha256((root/path).read_bytes()).hexdigest()
                                for path in sources},
              'compile_exit': compiled.returncode, 'test_exit': None,
              'expected_failure_marker': failure_marker}
    records.append(record)
    if compiled.returncode:
        raise AssertionError(f'{name} did not compile; not a semantic detection')
    executable = None
    for line in compiled.stdout.splitlines():
        try:
            artifact = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (artifact.get('reason') == 'compiler-artifact'
                and artifact.get('target', {}).get('name') == 'physical_azure_test'
                and artifact.get('executable')):
            executable = artifact['executable']
    assert executable is not None
    with (evidence / f'{name}-live.log').open('w') as log:
        live = subprocess.run([executable, '--ignored', '--exact', test_name, '--nocapture'],
                              cwd=root, env=env, stdout=log,
                              stderr=subprocess.STDOUT, timeout=120)
    record['test_exit'] = live.returncode
    output = (evidence / f'{name}-live.log').read_text()
    assert f'test {test_name} ...' in output, name
    assert (live.returncode == 0) == (failure_marker is None), name
    if failure_marker:
        assert "panicked at " in output and failure_marker in output, (name, output[-3000:])
    print(json.dumps({'name': name, 'compile_exit': compiled.returncode,
                      'test_exit': live.returncode}), flush=True)


mutants = [
    ('skip-blob-verification', closure,
     '        let binding = self.catalogue[&object.into()];\n        let read = self',
     '        if mode == Mode::Blob { return Ok(()); }\n        let binding = self.catalogue[&object.into()];\n        let read = self',
     'typed preparation read all exact provider objects'),
    ('release-serving-with-head', bridge,
     '        // Serving roots are independent of the derived head\'s lifetime.',
     '        for (id, root) in next.candidate.view().roots {\n            if root.kind == RootKind::Serving {\n                next.apply(Event::Release { root: id, lease: root.lease })?;\n            }\n        }\n        // Serving roots are independent of the derived head\'s lifetime.',
     'on an `Err` value: Expired'),
    ('ignore-serving-expiry', bridge,
     '        if view.now >= grant.until {',
     '        if false && view.now >= grant.until {',
     'right: Err(Expired)'),
    ('ignore-manifest-member', bridge,
     '            .find(|row| row.descriptor == object.into())',
     '            .find(|row| row.descriptor == object.into())\n            .or_else(|| manifest.objects.first())',
     'right: Err(Rejected)'),
    ('acknowledge-failed-delete', bridge,
     '            .delete(binding.key, delete.0)\n            .map_err(Error::Physical)?;',
     '            .delete(binding.key, delete.0)\n            .unwrap_or(DeleteReceipt { key: binding.key, delete: delete.0, already_absent: false });',
     'bridge.delete_current(rows[0])'),
    ('delete-without-etag', adapter,
     'if_match: Some(etag),\n                    timeout: Some(10),',
     'if_match: None,\n                    timeout: Some(10),',
     'request.if_match.is_some()'),
]
try:
    completed = {row['name'] for row in records}
    if 'mutation-baseline' not in completed:
        qualify('mutation-baseline')
    for name, path, before, after, marker in mutants:
        if name in completed:
            continue
        assert sources[path].count(before) == 1, (name, sources[path].count(before))
        qualify(name, path, sources[path].replace(before, after, 1), marker)
finally:
    for path, text in sources.items():
        (root / path).write_text(text)
    (evidence / 'mutation-results.json').write_text(json.dumps(records, indent=2) + '\n')
qualify('mutation-restored')
(evidence / 'mutation-results.json').write_text(json.dumps(records, indent=2) + '\n')
