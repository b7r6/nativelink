#!/usr/bin/env python3
import gzip,hashlib,io,json,pathlib,subprocess,tarfile
R=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence');W=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(name):return json.loads((R/name).read_text())
def desc(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}
q=read('qualified-source.json');assert q['commit']=='694f67741c3150247548236bcedef586b554aeac'
for p,h in q['files'].items():assert sha(W/p)==sha(R/'qualified-source'/p)==h
original=read('original-baseline-observations.json');assert(original['passed'],original['failed'],len(original['negative_failures']))==(11,22,22)
plan=read('mutant-plan-corrected.json');cases=[]
for case in plan['cases']:
 label=case.get('execution_label','mutant-'+case['name']);j=read(label+'.json');o=read(label+'-observation.json');assert j['compiler_errors']==0 and j['binary'] and j['source_unchanged'];assert sha(pathlib.Path(j['binary']))==j['binary_sha256'];assert sha(R/(label+'.log'))==j['log_sha256'];expected=dict(q['files']);expected[case['path']]=case['mutant_sha256'];assert j['source_before']==j['source_after']==expected
 assert j['exit_code'] in (0,101);expect_pass=j['exit_code']==0
 if not expect_pass:assert 'panicked at '+case['expected_panic_site'] in (R/(label+'.log')).read_text()
 cases.append({'name':case['name'],'test':case['test'],'mutated_path':case['path'],'mutated_source_sha256':case['mutant_sha256'],'binary_sha256':j['binary_sha256'],'compiler_fresh':j['compiler_fresh'],'result':'survived selected oracle; complementary guard remains' if expect_pass else 'detected at declared semantic assertion','receipt':desc(R/(label+'.json')),'observation':desc(R/(label+'-observation.json'))})
assert len(cases)==16 and len({c['mutated_source_sha256'] for c in cases})==15
for label in ['fixed-regression','strict-corrected','restored-regression','restored-strict']:
 j=read(label+'.json');assert j['exit_code']==0 and j['source_unchanged'];assert j['source_before']==j['source_after']==q['files'];assert sha(R/(label+'.log'))==j['log_sha256']
rest=read('source-restoration.json');assert rest['source_manifest_sha256']==sha(R/'qualified-source.json') and rest['all_selected_files_equal'] and rest['clean_git_status']
receipt={
 'scope':'Private read-only temporal storage admission for inert PreparedCanonicalOwner; no clock or Raft startup, production seal, request ingress, serving, or lifetime-expiry guarantee.',
 'base_commit':q['base'],'tests_first_commit':q['tests_first_commit'],'source_commit':q['commit'],'qualified_source':desc(R/'qualified-source.json'),
 'source_reviews':[desc(R/'independent-root-review'/'review.json'),desc(R/'independent-root-review'/'runtime-review.json'),desc(R/'independent-owner-tests-review'/'review.json'),desc(R/'independent-owner-runtime-review'/'review.json')],
 'invariant_table':desc(R/'temporal-invariants-review.json'),'proposed_delta':desc(R/'proposed-runtime-delta.json'),'source_commit_binding':read('source-commit.json'),
 'original_baseline':read('original.json'),'original_baseline_observations':original,
 'baseline_boundary':'Actual original runtime ran33 corrected tests:11passed,22failed at refuses after generic fixture validation, namespace release and unchanged authority records. Earlier fixtures with missing REQUEST1 witness were corrected before this run. Original ELF retained. Two custody/queue fixtures were added after runtime proposal approval, so the original33 and final35 are distinct counts.',
 'fixed_initial':read('fixed-focused-initial.json'),'strict_initial':read('strict-initial.json'),
 'fixture_correction':'Initial strict Clippy rejected only the custody helper tuple return type. The same tuple now has a TemporalPause type alias; no runtime or oracle semantics changed. Patch and both source freezes retained.',
 'qualification':[read(label+'.json') for label in ['strict-corrected','fixed-regression','restored-regression','restored-strict']],
 'mutation_compile_only_prerequisite_failure':read('mutant-skip-interest-interval.json'),
 'mutation_construction_correction':'Initial interest fault removed a used constant and failed unused-imports compilation; it is not a detection. Corrected interest and cooldown faults retain inert constant reads while removing their guards. Original candidates and plans retained.',
 'mutation_survival_addendum':desc(R/'mutant-survival-addendum.json'),
 'compiled_mutation_summary':desc(R/'compiled-mutation-summary.json'),
 'compiled_mutations':{'case_count':len(cases),'distinct_mutated_sources':len({c['mutated_source_sha256'] for c in cases}),'distinct_binaries':len({c['binary_sha256'] for c in cases}),'detected_cases':sum(c['result'].startswith('detected') for c in cases),'survived_cases':sum(c['result'].startswith('survived') for c in cases),'cases':cases,'interpretation':'The same stateless-Submit removal runs under two separate oracles. The execution-payload removal unexpectedly survived because generic REQUEST1 guarantees an equal original-operation request and the operation payload guard remains. Finite MAX has an independent finite-anchor range rejection; the batch counterexample is protected by both stateless Submit and intermediate poststate checks. Selected-oracle survival is preserved, not relabelled as detection. Compiler failures never count as detection. The queue fault removes only the owned Journal.io mutex guard, not the database Arc. It first fails the declared queue assertion at line140; the bounded paused hook subsequently panics sending to the dropped completion receiver at line67. That cleanup panic is not a second detection.'},
 'restoration':rest,
 'change':['Audit runs inside existing Journal.io and one read transaction before the owner current synchronization barrier. No authority records are written by the audit.','Applied state and retained snapshot independently require exact private Base/limits/contract/domain and temporal validity; the local metadata phase is checked separately. Every retained log row is decoded and checked, including covered and uncommitted events.','The suffix is staged by index after applied through every retained entry, using existing format rules and pure event application. Every intermediate poststate is validated. No effect or durable frontier is advanced.','Finite timeout projection has strict-expiry arithmetic headroom; captured payload distinguishes omitted timeout MAX. ACK/progress, running, interest and cooldown numeric anchors match fixed intervals; legitimate expired/revoked states and Uploading without Running remain accepted.'],
 'boundaries':['Numeric anchors do not attest historical clock samples. Future deadlines may exceed the admitted clock cutoff; headroom does not imply eventual expiry.','Every retained Submit/AdvanceTime obeys a stronger canonical admission rule even when covered/rejected/ignored. Generic unbound Journal semantics remain unchanged.','No total retained-log scan, startup-time or lifetime-work bound is claimed; decoded record/state memory bounds are inherited.','Synthetic sealed membership/state fixtures provide no production bootstrap or seal qualification. Authority-record byte equality excludes redb internal repair/filesystem bytes.','The queue fixture deliberately creates an extra private Journal alias. Owner.release returning while that separate audit holds the database tests the alias custody; public owners expose no such clone or audit.','Snapshot fixtures compare unsafe snapshot and safe applied vectors at the same index. They do not claim an older snapshot cut.','Original33 and final35 count separately; one existing ignored library syscall witness stays ignored in normal Cargo. Root syscall/Bazel qualification is separate.'],
 'binaries':'Actual ELF files retained externally with full SHA256 and file descriptors below; repository archive contains source, raw logs, drivers and receipts, not executable bytes.'
}
(R/'author-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=[];binaries=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts:continue
 with p.open('rb') as f:magic=f.read(4)
 if magic==b'\x7fELF':binaries.append(desc(p))
 else:files.append(p)
O=W/'nativelink-scheduler/design/categorical/evidence/canonical-temporal-preflight';O.mkdir(parents=True,exist_ok=True);a=O/'qualified-evidence.tar.gz'
with a.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in files:
  b=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(R)));i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
m={'scope':receipt['scope'],'source_commit':q['commit'],'tests_first_commit':q['tests_first_commit'],'author_receipt_sha256':sha(R/'author-receipt.json'),'archive':a.name,'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'members':[desc(p) for p in files],'external_executables':binaries,'distinct_external_executable_sha256_count':len({b['sha256'] for b in binaries})};f=O/'manifest.json';f.write_text(json.dumps(m,indent=2)+'\n')
with tarfile.open(a,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for v in m['members']:
  b=tar.extractfile(v['path']).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'source_commit':q['commit'],'receipt_sha256':m['author_receipt_sha256'],'manifest_sha256':sha(f),'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'members':len(files),'external_unique_elfs':m['distinct_external_executable_sha256_count']},indent=2))
