#!/usr/bin/env python3
import hashlib,json,pathlib,subprocess
R=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence');W=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight')
def sha(b):return hashlib.sha256(b).hexdigest()
q=json.loads((R/'qualified-source.json').read_text());rows=[]
for path,expected in q['files'].items():
 tree=sha((W/path).read_bytes());copy=sha((R/'qualified-source'/path).read_bytes());commit=sha(subprocess.check_output(['git','show',q['commit']+':'+path],cwd=W))
 rows.append({'path':path,'expected_sha256':expected,'tree_sha256':tree,'copy_sha256':copy,'commit_sha256':commit,'equal':expected==tree==copy==commit})
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=W,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
rest={'source_manifest_sha256':sha((R/'qualified-source.json').read_bytes()),'source_commit':q['commit'],'head_commit':head,'all_selected_files_equal':all(r['equal'] for r in rows),'clean_git_status':status=='','git_status':status,'selected_file_count':len(rows),'files':rows,'receipts':{label:sha((R/(label+'.json')).read_bytes()) for label in ('restored-regression','restored-strict')}}
assert rest['all_selected_files_equal'] and rest['clean_git_status'] and head==q['commit'],rest
for label in ('restored-regression','restored-strict'):
 j=json.loads((R/(label+'.json')).read_text());assert j['exit_code']==0 and j['source_before']==j['source_after']==q['files'] and j['source_unchanged']
before=json.loads((R/'fixed-regression.json').read_text());after=json.loads((R/'restored-regression.json').read_text());artifacts=[]
for a in after['artifacts']:
 p=pathlib.Path(a['copy']);actual=sha(p.read_bytes());assert actual==a['sha256']
 prior=next(x for x in before['artifacts'] if x['target']==a['target']);assert sha(pathlib.Path(prior['copy']).read_bytes())==prior['sha256']
 artifacts.append({'target':a['target'],'restored_path':str(p),'restored_sha256':actual,'initial_path':prior['copy'],'initial_sha256':prior['sha256'],'same_binary':actual==prior['sha256']})
rest['binary_comparisons']=artifacts
(R/'source-restoration.json').write_text(json.dumps(rest,indent=2)+'\n');print(json.dumps({'source_restoration_sha256':sha((R/'source-restoration.json').read_bytes()),'source_commit':head,'all_selected_files_equal':True,'clean_git_status':True,'selected_file_count':len(rows)},indent=2))
