#!/usr/bin/env python3
import hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
root=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence');work=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight')
label=sys.argv[1];argv=['/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo',*sys.argv[2:]]
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target';env['CARGO_INCREMENTAL']='0'
start=time.monotonic();run=subprocess.run(argv,cwd=work,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);seconds=time.monotonic()-start
log=root/(label+'.log');log.write_text(run.stdout);artifact=None
for line in run.stdout.splitlines():
 try:r=json.loads(line)
 except json.JSONDecodeError:continue
 if r.get('reason')=='compiler-artifact' and r.get('profile',{}).get('test') and r.get('executable') and r.get('target',{}).get('name')=='nativelink_scheduler':artifact=r
receipt={'command':argv,'exit_code':run.returncode,'seconds':seconds,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'test_results':[line for line in run.stdout.splitlines() if line.startswith('test result:')], 'compiler_errors':sum('"level":"error"' in line and 'compiler-message' in line for line in run.stdout.splitlines())}
if artifact:
 binary=root/(label+'-test-binary');shutil.copyfile(artifact['executable'],binary);binary.chmod(0o755);receipt.update(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),compiler_fresh=artifact['fresh'])
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
