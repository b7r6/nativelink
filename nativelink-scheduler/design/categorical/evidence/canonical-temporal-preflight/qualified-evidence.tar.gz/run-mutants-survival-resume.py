#!/usr/bin/env python3
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence');work=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight');plan=json.loads((root/'mutant-plan-qualified.json').read_text())
selected=set(sys.argv[1:]);cases=[case for case in plan['cases'] if not selected or case['name'] in selected]
for case in cases:
 p=work/case['path'];original=p.read_bytes();assert hashlib.sha256(original).hexdigest()==case['original_sha256'],case['name'];mutated=(root/'mutant-candidates'/case['name']/case['path']).read_bytes();assert hashlib.sha256(mutated).hexdigest()==case['mutant_sha256'];label='mutant-'+case['name'];print('BEGIN',case['name'],flush=True)
 try:
  p.write_bytes(mutated)
  subprocess.run([sys.executable,str(root/'run-cargo.py'),label,'test','-p','nativelink-scheduler','--lib','--locked','--offline','--profile','smol','-j8','--message-format=json','canonical_owner::tests::temporal::'+case['test'],'--','--test-threads=1','--nocapture'],check=True)
  receipt=json.loads((root/(label+'.json')).read_text());assert receipt['compiler_errors']==0 and receipt.get('binary'),('compiler failure is not a semantic detection',case['name'])
  log=(root/(label+'.log')).read_text()
  if case['expected'].startswith('expected survival') or case['name']=='skip-execution-payload':
   assert receipt['exit_code']==0 and any('1 passed; 0 failed;' in line for line in receipt['test_results']),(case['name'],'unexpected redundancy outcome')
  else:
   assert receipt['exit_code']==101 and any('0 passed; 1 failed;' in line for line in receipt['test_results']),(case['name'],'unexpected test outcome')
   assert 'panicked at '+case['expected_panic_site'] in log,(case['name'],'unexpected failure phase')
  observations={'case':case,'receipt_sha256':hashlib.sha256((root/(label+'.json')).read_bytes()).hexdigest(),'observed_exit_code':receipt['exit_code'],'test_results':receipt['test_results'],'panic_excerpt':log[log.find("thread 'authority::journal::canonical_owner::tests::temporal::"):] if "thread 'authority::journal::canonical_owner::tests::temporal::"in log else None};(root/(label+'-observation.json')).write_text(json.dumps(observations,indent=2)+'\n');print('END',case['name'],receipt['test_results'],flush=True)
 finally:
  p.write_bytes(original)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==case['original_sha256']
