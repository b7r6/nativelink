#!/usr/bin/env python3
import pathlib,json,hashlib,difflib
w=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight');r=pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence')
p='nativelink-scheduler/src/authority/canonical_temporal.rs';base=(w/p).read_text();cases=[]
def case(name,test,before,after,outcome='semantic refusal assertion must fail',path=p):
 source=(w/path).read_text();assert source.count(before)==1,(name,source.count(before));mutant=source.replace(before,after,1);d=r/'mutant-candidates'/name/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(mutant);diff=''.join(difflib.unified_diff(source.splitlines(True),mutant.splitlines(True),fromfile=path,tofile=path));(d.parents[len(pathlib.PurePosixPath(path).parts)-1]/'mutation.diff').write_text(diff)
 cases.append({'name':name,'test':test,'expected':outcome,'path':path,'original_sha256':hashlib.sha256(source.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest()})
case('raise-clock-cutoff','temporal_applied_cutoff_plus_one_refuses','if now > MAX_CLOCK {','if now > MAX_CLOCK + 1 {')
case('skip-snapshot-temporal','temporal_snapshot_deadline_refuses_with_safe_applied_deadline','                        applied(&saved.applied, domain, contract)?;','                        // Mutant omits snapshot temporal admission.')
case('skip-execution-payload','temporal_synthetic_execution_payload_refuses','        request(&execution.request)?;','        // Mutant omits execution payload admission.')
case('skip-operation-payload','temporal_synthetic_original_operation_payload_refuses','        request(&operation.original_request)?;','        // Mutant omits operation payload admission.')
case('skip-attempt-interval','temporal_accepted_deadline_requires_progress_interval','        anchor(attempt.deadline.at, interval, state.now)?;','        let _ = interval;')
case('skip-finite-running-anchor','temporal_running_deadline_cannot_precede_its_finite_duration','                anchor(deadline, timeout, state.now)?;','                // Mutant omits finite running anchor.')
case('omit-omitted-sentinel','temporal_omitted_timeout_cannot_have_finite_running_deadline','''                if deadline != u64::MAX {
                    return Err(failure(
                        ErrorVerb::Read,
                        "omitted canonical timeout is finite",
                    ));
                }''','                // Mutant accepts finite omitted timeout.')
case('skip-interest-interval','temporal_interest_deadline_cannot_start_before_zero','''        anchor(
            operation.view.interest_deadline.at,
            INTEREST_TIMEOUT,
            state.now,
        )?;''','        // Mutant omits interest interval.')
case('skip-cooldown-interval','temporal_nonzero_cooldown_cannot_start_before_zero','            anchor(execution.hold_cooldown_until, HOLD_COOLDOWN, state.now)?;','            // Mutant omits cooldown interval.')
case('skip-covered-log-events','temporal_covered_log_cutoff_refuses_with_safe_applied','                        event(&recorded.event)?;','''                        if applied_position.is_none_or(|position| entry.log_id.index > position.index) {
                            event(&recorded.event)?;
                        }''')
case('skip-uncommitted-log-rows','temporal_uncommitted_suffix_cutoff_refuses_before_replay','''                let entry = decode_log(domain.epoch, key.value(), value.value())?;''','''                let entry = decode_log(domain.epoch, key.value(), value.value())?;
                if committed.is_none_or(|position| entry.log_id.index > position.index) {
                    continue;
                }''')
case('skip-stateless-submit','temporal_rejected_covered_submit_requires_captured_payload','        Event::Submit { request: value, .. } => request(value),','        Event::Submit { .. } => Ok(()),')
case('redundant-finite-max-guard','temporal_maximum_finite_deadline_is_not_omitted','''                if deadline == u64::MAX {
                    return Err(failure(
                        ErrorVerb::Read,
                        "finite canonical timeout saturated",
                    ));
                }''','                // Mutant omits explicit finite MAX refusal.','expected survival: remaining finite anchor range independently rejects MAX at admitted clock')
case('redundant-intermediate-state','temporal_invalid_request_cannot_disappear_inside_a_batch','''                            state(&staged_state)?;''','''                            // Mutant omits intermediate poststate validation.''','expected survival: stateless Submit admission independently rejects this request')
case('redundant-stateless-submit','temporal_invalid_request_cannot_disappear_inside_a_batch','        Event::Submit { request: value, .. } => request(value),','        Event::Submit { .. } => Ok(()),','expected survival: intermediate poststate admission independently rejects this accepted request')
case('drop-io-queue-guard','temporal_cancelled_audit_retains_owned_journal_queue','            let _guard = guard;','            drop(guard);','queue custody assertion must fail after cancellation',path='nativelink-scheduler/src/authority/journal.rs')
j={'status':'Proposed compiled mutation matrix, no mutants executed yet. Prediction is not observation.','source_manifest_sha256':'5456cede34f6b74b44617b9309ff03e2766f4e7acbdf4d8797a50ec581cfd1bb','cases':cases};f=r/'mutant-plan.json';f.write_text(json.dumps(j,indent=2)+'\n');print(f,hashlib.sha256(f.read_bytes()).hexdigest(),len(cases))
