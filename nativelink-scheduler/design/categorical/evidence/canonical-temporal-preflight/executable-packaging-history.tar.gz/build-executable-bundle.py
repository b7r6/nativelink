#!/usr/bin/env python3
import gzip
import hashlib
import json
import pathlib
import tarfile

SOURCE = pathlib.Path('/tmp/nativelink-canonical-temporal-preflight-evidence')
OUTPUT = pathlib.Path('/tmp/nativelink-canonical-temporal-preflight/nativelink-scheduler/design/categorical/evidence/canonical-temporal-preflight')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


original = json.loads((OUTPUT / 'manifest.json').read_text())
unique = {}
for entry in original['external_executables']:
    source = SOURCE / entry['path']
    assert source.stat().st_size == entry['bytes'] and digest(source) == entry['sha256']
    with source.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
    unique.setdefault(entry['sha256'], entry)
assert len(unique) == 19
archives = []
items = sorted(unique.items())
for index, start in enumerate(range(0, len(items), 5)):
    group = items[start:start + 5]
    archive = OUTPUT / f'executable-evidence-{index:03}.tar.gz'
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                for key, entry in group:
                    info = tarfile.TarInfo('elf/' + key)
                    info.size = entry['bytes']
                    info.mode = 0o755
                    info.mtime = 0
                    with (SOURCE / entry['path']).open('rb') as stream:
                        tar.addfile(info, stream)
    assert archive.stat().st_size < 45 * 1024 * 1024
    archives.append({'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive), 'members': ['elf/' + key for key, _ in group]})
manifest = {
    'scope': 'Relocatable executable bytes for the sealed canonical temporal admission evidence. No additional execution or Cargo qualification is claimed.',
    'source_packet_manifest': {'path': 'manifest.json', 'sha256': digest(OUTPUT / 'manifest.json')},
    'source_packet_archive': {'path': original['archive'], 'sha256': original['archive_sha256']},
    'verifier': {'path': 'verify-executables.py', 'sha256': digest(OUTPUT / 'verify-executables.py')},
    'archive_limit_bytes': 45 * 1024 * 1024,
    'archives': archives,
    'distinct_executable_count': len(unique),
    'alias_count': len(original['external_executables']),
    'executables': [{'member': 'elf/' + key, 'bytes': entry['bytes'], 'sha256': key} for key, entry in sorted(unique.items())],
    'aliases': original['external_executables'],
    'interpretation': 'Nineteen distinct ELF files reproduce twenty-two retained paths: original baseline; initial focused fixed runtime; final library and external API; fifteen distinct compiled mutant sources; and restored library/API. The repeated stateless-submit mutation and restored binaries are content deduplicated. The compile-only rejected interest mutant produced no ELF and is recorded in the original source/log packet.',
}
(OUTPUT / 'executables-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'total_archive_bytes': sum(entry['bytes'] for entry in archives), 'archives': archives, 'manifest_sha256': digest(OUTPUT / 'executables-manifest.json')}, indent=2))
