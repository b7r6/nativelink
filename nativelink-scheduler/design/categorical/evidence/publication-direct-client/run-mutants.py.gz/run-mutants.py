from pathlib import Path
import os,subprocess,json,hashlib
root=Path('/tmp/nativelink-publication-direct-client');e=Path('/tmp/nativelink-categorical-evidence/publication-direct-client')
p=root/'nativelink-scheduler/tests/publication_candidate/direct_client.rs';original=p.read_text()
mutants=[
 ('foreign-context','if &grant.binding != binding || &binding.context != context || grant.revoked_at.is_some() {','if &grant.binding != binding || grant.revoked_at.is_some() {'),
 ('ignored-revocation','grant.revoked_at = Some(next.metadata.commit);','let _ = next.metadata.commit;'),
 ('noncanonical-response','''if result.exit_code != 0
                || response != &expected
                || candidate
                    .response
                    .require_response()
                    .map_err(|_| Error::Invalid)?
                    .encoded()
                    != expected.encode_to_vec()''','if result.exit_code != 0'),
 ('stage-before-grant','''if at > grant.issued_at
                    && at <= self.metadata.commit''','if at <= self.metadata.commit'),
 ('acceptance-after-revoke','''            || grant
                .revoked_at
                .is_some_and(|revoked| accepted.commit >= revoked)''',''),
]
env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/nativelink-history-mutations-target';env['CARGO_BUILD_JOBS']='8'
command=['cargo','test','--locked','--offline','--profile=smol','-p','nativelink-scheduler','--test','publication_candidate_test','direct_client','--','--nocapture']
results=[]
try:
 for name,old,new in mutants:
  assert original.count(old)==1,(name,original.count(old))
  source=original.replace(old,new);p.write_text(source)
  d=e/'mutants'/name;d.mkdir(parents=True,exist_ok=True);(d/'direct_client.rs').write_text(source)
  with (d/'test.log').open('w') as log:
   rc=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
  output=(d/'test.log').read_text();compiled='Finished `smol` profile' in output
  killed=rc!=0 and compiled and 'test result: FAILED.' in output
  result={'name':name,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'returncode':rc,'compiled':compiled,'killed':killed,'log_sha256':hashlib.sha256(output.encode()).hexdigest()}
  results.append(result);(e/'mutants.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
 p.write_text(original)
assert all(r['killed'] for r in results)
