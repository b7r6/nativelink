from pathlib import Path
import subprocess,json,hashlib,os,time,shutil
root=Path.cwd();out=Path('/tmp/nativelink-canonical-owner-root-integration/sync-run');out.mkdir(exist_ok=True)
names=[n for n in subprocess.check_output(['git','ls-files','-z'],text=True).split('\0') if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]
def snapshot():return {n:hashlib.sha256(os.readlink(root/n).encode() if (root/n).is_symlink() else (root/n).read_bytes()).hexdigest() for n in names}
def write(n,data):(out/n).write_text(json.dumps(data,indent=2)+'\n')
before=snapshot();write('sources-before.json',before)
(out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
binary=Path('/tmp/nativelink-canonical-owner-root-integration/api-dependency-corrected/binaries/nativelink-scheduler/unit_test')
cmd=['python','tools/test-canonical-owner-sync.py','--test-binary',str(binary),'--output',str(out/'matrix')]
write('command.json',cmd);t=time.monotonic()
with (out/'execution.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=snapshot();write('sources-after.json',after);assert before==after
result={'exit_code':code,'elapsed_seconds':time.monotonic()-t,'source_inputs_unchanged':len(before),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()};write('result.json',result)
shutil.copy2(__file__,out/'run.py');print(json.dumps(result),flush=True);raise SystemExit(code)
