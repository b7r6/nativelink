from pathlib import Path
import json,subprocess,hashlib,os,shutil,time,re
root=Path.cwd();out=Path('/tmp/nativelink-canonical-owner-root-integration/api-dependency-corrected');out.mkdir(exist_ok=True)
names=[n for n in subprocess.check_output(['git','ls-files','-z'],text=True).split('\0') if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]
def snapshot():return {n:hashlib.sha256(os.readlink(root/n).encode() if (root/n).is_symlink() else (root/n).read_bytes()).hexdigest() for n in names}
def write(n,data):(out/n).write_text(json.dumps(data,indent=2)+'\n')
before=snapshot();write('sources-before.json',before)
(out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True));(out/'status.txt').write_text(subprocess.check_output(['git','status','--porcelain'],text=True))
author=json.loads(Path('/tmp/nativelink-canonical-journal-owner-evidence/qualified-source.json').read_text())['files']
assert [n for n,h in author.items() if before[n]!=h]==['nativelink-scheduler/BUILD.bazel'];write('author-source-comparison.json',{'author_inputs':author,'root_inputs':{n:before[n] for n in author},'exact_inputs':16,'delta':'One missing tracing dependency added to external API Bazel test; runtime unchanged.'})
cmd=['bazel','test','--jobs=4','--local_test_jobs=1','--test_env=RUST_TEST_THREADS=1','--test_output=errors','--keep_going','--build_event_json_file='+str(out/'events.jsonl'),
'//nativelink-scheduler:unit_test','//nativelink-scheduler:canonical_owner_api_test','//tools/canonical-filesystem:ownership_test','//tools/canonical-filesystem:journal_test','//tools/canonical-filesystem:journal_bridge_test','//tools/canonical-store:canonical_store_test','//tools/canonical-store:fixed_digest_default_test','//nativelink-service:unit_test','//nativelink-service:integration_tests/authority_listener_test_test','//:nativelink']
assert os.environ.get('NL_FIXED_DIGEST_CASE') is None
write('command.json',cmd);t=time.monotonic()
with (out/'build-and-test.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
elapsed=time.monotonic()-t;after=snapshot();write('sources-after.json',after);assert before==after
summaries=[];counts=[0,0,0]
for line in (out/'events.jsonl').read_text().splitlines():
    row=json.loads(line)
    if 'testSummary' not in row:continue
    label=row['id']['testSummary']['label'];s=row['testSummary'];summaries.append({'label':label,'status':s['overallStatus'],'runs':s['totalRunCount'],'cached':s.get('totalNumCached',0),'duration':s['totalRunDuration']})
    p=label[2:].replace(':','/');dest=out/'testlogs'/p/'test.log';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'bazel-testlogs'/p/'test.log',dest)
    for result in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',dest.read_text()):counts=[a+int(b) for a,b in zip(counts,result)]
write('summaries.json',summaries)
result={'exit_code':code,'elapsed_seconds':elapsed,'targets':len(summaries),'passed':sum(s['status']=='PASSED' for s in summaries),'executed':sum(s['cached']==0 for s in summaries),'rust_counts_from_logs':counts,'source_inputs_unchanged':len(before)};write('result.json',result)
if code==0:
    for path in ['nativelink-scheduler/unit_test','nativelink-scheduler/canonical_owner_api_test']:
        dest=out/'binaries'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'bazel-bin'/path,dest)
print(json.dumps(result),flush=True);raise SystemExit(code)
