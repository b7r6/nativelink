from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('/tmp/nativelink-authority-listener-limits')
out=Path('/tmp/nativelink-categorical-evidence/authority-listener-wire-limits')
source=root/'nativelink-service/src/authority_listener.rs'
baseline=source.read_bytes()
env=os.environ.copy(); env.update(CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
command=['cargo','test','--manifest-path','tools/canonical-store/Cargo.toml','--locked','--offline','--profile','smol','-j8','--lib']
results=[]
def run(name,contents,filter_name=None,expected=0,marker=None):
    source.write_bytes(contents)
    scenario=out/name; scenario.mkdir(exist_ok=True)
    (scenario/'authority_listener.rs').write_bytes(contents)
    args=command+([filter_name,'--','--exact'] if filter_name else [])
    with (scenario/'cargo.log').open('wb') as log:
        completed=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    log=(scenario/'cargo.log').read_text()
    result={'name':name,'command':args,'exit_code':completed.returncode,'runtime_sha256':hashlib.sha256(contents).hexdigest()}
    matches=re.findall(r'Running unittests src/lib.rs \(([^)]+)\)',log)
    if matches:
        binary=Path(matches[-1]); shutil.copy2(binary,scenario/'test-binary')
        result['binary_sha256']=hashlib.sha256((scenario/'test-binary').read_bytes()).hexdigest()
    if marker: result['expected_marker_seen']=marker in log
    results.append(result); (out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    assert completed.returncode==expected,(name,completed.returncode)
    assert not marker or marker in log,(name,'missing witness marker')
try:
    run('baseline',baseline)
    decode=baseline.replace(b'.max_decoding_message_size(CACHE_MESSAGE_BYTES)',b'.max_decoding_message_size(2 * CACHE_MESSAGE_BYTES)')
    assert decode!=baseline
    run('decode-mutant',decode,'tests::listener::fixed_roles_refuse_oversized_malformed_and_compressed_writes_without_files',101,'called `Result::unwrap_err()` on an `Ok` value')
    encode=baseline.replace(b'.max_encoding_message_size(CACHE_MESSAGE_BYTES)',b'.max_encoding_message_size(2 * CACHE_MESSAGE_BYTES)')
    assert encode!=baseline
    run('encode-mutant',encode,'tests::listener::fixed_roles_refuse_large_encoded_responses_after_backend_reads',101,'oversized CAS response must fail during encoding')
    compression=baseline.replace(b'let compression = RemoteCacheCompressionInstances::default();',b'let compression = RemoteCacheCompressionInstances::from_enabled_instance_names([config.instance.clone()]);')
    assert compression!=baseline
    run('compression-mutant',compression,'tests::listener::fixed_roles_refuse_oversized_malformed_and_compressed_writes_without_files',101,'Expected the disabled-compression guard')
finally:
    source.write_bytes(baseline)
run('restored',baseline)
