from pathlib import Path
import subprocess,json,hashlib,shutil
root=Path.cwd(); out=Path(__file__).parent
names=set(json.loads(Path('/tmp/nativelink-categorical-evidence/authority-quantized-deadline/sources-before.json').read_text()))|{'tools/canonical-store/src/tests/listener.rs','nativelink-service/tests/authority_listener/limits.rs'}
def sources():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
before=sources(); (out/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n'); (out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','//nativelink-service:integration_tests/authority_listener_test_test','//tools/canonical-store:canonical_store_test','//:nativelink'];(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'bazel.log').open('w') as f: code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
for target in cmd:
 if target.startswith('//') and target!='//:nativelink':
  p=target[2:].replace(':','/');dest=out/'testlogs'/p/'test.log';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'bazel-testlogs'/p/'test.log',dest)
if code==0:
 binary=root/'bazel-bin/nativelink-service/integration_tests/authority_listener_test_test'
 cmd=['python3','tools/test-authority-listener-tls.py','--test-binary',str(binary),'--output',str(out/'tls')]
 with (out/'tls-driver.log').open('w') as f: code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 (out/'tls-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
after=sources(); (out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n'); assert before==after
print('exit',code,'inputs',len(before));raise SystemExit(code)
