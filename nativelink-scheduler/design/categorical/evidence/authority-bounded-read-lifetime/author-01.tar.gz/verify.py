from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/tmp/nativelink-authority-bounded-read-lifetime')
OUT = Path(__file__).parent
stage = sys.argv[1]
env = os.environ.copy()
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_TARGET_DIR'] = '/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
options = ['--locked', '--offline', '--profile', 'smol', '-j8']
commands = [
    ('service', ['cargo', 'test', *options, '-p', 'nativelink-service', '--lib', '--test', 'authority_listener_test']),
    ('canonical', ['cargo', 'test', *options, '--manifest-path', 'tools/canonical-store/Cargo.toml', '--lib']),
]
if stage == 'fixed':
    commands.append(('clippy', ['cargo', 'clippy', *options, '-p', 'nativelink-service', '--lib', '--test', 'authority_listener_test', '--', '-D', 'warnings']))
manifest = json.loads((OUT / 'fixed-source/manifest.json').read_text())
def exact_source():
    for name, sha in manifest['inputs'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
exact_source()
results = []
for name, command in commands:
    started = time.time()
    path = OUT / f'{stage}-{name}.log'
    with path.open('w') as log:
        run = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    log = path.read_text()
    binaries = []
    for match in re.finditer(r'Running [^\n]+ \((/[^\n]+)\)', log):
        src = Path(match.group(1)); dst = OUT / f'{stage}-{name}-{src.name}'
        shutil.copy2(src, dst)
        binaries.append({'name': dst.name, 'sha256': hashlib.sha256(dst.read_bytes()).hexdigest()})
    result = {'name': name, 'command': command, 'exit': run.returncode, 'elapsed_seconds': time.time() - started, 'binaries': binaries}
    results.append(result)
    (OUT / f'{stage}-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    print(log[-5000:], flush=True)
    assert run.returncode == 0
    exact_source()
