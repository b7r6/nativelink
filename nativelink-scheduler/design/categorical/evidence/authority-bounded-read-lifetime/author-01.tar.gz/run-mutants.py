from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

ROOT = Path('/tmp/nativelink-authority-bounded-read-lifetime')
OUT = Path(__file__).parent / 'mutants'
OUT.mkdir(exist_ok=True)
SOURCE = ROOT / 'nativelink-service/src/authority_server.rs'
original = SOURCE.read_bytes()
text = original.decode()
env = os.environ.copy()
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_TARGET_DIR'] = '/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
base = ['cargo', 'test', '--locked', '--offline', '--profile', 'smol', '-j8', '-p', 'nativelink-service', '--lib']
mutants = [
    ('ignore_error_after_eof',
     '        drop(writer);\n        result\n    };\n    let collect = async move {',
     '        let closed = writer.is_pipe_broken();\n        drop(writer);\n        if closed { Ok(()) } else { result }\n    };\n    let collect = async move {',
     'producer_failure_is_preserved_before_and_after_eof',
     'The pre-EOF error control passes, then EOF-followed-by-error is incorrectly accepted.'),
    ('wait_for_pending_producer_on_excess',
     '    let ((), bytes) = futures::try_join!(download, collect)?;',
     '    let (producer, collected) = futures::join!(download, collect);\n    producer?;\n    let bytes = collected?;',
     'excess_bytes_cancel_pending_producer_without_draining',
     'The first excess-byte case waits for a pending producer instead of returning ResourceExhausted and cancelling it.'),
    ('double_actual_byte_bound',
     '            if chunk.len() > FRAME_BYTES.saturating_sub(bytes.len()) {',
     '            if chunk.len() > FRAME_BYTES.saturating_mul(2).saturating_sub(bytes.len()) {',
     'excess_bytes_cancel_pending_producer_without_draining',
     'The first 64KiB+1 actual chunk is admitted despite the collector limit; the pending producer makes the caller timeout.'),
]
results = []
try:
    for name, before, after, test, claim in mutants:
        assert text.count(before) == 1, name
        d = OUT / name
        d.mkdir(exist_ok=True)
        mutated = text.replace(before, after).encode()
        SOURCE.write_bytes(mutated)
        (d / 'authority_server.rs').write_bytes(mutated)
        command = base + ['authority_server::storage_read_tests::' + test, '--', '--exact', '--nocapture']
        started = time.time()
        with (d / 'execution.log').open('w') as log:
            run = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        log = (d / 'execution.log').read_text()
        match = re.search(r'Running unittests src/lib.rs \(([^\n]+)\)', log)
        record = {'name': name, 'command': command, 'exit': run.returncode,
                  'elapsed_seconds': time.time() - started,
                  'source_sha256': hashlib.sha256(mutated).hexdigest(),
                  'compiled_and_executed': match is not None,
                  'claim': claim}
        if match:
            shutil.copy2(Path(match.group(1)), d / 'test-binary')
            record['binary_sha256'] = hashlib.sha256((d / 'test-binary').read_bytes()).hexdigest()
        record['detected'] = match is not None and run.returncode == 101 and 'test result: FAILED. 0 passed; 1 failed;' in log
        (d / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
        results.append(record)
        print(json.dumps(record), flush=True)
        assert record['detected'], log[-6000:]
finally:
    SOURCE.write_bytes(original)
    restored = SOURCE.read_bytes() == original
    (OUT / 'results.json').write_text(json.dumps({'results': results, 'restored': restored, 'fixed_source_sha256': hashlib.sha256(original).hexdigest()}, indent=2) + '\n')
    assert restored
