from pathlib import Path
import hashlib,json,struct,sys
preimage=bytearray(b"nativelink.canonical.namespace.v1\0")
preimage.extend(struct.pack("<I",1))
def text(value):
    encoded=value.encode("utf-8")
    preimage.extend(struct.pack("<I",len(encoded)))
    preimage.extend(encoded)
text("build-μ")
preimage.extend(struct.pack("<QQQ",0x0102030405060708,9,10))
for value in ["team","cas-A","ac-B"]: text(value)
preimage.extend(struct.pack("<Q",11))
text("exec-v1")
for role in range(1,5): preimage.extend(struct.pack("<BQQ",role,99+role,199+role))
assert len(preimage)==186
assert hashlib.sha256(preimage).hexdigest()=="598bb3c09d370046b3e07583476c659b191d272b02b192238cf24c1095e2be34"
assert bytes(preimage)==Path(sys.argv[1]).read_bytes()
print(json.dumps({"bytes":len(preimage),"sha256":hashlib.sha256(preimage).hexdigest(),"verified":sys.argv[1]}))
