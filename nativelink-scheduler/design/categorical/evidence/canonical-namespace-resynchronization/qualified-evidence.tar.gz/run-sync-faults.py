from pathlib import Path
import hashlib,json,os,re,subprocess,sys
binary=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve(); out.mkdir(parents=True,exist_ok=True)
test="tests::namespace::resynchronization_result_preserves_records_and_allows_explicit_retry"
roles=["journal/.nativelink-namespace-v1.json","journal","cas/.nativelink-namespace-v1.json","cas","sink/.nativelink-namespace-v1.json","sink","worker/.nativelink-namespace-v1.json","worker"]
results=[]
for case in [None,*range(8),"late-invalid"]:
    name="success" if case is None else "late-invalid" if case=="late-invalid" else f"sync-error-{case+1}"
    trace=out/f"{name}.strace"
    command=["strace","-f","-qq","-yy","-e","trace=fsync","-o",str(trace)]
    env=os.environ.copy()
    if isinstance(case,int):
        command += ["-e",f"inject=fsync:error=EIO:when={9+case}"]
        env["NL_NAMESPACE_TEST_EXPECT_SYNC_ERROR"]="sync_record" if case%2==0 else "sync_directory"
    selected="tests::namespace::invalid_last_record_refuses_before_any_sync" if case=="late-invalid" else test
    command += [str(binary),"--exact",selected,"--test-threads=1","--nocapture"]
    result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=out/f"{name}.log"; log.write_bytes(result.stdout)
    parsed=[]
    for line in trace.read_text().splitlines():
        match=re.match(r"^(\d+)\s+fsync\(\d+<([^>]*)>\)\s+= (.*)$",line)
        if match:
            path=match.group(2)
            relative=path.split("/nativelink-namespace-",1)[1].split("/",1)[1]
            parsed.append({"pid":int(match.group(1)),"path":relative,"result":match.group(3)})
    expected=roles if case=="late-invalid" else roles*3 if case is None else roles+roles[:case+1]+roles
    assert result.returncode==0,(name,result.returncode,result.stdout.decode())
    assert "1 passed; 0 failed" in result.stdout.decode(),name
    assert [entry["path"] for entry in parsed]==expected,(name,parsed,expected)
    assert len({entry["pid"] for entry in parsed})==1,(name,parsed)
    failures=[index for index,entry in enumerate(parsed) if entry["result"]!="0"]
    assert failures==([] if not isinstance(case,int) else [8+case]),(name,failures)
    if isinstance(case,int): assert "EIO" in parsed[8+case]["result"] and "INJECTED" in parsed[8+case]["result"]
    results.append({"name":name,"command":command,"environment":{key:value for key,value in env.items() if key.startswith("NL_NAMESPACE_TEST_")},"exit_code":result.returncode,"syncs":parsed,"trace_sha256":hashlib.sha256(trace.read_bytes()).hexdigest(),"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()})
receipt={"binary":str(binary),"binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),"cases":results,"claim":"actual targeted fsync EIOs and exact observed syscall sequence, not power-loss recovery"}
(out/"results.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"passed":len(results),"receipt":str(out/"results.json")}))
