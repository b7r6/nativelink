from pathlib import Path
import hashlib, struct
p = b"nativelink.canonical.namespace.v1\0" + struct.pack("<I", 1)
def s(value):
    value = value.encode("utf-8")
    return struct.pack("<I", len(value)) + value
p += s("build-μ") + struct.pack("<QQQ", 0x0102030405060708, 9, 10)
p += s("team") + s("cas-A") + s("ac-B") + struct.pack("<Q", 11) + s("exec-v1")
p += b"".join(struct.pack("<BQQ", role, role + 99, role + 199) for role in range(1, 5))
fixture = Path(__file__).parent / "source/tools/canonical-filesystem/fixtures/namespace-v1.preimage"
assert len(p) == 186
assert p == fixture.read_bytes()
assert hashlib.sha256(p).hexdigest() == "598bb3c09d370046b3e07583476c659b191d272b02b192238cf24c1095e2be34"
print("PASS: independent 186-byte preimage matches fixture and fixed SHA-256")
