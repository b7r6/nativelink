from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

repo = Path('/tmp/nativelink-canonical-namespace-resync')
out = Path('/tmp/nativelink-canonical-namespace-resync-evidence/mutants')
out.mkdir(parents=True, exist_ok=True)
cargo = '/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo'
namespace = repo / 'tools/canonical-filesystem/src/namespace.rs'
library = repo / 'tools/canonical-filesystem/src/lib.rs'
originals = {namespace: namespace.read_bytes(), library: library.read_bytes()}
env = os.environ.copy()
env['CARGO_TARGET_DIR'] = '/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target'
env['CARGO_INCREMENTAL'] = '0'
test_prefix = 'tests::namespace::'
mutants = [
    ('omit-node', namespace, '        digest.update(self.node.to_le_bytes());\n', '',
     'every_bound_field_changes_the_commitment_or_refuses_invalid_roots', False),
    ('omit-record-sync', namespace,
     '            record.sync_all().map_err(|_| failure("sync_record"))?;\n',
     '            let _ = record;\n',
     'resynchronization_result_preserves_records_and_allows_explicit_retry', True),
    ('omit-parent-sync', namespace,
     '            fsync(&root.descriptor).map_err(|_| failure("sync_directory"))?;\n',
     '            let _ = root;\n',
     'resynchronization_result_preserves_records_and_allows_explicit_retry', True),
    ('omit-last-binding-check', library,
     '        if record != self.record(root.role) {\n',
     '        if record != self.record(root.role) && root.role != Role::Worker {\n',
     'invalid_last_record_refuses_before_any_sync', False),
    ('release-custody-before-sync', namespace,
     '        let commitment = self.binding.namespace_commitment()?;\n',
     '        let commitment = self.binding.namespace_commitment()?;\n'
     '        for root in &self.roots {\n'
     '            rustix::fs::flock(&root.descriptor, rustix::fs::FlockOperation::Unlock).unwrap();\n'
     '        }\n',
     'dropped_waiter_keeps_blocking_operation_custody_until_completion', False),
    ('weak-token-custody', namespace, None, None,
     'namespace_token_alone_retains_every_role_lock', False),
]
attempts = []
try:
    for name, path, old, new, test, syscall_fault in mutants:
        for source, data in originals.items():
            source.write_bytes(data)
        current = path.read_text()
        if name == 'weak-token-custody':
            assert current.count('_ownership: Arc<Ownership>') == 1
            assert current.count('_ownership: self,') == 1
            current = current.replace('_ownership: Arc<Ownership>', '_ownership: std::sync::Weak<Ownership>')
            current = current.replace('_ownership: self,', '_ownership: Arc::downgrade(&self),')
        else:
            assert current.count(old) == 1, name
            current = current.replace(old, new)
        path.write_text(current)
        case = out / name
        case.mkdir(exist_ok=True)
        source_file = case / path.name
        source_file.write_bytes(path.read_bytes())
        build_command = [cargo, 'test', '--manifest-path', 'tools/canonical-filesystem/Cargo.toml',
                         '--locked', '--offline', '--profile', 'smol', '--all-features', '--lib',
                         '-j8', '--no-run', '--message-format=json']
        build = subprocess.run(build_command, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (case / 'build.log').write_bytes(build.stdout)
        artifacts = []
        for line in build.stdout.decode().splitlines():
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            if message.get('reason') == 'compiler-artifact' and message.get('executable') and message['target']['name'] == 'nativelink_canonical_filesystem':
                artifacts.append(message)
        attempt = {'name': name, 'source_path': str(path.relative_to(repo)),
                   'mutated_source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                   'build_command': build_command, 'build_exit': build.returncode,
                   'build_log_sha256': hashlib.sha256(build.stdout).hexdigest()}
        attempts.append(attempt)
        (out / 'attempts.json').write_text(json.dumps(attempts, indent=2) + '\n')
        assert build.returncode == 0 and len(artifacts) == 1, (name, 'compilation failed; not a detected fault')
        assert not artifacts[0]['fresh'], (name, 'mutated source was not recompiled')
        binary = case / 'test-binary'
        shutil.copy2(artifacts[0]['executable'], binary)
        attempt['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        attempt['compiler_observed'] = True
        command = [str(binary), '--exact', test_prefix + test, '--test-threads=1', '--nocapture']
        run_env = env.copy()
        if syscall_fault:
            command = ['strace', '-f', '-qq', '-yy', '-e', 'trace=fsync',
                       '-e', 'inject=fsync:error=EIO:when=16', '-o', str(case / 'execution.strace')] + command
            run_env['NL_NAMESPACE_TEST_EXPECT_SYNC_ERROR'] = 'sync_directory'
        result = subprocess.run(command, cwd=repo, env=run_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (case / 'execution.log').write_bytes(result.stdout)
        attempt.update({'execution_command': command, 'execution_exit': result.returncode,
                        'execution_log_sha256': hashlib.sha256(result.stdout).hexdigest(),
                        'detected': result.returncode == 101 and b'test result: FAILED' in result.stdout})
        (out / 'attempts.json').write_text(json.dumps(attempts, indent=2) + '\n')
        assert attempt['detected'], (name, result.returncode, result.stdout.decode())
        print(json.dumps({'name': name, 'compiled': True, 'detected': True}), flush=True)
finally:
    for source, data in originals.items():
        source.write_bytes(data)
    restoration = {str(source.relative_to(repo)): hashlib.sha256(source.read_bytes()).hexdigest() for source in originals}
    (out / 'restoration.json').write_text(json.dumps(restoration, indent=2) + '\n')
