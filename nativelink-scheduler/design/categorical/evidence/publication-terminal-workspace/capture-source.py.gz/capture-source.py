from pathlib import Path
import hashlib, json, subprocess, sys
root = Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03')
paths = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=root).decode().split('\0')
selected = {}
for name in sorted(set(paths)):
    if not name:
        continue
    path = root / name
    if not path.is_file() or path.is_symlink():
        continue
    if path.suffix in {'.rs', '.bazel', '.bzl', '.proto'} or path.name in {'Cargo.toml', 'Cargo.lock', '.bazelrc', '.bazelversion', 'rust-toolchain.toml', '.rustfmt.toml', 'clippy.toml'}:
        selected[name] = hashlib.sha256(path.read_bytes()).hexdigest()
value = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(), 'source_sha256': selected}
Path(sys.argv[1]).write_text(json.dumps(value, indent=2) + '\n')
print(f'{len(selected)} source/build/config files recorded')
