import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

WORK = Path('/tmp/nativelink-journal-capability')
OUT = Path('/tmp/nativelink-journal-capability-evidence')
SOURCE = WORK / 'tools/canonical-filesystem/src/journal.rs'
CARGO = '/nix/store/16iqjcbihzjbj6hdr7iqwdqzgwrwgrzr-rust-default-1.97.1/bin/cargo'
ENV = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-journal-capability-target', CARGO_INCREMENTAL='0')
ARGS = [CARGO, 'test', '--locked', '--offline', '--profile', 'smol', '-j8', '--manifest-path', 'tools/canonical-filesystem/Cargo.toml', '--features', 'redb', '--lib']
original = SOURCE.read_bytes()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def run(args, path, env=ENV):
    with path.open('wb') as log:
        completed = subprocess.run(args, cwd=WORK, env=env, stdout=log, stderr=subprocess.STDOUT)
    return completed.returncode

mutations = [
    ('existing_empty_initializes', [('if length == 0 && !self.created {', 'if length == u64::MAX && !self.created {')], 'journal::tests::empty_file_is_rechecked_by_redb_after_backend_open', False),
    ('backend_drops_namespace_custody', [('_ownership: Arc::clone(&self.ownership),', '_ownership: None,'), ('_ownership: Arc<Ownership>,', '_ownership: Option<Arc<Ownership>>,')], 'journal::tests::database_alone_retains_every_role_and_redb_exclusion', False),
    ('parent_sync_omitted', [('fsync(journal_root(&self.0))?;', 'let _root = journal_root(&self.0);')], 'journal::tests::parent_sync_result_preserves_initialized_file', True),
]
results = []
try:
    for name, replacements, test, inject in mutations:
        folder = OUT / 'mutations' / name
        folder.mkdir(parents=True, exist_ok=True)
        text = original.decode()
        for before, after in replacements:
            assert text.count(before) == 1, (name, before)
            text = text.replace(before, after)
        mutated = text.encode()
        SOURCE.write_bytes(mutated)
        (folder / 'journal.rs').write_bytes(mutated)
        compile_args = ARGS + ['--no-run', '--message-format=json']
        compile_status = run(compile_args, folder / 'compile.log')
        if compile_status != 0:
            raise RuntimeError(f'{name} did not compile; not counted as detection')
        executables = []
        for line in (folder / 'compile.log').read_text().splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if item.get('reason') == 'compiler-artifact' and item.get('executable'):
                executables.append(item['executable'])
        assert len(executables) == 1, executables
        executable = Path(executables[0])
        shutil.copy2(executable, folder / 'test-executable')
        test_args = [str(executable), '--exact', test, '--test-threads=1', '--nocapture']
        env = ENV
        if inject:
            env = dict(ENV, NL_JOURNAL_TEST_EXPECT_PARENT_SYNC_EIO='1')
            test_args = ['/run/current-system/sw/bin/strace', '-f', '-yy', '-e', 'trace=fsync,fdatasync', '-e', 'inject=fsync:error=EIO:when=9', '-o', str(folder / 'sync.strace')] + test_args
        test_status = run(test_args, folder / 'test.log', env)
        output = (folder / 'test.log').read_text()
        assert test_status == 101 and 'test result: FAILED' in output and 'panicked at' in output, (name, test_status, output)
        results.append(dict(name=name, replacements=replacements, compile_command=compile_args,
                            compile_exit=compile_status, test_command=test_args, test_exit=test_status,
                            test=test, source_sha256=digest(mutated), executable_sha256=digest(executable.read_bytes()),
                            expected_sync_fault=inject, detected=True))
        print(json.dumps(results[-1]), flush=True)
finally:
    SOURCE.write_bytes(original)
    assert digest(SOURCE.read_bytes()) == digest(original)
    (OUT / 'mutation-results.json').write_text(json.dumps(dict(baseline_sha256=digest(original), results=results, restored=True), indent=2) + '\n')

restored_status = run(ARGS + ['--', '--test-threads=1'], OUT / 'fs-restored.log')
assert restored_status == 0
print('restored suite passed', flush=True)
