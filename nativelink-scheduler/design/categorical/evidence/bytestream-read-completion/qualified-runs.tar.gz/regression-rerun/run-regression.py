from pathlib import Path
import json,subprocess,hashlib,os,shutil
out=Path(__file__).parent;root=Path.cwd();names=[n for n in subprocess.check_output(['git','ls-files','-z'],text=True).split('\0')if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]
def snapshot():return {n:hashlib.sha256(os.readlink(root/n).encode()if(root/n).is_symlink()else(root/n).read_bytes()).hexdigest()for n in names}
before=snapshot();(out/'regression-sources-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'regression-head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True));(out/'regression-status.txt').write_text(subprocess.check_output(['git','status','--porcelain'],text=True))
cmd=['bazel','test','--jobs=4','--local_test_jobs=1','--test_env=RUST_TEST_THREADS=1','--test_output=errors','--keep_going','--build_event_json_file='+str(out/'regression-events.jsonl'),'//nativelink-service:unit_test','//nativelink-service:integration_tests/bytestream_server_test_test','//nativelink-service:integration_tests/wire_compression_test_test','//nativelink-service:integration_tests/grpc_wire_compression_test_test','//nativelink-service:integration_tests/authority_listener_test_test','//tools/canonical-store:canonical_store_test','//:nativelink'];(out/'regression-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'regression.log').open('w')as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=snapshot();(out/'regression-sources-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
summaries=[]
for line in (out/'regression-events.jsonl').read_text().splitlines():
 row=json.loads(line)
 if 'testSummary'not in row:continue
 label=row['id']['testSummary']['label'];s=row['testSummary'];summaries.append({'label':label,'status':s['overallStatus'],'runs':s['totalRunCount'],'cached':s.get('totalNumCached',0),'duration':s['totalRunDuration']});p=label[2:].replace(':','/');dest=out/'regression-testlogs'/p/'test.log';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'bazel-testlogs'/p/'test.log',dest)
(out/'regression-summaries.json').write_text(json.dumps(summaries,indent=2)+'\n')
if code==0:shutil.copy2(root/'bazel-bin/nativelink-service/unit_test',out/'final-test-binary')
print('exit',code,'targets',len(summaries),'unchanged',len(before),flush=True);raise SystemExit(code)
