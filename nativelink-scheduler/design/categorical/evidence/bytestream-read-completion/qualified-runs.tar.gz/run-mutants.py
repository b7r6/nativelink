from pathlib import Path
import subprocess,json,hashlib,shutil,re
out=Path(__file__).parent;runtime=Path('nativelink-service/src/bytestream_server.rs');fixed=runtime.read_text();sources=json.loads((out/'qualified-source/manifest.json').read_text())['inputs'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,v in sources.items():assert h(Path(n))==v
mutants=[('ignore_awaited_error','None => state.get_part_fut.await,','None => state.get_part_fut.await.or(Ok(())),','http2_reports_late_backend_failure_after_delivered_bytes'),('acknowledge_pending_producer','None => state.get_part_fut.await,','None => Ok(()),','eof_waits_for_producer_and_stream_cancellation_releases_it')]
results=json.loads((out/'mutant-results.json').read_text())['results']
try:
 for name,old,new,oracle in mutants:
  assert fixed.count(old)==1,(name,fixed.count(old));path=out/'mutants'/name;path.mkdir(parents=True,exist_ok=True);runtime.write_text(fixed.replace(old,new));shutil.copyfile(runtime,path/'bytestream_server.rs')
  cmd=['bazel','test','--jobs=8','--local_test_jobs=2','--test_env=RUST_TEST_THREADS=4','--test_output=errors','--test_arg=bytestream_server::read_completion_tests::','//nativelink-service:unit_test']
  with (path/'build-and-test.log').open('w')as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
  log=Path('bazel-testlogs/nativelink-service/unit_test/test.log');shutil.copyfile(log,path/'test.log');shutil.copy2('bazel-bin/nativelink-service/unit_test',path/'test-binary')
  text=(path/'test.log').read_text();match=re.search(r'test result: FAILED\. (\d+) passed; (\d+) failed;',text);executed='Executed 1 out of 1 tests' in (path/'build-and-test.log').read_text() or 'Executed 1 out of 1 test' in (path/'build-and-test.log').read_text();detected=code==3 and match is not None and '::'+oracle+' ... FAILED'in text and executed
  row={'name':name,'command':cmd,'exit_code':code,'compiled_and_executed':executed,'source_sha256':h(runtime),'fixture_sha256':h(Path('nativelink-service/src/bytestream_read_completion_tests.rs')),'binary_sha256':h(path/'test-binary'),'expected_oracle':oracle,'detected':detected,'rust_counts':list(map(int,match.groups()))if match else None};(path/'result.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row);print(name,'detected',detected,'counts',row['rust_counts'],flush=True);assert detected,row
finally:
 runtime.write_text(fixed)
 for n,v in sources.items():assert h(Path(n))==v,n
 (out/'mutant-results.json').write_text(json.dumps({'restored_source_hashes':sources,'results':results},indent=2)+'\n')
