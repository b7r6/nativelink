from pathlib import Path
import subprocess,hashlib,json,os,shutil
root=Path.cwd();out=Path(__file__).parent
names=[n for n in subprocess.check_output(['git','ls-files','-z'],text=True).split('\0') if n and not n.startswith('nativelink-scheduler/design/categorical/evidence/')]
def sources():
 result={}
 for n in names:
  p=root/n; data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();result[n]=hashlib.sha256(data).hexdigest()
 return result
before=sources();(out/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True));(out/'status-before.txt').write_text(subprocess.check_output(['git','status','--porcelain'],text=True))
cmd=['bazel','test','--jobs=4','--local_test_jobs=1','--test_env=RUST_TEST_THREADS=1','--test_output=errors','--keep_going','--build_event_json_file='+str(out/'events.jsonl'),'//...','//tools/canonical-config:parser_test','//tools/canonical-config:conversion_test','//tools/canonical-filesystem:ownership_test','//tools/canonical-filesystem:journal_test','//tools/canonical-filesystem:journal_bridge_test','//tools/canonical-store:canonical_store_test'];(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
print('full checkpoint starting',len(before),'tracked inputs',flush=True)
with (out/'bazel.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=sources();(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
summaries=[]
for line in (out/'events.jsonl').read_text().splitlines():
 row=json.loads(line)
 if 'testSummary' not in row:continue
 label=row['id']['testSummary']['label'];summary=row['testSummary'];summaries.append({'label':label,**summary})
 if label.startswith('//'):
  path=label[2:].replace(':','/');log=root/'bazel-testlogs'/path/'test.log'
  if log.is_file():
   dst=out/'testlogs'/path/'test.log';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(log,dst)
(out/'test-summaries.json').write_text(json.dumps(summaries,indent=2)+'\n');print('exit',code,'target summaries',len(summaries),'unchanged inputs',len(before));raise SystemExit(code)
