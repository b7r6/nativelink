#!/usr/bin/env python3
"""Compile each one-contract mutant before counting assertion-level kills."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-publication-activation-v2-reference')
evidence = Path('/tmp/nativelink-publication-activation-v2-evidence')
source = root / 'nativelink-scheduler/tests/publication_activation_v2/reference.rs'
original = source.read_text()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-differential-target')
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p',
           'nativelink-scheduler', '--test', 'publication_activation_v2_reference_test', '--no-run']
binary = Path(env['CARGO_TARGET_DIR']) / 'smol/deps/publication_activation_v2_reference_test-59b3769b6478cb81'

# All expectations and fixtures remain unchanged. Some invariants are checked
# both during reduction and restore; those coupled guards form one mutation.
mutants = [('omit-retained-effect-dispositions', [('activation.dispositions.keys().ne(legacy.effects.keys())', 'false', 1)]), ('alias-old-and-new-physical-domains', [('old.physical_domain == new.physical_domain', 'false', 2)]), ('ignore-exact-typed-closure', [('if proof.typed != root.required {', 'if false {', 1)]), ('ignore-current-retirement-fence', [('if !proof.fences.is_subset(&facts.fences) {', 'if false {', 1)]), ('retired-generation-is-ready', [('if row.state != Readiness::Ready {', 'if row.state == Readiness::Writing {', 1)]), ('settle-without-complete-effect-quiescence', [('if !self.quiesced_effects.contains(&effect)\n                            && !facts.quiescent_effects.contains(&effect)', 'if false', 1)]), ('empty-request-map-clears-opaque-effect', [('.filter(|effect| !self.quiesced_effects.contains(effect))', '.filter(|effect| !self.quiesced_effects.contains(effect) && requests(&self.legacy).keys().any(|request| effect_of(*request) == *effect))', 1)]), ('empty-outbox-clears-opaque-domain', [('!self.domain_quiesced\n    }', '!self.domain_quiesced && !self.legacy.effects.is_empty()\n    }', 1), ('pub(crate) const fn unresolved_legacy_domain', 'pub(crate) fn unresolved_legacy_domain', 1)]), ('revalidate-original-worker-at-import', [('if !facts.migration_publishers.contains(&import.publisher) {', 'let Provenance::RecordedWorkerAcceptance(origin) = self.legacy.terminals[&import.terminal].provenance else { return Err(Reject::Unauthorized); };\n                    if !facts.current_workers.contains(&(origin.worker, origin.incarnation)) || !facts.migration_publishers.contains(&import.publisher) {', 1)]), ('discard-preexisting-late-outcomes', [('observations: legacy.late_outcomes.clone(),', 'observations: BTreeSet::new(),', 1)]), ('late-old-sink-outcome-selects-head', [('if !self.observations.insert(Observation {', 'if request.kind == EffectKind::Sink && *outcome == Delivery::Stored {\n                    let terminal = self.legacy.effects[&request.effect].terminal;\n                    for head in &mut self.heads { head.terminal = terminal; }\n                }\n                if !self.observations.insert(Observation {', 1)]), ('ignore-physical-incarnation', [('.find(|row| row.key == *key)', '.find(|row| row.key.namespace == key.namespace && row.key.number == key.number)', 1), ('row.key == generation && row.object == member.object', 'row.key.namespace == generation.namespace && row.key.number == generation.number && row.object == member.object', 1)]), ('unknown-origin-refuses-protected-cold-activation', [('validate_value(&terminal.value)?;', 'if terminal.provenance == Provenance::Unrecorded { return Err(Reject::Unauthorized); }\n        validate_value(&terminal.value)?;', 1)]), ('classification-invents-worker-acceptance-for-import', [('let Provenance::RecordedWorkerAcceptance(origin) = terminal.provenance else {\n            return Err(Reject::Unauthorized);\n        };', 'let origin = match terminal.provenance { Provenance::RecordedWorkerAcceptance(origin) => origin, _ => Origin { epoch: 0, accepted_commit: Some(1), effect: None, execution: terminal.id, attempt: 1, worker: 0, incarnation: 0 } };', 1)]), ('overwrite-independent-cancellation-with-execution', [('self.namespaces = Some([*old, *new]);', 'self.namespaces = Some([*old, *new]);\n                for operation in self.legacy.operations.values_mut() { if operation.provenance == OperationProvenance::RecordedIndependentCancellation { operation.value = self.legacy.terminals[&operation.execution].value.clone(); } }', 1)]), ('accept-fabricated-forwarded-operation-origin', [('if execution.is_none_or(|terminal| terminal.value != operation.value) {', 'if false && execution.is_none_or(|terminal| terminal.value != operation.value) {', 1)]), ('missing-operation-owner-needs-no-root', [('if subjects != expected.keys().copied().collect() {', 'if expected.keys().filter(|subject| !matches!(subject, Subject::OperationResult(_))).any(|subject| !subjects.contains(subject)) {', 1)]), ('logical-terminal-time-is-an-acceptance-position', [('if activation.commit == 0', 'if legacy.terminals.values().any(|terminal| terminal.terminal_at.is_some_and(|time| time >= activation.commit)) || activation.commit == 0', 1)]), ('diagnostic-history-requires-action-result', [('|| !valid_origin(effect.origin, effect.terminal)', '|| terminal.value.result().is_none() || !valid_origin(effect.origin, effect.terminal)', 1)]), ('history-relabels-unknown-terminal-origin', [('self.namespaces = Some([*old, *new]);', 'self.namespaces = Some([*old, *new]);\n                for history in self.legacy.histories.values() { let terminal = self.legacy.terminals.get_mut(&history.terminal).ok_or(Reject::Invalid)?; if terminal.provenance == Provenance::Unrecorded { terminal.provenance = Provenance::RecordedWorkerAcceptance(history.origin); } }', 1)]), ('ignore-captured-response-fingerprint', [('|| <[u8; 32]>::from(Sha256::digest(&response.encoded)) != response.sha256', '|| false', 1)]), ('restore-forgets-original-operation-facts', [('restored.legacy != *original', 'restored.legacy.terminals != original.terminals', 1)]), ('recorded-effect-origin-requires-invented-commit', [('&& (origin.accepted_commit.is_some() || origin.effect.is_some())', '&& origin.accepted_commit.is_some()', 1)])]

def run(name, changed):
    folder = evidence / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    source.write_text(changed)
    (folder / 'reference.rs').write_text(changed)
    with (folder / 'compile.log').open('wb') as log:
        compile_result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'source_sha256': hashlib.sha256(changed.encode()).hexdigest(),
              'compile_command': command, 'compile_status': compile_result.returncode}
    if compile_result.returncode:
        result['classification'] = 'COMPILE_REJECTED_NOT_A_KILL'
    else:
        result['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        with (folder / 'test.log').open('wb') as log:
            test_result = subprocess.run([str(binary)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        result['test_status'] = test_result.returncode
        result['classification'] = 'PASS' if not test_result.returncode else 'COMPILED_ASSERTION_KILL'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

results = []
try:
    baseline = run('baseline', original)
    assert baseline['classification'] == 'PASS', baseline
    for name, replacements in mutants:
        changed = original
        for old, new, count in replacements:
            assert changed.count(old) == count, (name, old, changed.count(old), count)
            changed = changed.replace(old, new)
        results.append(run(name, changed))
finally:
    source.write_text(original)
    restored = run('restored', original)
    (evidence / 'mutation-results.json').write_text(json.dumps({
        'baseline': baseline, 'mutants': results, 'restored': restored,
        'source_restored_exactly': source.read_text() == original,
    }, indent=2) + '\n')

assert restored['classification'] == 'PASS', restored
assert all(result['classification'] == 'COMPILED_ASSERTION_KILL' for result in results), results
