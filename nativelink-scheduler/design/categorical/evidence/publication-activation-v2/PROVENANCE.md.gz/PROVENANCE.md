# Evidence provenance

This independent additive activation-v2 reference was authored in isolated
worktree /tmp/nativelink-publication-activation-v2-reference, branch
categorical-publication-activation-v2-reference, based at
b79dfeae062319dcd54e74c958441e8bebe64bc1.

No new activation or publication candidate implementation was read. Normative
inputs were the user plan, previously frozen v1 oracle authored independently,
and public M4 terminal/view/effect/history DTO declarations plus the root agent's
reported State semantics. The bounded public State-field search also exposed
snapshot byte-writer plumbing; the public ResponsePayload search also exposed its
deserializer header. Neither exposed a transition algorithm or accepted-history
implementation. No algorithms were copied from production. V1's independently
authored effect/protection state machine and fifteen tests were copied into these
new files and adapted to the successor types. V1 stayed byte-identical.

The first Cargo invocation accidentally used a new local target directory. It
was stopped before finishing and that generated directory was removed. All
reported Cargo test and mutation results use the shared warm target
/tmp/nativelink-history-differential-target with at most eight jobs. The initial
archived Cargo log has twenty-six tests. A final integrity scenario brought the
frozen suite to twenty-seven; the compiled baseline/restored mutation run and
standalone Bazel log contain all twenty-seven.

Bazel ran the new standalone target in the existing warm workspace
/tmp/nativelink-accepted-history-reference at older base
c32897774415d514ad30427f0f331ed36fd84808. New Rust sources were copied exactly and
are hash-checked against the isolated v2 source after restoration. Dependencies
are only blake3, sha2, serde, and serde_json. No scheduler implementation enters
this target. Earlier frozen accepted-history, activation-v1, and head reference
files were hashed before the copy and rechecked unchanged afterward. Cargo and
Bazel compiler campaigns ran sequentially. No production files, factory selection,
runtime configuration, or cutover state were modified.

The initial strict Clippy passes found routine local formatting/doc lint errors;
the final strict Clippy log records their correction. Initial Vale spelling
errors were corrected in documentation without changing model expectations.
Mutants compile individually before their unchanged assertions run; compilation
rejections are not semantic kills. Baseline and restored sources are recorded.

The frozen head response-projection clarification is archived separately here as
an audit: it narrows the older response-byte claim before any actual REAPI
source/cached-response differential. The audit does not modify that reference.
This v2 reference preserves existing captured terminal bytes and does not add a
new response projection implementation.
