"""Independent size checks for reviewed fixed fields and serialization headers.

This does not import the candidate calculator or any transition reference.
The complete bound also relies on the source-audited cardinality/payload ledger.
"""
import itertools
import json

U64 = 2**64 - 1


def encoded(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode()


def nested(value):
    return len(encoded(list(encoded(value))))


resources = {"cpu_millis": U64, "memory_bytes": U64, "slots": U64}
retry = {"Retry": {"target": resources}}
reasons = ["AttemptBudgetExhausted", "MissingGrowthEvidence", "NoLargerEligibleWorker"]
branches = [retry] + [{"Terminal": {"reason": reason}} for reason in reasons]
rows = []
for peak, quiescent, disposition in itertools.product([None, U64], [False, True], [None] + branches):
    report = {"id": U64, "epoch": U64, "charged": resources,
              "peak_memory_bytes": peak, "quiescent": quiescent}
    decision = None if disposition is None else {
        "publication": U64, "until": U64, "position": U64, "at": U64,
        "disposition": disposition,
    }
    memory = {"report": report, "decision": decision}
    # Replace the enclosing object's two braces by its one separating comma.
    cost = len(encoded({"memory": memory})) - 1
    rows.append({"peak_present": peak is not None, "quiescent": quiescent,
                 "disposition": disposition, "field_bytes": cost})
assert max(row["field_bytes"] for row in rows) == 518

scheduler = {"version": U64, "state": {
    "epoch": U64, "limits": {key: U64 for key in ["max_executions", "max_operations", "max_workers", "max_effects", "max_payload_bytes"]},
    "now": U64, "next_execution": U64, "operation_watermark": U64,
    "next_attempt": U64, "next_reservation": U64, "next_effect": U64,
    "operations": {}, "executions": {}, "workers": {}, "holds": {},
    "attempts": {}, "reservations": {}, "effects": {},
    "receipt_retirement": None, "accepted_history": None,
}}
retention = {"format": U64, "state": {
    "limits": {key: U64 for key in ["cohorts", "generations", "roots", "closure", "mark_batch", "retire_batch", "writes", "delete_intents", "lease_ticks"]},
    "now": U64, "next_delete": U64, "cohorts": [], "generations": [],
    "roots": [], "writes": [], "deletes": [],
}}
metadata = {
    "commit": U64, "revision": U64, "next_root": U64, "next_write": U64,
    "actions": {}, "real": {"context": {"principal": None, "execution_config": None}, "actions": {}},
    "credits": {}, "clients": [], "update_authorizations": {},
    "terminal": {"enabled_at": U64, "reports": {}, "accepted": {}, "operations": {}},
    "prepared_memory_at": U64, "namespaces": [], "physical": [],
    "stages": {}, "accepted": {}, "heads": {}, "operations": {}, "grants": {},
}
headers = {"scheduler_nested": nested(scheduler), "retention_nested": nested(retention),
           "metadata_raw": len(encoded(metadata)),
           "outer_raw": len(encoded({"version": 5, "scheduler": [], "retention": [], "metadata": {}}))}
assert headers == {"scheduler_nested": 2162, "retention_nested": 1573, "metadata_raw": 498, "outer_raw": 57}
assert all(size <= 4096 for name, size in headers.items() if name != "outer_raw")
assert headers["outer_raw"] < 1024
assert len(encoded("\x00" * 256)) == 1538
for byte in range(256):
    assert len(encoded([byte])) <= 4 + 1
    assert len(encoded([byte] * 4096)) <= 4 * 4096 + 1

# These complete ledger subtotals are audited against the frozen source and
# candidate calculator; this helper independently checks their arithmetic.
ledger = {"scheduler": 1058032, "retention": 214096, "metadata": 753796, "envelope": 1024}
total = sum(ledger.values())
assert total == 2026948 < 2097152
print(json.dumps({"memory_variants": len(rows), "memory_field_max": 518,
                  "eight_stage_delta": 8 * 518, "headers": headers,
                  "label_json_bound": 1538, "ledger": ledger,
                  "total": total, "limit": 2097152, "headroom": 2097152-total,
                  "variant_rows": rows}, indent=2))
