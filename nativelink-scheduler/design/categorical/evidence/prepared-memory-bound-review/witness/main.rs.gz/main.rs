#![allow(dead_code)]
#[path = "coarse.rs"] mod coarse;
#[path = "protocol.rs"] mod protocol;
fn main() {
    let state = coarse::Coarse::new(protocol::Limits {
        cohorts:64, generations:64, roots:112, closure:8, mark_batch:8,
        retire_batch:8, writes:128, delete_intents:192, lease_ticks:100,
    }).unwrap();
    let canonical = state.snapshot().unwrap();
    let mut padded = canonical.clone();
    padded.resize(padded.len()+680_000, b' ');
    let restored = coarse::Coarse::restore(&padded).unwrap();
    assert_eq!(restored.snapshot().unwrap(), canonical);
    let wrapped = serde_json::to_vec(&padded).unwrap();
    assert!(wrapped.len()>2_026_948 && wrapped.len()<2*1024*1024);
    println!("{}", serde_json::json!({
        "child_restore_accepted":true,
        "canonical_child_bytes":canonical.len(),
        "padded_child_bytes":padded.len(),
        "outer_decimal_array_bytes":wrapped.len(),
        "canonical_resnapshot_unchanged":true,
        "scope":"retention child executable witness; outer acceptance follows source review, not executed by this helper"
    }));
}
