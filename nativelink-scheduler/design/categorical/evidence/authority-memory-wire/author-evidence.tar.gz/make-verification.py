import datetime,hashlib,json,pathlib,re,shutil,subprocess
root=pathlib.Path('/tmp/nativelink-authority-memory-wire')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-memory-wire')
manifest=json.loads((evidence/'pre-mutation-source-manifest.json').read_text())
for name,expected in manifest['files'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
checks=json.loads((evidence/'restored-checks.json').read_text())
assert len(checks)==4 and all(c['returncode']==0 for c in checks)
assert 'ALL CHECKS PASSED; SOURCE UNCHANGED' in (evidence/'restored-driver.log').read_text()
mutants=json.loads((evidence/'mutants/results.json').read_text())
assert len(mutants)==6 and all(m['compiled'] and m['detected'] for m in mutants)
oracles={}
for mutant in mutants:
 log=(evidence/'mutants'/mutant['name']/'run.log').read_text()
 lines=log.splitlines()
 start=next(i for i,l in enumerate(lines) if 'panicked at ' in l)
 excerpt='\n'.join(lines[start:start+7])
 expected={
  'ordinary_completion':'ResourceFailed',
  'ignore_exact_vector':'phase: Accepted',
  'validate_after_ack':'phase: Accepted',
  'ignore_committed_bound':'phase: Accepted',
  'retain_oversize_marker':'assertion failed: report.memory_breach.is_none()',
  'accept_protocol_one':'called `Result::unwrap_err()` on an `Ok` value',
 }[mutant['name']]
 assert expected in excerpt,(mutant['name'],excerpt)
 oracles[mutant['name']]={'expected_assertion':expected,'assertion_excerpt':excerpt}
(evidence/'mutation-oracles.json').write_text(json.dumps(oracles,indent=2)+'\n')
suites={}
binaries=evidence/'binaries'; binaries.mkdir(exist_ok=True)
for name in ['restored-worker-tests','service-tests']:
 log=(evidence/(name+'.log')).read_text()
 results=[{'passed':int(p),'failed':int(f),'ignored':int(i),'filtered':int(x)} for p,f,i,x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',log)]
 assert results and all(r['failed']==0 for r in results)
 suites[name]={'log':name+'.log','results':results}
 for path in re.findall(r'Running [^\n]*\((/[^\n()]+)\)',log):
  source=pathlib.Path(path); destination=binaries/source.name
  shutil.copy2(source,destination)
  suites[name].setdefault('binaries',[]).append({'path':str(destination.relative_to(evidence)),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest()})
assert sum(r['passed'] for r in suites['restored-worker-tests']['results'])==115
tls=json.loads((evidence/'restored-tls/manifest.json').read_text())
assert tls['passed'] and tls['test_exit_code']==0 and tls['temporary_certificate_directory_removed'] and not tls['private_keys_archived']
packet={
 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Experimental protocol 2 / mandatory capability 7 explicit memory-breach bridge; full captured response and original reservation validation; existing core retry/journal policy unchanged',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'base_commit':manifest['base_commit'],
 'files':manifest['files'],
 'checks':checks,'suites':suites,'mutants':mutants,'mutant_oracles':oracles,
 'hooks':'hooks-final.log',
 'tls':'restored-tls/manifest.json; default ignored fixture explicitly executed once using existing certificate runner, all four isolated/shared-trust negative-control digest cases pass; no private keys retained',
 'hooks_overlap':'hooks-overlap-source-check.json; hooks overlapped final test compilation but all 17 source hashes and changed-file set remained identical before/after; final driver checked again',
 'proto_generation':'proto-generation.json; canonical built gen_protos_tool and protoc against all 30 .proto inputs, canonical license prefix; only expected generated package changed; root canonical Bazel check separate',
 'reviews':{
  'production':'independent-production-review/review.json and format-addendum.json; source-only independent review by authority_core, under explicit root recipient oversized-result fallback adjudication',
  'fixtures':'independent-fixture-review/review.json and prerequisite-addendum.json; source-only independent review by storage_review; explicitly records missed fixture prerequisites discovered by actual tests',
  'doc_spelling_delta':'After source review, graphless overflow fallback changed to overflow fallback that omits the graph for Vale; no semantic or runtime change',
 },
 'qualification_limits':[
  'Recipient oversized actual result becomes bounded nonzero InternalError with no graph/usage/marker; automatic memory retry/full graph are lost in that existing ordinary size-failure path. Full plan graph/admission gate remains open.',
  'Once a bounded marked response reaches coordinator, captured JSON overflow refuses before acknowledgment, never falls back to ordinary completion.',
  'M4 temporary CAS and accepted history with no garbage collection; no M6 retention claim and no production construction path.',
  'Receipt is an observed first-selected memory policy stop with live sample and completed kill procedure; neither exact peak nor exclusive physical exit cause nor hard memory isolation.',
  'Clock stays at zero in memory RPC qualification; quantized clock/equality work and broader integrated root checks are separately owned.',
 ],
 'preserved_initial_failures':[
  'compile-initial.log: shared Cargo cache reused old proto artifact; forced fresh local proto timestamps, no semantic source change.',
  'compile-proto-refresh.log: fixture imported private EnvironmentSource; corrected to config source.',
  'memory-rpc-initial.log: eight passes, two fixture failures: large declared output list rejected at request admission; upload resource usage not finalized after upload error.',
  'memory-rpc-corrected.log and memory-rpc-corrected2.log: missing exhaustive helper enum branch; corrected in history helper.',
  'memory-rpc-corrected3.log: all ten new RPC tests pass, including child test entry.',
  'worker-regressions-initial.log: 53 unit, 8 ordering, 28 RPC pass; 25 recipient pass and new uncertainty fixture lacked negotiation.',
  'uncertain-recipient-corrected.log: added negotiation exposed inadequate fixture capacity, producing prelaunch decline.',
  'uncertain-recipient-corrected2.log: corrected capacity and asserted initial result absent; actual memory stop reports TerminationUncertain with captured graph and no marker.',
  'clippy-worker-initial.log: eight semicolon formatting findings, corrected without semantic change.',
  'hooks-initial.log: Vale graphless spelling finding, corrected prose.',
 ]
}
(evidence/'verification.json').write_text(json.dumps(packet,indent=2)+'\n')
receipts={str(p.relative_to(evidence)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(evidence.rglob('*')) if p.is_file() and p.name!='receipts.json'}
(evidence/'receipts.json').write_text(json.dumps({'files':receipts},indent=2)+'\n')
for name in ['verification.json','receipts.json']:
 print(name,hashlib.sha256((evidence/name).read_bytes()).hexdigest())
print('Artifacts',len(receipts))
