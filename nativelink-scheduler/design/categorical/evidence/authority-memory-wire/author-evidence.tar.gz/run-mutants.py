import difflib, hashlib, json, os, pathlib, subprocess
root=pathlib.Path('/tmp/nativelink-authority-memory-wire')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-memory-wire')
service=root/'nativelink-service/src/authority_server.rs'
worker=root/'nativelink-worker/src/authority_worker.rs'
bases={service:service.read_text(),worker:worker.read_text()}
validation='''        let memory_failure = if report.memory_breach.is_some() {
            let Some(candidate) = memory_failure_payload(&self.state, &attempt, &report) else {
                return Ok(());
            };
            Some(candidate)
        } else {
            None
        };
'''
route='''                self.commit(Event::MemoryFailure {
                    attempt: attempt.id,
                    worker,
                    incarnation,
                    charged,
                    // Process-group RSS is a policy sample, not an exact peak.
                    // The positive original charge drives the existing growth policy.
                    peak_memory_bytes: None,
                    quiescent: true,
                    result,
                })'''
ordinary='''                self.commit(Event::Complete {
                    attempt: attempt.id, worker, incarnation, result,
                })'''

def replace(base, old, new):
 assert base.count(old)==1,(old,base.count(old))
 return base.replace(old,new)

late=replace(bases[service],validation,'')
late=replace(late,'        let phase = match AuthorityAttemptPhase::try_from(report.phase).ok() {',validation+'        let phase = match AuthorityAttemptPhase::try_from(report.phase).ok() {')
cases=[
 ('ordinary_completion',service,replace(bases[service],route,ordinary),'memory_rpc_capacity_shrink_preserves_original_failure_without_growth'),
 ('ignore_exact_vector',service,replace(bases[service],'        || charged != reservation.charged','        || false'),'memory_rpc_malformed_evidence_cannot_acknowledge_release_decline_or_grow'),
 ('validate_after_ack',service,late,'memory_rpc_malformed_evidence_cannot_acknowledge_release_decline_or_grow'),
 ('ignore_committed_bound',service,replace(bases[service],'        || serde_json::to_vec(&captured).ok()?.len() > FRAME_BYTES','        || false'),'memory_rpc_malformed_evidence_cannot_acknowledge_release_decline_or_grow'),
 ('retain_oversize_marker',worker,replace(bases[worker],'            entry.report.resource_usage = None;\n            entry.report.memory_breach = None;','            entry.report.resource_usage = None;'),'memory_rpc_oversize_recipient_fallback_clears_explicit_memory_evidence'),
 ('accept_protocol_one',service,replace(bases[service],'        || registration.protocol_version != VERSION','        || (registration.protocol_version != VERSION && registration.protocol_version != 1)'),'memory_rpc_v2_and_capability_are_required_before_register_or_inventory'),
]
folder=evidence/'mutants'; folder.mkdir(exist_ok=True)
for path,base in bases.items(): (folder/(path.stem+'-baseline.rs')).write_text(base)
env=dict(os.environ,CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target',CARGO_INCREMENTAL='0')
results=[]
try:
 for name,path,changed,test in cases:
  for other,base in bases.items(): other.write_text(base)
  path.write_text(changed)
  target=folder/name; target.mkdir(exist_ok=True)
  (target/'source.rs').write_text(changed)
  (target/'mutation.patch').write_text(''.join(difflib.unified_diff(bases[path].splitlines(True),changed.splitlines(True),fromfile='baseline',tofile=name)))
  command=['cargo','test','--locked','--offline','--profile','smol','-p','nativelink-worker','-j4','--test','authority_rpc_test',test,'--','--nocapture','--test-threads=1']
  with (target/'run.log').open('w') as output:
   run=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
  log=(target/'run.log').read_text()
  compiled='Finished `smol` profile' in log and 'Running tests/authority_rpc_test.rs' in log
  detected=compiled and run.returncode!=0 and 'test result: FAILED. 0 passed; 1 failed;' in log
  record=dict(name=name,path=str(path.relative_to(root)),command=command,returncode=run.returncode,compiled=compiled,detected=detected,source_sha256=hashlib.sha256(changed.encode()).hexdigest())
  results.append(record); (folder/'results.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(record),flush=True)
  if not detected: raise RuntimeError('Unqualified mutant failure: '+name)
finally:
 for path,base in bases.items():
  path.write_text(base)
  print('RESTORED '+str(path)+' '+hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
