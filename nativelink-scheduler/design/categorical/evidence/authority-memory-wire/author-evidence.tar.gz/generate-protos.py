from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess
root=Path('/tmp/nativelink-authority-memory-wire')
evidence=Path('/tmp/nativelink-categorical-evidence/authority-memory-wire')
output=evidence/'codegen'
build=(root/'nativelink-proto/BUILD.bazel').read_text()
block=build.split('name = "gen_rs_protos",',1)[1].split('outs = ',1)[0]
inputs=['nativelink-proto/'+p for p in re.findall(r'"([^"\n]+\.proto)"',block)]
tool=Path('/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/bazel-bin/nativelink-proto/gen_protos_tool').resolve()
protoc=Path('/home/b7r6/.cache/bazel/_bazel_b7r6/d671d043dec5ec8e2f7ac544fd01f658/external/toolchains_protoc++protoc+toolchains_protoc_hub.linux_x86_64/bin/protoc')
command=[str(tool),*inputs,'-o',str(output)]
with (evidence/'proto-generation.log').open('w') as log:
 subprocess.run(command,cwd=root,env=dict(os.environ,PROTOC=str(protoc)),stdout=log,stderr=subprocess.STDOUT,check=True)
spec=importlib.util.spec_from_file_location('update_protos',root/'nativelink-proto/update_protos.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
changed=[]
for source in output.glob('*.rs'):
 target=root/'nativelink-proto/genproto'/(source.stem+'.pb.rs')
 expected=module._RUST_LICENSE.encode()+source.read_bytes()
 if target.read_bytes()!=expected:
  target.write_bytes(expected);changed.append(str(target.relative_to(root)))
record={'command':command,'generator_sha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'protoc_sha256':hashlib.sha256(protoc.read_bytes()).hexdigest(),'changed':changed,'inputs':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}}
(evidence/'proto-generation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
