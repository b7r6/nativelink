import hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/tmp/nativelink-authority-memory-wire')
evidence=pathlib.Path('/tmp/nativelink-categorical-evidence/authority-memory-wire')
manifest=json.loads((evidence/'pre-mutation-source-manifest.json').read_text())
for name,expected in manifest['files'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
common=['--locked','--offline','--profile','smol','-j4']
commands=[
 ('restored-worker-tests', ['cargo','test',*common,'-p','nativelink-worker','--lib','--test','authority_worker_test','--test','authority_rpc_test','--test','authority_publication_ordering_test','--','--test-threads=1']),
 ('service-tests',['cargo','test',*common,'-p','nativelink-service','--lib','--test','authority_listener_test','--','--test-threads=1']),
 ('clippy-worker-restored',['cargo','clippy',*common,'-p','nativelink-worker','--lib','--test','authority_worker_test','--test','authority_rpc_test','--test','authority_publication_ordering_test','--','-D','warnings']),
 ('clippy-service-final',['cargo','clippy',*common,'-p','nativelink-service','--lib','--test','authority_listener_test','--','-D','warnings']),
]
env=dict(os.environ,CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target',CARGO_INCREMENTAL='0')
results=[]
for name,command in commands:
 with (evidence/(name+'.log')).open('w') as output:
  run=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'returncode':run.returncode})
 (evidence/'restored-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if run.returncode: raise RuntimeError(name+' failed')
for name,expected in manifest['files'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
print('ALL CHECKS PASSED; SOURCE UNCHANGED',flush=True)
