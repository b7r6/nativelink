#!/usr/bin/env python3
"""Compile each algorithm fault before testing; restore isolated worktree always."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('/tmp/nativelink-azure-blake3-retention')
OUT = Path('/tmp/nativelink-categorical-evidence/azure-blake3-retention')
SOURCE = ROOT / 'nativelink-scheduler/tests/retention/typed_bridge.rs'
ENV = dict(os.environ, CARGO_BUILD_JOBS='8', CARGO_TARGET_DIR='/tmp/nativelink-categorical-physical/target', NATIVELINK_AZURITE_TEST_RUNNER_DIR='/tmp/nativelink-categorical-azurite/nativelink-store/tests/azurite_runner')
BASE = ['cargo', 'test', '--locked', '--offline', '-j', '8']
AZURE = BASE + ['-p', 'nativelink-store', '--test', 'physical_azure_test']
FILESYSTEM = BASE + ['-p', 'nativelink-scheduler', '--test', 'typed_physical_retention_test']
PROVIDER_TEST = 'local_azurite_blake3_retention_contract'
RESTORE_TEST = 'malformed_checkpoint_is_rejected_without_normalizing_or_truncating_physical_identity'
MUTANTS = [
 ('force_sha256_upload', 'ObjectId::for_bytes(algorithm, bytes)', 'ObjectId::for_bytes(Algorithm::Sha256, bytes)', AZURE, PROVIDER_TEST, ['--ignored', '--exact', '--nocapture'], 'every uploaded descriptor preserves the requested digest function'),
 ('ignore_manifest_algorithm', '.find(|row| row.descriptor == object.into())', '.find(|row| row.descriptor.hash == object.hash && row.descriptor.size == object.size)', AZURE, PROVIDER_TEST, ['--ignored', '--exact', '--nocapture'], 'identical hash bytes under another algorithm are not a manifest member'),
 ('normalize_unknown_algorithm', '_ => return Err(Error::CorruptCheckpoint),', '_ => Algorithm::Sha256,', FILESYSTEM, RESTORE_TEST, ['--exact', '--nocapture'], 'unsupported descriptor algorithm must fail closed'),
]
original = SOURCE.read_text()
for name, before, *_ in MUTANTS:
    assert original.count(before) == 1, name
report = {'base_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'scope': 'Three compiled algorithm faults in the test-only shared bridge; actual local Azurite for upload/read faults, filesystem checkpoint fixture for malformed restoration', 'original_bridge_sha256': hashlib.sha256(original.encode()).hexdigest(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'commands': [], 'mutants': []}
def save():
    (OUT / 'mutation-results.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name, argv):
    log=OUT/(name+'.log')
    started=time.monotonic()
    try:
        with log.open('wb') as stream:
            result=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT,timeout=600,check=False)
        code=result.returncode
    except subprocess.TimeoutExpired:
        code='timeout'
    text=log.read_text(errors='replace')
    report['commands'].append({'name':name,'argv':argv,'cwd':str(ROOT),'status':code,'seconds':time.monotonic()-started,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    save()
    return code,text
def baseline(stage):
    code,text=run(stage+'-compile',AZURE+['--no-run'])
    assert code==0, 'provider baseline must compile'
    code,text=run(stage+'-provider',AZURE+[PROVIDER_TEST,'--','--ignored','--exact','--nocapture'])
    assert code==0 and f'test {PROVIDER_TEST} ... ok' in text, 'provider baseline must pass'
    code,text=run(stage+'-restore',FILESYSTEM+[RESTORE_TEST,'--','--exact'])
    assert code==0 and f'test {RESTORE_TEST} ... ok' in text, 'restoration baseline must pass'
try:
    baseline('mutation-baseline')
    for name,before,after,command,test,args,marker in MUTANTS:
        mutated=original.replace(before,after,1)
        SOURCE.write_text(mutated)
        (OUT/(name+'-source.rs')).write_text(mutated)
        code,_=run(name+'-compile',command+['--no-run'])
        row={'name':name,'before':before,'after':after,'test':test,'marker':marker,'mutant_sha256':hashlib.sha256(mutated.encode()).hexdigest()}
        if code!=0:
            row['classification']='compile_error' if code==101 else 'process_error'
        else:
            code,text=run(name+'-test',command+[test,'--',*args])
            proper_panic = re.search(rf"thread '{re.escape(test)}'.*panicked at",text) and marker in text and f'test {test} ... FAILED' in text and 'test result: FAILED. 0 passed; 1 failed;' in text
            row['classification']='semantic_kill' if code==101 and proper_panic else ('survived' if code==0 else 'process_or_unexpected_test_error')
        report['mutants'].append(row)
        save()
        print(json.dumps({'name':name,'classification':row['classification']}),flush=True)
finally:
    SOURCE.write_text(original)
    baseline('mutation-restored')
    report['restored_bridge_sha256']=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    report['all_killed']=len(report['mutants'])==len(MUTANTS) and all(row['classification']=='semantic_kill' for row in report['mutants']) and report['restored_bridge_sha256']==report['original_bridge_sha256']
    save()
print(json.dumps({'all_killed':report['all_killed']}),flush=True)
raise SystemExit(0 if report['all_killed'] else 1)
