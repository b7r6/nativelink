#!/usr/bin/env python3
"""Compile each candidate mutation with unchanged State, fixtures and frozen oracle."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/nativelink-activation-inventory')
evidence = Path('/tmp/nativelink-activation-inventory-operation-binding-evidence')
source = root / 'nativelink-scheduler/tests/activation_inventory/adapter.rs'
original = source.read_text()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/nativelink-history-differential-target')
command = ['cargo', 'test', '--locked', '--profile', 'smol', '-j', '8', '-p',
           'nativelink-scheduler', '--test', 'activation_inventory_test', '--no-run']
binary = Path(env['CARGO_TARGET_DIR']) / 'smol/deps/activation_inventory_test-8ba5d1f22f10474e'
mutants = [('inherit-representative-principal', [('context.action(operation.execution, original)? != action', 'context.action(operation.execution, &execution.request)? != action')]), ('capture-first-request-for-every-operation', [('.operation_request(operation.id)', '.operation_request(OperationId(1))')]), ('require-identical-full-joined-request', [('if context.action(operation.execution, original)? != action {', 'if context.action(operation.execution, original)? != action || original != &execution.request {')])]

def run(name, changed):
    folder = evidence / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    source.write_text(changed)
    (folder / 'adapter.rs').write_text(changed)
    with (folder / 'compile.log').open('wb') as log:
        compiled = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = {'name': name, 'source_sha256': hashlib.sha256(changed.encode()).hexdigest(),
              'compile_command': command, 'compile_status': compiled.returncode}
    if compiled.returncode:
        result['classification'] = 'COMPILE_REJECTED_NOT_A_KILL'
    else:
        result['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        with (folder / 'test.log').open('wb') as log:
            tested = subprocess.run([str(binary)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        result['test_status'] = tested.returncode
        result['classification'] = 'PASS' if not tested.returncode else 'COMPILED_ASSERTION_KILL'
    (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

results = []
try:
    baseline = run('baseline', original)
    assert baseline['classification'] == 'PASS', baseline
    for name, replacements in mutants:
        changed = original
        for old, new in replacements:
            assert changed.count(old) == 1, (name, old, changed.count(old))
            changed = changed.replace(old, new)
        results.append(run(name, changed))
finally:
    source.write_text(original)
    restored = run('restored', original)
    (evidence / 'mutation-results.json').write_text(json.dumps({
        'baseline': baseline, 'mutants': results, 'restored': restored,
        'source_restored_exactly': source.read_text() == original,
    }, indent=2) + '\n')
assert restored['classification'] == 'PASS', restored
assert all(result['classification'] == 'COMPILED_ASSERTION_KILL' for result in results), results
