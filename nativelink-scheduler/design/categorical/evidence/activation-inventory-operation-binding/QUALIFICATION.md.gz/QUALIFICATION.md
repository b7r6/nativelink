# Original operation request binding correction

This additive correction follows an independent source review of the real-request
publication extension. That review found two relational restore gaps: a joined
operation's private original request was not checked against the outer trusted
context, and a real snapshot with action label equal to its original instance
could be downgraded to synthetic mode while retaining captured request payloads.
The publication author reproduced and corrected both separately. This package
covers the corresponding retained-inventory correction only.

The frozen inventory adapter checked each terminal operation through its
representative execution request. Actual State can join requests with different
captured principals when no invocation scope is present; the external authority
must enforce its own principal context. A new regression drives that valid State
through two submissions, worker acceptance, and completion. Original snapshot
bytes preserve both callers, but the old projection incorrectly assigned the
foreign operation the execution's principal. The compiled failure and exact old
adapter plus new test fixture are preserved here. The earlier 16-case archive
remains unchanged and is qualified by this correction.

SourceInventory now captures each original operation request through the new
read-only State query. Snapshot correspondence validates this map. Projection
checks each terminal operation's own captured principal and qualified action
against the explicit execution authority and representative action. Unknown
older payloads still require the explicit external binding; no principal is
invented. Capture remains lossless when projection refuses.

A positive regression varies priority, original queue time, and lookup policy on
joined requests while keeping their actual qualified action the same. These
requests remain valid and both originals are retained. A source-map deletion also
fails the snapshot correspondence check. This does not require full Request
identity for a valid join or modify the scheduler's compatibility predicate.

Validation: 18 Cargo tests pass; strict Clippy, pinned rustfmt, typos, Vale,
reverse-patch and whitespace checks pass. Three candidate mutations compile and
fail assertions: use the representative principal for operation projection, copy
the first original request into every source row, and incorrectly require full
request equality for joins. Baseline and exact restored candidate pass all 18
cases. Integrated Bazel qualification is recorded separately when available.

The patch changes three inventory files and depends on the separate read-only
State::operation_request accessor. It does not include that production API diff.
The frozen v2 oracle and bounded admission helper remain unchanged. Physical
preparation, activation facts, unknown historical send exposure, production
migration, and deployment scope retain their prior boundaries.
