from pathlib import Path
import subprocess,hashlib,json,shutil
root=Path.cwd();out=Path(__file__).parent
names=json.loads((out/'fixed-source-names.json').read_text())
def sources():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}
before=sources();(out/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
(roothead:=out/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
cmd=['bazel', 'test', '--jobs=8', '--local_test_jobs=2', '--test_env=RUST_TEST_THREADS=4', '--test_output=errors', '--test_arg=hash_context::', '//tools/canonical-store:canonical_store_test', '//:nativelink']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'integration.log').open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=sources();(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
for label in cmd:
 if label.startswith('//') and label!='//:nativelink':
  path=label[2:].replace(':','/');dest=out/'testlogs'/path/'test.log';dest.parent.mkdir(parents=True,exist_ok=True);source=root/'bazel-testlogs'/path/'test.log'
  if source.exists():shutil.copyfile(source,dest)
print('integration exit',code,'unchanged inputs',len(before));raise SystemExit(code)
