import hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/tmp/nativelink-authority-storage-hash-context');evidence=pathlib.Path(__file__).resolve().parent
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((evidence/'final-source-manifest.json').read_text())
for path,digest in manifest['files'].items():assert sha(root/path)==digest,path
commands=[
 ('restored-canonical',['cargo','test','--manifest-path','tools/canonical-store/Cargo.toml','--locked','--offline','--profile','smol','-j8'],['nativelink_canonical_store-']),
 ('restored-service',['cargo','test','-p','nativelink-service','--lib','--test','authority_listener_test','--locked','--offline','--profile','smol','-j8'],['nativelink_service-','authority_listener_test-']),
]
results=[]
for name,command,prefixes in commands:
 with (evidence/(name+'.log')).open('w') as log:
  finished=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'exit_code':finished.returncode,'binaries':{}}
 if finished.returncode==0:
  destination=evidence/'restored-binaries';destination.mkdir(exist_ok=True)
  for prefix in prefixes:
   candidates=[p for p in pathlib.Path(env['CARGO_TARGET_DIR'],'smol/deps').glob(prefix+'*') if p.is_file() and os.access(p,os.X_OK) and p.suffix!='.d']
   binary=max(candidates,key=lambda p:p.stat().st_mtime_ns);shutil.copy2(binary,destination/binary.name);record['binaries'][binary.name]=sha(destination/binary.name)
 results.append(record);(evidence/'final-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert finished.returncode==0,name
for path,digest in manifest['files'].items():assert sha(root/path)==digest,path
print('ALL_FINAL_CHECKS_PASSED',flush=True)
