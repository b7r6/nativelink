import hashlib, json, os, pathlib, shutil, subprocess
root=pathlib.Path('/tmp/nativelink-authority-storage-hash-context')
evidence=pathlib.Path(__file__).resolve().parent
source=root/'nativelink-service/src/authority_server.rs'
baseline=source.read_bytes()
text=baseline.decode()
fixture=root/'tools/canonical-store/src/tests/listener/hash_context.rs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base_cmd=['cargo','test','--manifest-path','tools/canonical-store/Cargo.toml','--locked','--offline','--profile','smol','-j8']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/b7r6/src/tracemachina/nativelink/nativelink-b7r6-0x03/target')
mutants=[
 ('unknown_ambient', '            Ok(digest_function::Value::Unknown | digest_function::Value::Sha256) => {\n                DigestHasherFunc::Sha256\n            }', '            Ok(digest_function::Value::Unknown) => nativelink_util::digest_hasher::digest_hasher_func_from_context(),\n            Ok(digest_function::Value::Sha256) => DigestHasherFunc::Sha256,', 'unknown_request_uses_fixed_sha256_despite_ambient_blake3_context'),
 ('capture_action', '        .with_context(context.clone())\n', '', 'capture_uses_request_algorithm_for_canonical_action_and_command'),
 ('capture_command', '        .with_context(context)\n', '', 'capture_uses_request_algorithm_for_canonical_action_and_command'),
 ('lookup', '            let result = match bounded_blob(sink, digest(action)?)\n                .with_context(action_context(action)?)\n', '            let result = match bounded_blob(sink, digest(action)?)\n', 'lookup_uses_action_algorithm_and_preserves_same_key_namespace_isolation'),
 ('publication', '            sink.update_oneshot(digest(action)?, bytes.into())\n                .with_context(action_context(action)?)\n', '            sink.update_oneshot(digest(action)?, bytes.into())\n', 'accepted_publication_replay_uses_persisted_algorithm_after_restart'),
]
results=[]
try:
 for name, before, after, test in mutants:
  assert text.count(before)==1,(name,text.count(before))
  directory=evidence/'mutants'/name;directory.mkdir(parents=True,exist_ok=True)
  source.write_text(text.replace(before,after))
  shutil.copy2(source,directory/'authority_server.rs')
  command=base_cmd+['tests::listener::hash_context::'+test,'--','--exact']
  with (directory/'run.log').open('w') as log:
   completed=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  output=(directory/'run.log').read_text()
  compiled='Finished `smol` profile' in output and 'running 1 test' in output
  detected=compiled and completed.returncode==101 and 'test result: FAILED. 0 passed; 1 failed;' in output
  record={'name':name,'command':command,'source_sha256':sha(source),'fixture_sha256':sha(fixture),'exit_code':completed.returncode,'compiled':compiled,'detected':detected}
  if compiled:
   candidates=[p for p in pathlib.Path(env['CARGO_TARGET_DIR'],'smol/deps').glob('nativelink_canonical_store-*') if p.is_file() and os.access(p,os.X_OK) and p.suffix!='.d']
   binary=max(candidates,key=lambda p:p.stat().st_mtime_ns)
   shutil.copy2(binary,directory/'test-binary');record['binary_sha256']=sha(directory/'test-binary')
  results.append(record);(evidence/'mutants/results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(record),flush=True)
  source.write_bytes(baseline)
  assert detected,(name,'did not compile and detect; inspect retained log')
finally:
 source.write_bytes(baseline)
 assert hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(baseline).digest()
