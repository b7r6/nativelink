from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time,collections
OUT=Path(__file__).parent
corpus=json.loads((OUT/'corpus.json').read_text());freeze=json.loads((OUT/'freeze.json').read_text())
assert hashlib.sha256((OUT/'corpus.json').read_bytes()).hexdigest()==freeze['corpus_sha256']
BIN=Path('/tmp/nativelink-canonical-config-target/smol/canonical-parser-qualification')
assert hashlib.sha256(BIN.read_bytes()).hexdigest()==freeze['harness_binary_sha256']
def check(task):
 case,mode=task;raw=(OUT/'cases'/case['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==case['sha256']
 start=time.monotonic()
 row={'case':case['file'],'mode':mode}
 try:
  result=subprocess.run(['prlimit','--as=2147483648','--cpu=6','--stack=8388608','--',str(BIN),mode],input=raw,capture_output=True,timeout=10)
 except subprocess.TimeoutExpired:
  row.update(failures=['timeout'],seconds=time.monotonic()-start);return row
 row.update(exit=result.returncode,seconds=time.monotonic()-start)
 failures=[]
 if result.returncode!=0:failures.append('process_failure');row['stderr']=result.stderr.decode('utf-8','replace')[:2000]
 else:
  try:observed=json.loads(result.stdout)
  except Exception:failures.append('non_json_output');observed={}
  row['observed']=observed
  if observed.get('panic'):failures.append('panic')
  if 'data' in observed:
   data=observed['data'];canonical=observed['canonical']
   if case['expected_data'] is not None and data['ok']!=case['expected_data']:failures.append('data_acceptance')
   if case['expected_canonical'] is not None and canonical['ok']!=case['expected_canonical']:failures.append('canonical_acceptance')
   if 'expected_code' in case and canonical.get('code')!=case['expected_code']:failures.append('canonical_error_code')
   if 'expected_scalar' in case and data.get('scalar')!=case['expected_scalar']:failures.append('scalar_value')
   if 'expected_node_id' in case and canonical.get('node_id')!=case['expected_node_id']:failures.append('identity_precision')
   if data['ok'] and data['max_depth']>32:failures.append('depth_escape')
   if data['ok'] and data['nodes']>16384:failures.append('item_escape')
   if canonical['ok'] and any(key in data.get('top_keys',[]) for key in ['stores','schedulers']):failures.append('accepted_legacy_key')
   # Keep results bounded; successful scalar objects/arrays are unnecessary in the receipt.
   if isinstance(data.get('scalar'),(dict,list)) or isinstance(data.get('scalar'),str) and len(data['scalar'])>200:
    data['scalar_summary_sha256']=hashlib.sha256(json.dumps(data.pop('scalar'),sort_keys=True).encode()).hexdigest()
 row['failures']=failures
 return row
started=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(check,[(case,mode) for case in corpus for mode in ['main','thread']]))
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
failures=[r for r in results if r['failures']]
summary={'cases':len(corpus),'executions':len(results),'seconds':time.monotonic()-started,'failure_executions':len(failures),'failure_kinds':dict(collections.Counter(f for r in failures for f in r['failures'])),'resource_caps':{'address_space_bytes':2147483648,'main_stack_bytes':8388608,'thread_stack_bytes':2097152,'cpu_seconds_per_process':6,'wall_timeout_seconds':10},'failing_cases':[{'case':r['case'],'mode':r['mode'],'failures':r['failures'],'observed':r.get('observed'),'stderr':r.get('stderr')} for r in failures]}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
