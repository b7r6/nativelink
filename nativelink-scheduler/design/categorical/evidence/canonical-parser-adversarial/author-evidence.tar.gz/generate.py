from pathlib import Path
import json,hashlib,random
OUT=Path(__file__).parent
CASES=OUT/'cases';CASES.mkdir(exist_ok=True)
ROOT=Path('/tmp/nativelink-canonical-config')
manifest=json.loads((ROOT/'tools/canonical-config/fixtures/canonical.json').read_text())
base=json.dumps(manifest,separators=(',',':'))
rows=[]
def add(label,body,data=None,canonical=False,code=None,scalar=None,node_id=None):
    raw=body.encode('utf-8') if isinstance(body,str) else body
    name=f'{len(rows):05d}-{label}.json5'
    (CASES/name).write_bytes(raw)
    row={'file':name,'label':label,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'expected_data':data,'expected_canonical':canonical}
    if code:row['expected_code']=code
    if scalar is not None:row['expected_scalar']=scalar
    if node_id is not None:row['expected_node_id']=node_id
    rows.append(row)

def canonical_field(value):
    obj=manifest.copy();obj['authority']=manifest['authority'].copy();obj['authority']['node_id']=value
    return json.dumps(obj,separators=(',',':'))

add('canonical-control',base,True,True,node_id=1)
for keyword in ['stores','schedulers']:
    spellings=[keyword,json.dumps(keyword),"'"+keyword+"'",'\\u%04x'%ord(keyword[0])+keyword[1:], '"'+''.join('\\u%04x'%ord(c) for c in keyword)+'"',"'\\x%02x"%ord(keyword[0])+keyword[1:]+"'"]
    for terminator in ['\n','\r','\r\n','\u2028','\u2029']:
        spellings.append("'"+keyword[:2]+'\\'+terminator+keyword[2:]+"'")
    for spelling in spellings:
        for value in ['null','[]','{}','false','0','"literal"']:
            for position in ['first','last']:
                body=('{'+spelling+':'+value+','+base[1:]) if position=='first' else (base[:-1]+','+spelling+':'+value+'}')
                add('legacy-'+keyword+'-'+position,body,True,False,'legacy_key')
    for left in spellings:
        for right in spellings:
            add('duplicate-'+keyword,'{'+left+':null,'+right+':[]}',False,False,'invalid_json5')
    add('nested-'+keyword,'{a:{'+keyword+':null}}',True,False,'canonical_schema')

for left,right in [('x','"\\u0078"'),("'x'","'\\x78'"),('é','"\\u00e9"'),('a','"a\\\n"')]:
    for depth in [0,1,15,30]:
        body='{'+left+':1,'+right+':2}'
        body='{a:'*depth+body+'}'*depth
        add('nested-duplicate',body,False,False,'invalid_json5')

terminators=['\n','\r','\r\n','\u2028','\u2029']
comments=['', '/* [ { \' \\" // */', '// [ { \' \\"'+ '\n', '// [ { \' \\"'+ '\r', '// [ { \' \\"'+ '\r\n', '// [ { \' \\"'+ '\u2028', '// [ { \' \\"'+ '\u2029']
for n in [0,1,15,30,31,32,33,128,4096,100000]:
    for comment in comments:
        add('array-depth', '{a:'+comment+'['*n+'0'+']'*n+'}', n<32, False, None if n<32 else 'input_bound')
    body='{a:'*n+'0'+'}'*n
    if n:
        add('object-depth',body,n<=32,False,None if n<=32 else 'input_bound')
for term in terminators:
    add('continuation-string-depth','{a:"one\\'+term+'two'+'['*100+'"}',True,False)
    add('line-comment-eof','{a:1}//'+'['*100+term,True,False)
    add('terminator-ending-comment-hides-no-depth','{a://hidden'+term+'['*32+'0'+']'*32+'}',False,False,'input_bound')
for whitespace in ['\t','\v','\f',' ','\u00a0','\ufeff','\u1680','\u2000','\u202f','\u3000']:
    add('json5-whitespace',whitespace+'{'+whitespace+'a'+whitespace+':'+whitespace+'1'+whitespace+'}'+whitespace,True,False,scalar=1)

for malformed in ['{a:]', '{a:[}', '{a:1}}', ']}'+'{a:'*40+'1'+'}'*40, '{a:/*unterminated'+'['*100, '{a:"unterminated'+'['*100, "{a:'unescaped\nnewline'}", '{a:"\\"}', '{a:"\\uD800"}', '{a:"\\uDC00"}', '{a:"\\uD800\\uDC00"}', '{a:"\\xG0"}', '{a:0,}', '{}{}', '{a:01}', '{a:0x}', '{a:1e}', '{"sto"/*comment*/"res":[]}']:
    # The trailing-comma case is a positive JSON5 control.
    add('malformed-or-grammar-control',malformed,malformed=='{a:0,}',False)

numbers=[('0',True,0),('-0',True,0),('+0',True,0),('1',True,1),('-1',True,-1),('9007199254740991',True,9007199254740991),('9007199254740992',True,9007199254740992),('9007199254740993',True,9007199254740993),('9223372036854775807',True,9223372036854775807),('-9223372036854775808',True,-9223372036854775808),('9223372036854775808',False,None),('-9223372036854775809',False,None),('18446744073709551615',False,None),('18446744073709551616',False,None),('0xffffffff',True,4294967295),('0XFFFFFFFF',True,4294967295),('0x100000000',False,None),('-0x1',False,None),('+0x1',False,None),('1.0',True,1.0),('1e0',True,1.0),('.1',True,.1),('1.',True,1.0),('1e308',True,1e308),('1e309',False,None),('-1e309',False,None),('1e-999',True,0.0),('NaN',False,None),('-NaN',False,None),('+NaN',False,None),('Infinity',False,None),('-Infinity',False,None),('+Infinity',False,None)]
for literal,accepted,scalar in numbers:
    add('number-data','{a:'+literal+'}',accepted,False,scalar=scalar)
    node_ok=accepted and isinstance(scalar,int) and scalar>0
    replacement=base.replace('"node_id":1','"node_id":'+literal)
    add('number-identity',replacement,accepted,node_ok,node_id=scalar if node_ok else None)

for size in [0,1,4095,4096,4097,65536,1048568]:
    add('ascii-string-bound','{a:"'+'x'*size+'"}',size<=4096,False)
for char in ['é','界','😀']:
    width=len(char.encode())
    for count in [4096//width,4096//width+1]:
        add('utf8-string-bound','{a:"'+char*count+'"}',count*width<=4096,False)
for count in [4095,4096,4097]:
    add('escaped-string-bound','{a:"'+'\\u0061'*count+'"}',count<=4096,False)
    add('key-string-bound','{"'+'x'*count+'":0}',count<=4096,False)
for count in [16381,16382,16383,32768,200000,524284]:
    add('wide-array-bound','{a:['+','.join('0' for _ in range(count))+']}',count+2<=16384,False)
for total in [1048575,1048576,1048577]:
    add('byte-bound-block-comment','{}/*'+'x'*(total-6)+'*/',total<=1048576,False,None if total<=1048576 else 'input_bound')
    add('byte-bound-line-comment','{}//'+'x'*(total-4),total<=1048576,False,None if total<=1048576 else 'input_bound')
for size in [4096,65536,1048572]:
    add('hostile-number-length','{a:'+'9'*size+'}',False,False)
for encoded in [b'\xff',b'{a:"\xc0\xaf"}',b'{a:"\xed\xa0\x80"}',b'{a:"\xf4\x90\x80\x80"}',b'{a:"\xe2\x80"}',b'{a:"\x80"}']:
    add('invalid-utf8',encoded,False,False,'invalid_utf8')

rng=random.Random(0x43464731)
alphabet=['{','}','[',']','/', '*','"',"'",'\\','\n','\r','\u2028','\u2029',':',',','0','e','u',' ','\x00']
seeds=[base,'{a:[1,{b:"literal"},3]}','{a:/*comment*/"escaped\\\"text"}','{stores:null}','{schedulers:[]}',"{a:'continued\\\nstring'}"]
for index in range(1500):
    text=rng.choice(seeds)
    for _ in range(rng.randrange(1,5)):
        at=rng.randrange(len(text)+1); kind=rng.randrange(3)
        if kind==0:text=text[:at]+rng.choice(alphabet)+text[at:]
        elif kind==1:text=text[:at]+text[at+1:]
        else:text=text[:at]+rng.choice(alphabet)+text[at+1:]
    add('deterministic-mutation',text,None,None)

(OUT/'corpus.json').write_text(json.dumps(rows,indent=2)+'\n')
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'tools/canonical-config/src').glob('*.rs') if p.name in ['lib.rs','parse.rs','schema.rs']}
freeze={'seed':'0x43464731','cases':len(rows),'corpus_sha256':hashlib.sha256((OUT/'corpus.json').read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'target_source_sha256':sources,'harness_source_sha256':hashlib.sha256(Path('/tmp/nativelink-canonical-parser-qualification/src/main.rs').read_bytes()).hexdigest(),'harness_binary_sha256':hashlib.sha256(Path('/tmp/nativelink-canonical-config-target/smol/canonical-parser-qualification').read_bytes()).hexdigest()}
(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(freeze,indent=2))
