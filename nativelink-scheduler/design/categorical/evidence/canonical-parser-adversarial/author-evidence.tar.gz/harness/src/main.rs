use std::io::Read;
use nativelink_canonical_config::{parse_canonical, parse_data};
use serde_json::{Value, json};

fn inspect(input: Vec<u8>) -> Value {
    let data = match parse_data(&input) {
        Ok(value) => {
            let mut stack = vec![(&value, 1_usize)];
            let mut max_depth = 0;
            let mut nodes = 0;
            while let Some((value, depth)) = stack.pop() {
                nodes += 1;
                match value {
                    Value::Array(values) => { max_depth = max_depth.max(depth); stack.extend(values.iter().map(|v| (v, depth+1))); }
                    Value::Object(values) => { max_depth = max_depth.max(depth); stack.extend(values.values().map(|v| (v, depth+1))); }
                    _ => {}
                }
            }
            json!({"ok":true,"top_keys":value.as_object().unwrap().keys().collect::<Vec<_>>(),"max_depth":max_depth,"nodes":nodes,"scalar":value.get("a")})
        }
        Err(error) => json!({"ok":false,"code":error.code}),
    };
    let canonical = match parse_canonical(&input) {
        Ok(manifest) => json!({"ok":true,"node_id":manifest.authority.node_id}),
        Err(error) => json!({"ok":false,"code":error.code}),
    };
    json!({"data":data,"canonical":canonical})
}

fn main() {
    let mut input = Vec::new();
    std::io::stdin().read_to_end(&mut input).unwrap();
    let result = if std::env::args().nth(1).as_deref()==Some("thread") {
        std::thread::Builder::new().stack_size(2*1024*1024).spawn(move|| inspect(input)).unwrap().join()
    } else {
        std::panic::catch_unwind(|| inspect(input))
    };
    println!("{}", result.unwrap_or_else(|_|json!({"panic":true})));
}
